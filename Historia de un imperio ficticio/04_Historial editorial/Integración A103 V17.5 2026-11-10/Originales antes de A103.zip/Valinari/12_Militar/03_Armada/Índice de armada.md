---
tipo: índice militar
canon: V16
estado: vigente
actualizado: 2026-11-10
---
# Índice de Armada

- [[12_Militar/03_Armada/AM1 Armada 1875-2026|AM1 — Armada valinari, 1875–2026]]
- [[12_Militar/03_Armada/AM1 Armada 1973 — reconstrucción y turbinas|Armada Valinari en 1973 — reconstrucción AM1]]
- [[12_Militar/03_Armada/Armada 1500-1600|Armada valinari, 1500–1600]]
- [[12_Militar/03_Armada/Armada antigua 500 aC-500 dC|Armada antigua, 500 a. C.–500 d. C.]]
- [[12_Militar/03_Armada/Armada|Armada]]
- [[12_Militar/03_Armada/Clases navales 1980|Clases navales de referencia 1980]]
- [[12_Militar/03_Armada/Clases navales 2026|Clases navales de referencia 2026]]
- [[12_Militar/03_Armada/Comparación naval Valinor y Royal Navy (1907)|Comparación naval Valinor y Royal Navy en 1907]]
- [[12_Militar/03_Armada/Cultura naval y continuidad de rutas|Cultura naval y continuidad de rutas]]
- [[12_Militar/03_Armada/Desarrollo naval 1882-1945|Desarrollo naval 1882–1945]]
- [[12_Militar/03_Armada/Destructores Gil-galad — evolución de la familia|Destructores Gil-galad]]
- [[12_Militar/03_Armada/Evolución Naval 1850-2026|Evolución Naval 1850–2026]]
- [[12_Militar/03_Armada/Reconstrucciones navales 1945 y 1960|Reconstrucciones navales de 1945 y 1960]]
- [[12_Militar/03_Armada/Registro naval 2026 A092|Registro administrativo naval 2026 A092]]
- [[12_Militar/03_Armada/Serie Círdan y transición a Voronwë|Serie Círdan y transición a Voronwë]]
- [[12_Militar/03_Armada/Serie naval anual 1875 2026 A092|Serie naval anual 1875 a 2026 A092]]

## Catálogos históricos

- [[12_Militar/03_Armada/Armada 1875/Índice de la Armada de 1875|Armada de 1875]]

[[12_Militar/Índice Militar|Volver al índice militar]]

## Desarrollo naval A093

- [[00_Canon/Integraciones V16/Acumulativa A093 V16.5|Resoluciones integradas en V16.5]]
- [[12_Militar/03_Armada/Corbetas fragatas y persistencia naval]]
- [[12_Militar/03_Armada/Escenario de composición naval A093]]
- [[12_Militar/03_Armada/Lanchas misilísticas y territorios candidatos]]
- [[12_Militar/03_Armada/Redes navales y transición a drones]]

## Integración exportadora V17 3 A101

- [[00_Canon/Integraciones V16/Acumulativa A101 Reconstrucción exportadora|Resoluciones y reconstrucción E1]]
- [[12_Militar/03_Armada/Exportaciones A099 A101/Índice de expedientes|27 expedientes y lotes]]
- [[00_Canon/Integraciones V16/Ámbitos de numeración A094 A101|Ámbitos A094 y A095]]

## Catálogo maestro consolidado

[[12_Militar/03_Armada/Catálogo maestro naval 1875-2026|Catálogo maestro naval 1875 a 2026]] reúne clases, familias, generaciones, perfiles técnicos y discrepancias con sus fuentes. La consolidación CMN 1 conserva las cantidades y reservas de V17.4 A102.
