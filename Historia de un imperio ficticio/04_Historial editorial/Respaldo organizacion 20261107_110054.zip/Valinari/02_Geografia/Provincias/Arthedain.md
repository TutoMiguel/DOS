---
tipo: provincia
canon: V16
estado: vigente
econ03: incluida
---
# Arthedain (Nueva Escocia)

Provincia de Arnor equivalente a Nueva Escocia.

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
Arnor equivalente a Nueva Escocia
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[02_Geografia/Índice Geográfico|Índice Geográfico]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[08_Economia/ECON-03 Resumen|ECON-03 Resumen]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[02_Geografia/Provincias/Índice de Provincias|Índice de Provincias]]
- [[10_Archivo/Documentos de trabajo integrados/actualizacion_canon_arnor_poblacion_economia_526ac_2026|actualizacion_canon_arnor_poblacion_economia_526ac_2026]]
- [[10_Archivo/Documentos de trabajo integrados/actualizaciones_acumulativas_canon_v12|actualizaciones_acumulativas_canon_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Optimizado v14|Canon Maestro Optimizado v14]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_provincia_arnor_v12|enmienda_canon_provincia_arnor_v12]]
