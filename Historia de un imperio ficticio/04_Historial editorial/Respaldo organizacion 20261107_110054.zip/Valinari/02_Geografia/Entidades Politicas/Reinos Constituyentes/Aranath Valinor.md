---
tipo: entidad territorial
estado_canonico: vigente
canon: V16
---
# Aranath Valinor

Reino constituyente de [[02_Geografia/Entidades Politicas/Federacion Directa/Gwaith Valinor|Gwaith Valinor]]. Incluye el núcleo insular y los territorios directos del Reino. Población: 481 millones. PIB PPA central: 58,50 billones.

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
No fijada de forma explícita en esta ficha.
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[02_Geografia/Índice Geográfico|Índice Geográfico]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[08_Economia/ECON-03 Resumen|ECON-03 Resumen]]
- [[00_Canon/Auditoría de Coherencia V16|Auditoría de Coherencia V16]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[00_Canon/Cifras Oficiales V16|Cifras Oficiales V16]]
- [[00_Canon/Integraciones V16/Integración septentrional Islandia Groenlandia V16|Integración septentrional Islandia Groenlandia V16]]
- [[00_Canon/Matriz de Estatus Político|Matriz de Estatus Político]]
- [[00_Canon/Matriz Territorial Económica|Matriz Territorial Económica]]
- [[00_Canon/Registro de Cambios|Registro de Cambios]]
- [[00_Indice Territorial/Índice Jerárquico Gwaith Valinor|Índice Jerárquico Gwaith Valinor]]
- [[00_Indice Territorial/Mapa de Relaciones Territoriales|Mapa de Relaciones Territoriales]]
- [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]
- [[01_Cronologia/Incorporación a la Federación|Incorporación a la Federación]]
- [[01_Cronologia/Incorporación al Reino|Incorporación al Reino]]
- [[02_Geografia/Aranath Valinor|Aranath Valinor]]
- [[02_Geografia/Arnor|Arnor]]
- [[02_Geografia/Entidades Politicas/Federacion Directa/Gwaith Valinor|Gwaith Valinor]]
- [[02_Geografia/Entidades Politicas/Índice de Entidades Políticas|Índice de Entidades Políticas]]
- [[02_Geografia/Provincias/Arnor Oriental|Arnor Oriental]]
- [[02_Geografia/Regiones/Nosselië Toliva|Nosselië Toliva]]
- [[02_Geografia/Territorios Federales/Groenlandia/Groenlandia|Groenlandia]]
- [[02_Geografia/Territorios Federales/Groenlandia/Integración septentrional|Integración septentrional]]
- [[02_Geografia/Territorios Federales/Islandia/Islandia|Islandia]]
- [[02_Geografia/Valinor a Tyl|Valinor a Tyl]]
- [[04_Mapa Politico/Capitales/Barad Valinor|Barad Valinor]]
- [[04_Mapa Politico/Capitales/Capitales del Canon V16|Capitales del Canon V16]]
- [[04_Mapa Politico/Capitales/Nueva Tirion|Nueva Tirion]]
- [[04_Mapa Politico/Núcleos Insulares/Índice de Núcleos Insulares|Índice de Núcleos Insulares]]
- [[08_Economia/ECON-03/Reglas de integracion|Reglas de integracion]]
- [[09_Politica/Historia Constitucional/Historia Constitucional de las Casas y la Corona|Historia Constitucional de las Casas y la Corona]]
- [[10_Archivo/Documentos de trabajo integrados/actualizaciones_acumulativas_canon_v12|actualizaciones_acumulativas_canon_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Optimizado v14|Canon Maestro Optimizado v14]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_federacion_golfo_oriental_v14|enmienda_canon_federacion_golfo_oriental_v14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_nosselie_toliva_canarias_v12|enmienda_canon_nosselie_toliva_canarias_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Integracion septentrional Islandia Groenlandia V16|Integracion septentrional Islandia Groenlandia V16]]
- [[10_Archivo/Documentos de trabajo integrados/Matriz de conciliacion y plan de integracion del Canon Maestro|Matriz de conciliacion y plan de integracion del Canon Maestro]]
- [[Inicio Valinari|Inicio Valinari]]
