---
tipo: entidad territorial
estado_canonico: vigente/provisional
canon: V16
---
# Círdan (Socotra)

Protectorado equivalente a Socotra. Capital propuesta: Hadibu.

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
No fijada de forma explícita en esta ficha.
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[02_Geografia/Índice Geográfico|Índice Geográfico]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[08_Economia/ECON-03 Resumen|ECON-03 Resumen]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[00_Canon/Integraciones V16/Bases navales y desarrollo aeronaval V16|Bases navales y desarrollo aeronaval V16]]
- [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]
- [[01_Cronologia/Red de Protectorados|Red de Protectorados]]
- [[02_Geografia/Beleg Valinor|Beleg Valinor]]
- [[02_Geografia/Entidades Politicas/Índice de Entidades Políticas|Índice de Entidades Políticas]]
- [[02_Geografia/Red Oriental de Enclaves y Protectorados|Red Oriental de Enclaves y Protectorados]]
- [[04_Mapa Politico/Capitales/Capitales del Canon V16|Capitales del Canon V16]]
- [[04_Mapa Politico/Capitales/Círdanost|Círdanost]]
- [[04_Mapa Politico/Ciudades/Hadibu|Hadibu]]
- [[04_Mapa Politico/Protectorados/Índice de Protectorados|Índice de Protectorados]]
- [[07_Imagenes/Índice de Imágenes|Índice de Imágenes]]
- [[09_Politica/Auditoría de Prompts Visuales de las Casas|Auditoría de Prompts Visuales de las Casas]]
- [[09_Politica/Casa Real/Casa Telcontar|Casa Telcontar]]
- [[09_Politica/Casas Mayores/Casa Círdan|Casa Círdan]]
- [[09_Politica/Casas Mayores/Índice de Casas Mayores|Índice de Casas Mayores]]
- [[09_Politica/Casas Menores de Exploración y Comercio|Casas Menores de Exploración y Comercio]]
- [[09_Politica/Casas Menores/Casa Círdanir|Casa Círdanir]]
- [[09_Politica/Casas Menores/Índice de Casas Menores|Índice de Casas Menores]]
- [[09_Politica/Casas Vasallas/Casa Ardamir|Casa Ardamir]]
- [[09_Politica/Casas Vasallas/Casa Wídfara|Casa Wídfara]]
- [[09_Politica/Casas Vasallas/Índice de Casas Vasallas|Índice de Casas Vasallas]]
- [[09_Politica/Índice de Casas Nobles|Índice de Casas Nobles]]
- [[09_Politica/Matriz Heráldica y Funcional de las Casas|Matriz Heráldica y Funcional de las Casas]]
- [[09_Politica/Perfil Fenotípico/Casas Mayores|Casas Mayores]]
- [[09_Politica/Perfil Fenotípico/Casas Menores|Casas Menores]]
- [[09_Politica/Perfil Fenotípico/Perfil Fenotípico del reino|Perfil Fenotípico del reino]]
- [[09_Politica/Prompts Visuales de las 84 Casas|Prompts Visuales de las 84 Casas]]
- [[09_Politica/Registro de representantes de las Casas|Registro de representantes de las Casas]]
- [[10_Archivo/Documentos de trabajo integrados/actualizaciones_acumulativas_canon_v12|actualizaciones_acumulativas_canon_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Optimizado v14|Canon Maestro Optimizado v14]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_enclaves_medio_oriente_v12|enmienda_canon_enclaves_medio_oriente_v12]]
- [[10_Archivo/Documentos de trabajo integrados/prompts_visuales_actualizados|prompts_visuales_actualizados]]
- [[12_Militar/Evolución Naval 1850-2026|Evolución Naval 1850-2026]]
