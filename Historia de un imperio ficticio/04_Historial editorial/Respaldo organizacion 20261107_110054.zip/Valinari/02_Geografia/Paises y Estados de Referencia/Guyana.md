---
tipo: entidad territorial
estado_canonico: referencia
canon: V16
---
# Guyana

Entidad geográfica de referencia utilizada por el canon para delimitar territorios ficticios. [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
No fijada de forma explícita en esta ficha.
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[02_Geografia/Índice Geográfico|Índice Geográfico]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[08_Economia/ECON-03 Resumen|ECON-03 Resumen]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[00_Canon/Registro de Nombres y Alias|Registro de Nombres y Alias]]
- [[00_Indice Territorial/Índice Jerárquico Gwaith Valinor|Índice Jerárquico Gwaith Valinor]]
- [[02_Geografia/Provincias/Índice de Provincias|Índice de Provincias]]
- [[02_Geografia/Provincias/Provincia de Guyana|Provincia de Guyana]]
- [[02_Geografia/Regiones/Sírënandë|Sírënandë]]
- [[10_Archivo/Documentos de trabajo integrados/actualizaciones_acumulativas_canon_v12|actualizaciones_acumulativas_canon_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Optimizado v14|Canon Maestro Optimizado v14]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_sirenande_poblacion_v12|enmienda_canon_sirenande_poblacion_v12]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_sirenande_v12|enmienda_canon_sirenande_v12]]
