> Antecedente del primer sorteo. El reparto individual vigente de las nueve parejas pendientes se documenta al final.

# Auditoría de la actualización visual de seis Casas

| Casa | Categoría | Cabello | Ojos | Imagen previa |
|---|---|---|---|---|
| Casa Hallas | Casas Menores | castaño claro | verdes | Ninguna detectada |
| Casa Thoron | Casas Menores | castaño claro | verdes | Ninguna detectada |
| Casa Angren | Casas Menores | castaño claro | verdes | Ninguna detectada |
| Casa Fornost | Casas Mayores | pelirrojo | celestes | Ninguna detectada |
| Casa Harnost | Casas Mayores | pelirrojo | celestes | Ninguna detectada |
| Casa Mithlond | Casas Mayores | pelirrojo | celestes | Ninguna detectada |

- Orden de las 84 Casas idéntico al catálogo anterior respaldado.
- Tres Casas Menores castañas de ojos verdes y tres Mayores pelirrojas de ojos celestes.
- Las otras 78 Casas conservan su perfil fenotípico.
- Se conservan las 84 asignaciones de altura, complexión, peinado, postura, posición e implementos.
- Se conservan los 84 apartados de genotipo orientativo y las 84 referencias genéticas.
- Ninguna Casa seleccionada tiene imágenes asociadas al momento de la verificación.
- Se verificaron los 84 enlaces a las fichas fuente.
- Se sincronizaron las seis fichas, los perfiles agregados y los dos Markdown del Canon V16.

**Casas protegidas por disponer de imágenes:** Alqualondë, Annúminas, Armenelos, Barad Calen, Calenhad, Calenor, Círdan, Dol Amroth, Eldalondë, Noldor.

**Semilla del sorteo registrado:** 9576318432291185622.

Las variantes son tendencias de representación familiar, con variación individual; las referencias genéticas no fijan genotipos exclusivos.

## Reparto individual vigente de las nueve parejas pendientes

Las nueve parejas de la galería pendientes de imagen tienen una asignación capilar individual registrada por separado para cada cónyuge. En conjunto, siete hombres y siete mujeres conservan tonos rubios habituales; dos hombres y dos mujeres son pelirrojos. El reparto admite matrimonios de distinto color natural de cabello, dentro de la variación humana de los linajes. Esta asignación individual prevalece sobre la tendencia capilar general de la Casa al representar a estos dieciocho personajes.

| Casa | Cabello del hombre | Cabello de la mujer |
|---|---|---|
| [[09_Politica/Casas Mayores/Casa Harlond|Casa Harlond]] | pelirrojo | rubio muy claro |
| [[09_Politica/Casas Mayores/Casa Harnost|Casa Harnost]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Mayores/Casa Minas Anor|Casa Minas Anor]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Mithlond|Casa Mithlond]] | rubio oscuro | rubio dorado |
| [[09_Politica/Casas Mayores/Casa Pelargir|Casa Pelargir]] | rubio ceniza | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Rhunost|Casa Rhunost]] | pelirrojo | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Taur-en-Mor|Casa Taur-en-Mor]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Teleri|Casa Teleri]] | rubio platino | rubio oscuro |
| [[09_Politica/Casas Mayores/Casa Vanyar|Casa Vanyar]] | rubio muy claro | rubio platino |

Las quince Casas Mayores ya ilustradas conservan sus asignaciones. Se mantienen los 84 genotipos y referencias genéticas del catálogo.

## Consolidación vigente de Mayores Menores y Vasallas

Se conserva el sorteo de las nueve Casas Mayores pendientes: dos hombres y dos mujeres pelirrojos, siete hombres y siete mujeres de tonos rubios habituales. En las 24 Casas Menores hay tres mujeres y dos hombres pelirrojos; los dos hombres reemplazan dos de los tres casos castaño claro del reparto anterior, quedando un hombre y tres mujeres castaño claro. En las 35 Casas Vasallas se asignan cuatro mujeres y dos hombres pelirrojos, tres mujeres castaño claro, un hombre castaño oscuro y tres representantes de cabello rubio platinado blanco, dos mujeres y un hombre. Los demás representantes conservan tonos rubios habituales.

[[09_Politica/Registro de representantes de las Casas|Registro completo y verificable del reparto]].
