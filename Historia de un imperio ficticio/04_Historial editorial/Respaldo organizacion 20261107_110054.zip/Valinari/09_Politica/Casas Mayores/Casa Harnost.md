---
tipo: casa noble
numero: 22
estatus: Casa noble
fecha_referencia: 833dc
canon: V16
---
# Casa Harnost

## Estatus

Casa noble.

## Característica histórica

La tradición histórica de la Casa se expresa en sus linajes, símbolos y funciones canónicas.

## Origen geográfico

- **Origen:** Ystad (Escania).
- **Característica histórica:** navegación báltica y comercio oriental.

## Régimen político

Casa Mayor con asiento y voto en el Consejo de las 24 Casas. Conserva patrimonio, jurisdicción interna y representación histórica dentro de la monarquía pactada.

## Blasón

- Campo: diseño heráldico pendiente de ilustración final.
- Emblema: Harnost.
- Colores: se definirán en la carta heráldica visual sin alterar el emblema textual.

## Estandarte

Estandarte vertical con el emblema de la casa, pensado para corte, fortaleza y ceremonia.

## Lema

- Sindarin: **La arena guarda la riqueza**
- Glosa: lema de la casa asociado a Harnost.
- Transcripción para alto tengwar: **Aren dorthad i mâl**

## Carta heráldica y visual

- **Blasón:** Campo rojo y negro; nave dorada bajo estrella.
- **Estandarte:** Estandarte rojo con nave dorada y estrella negra.
- **Lema:** **Hacia el mar naciente**
- **Transcripción en alto tengwar:** pendiente de composición gráfica definitiva a partir del lema canónico.

## Representantes de la galería

Pareja adulta anónima para la imagen individual de esta Casa.

- **Cabello del hombre:** rubio dorado
- **Cabello de la mujer:** rubio claro

El color se asigna individualmente a cada cónyuge. El perfil familiar describe tendencias con variación interna; los matrimonios entre linajes permiten parejas de distinto color natural de cabello. Se conservan los ojos, piel, pecas y textura capilar de la ficha, así como las alturas, complexiones, peinados, posturas e implementos ya fijados.

[[09_Politica/Distribución capilar de las nueve Casas Mayores pendientes|Distribución de las nueve parejas pendientes]].

## Personajes asociados

No hay personajes individualizados en esta ficha. Se añadirán cuando el canon los reconozca.

## Perfil fenotípico canónico

Cabello pelirrojo; ojos celestes; piel clara; pecas frecuentes; cabello ondulado y cuerpo atlético.

## Referencias genéticas orientativas

- HERC2/OCA2: pigmentación del iris.
- KITLG, IRF4, SLC24A4, TYRP1 y TPCN2: pigmentación capilar.
- SLC24A5, SLC45A2, TYR y OCA2: melanogénesis y piel.
- MC1R: pecas y variación de pigmentación.
- EDAR, TCHH, KRT71 y FGFR2: forma del cabello.

Estas referencias son orientativas y poligénicas; no constituyen genotipos obligatorios ni rasgos exclusivos de una Casa.

## Representación visual

![[07_Imagenes/Casa Harnost.jpg]]

## Matriz funcional y heráldica

[[09_Politica/Matriz Heráldica y Funcional de las Casas]]

## Evolución institucional posterior a la referencia histórica

La ficha conserva sus rasgos y relaciones en la fecha de referencia indicada. Desde el siglo XV, las actividades de la Casa pueden organizarse mediante compañías, banca, instituciones productivas y fundaciones conforme al marco común. El rango de Mayor, Menor, Vasalla o Real no asigna automáticamente un monopolio ni garantiza tamaño empresarial. Los sectores particulares se determinan por su característica histórica y los proyectos expresamente documentados.

La prestación militar evoluciona hacia servicio profesional y empresas reguladas; el mando de las fuerzas armadas pertenece al Estado en la organización moderna. El patrimonio de la Casa, los depósitos de clientes, sus fundaciones y los bienes públicos administrados mantienen cuentas separadas.

## Relaciones

- [[09_Politica/Índice de Casas Nobles]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[09_Politica/Índice Político Institucional|Índice Político Institucional]]

## Enlaces de gestión

- [[09_Politica/Índice de Casas Nobles|Índice de Casas Nobles]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[00_Canon/Panel de Control V16|Panel de Control V16]]
- [[04_Mapa Politico/Índice Político|Índice Político Territorial]]
- [[02_Geografia/Entidades Politicas/Índice de Entidades Políticas|Índice de Entidades Políticas]]
- [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]
- [[03_Personajes/Índice de Personajes|Índice de Personajes]]

## Referencias relacionadas

- [[09_Politica/Índice Político Institucional|Índice Político Institucional]]
- [[09_Politica/Índice de Casas Nobles|Índice de Casas Nobles]]
- [[04_Mapa Politico/Índice Político|Índice Político Territorial]]
- [[00_Canon/Matriz de Estatus Político|Matriz de Estatus Político]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[09_Politica/Auditoría de Prompts Visuales de las Casas|Auditoría de Prompts Visuales de las Casas]]
- [[09_Politica/Casas Mayores/Índice de Casas Mayores|Índice de Casas Mayores]]
- [[09_Politica/Casas Vasallas/Casa Malbeth|Casa Malbeth]]
- [[09_Politica/Casas Vasallas/Índice de Casas Vasallas|Índice de Casas Vasallas]]
- [[09_Politica/Distribución capilar de las nueve Casas Mayores pendientes|Distribución capilar de las nueve Casas Mayores pendientes]]
- [[09_Politica/Perfil Fenotípico/Casas Mayores|Casas Mayores]]
- [[09_Politica/Prompts Visuales de las 84 Casas|Prompts Visuales de las 84 Casas]]
- [[09_Politica/Registro de representantes de las Casas|Registro de representantes de las Casas]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/prompts_visuales_actualizados|prompts_visuales_actualizados]]
- [[09_Politica/Evolución económica e institucional de las Casas]]
- [[08_Economia/Sistema Valinari de Fomento y Desarrollo]]
- [[08_Economia/Banca valinari 550-1875]]
