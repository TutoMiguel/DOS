---
tipo: registro de propuestas
canon: V16
revision_editorial: V16.1
estado: pendientes de definición particular
---
# Propuestas pendientes tras revisión V16.1

Los diez desarrollos temáticos y la guía de 83 unidades están integrados. Las cuestiones siguientes requieren decisiones o trabajo específico; no se presentan como capítulos vigentes completos por estar mencionadas en la fuente.

1. Redactar los 83 capítulos narrativos completos. El índice y las diez fichas desarrolladas proporcionan su organización, sin sustituir ese trabajo literario. La pasada narrativa deberá fusionar los tratamientos agrícolas reiterados, los dos relatos de la Guerra del Pacífico y los solapamientos entre síntesis y desarrollo religioso, conservando sus datos únicos. La revisión actual no certifica la eliminación de toda reiteración semántica del libro.
2. Conciliar el desglose territorial del Senado de 74 miembros y cerrar Cámara Popular, elecciones, mandatos y resolución de bloqueos conforme al catálogo V16.
3. Revisar la serie naval 1500–1600 y su financiación, dotaciones, tonelaje y artillería. Las variantes v050 de 3.300 o 2.288 cañones y la curva 1500–2026 permanecen como antecedentes sin adoptar.
4. Precisar fechas y estatutos de nuevos órganos propuestos: Cámara Federal de Seguros, Registro de Testimonio Técnico Oral y órganos consultivos científicos. Se integran sus funciones compatibles sin inventar fecha o biografía fundacional.
5. Revisar la incorporación personal de Maia Rómen y su informe propuesto de 1741, sin atribuir a una persona toda la reforma financiera ya canónica.
6. Conciliar el perímetro censal de 50 d. C., las cohortes y el balance de fecundidad y mortalidad. Los 8 millones en 800 d. C. son el valor adoptado del escenario, no el resultado de una simulación demográfica validada en esta revisión. Los intervalos de esperanza de vida, crisis y composición requieren esa comprobación cuantitativa antes de atribuirles precisión estadística.
7. Desarrollar abolición y calendarios de liberación por territorio, así como consecuencias de conquista y trabajo coercitivo. No se importa una prohibición general de trata africana desde v050 para cerrar el vacío.
8. Precisar lenguas litúrgicas, composición confesional, religiones residentes y fechas de textos, manteniendo las controversias y el pacto de 864 ya adoptados.
9. Revisar nuevas crisis diplomáticas, leyes y tratados contenidos solo en v050. Las fechas de Chile, Gibraltar, capital nacional y OceanNet siguen las decisiones V16.
10. Resolver la retirada administrativa de Escandinavia y los remanentes actuales: las fechas de 150 y 380 d. C. propuestas en conversación no sustituyen las funciones de Forostar hasta 1200 recogidas en V16 sin una conciliación expresa. El contacto con la Rus y el mar Negro permanece como propuesta de desarrollo, sin nuevos enclaves soberanos adoptados.

## Referencias relacionadas

[[00_Canon/Integraciones V16/Revisión editorial V16.1]]
[[00_Canon/Canon V16 Maestro]]
[[08_Historia/Índice narrativo V16]]
