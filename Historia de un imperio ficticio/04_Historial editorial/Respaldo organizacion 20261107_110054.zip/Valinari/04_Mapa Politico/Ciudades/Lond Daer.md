---
tipo: ciudad
canon: V16
estado: vigente
econ03: incluida
---
# Lond Daer

Equivalencia: Bridgetown. Territorio o grupo: Caribe del Reino. Función: capital administrativa propuesta de Barbados. Su población y producción están incluidas en la cuenta ECON-03 de su entidad superior y no se suman aparte.

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
No fijada de forma explícita en esta ficha.
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[04_Mapa Politico/Capitales/Capitales del Canon V16|Capitales del Canon V16]]
- [[04_Mapa Politico/Ciudades/Índice de Ciudades|Índice de Ciudades]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[04_Mapa Politico/Capitales/Lond Daer|Lond Daer]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_ciudades_poblacion_industrial_v12|enmienda_canon_ciudades_poblacion_industrial_v12]]
