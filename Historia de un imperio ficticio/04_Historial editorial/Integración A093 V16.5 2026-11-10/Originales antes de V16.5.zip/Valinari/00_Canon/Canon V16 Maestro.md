# Canon V16 Maestro de la Unión Valinoriana

Estado: CANON VIGENTE

Integración editorial: 2026-11-09

Revisión editorial: V16.4 con acumulativa A092

Canon temático consolidado con las decisiones A092 del autor, la conciliación territorial y la recuperación de contenidos de Word y Obsidian. Se conservan los antecedentes y las hipótesis con su estado; A092 prevalece en las disposiciones que sustituye.

## Acumulativa A092 de conciliación del Canon V16

Revisión editorial V16.4. Decisión e integración del 9 de noviembre de 2026.

Esta acumulativa aplica las instrucciones posteriores del autor: conservar Groenlandia en 55–75 d. C., devolver Tol Eressëa a 20–40 d. C., conservar las poblaciones antiguas, conciliar Beleg con el rango rector 724,5–879,5 millones y separar las poblaciones aliadas. Regulariza las cuentas de 2026 y establece una representación común para Word y Obsidian. Desarrolla los registros navales, presupuestarios e industriales distinguiendo cifras heredadas, cálculos derivados y modelos nuevos.

Las decisiones expresas son vigentes. Los escenarios nuevos se identifican como hipótesis de planificación; no son censos, presupuestos ejecutados ni capacidades medidas. La falta de identidad de un casco, una población o un gasto anual se conserva como dato pendiente, sin sustituirla por cero.

### 1 Precedencia y alcance

A092 R01 sustituye V16.3-01 en la fecha de Tol Eressëa y las exclusiones de asentamientos que dependían de ella. R02 conserva las poblaciones antiguas por ámbito. R03 separa cuentas constitucionales y operativas. R04 regula Beleg y Gwaith Aear. R05 establece una fuente editorial común y cotejo por bloque. R06 desarrolla inventario, presupuesto y capacidades materiales. Las disposiciones no sustituidas siguen vigentes.

Se conservan originales y textos antes/después. La fecha de integración editorial no se convierte en fecha de descubrimiento, soberanía o producción histórica.

### 2 Cronología atlántica corregida

Estado VIGENTE por instrucción expresa del autor. Tol Eressëa se descubre entre 20 y 40 d. C. La ventana permite entre quince y cincuenta y cinco años hasta el reconocimiento groenlandés de 55–75. Un descubrimiento no supone colonización completa, pero sí permite establecer escalas y explorar rutas posteriores.

| Hito | Fecha rectora | Alcance |
| --- | --- | --- |
| Tol Eressëa | 20–40 d. C. | Descubrimiento y estaciones tempranas |
| Tol Eressëa hacia 50 | 50 d. C. | Presencia insular; no provincia moderna |
| Groenlandia | 55–75 d. C. | Reconocimiento desde rutas de Tol Eressëa |
| Groenlandia estacional | 70–110 d. C. | Escalas sin anexión provincial |
| Situación hacia 85 | 85 d. C. | Estaciones de Tol y presencia groenlandesa |
| Terranova | 400–500 d. C. | Primeras expediciones conservadas |
| Valinor | 650–750 d. C. | Descubrimiento formal conservado |
| Valinor y Nueva Tirion | 750–850 d. C. | Primeros asentamientos permanentes |
| Númenor y Armenelos | 920–980 d. C. | Asentamiento y fundación posterior |

La fecha 340–350 de Tol Eressëa queda como antecedente sustituido. No se restablecen las fechas de Terranova en 140–180 ni de Valinor en 350–450, porque la nueva decisión se refiere a Tol Eressëa y Groenlandia. El contacto caribeño de c. 150 a. C. corresponde a una ruta paralela; no depende del paso por Terranova.

Las primeras instalaciones de Tol Eressëa son agua, abrigo, reparación ligera, almacén, observación, santuario y archivo. No presuponen grandes astilleros, urbanización completa ni administración federal moderna. Su autonomía y posterior integración se desarrollan gradualmente.

### 3 Población antigua conservada

Se mantienen 475.000–545.000 habitantes bajo administración directa hacia 50 d. C. y 1,68–1,75 millones para el ámbito administrado o dependiente hacia 85. El modelo de 1,70 millones hacia 50, presente en el Markdown, representa población residente o vinculada a una red más amplia; no sustituye ni se suma al núcleo directo. La diferencia de ámbito debe aparecer junto a cada cifra.

La red comercial y de parentesco de 800.000–1.050.000 personas hacia 50 tampoco es una cuenta independiente que se pueda agregar al núcleo administrado: contiene solapamientos. El registro debe separar residencia directa, dependencia política, comunidades vinculadas y contacto con extranjeros.

El desglose por territorio de los totales de 50 y 85 todavía no está fijado de forma completa. Se conserva la población solicitada sin inventar una distribución insular. Queda resuelta la contradicción que excluía a Tol Eressëa por descubrirse demasiado tarde; no se afirma que adelantar una fecha valide por sí mismo las tasas demográficas del modelo.

### 4 Perímetro constitucional y operativo

Harnen mantiene su condición de protectorado de Beleg Valinor; Rhunost/Musandam es parte interna de Harnen. No se federaliza Harnen para cuadrar la suma ni se añade Musandam por separado.

Los totales de 523,5 millones y 65,50 billones incluyen los 8 millones y 0,52 billones de Harnen. Por ello su rótulo correcto es agregado operativo ECON-03. El ámbito estrictamente constitucional es 515,5 millones y 64,98 billones. La diferencia no es pérdida de habitantes o producción ni cambio de fronteras: separa dos perímetros previamente mezclados.

| Ámbito | Población M | PIB PPA | Tratamiento |
| --- | --- | --- | --- |
| Reino | 481,0 | 58,50 | 14 cuentas; Númenor y Canarias dentro |
| Ocho externas federales | 34,5 | 6,48 | Malaca, Oceanía, Eryndor, Islandia, Groenlandia |
| Constitucional | 515,5 | 64,98 | Reino más ocho externas |
| Harnen | 8,0 | 0,52 | Protectorado; incluye Rhunost |
| Operativo ECON-03 | 523,5 | 65,50 | Constitucional más Harnen |
| Externas operativas | 42,5 | 7,00 | 34,5 federales más 8 de Harnen |

La adición septentrional, ya incluida, es 3,5 + 2,0 = 5,5 millones y 0,55 + 0,40 = 0,95 billones. No vuelve a sumarse. El puente histórico completo es 508 + 10 + 5,5 = 523,5 para el agregado operativo; la expresión anterior 508 + 10 = 523,5 omitía el último sumando.

### 5 Matriz maestra de las 23 cuentas

Cada ID representa una cuenta territorial única. Se cuenta una vez la residencia habitual. Un traslado interno genera una salida y una entrada, con efecto neto nulo en el total superior. La asignación de un puerto a una red militar o comercial no incorpora toda la población del país anfitrión.

| ID | Cuenta | Ámbito | Población M | PIB PPA |
| --- | --- | --- | --- | --- |
| T01 | Valinor a Tyl | Reino | 26,00 | 3,10 |
| T02 | Arnor | Reino | 145,00 | 20,00 |
| T03 | Calenardhon Austral | Reino | 88,00 | 11,50 |
| T04 | Sírënandë | Reino | 55,00 | 3,50 |
| T05 | Venezuela Federal | Reino | 50,00 | 4,50 |
| T06 | Provincia del Orinoco | Reino | 15,00 | 2,20 |
| T07 | Colombia Costera | Reino | 53,00 | 7,20 |
| T08 | Panamá Federal | Reino | 17,00 | 2,50 |
| T09 | Trinidad | Reino | 8,00 | 1,20 |
| T10 | Tobago | Reino | 1,00 | 0,10 |
| T11 | Bahamas | Reino | 6,00 | 0,80 |
| T12 | Bermudas | Reino | 2,00 | 0,40 |
| T13 | Barbados | Reino | 5,00 | 0,50 |
| T14 | Nosselië Toliva | Reino | 10,00 | 1,00 |
| T15 | Malaca | Federal externa | 16,00 | 2,97 |
| T16 | Hawái | Federal externa | 4,00 | 1,35 |
| T17 | Fiyi | Federal externa | 3,00 | 0,42 |
| T18 | Polinesia | Federal externa | 2,50 | 0,35 |
| T19 | Micronesia | Federal externa | 1,50 | 0,26 |
| T20 | Eryndor | Federal externa | 2,00 | 0,18 |
| T21 | Harnen | Protectorado operativo | 8,00 | 0,52 |
| T22 | Islandia | Federal externa | 3,50 | 0,55 |
| T23 | Groenlandia | Federal externa | 2,00 | 0,40 |

La matriz complementaria incluye capital de referencia, superficie, perímetro, exclusiones, fecha y fuente. Las superficies no documentadas siguen sin cifra. El total antiguo de Gwaith de 5,6–5,7 millones km² necesita comprobar si incluía los 2.269.000 km² septentrionales; no se agrega esa extensión a ciegas ni se certifica un total sin límites territoriales verificables.

Las capitales se recuperan del índice canónico existente, con su estado provisional cuando corresponde. Islandia y Groenlandia mantienen la capital territorial pendiente de fijación. Una tabla completa en campos no equivale a disponer de datos que las fuentes nunca fijaron.

### 6 Urbanización y cuentas económicas

Las 21 cuentas anteriores suman 464,05 millones urbanos y 53,95 rurales: 518 millones. Faltaba la distribución de los 5,5 millones septentrionales. A092 desarrolla como HIPÓTESIS una tasa urbana de 92 % para Islandia, 3,22 urbanos y 0,28 rurales, y 85 % para Groenlandia, 1,70 urbanos y 0,30 rurales. Sus totales territoriales no cambian.

| Ámbito | Urbana M | Rural M | Total M | Urbanización |
| --- | --- | --- | --- | --- |
| Reino | 431,85 | 49,15 | 481,00 | 89,78 % |
| Constitucional | 462,37 | 53,13 | 515,50 | 89,69 % |
| Operativo | 468,97 | 54,53 | 523,50 | 89,58 % |

Las tablas urbanas heredadas se contrastaron por cuenta: sus filas de ciudades y remanentes coinciden con los objetivos urbanos y rurales existentes. Númenor está dentro de Arnor; Valinor, Tol Eressëa y Systreyjar son componentes de Valinor a Tyl; el canal está dentro de Panamá. Los nombres repetidos de ciudades requieren identificador territorial, sin duplicar residentes.

Producción menos consumo intermedio debe ser igual a VAB, y VAB más impuestos netos debe ser igual a PIB. Se preservan los objetivos territoriales. Las diferencias heredadas de redondeo, hasta 0,0001 billones, se ajustan explícitamente en el insumo del sector J. Cada ajuste tiene importe y trazabilidad; no se presenta como crecimiento económico.

| Ámbito | PIB | Impuestos | VAB | Producción | Insumos |
| --- | --- | --- | --- | --- | --- |
| Reino | 58,50000 | 2,70390 | 55,79610 | 95,47964 | 39,68354 |
| Constitucional | 64,98000 | 3,00390 | 61,97610 | 106,33371 | 44,35761 |
| Operativo | 65,50000 | 3,02210 | 62,47790 | 107,20049 | 44,72259 |

La nueva fiscalidad septentrional reparte el incremento conjunto de 0,05 billones en 0,03 de Islandia y 0,02 de Groenlandia. Sus VAB son 0,52 y 0,38. Es un reparto de planificación, no recaudación observada. Las dos matrices nuevas completan 23 cuentas con diez sectores cada una.

El resumen anterior de 3,92210 billones de impuestos netos y 61,57790 de VAB no coincide con la suma por jurisdicción. El cierre operativo regularizado es 3,02210 + 62,47790 = 65,50000. Se elimina la diferencia fiscal de 0,90000 sin alterar el PIB objetivo. Producción e insumos se reconstruyen desde las cuentas, en vez de conservar resúmenes incompatibles.

El intervalo 60,85–70,20 permanece como escenario macro del ámbito operativo. No se deduce PIB nominal multiplicando PPA por un factor genérico. Los centros nominales heredados de 48,5 y 49,2 siguen siendo escenarios sin conciliación homogénea; no se presentan como dos cifras oficiales simultáneas.

### 7 Conciliación de Beleg Valinor

Se conserva el rango rector 724,5–879,5 millones. La instrucción abreviada 724–879 se interpreta como referencia a ese rango previo, sin eliminar sus decimales. Beleg contiene el ámbito constitucional, Harnen, Esgal Nénar y otros componentes no solapados. No se añade Harnen otra vez a una base operativa que ya lo incluye.

| Componente | Población M | PIB PPA | Estado |
| --- | --- | --- | --- |
| Constitucional | 515,5 | 64,98 | Cuentas territoriales |
| Harnen y Rhunost | 8,0 | 0,52 | Una sola cuenta |
| Esgal Nénar | 11,5 | 0,52 | Ficha vigente |
| Subtotal identificado | 535,0 | 66,02 | Suma anterior |
| Otros componentes necesarios | 189,5–344,5 | 7,33–27,73 | Residuo sin asignación demostrada |
| Beleg objetivo | 724,5–879,5 | 73,35–93,75 | Rango rector; desglose incompleto |

La prueba inferior es 515,5 + 8 + 11,5 + 189,5 = 724,5; la superior es 515,5 + 8 + 11,5 + 344,5 = 879,5. Por la ruta operativa, 523,5 + 11,5 + residuo da lo mismo. Las rutas son alternativas, no sumandos adicionales.

La atribución anterior del salto completo a Esgal Nénar era insuficiente: 715,5–865,5 más 11,5 da 727,0–877,0, no 724,5–879,5. Mantener el rango rector implica una base previa algebraica de 713–868. Esa resta no identifica población territorial nueva. Se conserva el rango ordenado, con un residuo explícito de 189,5–344,5 millones por asignar; no se reparte entre pequeños enclaves sin territorio que lo sustente.

| Entidad | Población | Tratamiento | Exclusión |
| --- | --- | --- | --- |
| Harnen/Omán | 8 M | Ya en base operativa | Rhunost 0,45 M está dentro de los 8 |
| Esgal Nénar | 11,5 M | Beleg exterior a base operativa | No federal; 0,52 billones |
| Kheled-zâram/Kuwait | Sin cifra | Protectorado por desarrollar | No añadir vecinos |
| Círdan/Socotra | Sin cifra | Nodo protegido exterior | No Yemen completo |
| Harlond/Adén | Sin cifra | Nodo protegido exterior | No Yemen completo |
| Amon Rûdh/Yibuti | Sin cifra | Protectorado portuario | Delimitar puerto y país |
| Alqualondë/Chipre | Sin cifra | Asociación; adscripción mixta | Residentes del nodo una vez |
| Eglarest/Malta | Sin cifra | Asociación; adscripción mixta | No isla completa sin tratado |
| Pelargir/Alejandría | Sin cifra | Puerto asociado | No Egipto completo |
| Nanduhirion/Palaos | Incluido | Dentro de Micronesia | Incremento Beleg cero |
| Eärendil/Cabo Verde | Sin cifra | Enclave asociado | Solo perímetro enclave |
| Tol Morwen/Santo Tomé | Sin cifra | Puerto científico | No soberanía completa |
| Nandor Occidental/Bijagós | Sin cifra | Red de acuerdos | No Guinea-Bisáu completa |
| Tol Eressëa Occidental/Madeira | Sin cifra | Puerto asociado | Distinta de Tol Eressëa |
| Barad Nimras/Gibraltar | Sin cifra | Base arrendada | Solo perímetro documentado |
| Eressëa Índica/Seychelles | Sin cifra | Enclave científico | No país completo |
| Harlond Caribe/Curaçao | Sin cifra | Concesión logística | Distinto de Adén |
| Forlond Austral/Malvinas | Sin cifra | Estación arrendada | No archipiélago completo |
| Amon Uilos/Ascensión | Sin cifra | Estación científica | No toda población anfitriona |

Alqualondë, Eglarest y Pelargir aparecen tanto en el catálogo de Beleg como en la red de Gwaith Aear. La pertenencia funcional múltiple no autoriza una cuenta doble. Sus perímetros jurídicos detallados siguen provisionales; un acuerdo portuario no incorpora por sí mismo Chipre, Malta o Egipto completos. Nanduhirion/Palaos ya está dentro de Micronesia y no genera un incremento adicional de Beleg.

### 8 Aliados de Gwaith Aear

Chile es el aliado soberano expresamente identificado en las fuentes examinadas: Tratado de Valparaíso de 1848, Pacto del Pacífico Austral de 1876, tratados posteriores y Andúnië Austral. Los acuerdos portuarios mediterráneos prueban asociación de nodos, no necesariamente alianza demográfica nacional. Los convenios universitarios no acreditan alianza soberana con sus países.

| Vínculo | Prueba | Regla de población |
| --- | --- | --- |
| Chile | Alianza expresa y tratados australes | Población canónica de 2026 una vez cuando exista cuenta |
| Andúnië Austral | Arrendamiento soberano chileno | Subconjunto de Chile; incremento cero al incluir Chile |
| Chipre/Alqualondë | Puerto asociado | Solo perímetro documentado; si está en Beleg, incremento cero |
| Malta/Eglarest | Puerto asociado | Una sola cuenta de residentes |
| Egipto/Pelargir | Cooperación en Alejandría | No población nacional sin tratado y cuenta |
| Contactos científicos y comerciales | Relaciones sectoriales | No equivalen automáticamente a alianza soberana |

La fórmula es P(Aear) = P(Beleg) + P(aliados fuera de Beleg). Se trata de una unión de conjuntos de residentes, no de sumar listas de pertenencias. Si se incorpora Chile completo, Andúnië no se agrega. Si un puerto está en Beleg, se descuenta al incorporar su país. Se exige el mismo año y un único perímetro para cada población.

Los rangos heredados 1.115,5–1.515,5 millones y PIB de 98–128 o 105,7–140,7 billones no están conciliados con una lista cuantificada de aliados. El incremento implícito antiguo de 400–650 millones produciría, aplicado al nuevo Beleg, 1.124,5–1.529,5 millones. Es una sensibilidad algebraica, no identifica a esos habitantes y no se adopta como nuevo censo.

La relación de aliados confirmados y las exclusiones quedan identificadas. El total demográfico final de Aear sigue sin dato: falta población chilena canónica de 2026 y padrón completo de aliados. No se llena con población contemporánea del mundo real, cuyas fronteras y trayectorias difieren del canon.

### 9 Inventario naval por unidad y año

El registro de 2026 contiene 615 identificadores administrativos únicos derivados de AM1: 595 buques tripulados y veinte vehículos no tripulados. Cada registro tiene año, familia, naturaleza, referencia técnica, identidad histórica, estado observado, teatro y estado de simulación. Los identificadores de control no son matrículas históricas inventadas.

Las fuentes fijan cantidades por familia, pero no todos los nombres, botaduras y destinos individuales. Esos campos permanecen sin dato. La hipótesis de 449 disponibles se reparte proporcionalmente por mayores restos entre familias, con 166 no disponibles. Es una prueba de aritmética, no una observación de mantenimiento ni una orden de despliegue.

| Familia | Inventario | Disponibles modelo | No disponibles |
| --- | --- | --- | --- |
| Portaaviones nucleares Telperion | 4 | 3 | 1 |
| Portaaviones convencionales Anárion II / Elwing I / Aldarion I | 3 | 2 | 1 |
| Portaaviones ligeros STOVL Varda II–III | 4 | 3 | 1 |
| Submarinos estratégicos Arnor II–IV | 10 | 7 | 3 |
| Submarinos nucleares de ataque Eärendil II–IV | 18 | 13 | 5 |
| Submarinos convencionales AIP Tolfalas II–IV | 18 | 13 | 5 |
| Submarinos especiales Aeglos y rescate Falathar | 8 | 6 | 2 |
| Destructores Gil-galad de defensa aérea | 24 | 17 | 7 |
| Fragatas Círdan/Voronwë multipropósito | 64 | 47 | 17 |
| Corbetas oceánicas Calenport | 72 | 52 | 20 |
| Escoltas especializados ASW/AAW | 30 | 22 | 8 |
| Buques de asalto/anfibios | 14 | 10 | 4 |
| LPD/LSD de desembarco | 20 | 15 | 5 |
| OPV Sírënandë | 80 | 58 | 22 |
| Patrulleros rápidos | 70 | 51 | 19 |
| Guerra de minas | 30 | 22 | 8 |
| Hidrografía | 20 | 15 | 5 |
| Vehículos no tripulados navales | 20 | 15 | 5 |
| Petroleros de flota | 20 | 15 | 5 |
| Reabastecedores multipropósito | 18 | 13 | 5 |
| Transportes estratégicos | 12 | 9 | 3 |
| Hospitales | 10 | 7 | 3 |
| Reparación/taller | 12 | 9 | 3 |
| Oceanográficos | 10 | 7 | 3 |
| Salvamento y rescate | 8 | 6 | 2 |
| Mando, comunicaciones y apoyo especializado | 16 | 12 | 4 |

Los estados de casco son servicio, reserva, mantenimiento, modernización y baja. Disponible es una condición adicional de aptitud; entrenamiento es una actividad. Una baja retira la unidad del inventario vigente. El registro de movimientos conserva su historia, pero no mantiene unidades retiradas dentro de las 615 para inflar la cifra.

Cada observación debe tener inicio y fin. El control rechaza dos estados de casco o dos teatros simultáneos de la misma unidad. Una nave puede aparecer en varios años sin convertirse en varios cascos. Los nombres de familias de 1980 y 2026 no demuestran continuidad de unidades sin ficha individual.

Se conservan 332 unidades de referencia en 1875, 427 en 1980 y 615 plataformas en 2026, con categorías y fuentes separadas. Las reconstrucciones de 1945, 1960 y 1973 mantienen su etiqueta de hipótesis. Las embarcaciones transportadas y los vehículos de misión no añaden cascos a otra familia salvo alta explícita. La modernización integral de media vida se programa una vez por casco, separada de reparaciones ordinarias.

El fichero JSON contiene los campos técnicos completos; el Markdown permite revisar todos los IDs. Los importes por casco, dotaciones efectivas y teatros no documentados no se generan a partir de promedios de clase como si fueran hechos históricos.

### 10 Presupuesto y serie anual naval

Se entrega un registro de 1875 a 2026, 152 años, con apropiación, ejecución, moneda nominal, deflactor, PIB PPA, equivalencia y escenario separados. Los valores no documentados quedan sin dato. La regla comparativa estadounidense se conserva como referencia heredada de AM1; esta acumulativa no vuelve a certificar sus fuentes externas.

Las anclas de diseño son 0,23 % en 1875 sin PIB valinari homogéneo fijado; 1,65 % sobre 5,73 billones de trabajo en 1980; y 0,9 % sobre 65,50 en 2026. La multiplicación exacta de 1980 es 0,094545 billones, 94,545 mil millones, frente al redondeo heredado de 94,4. La de 2026 es 0,58950 billones, 589,5 mil millones PPA. Son equivalencias de diseño, no pagos ni apropiaciones nominales demostradas.

Se desarrolla una sensibilidad 1980–2026: PIB(t) = 5,73 × (65,50 / 5,73)^((t − 1980) / 46). La tasa de esfuerzo baja linealmente de 1,65 % a 0,9 %. El producto produce un presupuesto teórico anual. No reconstruye guerras, crisis, leyes presupuestarias ni ejecución histórica. Los años anteriores a 1980 sin PIB de referencia no reciben importes ficticios.

#### Distribución de diseño en 2026

| Rubro de hipótesis | Participación | Mil millones PPA |
| --- | --- | --- |
| Personal y formación | 25 % | 147,375 |
| Operación y mantenimiento | 25 % | 147,375 |
| Adquisición y modernización | 25 % | 147,375 |
| Munición y reposición | 10 % | 58,950 |
| Investigación y pruebas | 5 % | 29,475 |
| Bases e infraestructura | 8 % | 47,160 |
| Contingencia | 2 % | 11,790 |
| Total | 100 % | 589,500 |

La distribución es una HIPÓTESIS nueva. No se suman 589,5 mil millones a defensa, COFOVAL o PIB como nueva producción. Cada contrato tiene una fuente principal; las transferencias internas se eliminan al consolidar. Los 393 mil millones PPA de apropiación COFOVAL ya están dentro de su cartera movilizable de 917; no son 1.310 adicionales.

El control de ejecución exige apropiación inicial y modificada, compromisos, obligaciones, pagos, saldos, calendario fiscal y perímetro institucional homogéneo. Convertir nominal a PPA requiere método por rubro; no se aplica el cociente del PIB a todo un buque. El ciclo de vida separa construcción, personal, combustible, mantenimiento, refit único, baja y desmantelamiento. La comparación entre fuerza y presupuesto incluye personal en tierra, aviación e Infantería de Marina cuando el perímetro lo exige.

### 11 Capacidades industriales y materiales

Cada capacidad se expresa como entradas, proceso, salida útil y demanda. Reservas geológicas no equivalen a extracción; conservar una receta metalúrgica no crea hornos, fábricas de motores o técnicos. Investigación, prototipo, producción en serie y despliegue son etapas distintas. El adelanto tecnológico se evalúa por sector y rival, sin una ventaja uniforme para toda la economía.

#### Balance semiconductor recuperado

Se recupera del Markdown el balance físico central de 2026: 6,90 millones de obleas equivalentes producidas + 1,35 importadas = 7,50 de demanda + 0,65 exportadas + 0,10 de inventario. La disponibilidad local neta es 6,15, el 82 % de la demanda física; la cobertura por valor es otra magnitud, 60–75 %.

| Familia | Demanda | Producción | Importa | Exporta | Inventario |
| --- | --- | --- | --- | --- | --- |
| Lógica madura y control | 2,40 | 2,65 | 0,15 | 0,35 | 0,05 |
| Analógico y potencia | 1,85 | 1,95 | 0,10 | 0,15 | 0,05 |
| Memoria | 1,50 | 1,00 | 0,55 | 0,05 | 0,00 |
| RF imagen y sensores | 1,05 | 0,90 | 0,20 | 0,05 | 0,00 |
| Procesadores avanzados | 0,70 | 0,40 | 0,35 | 0,05 | 0,00 |
| Total millones obleas | 7,50 | 6,90 | 1,35 | 0,65 | 0,10 |

Los componentes empaquetados cumplen 48 mil millones locales + 14 importados = 62 de demanda + 2 exportados. No se aplica un número constante de componentes por oblea: depende de área del dado, proceso, defectos, encapsulado y rendimiento.

Como HIPÓTESIS A092, capacidad nominal de 8,5 millones y utilización de 86 % producen 7,31 millones iniciadas. Una salida útil de 6,90 implica 0,41 de rechazo equivalente y 94,39 % de rendimiento. Encaja en las envolventes heredadas de capacidad 7,0–8,8 y utilización 82–88 %. El caso usa 16 TWh de electricidad y 70 millones de m³ de agua bruta como centros de los rangos 12–20 TWh y 50–90 millones de m³. Agua bruta no equivale a consumo neto; exige recirculación y balance de cuenca.

El diseño usa cinco polos, doce líneas maduras/especializadas, tres avanzadas, ocho centros de encapsulado y tres de investigación. Está dentro de las envolventes heredadas. No se divide el total entre cinco para afirmar que cada sitio tiene recursos suficientes: cada planta debe acreditar ubicación, agua, energía, transporte, plantilla y contingencias. Las ventas electrónicas ya están dentro de ECON-03; no incrementan por segunda vez el PIB.

#### Escenario material de la trayectoria industrial

Las siguientes son HIPÓTESIS nuevas para desarrollar el mundo ficticio, no producción realizada ni series históricas previamente aprobadas. Permiten comprobar relaciones y órdenes de magnitud antes de adoptar una capacidad detallada por planta.

| Año | Acero Mt/año | Electricidad TWh/año | Técnicos industriales | Personal naval incluido |
| --- | --- | --- | --- | --- |
| 1875 | 2,4 | 1,1 | 450.000 | 60.000 |
| 1980 | 120 | 900 | 5.500.000 | 220.000 |
| 2026 | 280 | 6.200 | 12.000.000 | 320.000 |

El escenario eléctrico de 2026 equivale a 11,84 MWh por habitante operativo; no es consumo doméstico individual. Los 16 TWh de semiconductores son aproximadamente 0,26 % del total. Acero, electricidad, plantilla y astilleros se contrastan con extracción, combustibles, red, formación, demanda civil y comercio, sin sumar magnitudes de distinta naturaleza.

Con vida de referencia de 35 años, la reposición de 595 buques tripulados es aproximadamente diecisiete al año. Los vehículos no tripulados tienen otro ciclo. No supone diecisiete buques idénticos cada año: se distribuyen tonelaje, especialidad, diques, reactores, sensores y plazos.

Noventa días de mantenimiento anual por buque implican 53.550 días de puesto. Con trescientos días útiles por puesto, son 178,5 puestos equivalentes. No son 179 diques secos para portaaviones: deben separarse muelle, varada, gran carena, reactor y reparación de equipos. La planificación reserva capacidad para averías y refits; no ocupa el cien por cien y promete respuesta inmediata.

Cada planta registrará ubicación, tecnología, habilitación, capacidad nominal, utilización, rendimiento, rechazo, salida útil, energía, agua, plantilla, turnos, inversión y coste operativo. Cada astillero añadirá eslora y tonelaje admitidos, especialidad, ocupación y pedidos civiles y militares. Un trabajador o equipo compartido no cuenta como dos capacidades completas en el mismo turno.

### 12 Equivalencia entre Word y Obsidian

Se cotejan párrafos sustantivos y tablas de ambas representaciones. La normalización de signos o formato no autoriza a borrar diferencias de significado. Los materiales exclusivos se recuperan con su contexto temático; los antecedentes no recuperan vigencia por trasladarse de archivo.

El resultado usa una secuencia común. Cada párrafo o tabla tiene identificador, sección, estado y huella de contenido. El Markdown se exporta de esa misma secuencia final de Word. El control exige igual cantidad, orden y contenido normalizado de todos los bloques, incluidas celdas, no solo coincidencia de títulos o número de páginas.

Se conserva el Word temático como estructura base. Los contenidos exclusivos del Markdown se recuperan en un suplemento identificado por sección de origen. Las resoluciones A092 prevalecen en sus materias; las diferencias históricas o provisionales conservan su estado. Las tablas recuperadas se preservan como tablas, no como capturas.

### 13 Estados y criterios de aceptación

VIGENTE identifica decisiones aprobadas y texto heredado compatible. ANTECEDENTE conserva disposiciones sustituidas. HIPÓTESIS identifica modelos y reconstrucciones. PENDIENTE identifica un dato o conciliación sin cierre. El registro clasifica cada bloque, con referencia de precedencia y sección. Un mismo bloque que mezcla estados se divide o recibe una nota específica; la fecha de publicación no lo vuelve vigente automáticamente.

Las nuevas matrices septentrionales, sus tasas urbanas, el reparto presupuestario, la disponibilidad simulada y las capacidades industriales llevan etiqueta de hipótesis. Sin dato no significa cero: población no fijada no equivale a territorio deshabitado y gasto desconocido no significa ausencia de presupuesto.

El control exige 23 cuentas y 230 filas sectoriales; 481 millones del Reino, 515,5 constitucionales y 523,5 operativos; PIB de 58,50, 64,98 y 65,50 billones; población urbana más rural igual al total; y las dos identidades económicas en cada cuenta. El inventario exige 615 IDs únicos, 595 tripulados y veinte no tripulados. La simulación exige 449 disponibles y 166 no disponibles. La serie contiene 152 años sin transformar campos desconocidos en ejecución presupuestaria falsa.

Beleg mantiene su rango rector, con 189,5–344,5 millones todavía sin componentes territoriales documentados. Gwaith Aear necesita padrón y poblaciones fuera de Beleg. Esos vacíos no se ocultan inventando habitantes de enclaves o tratados.

### 14 Procedencia y trazabilidad

Las decisiones rectoras son las siete anotaciones del autor posteriores a V16.3. Las cuentas usan los capítulos 34 a 36 del Markdown anterior, contrastados con las tablas del Word oficial. Se consultan las fichas de Harnen, Esgal Nénar, Beleg, Gwaith Aear, la red oriental, la matriz territorial, cifras oficiales, capitales y AM1. El balance semiconductor procede del capítulo de COFOVAL y electrónica.

El paquete incluye cotejo por sección y bloque, sustituciones, matriz territorial, cuentas sectoriales, inventario de 615 unidades, serie de 152 años, relación de protectorados y aliados y originales anteriores. Las huellas permiten verificar fuentes y publicación local. La ubicación en OneDrive no demuestra que haya terminado la sincronización remota.

[[Acumulativa A092 V16.4]]

## Índice

Índice narrativo de 83 unidades · Registro de integración V16.1

- Resoluciones acumulativas V16.2

- Criterios editoriales y naturaleza del escenario

- Orígenes, expansión y relaciones exteriores

- Organización territorial y capitales

- Corona, gobierno y administración

- Casas e instituciones patrimoniales

- Religión y memoria

- Población, hogares y trabajo

- Economía, agricultura y cuentas territoriales

- Moneda, banca y fomento

- Educación y custodia del conocimiento

- Energía, industria y tecnología

- Defensa y fuerzas armadas

## Criterios editoriales y naturaleza del escenario

### Regla primordial de nomenclatura urbana

Toda ciudad, puerto, asentamiento, provincia urbana o nodo administrativo nuevo debe usar el formato Nombre ficticio (nombre real). El nombre ficticio procederá preferentemente de Tolkien, especialmente del sindarin, y se escogerá por relación con la región, función, paisaje, linaje o tradición local. Los nombres de Juego de Tronos solo se usarán como segunda reserva cuando no exista un nombre tolkieniano pertinente.

No se repetirán nombres ficticios completos. Las raíces compartidas podrán conservarse cuando el calificativo forme parte de una denominación histórica consolidada y la entidad sea inequívoca.

Los calificadores geográficos artificiales no se crearán para resolver duplicaciones. Sin embargo, los nombres históricos ya adoptados por el canon —como Calenardhon Austral, Pelargir Austral, Erellond Sur, Amon Rûdh Oriental o Calenport Sur— se conservan hasta una revisión expresa.

Los nombres inventados fuera de Tolkien o Juego de Tronos deberán justificar su relación lingüística, geográfica o histórica con el territorio. No se incorporará una ciudad ficticia usando únicamente el nombre real. Las ciudades ya adoptadas conservan su identidad canónica hasta una revisión formal de la tabla de renombramiento.

### Estado cartográfico

Los mapas generados anteriormente fueron eliminados y no forman parte del canon ni del proyecto. Las coordenadas de Valinor, Tol Eressëa, Númenor, ciudades y territorios permanecen como datos textuales independientes.

### Principio ontológico de Valinor y los Valinari

El escenario se desarrolla en el mundo real mediante una historia alternativa. Valinor es una entidad histórica y territorial humana asentada en territorios reales; no pertenece a un universo separado ni implica la existencia real de elfos o pueblos fantásticos.

Valinari es el gentilicio colectivo utilizado por los ciudadanos de Valinor y, por extensión histórica, por las poblaciones vinculadas a su civilización. Tolkien se utiliza únicamente como referencia estética y nomenclatural para nombres de personas, lugares, Casas, instituciones y tradiciones.

Las equivalencias con Canarias, América, Europa, África o Asia describen territorios reales dentro de una línea temporal alternativa. Los nombres inspirados en Tolkien son nomenclatura ficticia y no constituyen evidencia de una geografía fantástica o de especies no humanas.

## Orígenes, expansión y relaciones exteriores

### Incorporación atlántica septentrional de Islandia y Groenlandia

La clasificación territorial V16.2, vigente editorialmente desde el 1 de noviembre de 2026, reconoce a Islandia y Groenlandia como territorios federales autónomos de Gwaith Valinor. Esa fecha no es su primera incorporación histórica. No pertenecen a Aranath Valinor ni son protectorados de Beleg Valinor. V16.3-02 distingue incorporación pactista, constitucionalización y clasificación editorial.

##### Islandia

Estatus: territorio federal marítimo autónomo. La incorporación se desarrolló mediante reconocimiento, escalas, estaciones de navegación, un protectorado pactado hacia 950 d. C. e integración autónoma entre 1120 y 1150. La consolidación administrativa y económica se completó durante la industrialización moderna.

Superficie de referencia: 103.000 km². Población canónica en 2026: 3,5 millones. PIB PPA: 0,55 billones de dólares.

Su economía combina pesca industrial, energía geotérmica e hidroeléctrica, aluminio, astilleros, reparación naval, transporte aéreo, meteorología, oceanografía y servicios portuarios. Sus principales instalaciones federales son una base naval del Atlántico Norte, un centro meteorológico y una red de vigilancia antisubmarina.

##### Groenlandia

Estatus: territorio federal ártico autónomo con régimen especial. La presencia valinoriana comenzó con expediciones y estaciones discontinuas; el protectorado se consolidó de forma gradual desde el siglo XI, perdió continuidad entre los siglos XIII y XVI y fue restablecido en el siglo XIX. La incorporación federal estratégica se produjo entre 1945 y 1956, con reconocimiento de las comunidades locales y autonomía administrativa.

Superficie de referencia: 2.166.000 km². Población canónica en 2026: 2 millones. PIB PPA: 0,40 billones de dólares.

Groenlandia concentra investigación polar y nuclear, radares, comunicaciones, hidroelectricidad, minería de hierro, cobre, níquel, zinc y tierras raras, pesca, biotecnología marina, construcción especializada y centros de cohetería. La industria pesada y el enriquecimiento nuclear permanecen distribuidos en Arnor, Valinor, Númenor y Calenardhon Austral; Groenlandia aporta investigación, materias primas, pruebas y vigilancia estratégica.

##### Efecto económico y demográfico

La incorporación añade 5,5 millones de habitantes, 2.269.000 km² y 0,95 billones de dólares PPA. Gwaith Valinor pasa a 523,5 millones de habitantes y 60,85–70,20 billones de dólares PPA. Beleg Valinor y Gwaith Aear se recalculan por adición proporcional, sin modificar las cifras internas de Aranath Valinor.

##### Efecto militar y tecnológico

La incorporación crea el Comando del Atlántico Norte, refuerza la patrulla antisubmarina, los rompehielos, los radares de alerta temprana, la meteorología y la protección de cables. Groenlandia alberga el Instituto Ártico de Física Nuclear, centros de cálculo, seguimiento de misiles y materiales resistentes al frío. En 1956 Valinor dispone de una capacidad nuclear de umbral avanzado; la primera prueba se sitúa entre 1957 y 1958, seguida por una disuasión mínima entre 1959 y 1961.

##### Secuencia histórica de descubrimiento, conquista e integración

- 720–650 a. C.: reconocimiento atlántico septentrional e identificación de Islandia como escala oceánica.

- 600–300 a. C.: estaciones estacionales de navegación, pesca y observación en Islandia.

- 300 a. C.–300 d. C.: exploraciones hacia Groenlandia y establecimiento de puntos temporales de abastecimiento.

- 700–950: reapertura de rutas septentrionales y creación de comunidades marítimas permanentes en Islandia.

- 950: protectorado marítimo islandés pactado.

- 1050: primer protectorado groenlandés discontinuo.

- 1120–1150: incorporación pactista de Islandia con autonomía marítima; antecedente institucional del régimen federal moderno, sin proyectar sobre la Edad Media su Constitución de 1956.

- 1250–1500: disminución de la presencia groenlandesa por clima, aislamiento y dificultades de abastecimiento; no se considera una pérdida de soberanía absoluta, sino una administración intermitente.

- 1600–1800: recuperación de estaciones, cartografía y rutas polares.

- 1850: restablecimiento permanente de la administración groenlandesa.

- 1900–1945: ampliación de puertos, minería, aviación, meteorología y comunicaciones.

- 1945–1956: conversión de Groenlandia en territorio científico-militar ártico.

- 1956: reconocimiento constitucional de Islandia y Groenlandia en el régimen federal moderno; bases de radar, patrulla, investigación nuclear y cohetería. No constituye una segunda primera incorporación de Islandia.

- 1958–1969: conexión progresiva de ambos territorios con la Red Federal de Comunicaciones Marítimas y posteriormente con OceanNet.

- 2026: Islandia es un territorio marítimo productivo; Groenlandia, un territorio ártico estratégico, científico y minero.

### Cronología atlántica principal

- c. 150 a. C.: primer contacto documentado con el Caribe.

- 20–40 d. C.: descubrimiento de Tol Eressëa.

- 400–500: expediciones desde Tol Eressëa alcanzan Terranova.

- 650–750: descubrimiento de Valinor.

- 750–850: primeros asentamientos permanentes en Valinor y fundación inicial de Nueva Tirion.

- 920–980: asentamiento permanente de Númenor en Terranova.

### Cronología oriental resumida

- 930 a. C.: reconocimiento del Mediterráneo occidental.

- 706 a. C.: primer acceso a Egipto.

- 512 a. C.: exploración del mar Rojo.

- 438 a. C.: primer desembarco en Adén.

- 401 a. C.: descubrimiento de Socotra.

- 291 a. C.: reconocimiento de Musandam y Ormuz.

- 248 a. C.: descubrimiento de Baréin.

- 219 a. C.: primer contacto con Kuwait.

- 247 d. C.: Socotra se convierte en protectorado.

- 376: Yibuti entra en la red protectoral.

- 1536: Baréin se incorpora como Eryndor.

- 1611: Musandam se incorpora como Rhunost.

- 1958: integración de la red oriental en OceanNet.

- 2026: consolidación del sistema mediterráneo–Golfo–Índico.

### Origen geográfico de los primeros Valinari

Por decisión canónica, los primeros Valinari proceden de las comunidades humanas asentadas en las 14 subzonas históricas de Escania y en las 15 provincias noruegas. Estas comunidades forman la base demográfica, marítima y cultural de la población que posteriormente se organiza alrededor de Valinor.

Las 14 subzonas de Escania son: Helsingborg, Ängelholm–Båstad, Höganäs–Kullen, Kristianstad, Hässleholm, Osby–Östra Göinge, Bromölla, Ystad, Simrishamn, Tomelilla, Sjöbo–Skurup, Lund, Malmö y Trelleborg–Svedala–Vellinge.

Las 15 provincias noruegas de referencia son: Østfold, Akershus, Oslo, Innlandet, Buskerud, Vestfold, Telemark, Agder, Rogaland, Vestland, Møre og Romsdal, Trøndelag, Nordland, Troms y Finnmark.

La Casa Telcontar y sus primeros seguidores proceden específicamente de Helsingborg, en la Escania noroccidental. Las 24 Casas se forman posteriormente mediante la integración política de estas comunidades y sus linajes marítimos, costeros, agrícolas y comerciales.

Dinamarca queda reconocida como zona de procedencia de migración original hacia las comunidades valinarias, junto con Escania y Noruega. No forma parte de las 15 provincias noruegas ni de las 9 subzonas escanianas asignadas a las 24 Casas, y no constituye el origen fundacional de ninguna de las 25 Casas. Su función histórica es la de corredor migratorio, zona de contacto y fuente de familias integradas antes y durante la formación del Reino.

### Origen, migración y secuencia atlántica

La migración exterior original hacia las comunidades valinarias procede de Dinamarca, Escania y Noruega. Entre 1000 a. C. y 1000 d. C. las llegadas se producen por etapas, limitadas por partida, transporte, supervivencia, recepción, alimentos, agua y capacidad de asentamiento. No existe una cuota migratoria obligatoria ni una deuda demográfica acumulada.

La población se calcula distinguiendo población inicial, nacimientos, defunciones, entradas y salidas exteriores y movimientos internos. El contacto, el comercio, la transmisión de conocimientos y la presencia temporal no equivalen automáticamente a inmigración permanente.

La secuencia territorial vigente conserva: reconocimiento atlántico de Nosselië Toliva entre 900–750 a. C.; primer registro en 720 a. C.; primera presencia estacional en 680 a. C.; estación permanente en 620 a. C.; factoría en 540 a. C.; conexión atlántica en 430 a. C.; rutas africanas en 250 a. C.; primer contacto documentado con el Caribe en 150 a. C.; descubrimiento de Tol Eressëa en 20–40 d. C.; expediciones hacia Terranova entre 400–500; y descubrimiento de Valinor entre 650–750.

La Casa Telcontar y sus primeros seguidores proceden de Helsingborg. Las 24 Casas fundacionales proceden exclusivamente de las 15 provincias noruegas y 9 subzonas de Escania fijadas en la matriz nobiliaria. Dinamarca aporta migración y contactos, pero no una Casa fundacional.

##### Casas Menores de Exploración y Comercio

Las 24 Casas mayores reconocidas en 990 a. C. no son sustituidas por los linajes posteriores de las crónicas. Falastur, Círdanir, Ostor, Eärond, Voronwë, Meneldir, Thoron, Elentir, Lindor, Hallas, Gwindor, Aglaran, Tarond, Baranor, Celepharn, Maethor, Belegor, Duilin, Tumladen y Angren se clasifican como Casas Menores de Exploración y Comercio.

Estas Casas Menores proceden de las zonas originarias no asignadas a las 24 Casas mayores: Dinamarca, Götaland, Öland, Gotland, costas bálticas occidentales y las cinco subzonas restantes de Escania. Se incorporan además las Casas Erestor, Nimrodel, Falathar y Aerandir como M-21–M-24, procedentes respectivamente de Höganäs–Kullen, Simrishamn, Tomelilla y Sjöbo–Skurup. Sus funciones son la exploración, el comercio marítimo, la fundación de puertos, la cartografía, la traducción y la protección de convoyes.

No poseen asiento propio en el Consejo de las 24 Casas. Pueden estar subordinadas, aliadas o vinculadas por matrimonio a una Casa mayor. Sus miembros pueden recibir títulos de capitán, maestre de puerto, custodio de archivo, fundador de factoría o almirante de expedición.

Las Casas Menores son responsables de buena parte de los descubrimientos y establecimientos atlánticos tempranos, pero el descubrimiento de un territorio no implica por sí solo soberanía, incorporación ni creación de una nueva Casa mayor.

### Fragmentación, recuperación y memoria institucional

Las 24 Casas Mayores proceden de las 15 provincias noruegas y 9 subzonas escanianas fijadas en la matriz nobiliaria. Dinamarca aporta migración general, y Finlandia interviene en fases posteriores específicas; ninguna de ellas sustituye los orígenes fundacionales de esas 24 Casas. Esto no significa que toda la inmigración exterior del periodo fuera nórdica. Entre 1000 a. C. y 800 d. C. se fija una corriente no nórdica acumulada equivalente al 60 % de la corriente nórdica: comunidades germánicas continentales y de Europa oriental se incorporan principalmente a puertos, talleres, agricultura, navegación y comunidades mixtas, sin fundar las Casas Mayores ni incorporarse automáticamente a la ciudadanía de linaje. Las llegadas quedan limitadas por transporte, supervivencia, recepción, alimentos, agua, capacidad portuaria, conflictos y disponibilidad de asentamientos.

La población inicial, los nacimientos, las defunciones, las entradas y salidas exteriores y los movimientos internos se contabilizan por separado. El contacto, el comercio, la transmisión de conocimientos y la presencia temporal no equivalen automáticamente a inmigración permanente. La relación con la mortalidad de la Dinamarca de referencia puede utilizarse como hipótesis de planificación, pero no como regla canónica de llegadas.

En un periodo histórico aún pendiente de datación precisa, epidemias, interrupciones de abastecimiento, rivalidades y pérdida documental desarticulan ligas y rutas. La Fragmentación reduce capacidades locales sin borrar toda la memoria compartida. Algunas comunidades quedan aisladas; hogares, instituciones religiosas y redes de refugio sostienen la continuidad social, aunque también disputan recursos y autoridad.

La reconstrucción asociada a Sigrid Andersdotter se apoya en inventarios de pérdidas, testimonios, copias y memoria comunitaria. Sus métodos exigen contrastar usos y relatos y no interpretar la ausencia documental como ausencia automática de derechos.

Los Consejos de Recuperación vinculados a Björn Arnesen coordinan abastecimiento, reparación de rutas y financiación negociada. Sus mandatos responden a crisis concretas y no sustituyen al Consejo de las 24 Casas ni a los órganos posteriores. La cooperación religiosa presta refugio, educación y asistencia sin exigir uniformidad doctrinal.

La recuperación restaura producción, reparación, acuerdos locales, alfabetización y archivos. La publicidad de cuentas y los límites de mandato tienen alcance desigual; no implican controles perfectos. Los Consejos Atlánticos permanentes de 1135 y la posterior Administración Real de Oficinas pertenecen a etapas institucionales distintas y no deben confundirse con los Consejos de Recuperación.

### Relato fundacional de las Casas y la Marcha hacia Occidente

Entre las comunidades humanas de Dinamarca, Escania y Noruega se desarrolla una tradición marítima común. La migración danesa funciona como corredor de contacto y aporte demográfico, mientras que las 24 Casas fundacionales proceden de las 15 provincias noruegas y 9 subzonas de Escania establecidas en la matriz nobiliaria.

Durante el periodo anterior al Concilio de Forostar se combinan malas cosechas, tensiones comerciales, conflictos dinásticos y guerras entre Casas. En Escania surge Míriel Elerwen, posteriormente recordada como la Doncella de las Estrellas. Sus sueños y la aparición de una estrella occidental adquieren importancia religiosa y política, aunque la crónica distingue entre la interpretación de la visión y los hechos verificables de las expediciones.

La tradición conserva cinco imágenes de la Visión de Elerwen: un gran océano, costas verdes, islas remotas, un bosque sobre el mar y una montaña de fuego. Los cronistas posteriores las relacionan con la expansión atlántica hacia Galicia, Madeira, Azores, Canarias y el Teide. La visión no constituye por sí misma una prueba geográfica ni sustituye los registros de navegación.

El Juramento Occidental reúne a las Casas alrededor de cinco obligaciones: conservar la lengua, conservar la escritura, conservar la fe, conservar la memoria y seguir la estrella. El juramento explica la cohesión cultural, pero la autoridad política se formaliza después mediante el Consejo de las 24 Casas, la Corona electiva y el Pacto de Forlond.

La llamada Ley de Sangre y Memoria es una doctrina de continuidad genealógica y cultural. Exige conservar registros familiares, proteger la transmisión lingüística y someter los matrimonios entre linajes a reglas religiosas y civiles. No establece superioridad biológica, no convierte a las Casas en etnias cerradas y permite adopción, conversión e integración bajo condiciones jurídicas.

La expansión hacia el Atlántico se organiza mediante exploración, factorías, puertos, alianzas y asentamientos. Las denominaciones retrospectivas de Galicia, Portugal, Marruecos, Canarias, Madeira y Azores pertenecen a la tradición de los cronistas; sus nombres canónicos se registran según la regla primordial de nomenclatura urbana.

Lindor se incorpora como depósito documental y centro genealógico; Annúmin como centro temprano de astronomía, navegación y cartografía; y Annúminas Belegaer como capital naval histórica del Reino del Oeste. Ninguna de estas sedes sustituye a Nueva Tirion como capital de Valinor ni altera las capitales territoriales vigentes.

Las relaciones con poblaciones locales se describen mediante comercio, pactos, convivencia, conflicto e integración gradual. En Nosselië Toliva, el canon vigente no presupone poblaciones residentes anteriores al establecimiento valinario; las comunidades locales mencionadas por las crónicas son asentamientos y grupos organizados durante la expansión.

##### Tendencias fenotípicas de las Casas

Las características físicas de las Casas son tendencias poligénicas predominantes, no rasgos exclusivos ni genotipos obligatorios. Existe variación interna, matrimonios entre linajes y excepciones individuales. Los genes citados funcionan como referencias biológicas generales, no como marcadores deterministas.

- Noldor: rubio muy claro o platino, ojos azules, piel clara, pecas discretas, rostro anguloso y cabello liso.

- Vanyar: rubio platino, ojos celestes, piel muy clara, rostro fino y cabello liso.

- Teleri: rubio claro, ojos azules o gris azulados, piel clara, cabello ondulado y complexión atlética.

- Elwing: rubio ceniza, ojos celestes, piel clara con pecas, rostro anguloso y cabello ondulado.

- Círdan: rubio claro, ojos azul zafiro, piel clara adaptada al clima, cabello liso y complexión atlética.

- Mithlond: Cabello pelirrojo; ojos celestes; piel clara; pecas frecuentes y complexión robusta.

- Esgal: rubio ceniza, ojos azul grisáceos, piel clara con pecas y cabello ondulado.

- Calenhad: rubio claro a dorado, ojos azules o verdes claros, piel clara y cuerpo atlético.

- Fornost: Cabello pelirrojo; ojos celestes; piel clara; rostro anguloso y complexión fuerte.

- Annúminas: rubio claro, ojos celestes, piel clara, cabello liso y rostro simétrico.

- Alqualondë: rubio dorado, ojos azules o turquesa, piel clara, cabello ondulado y complexión marítima.

- Armenelos: rubio claro, ojos azul intenso, piel clara, pecas leves, cabello liso y rostro alargado.

- Eldalondë: rubio ceniza, ojos celestes, piel clara, cabello liso u ondulado y rasgos finos.

- Taur-en-Mor: rubio oscuro o ceniza, ojos azul grisáceos, piel clara con pecas y cuerpo robusto.

- Barad Calen: rubio dorado, ojos azules, piel clara, rostro anguloso, cabello liso y musculatura desarrollada.

- Dol Amroth: rubio claro, ojos azul zafiro, piel clara, cabello ondulado, nariz recta y complexión atlética.

- Pelargir: rubio claro a dorado, ojos azules o verdes claros, piel clara, cabello liso y rasgos cosmopolitas.

- Harlond: rubio ceniza, ojos azul grisáceos, piel clara, pecas moderadas, cabello liso y rostro fino.

- Minas Anor: rubio muy claro, ojos azul intenso, piel clara, rostro anguloso y cuerpo atlético.

- Eryn Lasgalen: rubio ceniza, ojos celestes o verde azulados, piel clara con pecas y cabello ondulado.

- Rhunost: rubio oscuro a claro, ojos azul grisáceos, piel clara, cabello liso y complexión resistente.

- Harnost: Cabello pelirrojo; ojos celestes; piel clara; pecas frecuentes; cabello ondulado y cuerpo atlético.

- Eressëa Menel: rubio platino o muy claro, ojos celestes, piel muy clara, rostro fino y cabello liso.

- Calenor: rubio claro, ojos azules o gris azulados, piel clara con pecas, cabello liso y complexión equilibrada.

- Telcontar: rubio claro a dorado, ojos azules o celestes, piel clara, cabello liso u ondulado, rostro anguloso y presencia atlética.

Las referencias poligénicas incluyen HERC2/OCA2 para pigmentación del iris; KITLG, IRF4, SLC24A4, TYRP1 y TPCN2 para pigmentación capilar; SLC24A5, SLC45A2, TYR y OCA2 para melanogénesis; MC1R para pecas; y EDAR, TCHH, KRT71 y FGFR2 para forma del cabello. El albinismo puede aparecer excepcionalmente en cualquier Casa, pero no es un rasgo nobiliario de ninguna de ellas.

##### Distribución originaria de las 24 Casas

La distribución fundacional es uno-a-uno: 15 Casas proceden de las provincias noruegas de referencia y 9 de subzonas de Escania. La Casa Telcontar no está incluida en esta distribución: aparece posteriormente como Casa Real número 25.

| Casa | Origen | Rasgo histórico dominante |
| --- | --- | --- |
| Noldor | Oslo | conocimiento, administración y archivos |
| Vanyar | Vestland | fiordos, navegación y tradición ceremonial |
| Teleri | Møre og Romsdal | navegación, pesca y construcción naval |
| Elwing | Nordland | islas, exploración y rutas septentrionales |
| Círdan | Troms | astilleros, navegación polar y defensa marítima |
| Mithlond | Finnmark | puertos extremos, vigilancia y comercio ártico |
| Esgal | Innlandet | bosques, lagos y rutas interiores |
| Calenhad | Agder | agricultura costera, defensa y navegación meridional |
| Fornost | Buskerud | montañas, fortificaciones y minería |
| Annúminas | Akershus | administración, fiordos interiores y gobierno |
| Alqualondë | Rogaland | grandes puertos, comercio y armada |
| Armenelos | Østfold | agricultura fértil, ciudades y artesanía |
| Eldalondë | Trøndelag | asambleas, agricultura y corredor central |
| Taur-en-Mor | Telemark | bosques, valles y recursos forestales |
| Barad Calen | Vestfold | costa, defensa y producción naval |
| Dol Amroth | Helsingborg | estrecho, puerto y diplomacia marítima |
| Pelargir | Malmö | comercio internacional y administración portuaria |
| Harlond | Lund | educación, escritura y derecho marítimo |
| Minas Anor | Kristianstad | fortificación, agricultura y defensa interior |
| Eryn Lasgalen | Osby–Östra Göinge | bosques, lagos y frontera forestal |
| Rhunost | Bromölla | corredor costero y defensa del Báltico |
| Harnost | Ystad | navegación báltica y comercio oriental |
| Eressëa Menel | Ängelholm–Båstad | observación celeste y navegación costera |
| Calenor | Hässleholm | caminos interiores, agricultura y administración local |

La Casa Telcontar y sus primeros seguidores proceden de Helsingborg y se vinculan posteriormente con la tradición de Dol Amroth, pero la Casa Real no forma parte de las 24 Casas fundacionales ni recibe un voto adicional.

##### Tol Eressëa

- Centro: 35,8188° N, 42,4778° O.

- Vértices: 36,42° N, 43,35° O; 36,58° N, 42,10° O; 36,05° N, 41,55° O; 35,20° N, 41,72° O; 34,78° N, 42,38° O; 34,92° N, 43,18° O; 35,55° N, 43,48° O.

- Ciudades: Eldalondë (35,90° N, 42,50° O); Avallónë (35,75° N, 42,35° O).

- Avallónë es la capital de Tol Eressëa y su principal puerto y centro administrativo. Eldalondë permanece como ciudad principal secundaria.

##### Systreyjar

- Referencia territorial: 45,00° N, 25,00° O.

- Taur-en-Mor: 45,20° N, 24,80° O.

- Esta referencia identifica el territorio como unidad atlántica; no constituye un polígono jurídico adicional.

##### Nosselië Toliva (Canarias)

- Referencia territorial: 28,30° N, 15,50° O.

- Eressëa (Las Palmas): 28,10° N, 15,40° O.

- Caladhrim (Santa Cruz de Tenerife): 28,46° N, 16,25° O.

- Forma parte de Aranath Valinor y, por medio del Reino constituyente, de Gwaith Valinor. No es una adición federal externa ni un miembro federal directo.

Estas coordenadas son datos textuales del canon. No autorizan por sí solas nuevos mapas, fronteras políticas ni polígonos para territorios que aquí solo tienen un punto de referencia.

### Magallanes y Andúnië Austral

Estado: [CANON VIGENTE] — incorporación del 30 de octubre de 2026.

Dentro de la alianza entre Chile y Gwaith Aear, el estrecho de Magallanes se consolida como uno de los principales nodos científicos, antárticos y marítimos de la Unión.

##### Andúnië Austral

- Ubicación: Región de Magallanes y de la Antártica Chilena, en el entorno real del estrecho de Magallanes.

- Estatus: ciudad científica federal arrendada bajo soberanía chilena.

- Población: aproximadamente 1,1 millones.

- PIB PPA: 0,15–0,20 billones.

- Urbanización: superior al 90 %.

Chile conserva la soberanía territorial. Andúnië Austral no es una anexión, colonia ni provincia chilena; es una concesión científica, portuaria y logística de largo plazo vinculada a Gwaith Aear.

##### Funciones

- oceanografía austral;

- meteorología antártica;

- glaciología;

- astronomía;

- cartografía submarina;

- vigilancia sísmica y volcánica;

- biología marina;

- expediciones antárticas;

- protección de cables submarinos;

- búsqueda y rescate;

- reparación de buques científicos;

- apoyo logístico austral.

##### Infraestructura

Andúnië Austral cuenta con puerto científico de aguas profundas, astilleros de investigación, aeropuerto internacional, observatorio astronómico, centro OceanNet, radares Palantír-4D, laboratorios polares, hospital austral, almacenes de emergencia y terminal antártica.

La Armada mantiene allí patrulleros Forlond, buques oceanográficos, buques hospital Estë, transportes Rómenna, remolcadores Vingilot y drones submarinos Abyssal. La base prioriza ciencia, rescate, vigilancia y apoyo antártico, no operaciones ofensivas.

##### Alcance territorial

El canon no establece que Chile haya conquistado Mendoza ni Neuquén. Ambas provincias permanecen fuera de Chile y fuera de los territorios valinorianos. La alianza chilena y el arrendamiento de Andúnië Austral no modifican las fronteras argentinas.

### Retcon histórico — Gran Guerra del Pacífico, 1879–1886

Estado: [CANON VIGENTE — RETCON AUTORIZADO] — incorporación del 30 de octubre de 2026.

La Guerra del Pacífico se amplía a un conflicto continental entre 1879 y 1886. Chile recibe apoyo financiero, tecnológico y logístico de la Unión Valinoriana, pero no tropas federales ni una declaración de guerra valinoriana.

##### Antecedentes y primera guerra

- 1848: Tratado de Valparaíso entre Chile y la Unión Valinoriana.

- 1876: Pacto del Pacífico Austral; cooperación naval, formación de oficiales, seguros, astilleros y logística.

- 1879: crisis por impuestos y concesiones en Antofagasta; Chile ocupa la ciudad y Perú activa su alianza defensiva con Bolivia.

- 1879–1880: campaña naval, ocupación de Antofagasta y captura anticipada del Huáscar.

- 1880: caída de Tarapacá; campañas de Tacna y Arica.

- 1881: desembarcos y caída de Lima tras Chorrillos y Miraflores.

- 1882–1883: resistencia peruana en la sierra y agotamiento boliviano.

##### Internacionalización

Argentina teme una hegemonía chilena sobre el Pacífico sur, los accesos australes y la cordillera. Entre 1881 y 1883 aumenta fortificaciones, movilización y apoyo indirecto a Perú y Bolivia. En 1884 inicia la Operación de Garantía Continental, una intervención limitada para impedir la desaparición de Bolivia y contener la hegemonía chilena.

Valinor mantiene apoyo financiero y técnico a Chile, pero no despliega divisiones federales. Brasil y las potencias europeas permanecen fuera del conflicto.

##### Campañas contra Argentina

- 1884–1885: campaña andina en Icalma, Pino Hachado y Mamuil Malal.

- 1885: batalla de Zapala; Chile controla los accesos occidentales de Neuquén sin ocupar toda la provincia.

- 1885: batalla de Uspallata; Chile controla pasos y alturas de la alta cordillera mendocina, pero no conquista Mendoza capital.

- 1885: batalla de Río Gallegos; Chile ocupa la ciudad y consolida el control del extremo austral.

La estrategia chilena busca pasos, corredores, puertos y posiciones defendibles, no la anexión completa de Neuquén o Mendoza.

##### Tratado de Nueva Tirion, 1886

Bolivia transfiere a Chile: Antofagasta, Cobija, Mejillones, Tocopilla y la Puna de Atacama.

Perú transfiere a Chile: Arica, Tacna y Mollendo. Arequipa y Puno permanecen peruanas.

Argentina transfiere a Chile: Tierra del Fuego completa; Santa Cruz meridional y un corredor austral conectado con Magallanes; Neuquén occidental, incluyendo San Martín de los Andes, Junín de los Andes, Aluminé y Zapala; y la alta cordillera mendocina, incluidos Uspallata, Las Cuevas y los principales pasos.

Mendoza capital y la mayor parte de Neuquén permanecen argentinas. Vaca Muerta y la totalidad de la cuenca neuquina no son objetivos conocidos en 1886; su importancia energética posterior se convierte en una causa de tensión histórica duradera.

##### Consecuencias

Chile se transforma en la principal potencia marítima del Pacífico suroriental. Controla el litoral minero del norte, los corredores australes, Magallanes y las rutas hacia la Antártida. La doctrina militar chilena queda resumida como:

El dominio marítimo decide las guerras terrestres del Pacífico.

La guerra consolida la relación chileno-valinoriana y prepara la creación posterior de Andúnië Austral como ciudad científica y puerto federal arrendado bajo soberanía chilena.

### Consolidación canónica — Guerra del Pacífico ampliada

Estado: [CANON VIGENTE — RETCON CONSOLIDADO] — 30 de octubre de 2026.

La versión detallada de la Guerra del Pacífico sustituye cualquier formulación anterior que presentara la entrada argentina después de la derrota definitiva de Perú y Bolivia. En el canon vigente, Argentina interviene mientras la guerra aún está abierta.

##### Secuencia consolidada

- 1848–1879: Valinor financia ferrocarriles, puertos, diques secos, telégrafos, seguros, acero, maquinaria, repuestos y formación de oficiales chilenos.

- 1879: Chile ocupa Antofagasta; Perú activa su alianza defensiva con Bolivia.

- 1879–1880: Chile obtiene supremacía naval y captura anticipadamente el Huáscar.

- 1880–1881: Chile conquista Tarapacá, Tacna y Arica, y ocupa Lima.

- 1882–1883: Perú resiste en la sierra; Bolivia queda militarmente agotada.

- 1883: Buenos Aires decide intervenir antes de la derrota definitiva de Perú y Bolivia para impedir una hegemonía chilena sobre el Pacífico sur.

- 1884: Argentina inicia la Operación de Garantía Continental y se convierte en tercer adversario de Chile.

- 1884–1885: Operación Cordillera Oriental; columnas chilenas cruzan Icalma, Pino Hachado y Mamuil Malal.

- 1884: batalla de Aluminé y caída de Junín de los Andes.

- Marzo de 1885: batalla de Zapala; Chile controla los accesos occidentales de Neuquén.

- 1885: batalla de Uspallata; Chile ocupa pasos y alturas de la alta cordillera mendocina.

- Finales de 1885: control chileno de Las Cuevas, Portillo y los principales pasos internacionales.

- 1885: batalla de Río Gallegos y consolidación del frente austral.

- 1886: colapso de la coalición; Argentina combate prácticamente sola.

- 1886: Tratado de Nueva Tirion y final de la guerra continental.

##### Resultado territorial consolidado

Chile incorpora el litoral boliviano, Arica, Tacna, Mollendo, Tierra del Fuego, Santa Cruz meridional, Neuquén occidental y la alta cordillera mendocina. Mendoza capital y la mayor parte de Neuquén permanecen argentinas.

La guerra no se interpreta como una conquista valinoriana. La Unión aporta crédito, tecnología, inteligencia hidrográfica, seguros, formación y logística, pero no despliega tropas federales ni declara la guerra.

La doctrina chilena posterior queda fijada como: el dominio marítimo decide las guerras terrestres del Pacífico. La importancia energética posterior de la cuenca neuquina transforma retrospectivamente las cesiones de 1886 en uno de los principales giros geopolíticos de Sudamérica.

### Red histórica ampliada de enclaves y posiciones asociadas

La expansión exterior se desarrolló mediante reconocimiento, escalas, factorías, tratados portuarios, protectorados limitados, concesiones navales y estaciones científicas. La red ampliada comprende Eärendil, Tol Morwen, Nandor Occidental, Tol Eressëa Occidental, Barad Nimras, Eressëa Índica, Nanduhirion, Harlond Caribe, Forlond Austral y Amon Uilos. Se separan territorios federales, protectorados, puertos asociados, redes de acuerdos y estaciones arrendadas.

La secuencia histórica es: reconocimiento y navegación entre 900 a. C. y 1200 d. C.; factorías y puertos entre 1200 y 1600; concesiones navales y protectorados limitados entre 1600 y 1900; nodos tecnológicos, científicos y militares entre 1900 y 2026. Desde 1958, la red se integra progresivamente en OceanNet.

### Integración del comercio mediterráneo y la circulación del conocimiento

El comercio mediterráneo se incorpora como proceso histórico gradual entre c.1000 a. C. y 2026. Las primeras fases consisten en intercambio indirecto, intermediación, aprendizaje técnico y circulación de bienes; no prueban factorías, conquistas ni soberanía valinari. Desde la Antigüedad tardía, las redes bizantinas, islámicas, magrebíes, ibéricas e italianas amplían la circulación de manuscritos, especialistas, instrumentos, técnicas y prácticas administrativas.

La red moderna distingue puertos asociados, protectorados, enclaves científicos, bases arrendadas y estaciones de OceanNet. Alqualondë, Eglarest y Pelargir son puertos asociados; Barad Nimras (Gibraltar) es una base arrendada desde 1815; Nandor Occidental (Bijagós) es una red de acuerdos marítimos. Las demás posiciones se rigen por sus fichas territoriales V16.

OceanNet deriva de redes precursoras entre 1954 y 1958, comienza su funcionamiento operativo inicial en 1959, se expande entre 1960 y 1968, se institucionaliza desde 1969, adopta un protocolo federal común en 1983 y alcanza su forma digital general entre 2000 y 2026.

### Incorporación de Esgal Nénar

Esgal Nénar (corredor del río Gambia y Casamance) se incorpora como protectorado fluvial y portuario de Beleg Valinor desde aproximadamente 950 d.C. Conserva administración local; Valinor coordina defensa exterior, puertos, navegación, comunicaciones y arbitraje comercial. En 2026 cuenta con 11,5 millones de habitantes y un PIB PPA estimado de 0,52 billones de dólares. Sus cifras se incluyen en el agregado operativo de Gran Valinor, pero no en la población ni en el PIB constitucional de Gwaith Valinor.

Esgal Nénar aporta 11,5 millones y 0,52 billones PPA fuera del ámbito constitucional. Beleg conserva el rango rector 724,5–879,5 millones y 73,35–93,75 billones PPA. La cuenta identificada suma 535 millones y 66,02 billones; el residuo es 189,5–344,5 millones y 7,33–27,73 billones. Harnen se cuenta una vez, según A092-R04.

### Comercio valinari temprano, 1000–500 a. C.

Durante este periodo, el comercio valinari se organiza como una red marítima regional. No existe todavía un sistema imperial ni una presencia estable en el Mediterráneo; la economía depende de puertos, mercados estacionales, rutas costeras y pactos entre comunidades.

##### Eje de Escania

Escania constituye el principal núcleo comercial y demográfico valinari. Sus puertos conectan el Øresund, el Kattegat, el Báltico occidental, las costas noruegas, Dinamarca y el mar del Norte. Helsingborg controla el paso del Øresund; Lund concentra administración, culto e intercambio terrestre; Malmö articula el mercado meridional; Ystad y Simrishamn sirven a la navegación báltica; Kristianstad, Åhus y Bromölla canalizan cereales, sal, madera y productos fluviales; Trelleborg y Falsterbo conectan con Dinamarca y el mar del Norte.

Escania exporta cereales, pescado conservado, pieles, madera, cerámica, herramientas y textiles. Importa metales, ámbar, ganado, sal y bienes de prestigio.

##### Rutas noruegas y danesas

Noruega aporta marineros, madera, hierro, pieles, aceite, pescado seco y conocimiento náutico. Las rutas parten del Oslofjord, Vestfold, Østfold, Rogaland, Hordaland, Sogn, Møre y Trøndelag. Las comunidades septentrionales participan de forma más limitada y proporcionan pieles, pescado, grasa animal y productos árticos.

Dinamarca desempeña el papel de corredor marítimo, fuente de migración y zona de intermediación entre el Báltico y el mar del Norte. No es territorio valinari ni origen fundacional de una Casa Mayor: su función es la de espacio de contacto, tránsito, matrimonios y llegada de familias integradas a las comunidades valinarias.

##### Báltico, mar del Norte y Atlántico

El Báltico es el principal espacio de expansión comercial temprana. Las rutas alcanzan Bornholm, Gotland, Öland, las costas bálticas de Suecia, el golfo de Finlandia y las costas orientales. Se intercambian ámbar, pieles, cera, miel, madera, hierro, pescado y otros bienes regionales.

El mar del Norte permite contactos con las costas germánicas, Frisia, las islas británicas y el norte de Francia. En esta fase los contactos son principalmente comerciales y no constituyen una política de conquista sistemática. Hacia el oeste se desarrolla una exploración costera gradual del Atlántico nororiental, condicionada por el clima, la navegación y la seguridad de los puertos.

##### Mediterráneo conocido de forma indirecta

El Mediterráneo forma parte del horizonte geográfico e intelectual valinari, pero no de su espacio político o colonial durante 1000–500 a. C. Su conocimiento llega por mercancías, relatos de comerciantes daneses, germánicos y atlánticos, objetos de lujo, metales trabajados, cerámicas y rutas terrestres o fluviales europeas.

No existen en esta etapa puertos valinari permanentes en el Mediterráneo, enclaves diplomáticos estables, provincias mediterráneas, control de Gibraltar ni redes comerciales directas y continuas con Egipto, Fenicia, Grecia, Italia o el Levante. Los contactos mediterráneos posteriores se desarrollan gradualmente y no deben proyectarse retrospectivamente sobre la primera organización valinari.

##### Instituciones comerciales

El intercambio se estructura mediante mercados locales, ferias regionales, rutas de larga distancia y pactos portuarios. Estos últimos regulan derechos de atraque, tasas, reparación de barcos, protección de comerciantes, neutralidad temporal, devolución de mercancías y seguridad de almacenes.

Las Casas Mayores controlan recursos y rutas interiores. Las Casas Menores se especializan en navegación, exploración, cartografía, traducción, fundación de factorías y protección de convoyes. Las Casas Vasallas todavía no forman una estructura plenamente desarrollada; sus antecedentes aparecen como capitanías, administradores portuarios, ramas matrimoniales y comunidades asociadas.

##### Evolución del periodo

- 1000–990 a. C.: crisis de las comunidades originarias, fragmentación de rutas y competencia por alimentos, puertos y metales.

- 990–950 a. C.: el Concilio de Forostar protege mercados, almacenes y puertos neutrales.

- 950–850 a. C.: recuperación de las rutas entre Escania, Noruega, Dinamarca y el Báltico occidental.

- 850–750 a. C.: expansión hacia el mar del Norte y aparición de factorías temporales.

- 750–700 a. C.: reconocimiento sistemático de las islas atlánticas orientales.

- 700–600 a. C.: crisis de abastecimiento y aumento de la dependencia de pactos de protección.

- 600–550 a. C.: retorno de la Casa Telcontar desde su autoexilio finlandés y reorganización de rutas.

- 550–500 a. C.: el pacto de 550 a. C. subordina la coordinación comercial a la Corona, conservando derechos portuarios de las Casas.

La estructura comercial de 1000–500 a. C. es marítima, regional, descentralizada y dependiente de puertos y pactos. Constituye la base de la expansión atlántica posterior sin convertir a Valinor en una potencia transcontinental prematura.

### Secuencia atlántica septentrional y descubrimiento de Valinor

##### Salida definitiva de Escania y evolución hasta 50 d. C.

La salida valinaria de Escania no fue un éxodo único ni implicó el abandono total de la población local. Entre 1000 y 990 a. C. comenzó la migración de comunidades procedentes de las subzonas históricas de Escania y de las provincias noruegas. Entre 990 y 850 a. C., las Casas fundacionales establecieron asentamientos, santuarios, puertos y redes de parentesco en las costas del Báltico, Dinamarca, Noruega y el mar del Norte.

Entre 850 y 700 a. C. el centro político, económico y naval se desplazó gradualmente hacia las rutas occidentales. La riqueza procedente del comercio marítimo, la fundación de puertos y la aparición de archivos exteriores redujeron la dependencia institucional de Escania.

Hacia 650 a. C., Escania dejó definitivamente de ser el centro político y demográfico principal de las Casas. Este hito no significa despoblamiento ni desaparición de las comunidades escanianas. La región conservó santuarios, propiedades, ramas familiares, cementerios, rutas comerciales y memoria genealógica. Helsingborg permaneció como origen ancestral particular de la Casa Telcontar.

##### Espacios de desarrollo valinari, 650 a. C.–50 d. C.

El desarrollo valinari se produjo en una red de regiones conectadas, no en un único territorio. Cada espacio cumplió una función diferente.

##### Escania

Escania fue la patria ancestral de las Casas y el principal centro de memoria genealógica. Tras 650 a. C. dejó de ser el centro político, pero mantuvo:

- santuarios ancestrales;

- propiedades de las Casas;

- cementerios y archivos familiares;

- talleres metalúrgicos;

- puertos de reclutamiento;

- vínculos matrimoniales;

- intercambio de marinos y artesanos.

Helsingborg conservó una importancia particular para Telcontar. Lund y Ystad funcionaron como centros de intercambio, escritura, religión y navegación regional.

##### Noruega

Las comunidades noruegas aportaron madera, hierro, pieles, pescado, grasa animal, conocimiento de fiordos y técnicas de navegación en mares fríos. Los principales espacios de desarrollo fueron:

- Oslofjord: administración, comercio y construcción naval;

- Vestfold y Østfold: agricultura, astilleros y navegación costera;

- Rogaland y Hordaland: marinería, pesca y rutas del mar del Norte;

- Sogn y Møre: navegación de fiordos, madera y exploración septentrional;

- Trøndelag: hierro, ganadería y conexión con las rutas árticas.

Noruega no fue solo una fuente migratoria: se convirtió en una reserva permanente de marinos, materias primas y conocimiento náutico.

##### Dinamarca

Dinamarca actuó como territorio de tránsito y conexión entre el Báltico, el mar del Norte y las rutas continentales. Sus funciones fueron:

- transporte de personas y mercancías;

- intercambio con comunidades germánicas y atlánticas;

- acceso a ríos europeos;

- construcción de embarcaciones ligeras;

- intermediación comercial;

- transmisión de noticias mediterráneas.

La migración danesa forma parte del origen histórico de las comunidades valinari, pero ninguna de las 24 Casas Mayores procede exclusivamente de Dinamarca.

##### Báltico y mar del Norte

El Báltico proporcionó ámbar, madera, pieles, pescado, metales y rutas de cabotaje. El mar del Norte permitió conectar Escania, Noruega, Dinamarca, las islas británicas y las costas atlánticas.

En esta región se desarrollaron:

- navegación de corta y media distancia;

- sistemas de señales;

- puertos defensivos;

- almacenes de grano;

- mercados estacionales;

- primeras redes de convoy;

- escuelas prácticas de navegación.

##### Systreyjar

Systreyjar se convirtió en un centro insular de escala y coordinación marítima. Su importancia se basó en:

- posición entre el mar del Norte y el Atlántico;

- puertos naturales;

- reparación de barcos;

- observación meteorológica;

- almacenamiento de agua y alimentos;

- formación de pilotos;

- conexión con las rutas occidentales.

Hacia 50 d. C. Systreyjar formaba parte del núcleo político-marítimo valinari.

##### Nosselië Toliva (Canarias)

Nosselië Toliva actuó como escala atlántica oriental y como punto de conexión con África y las rutas mediterráneas. Durante este periodo se desarrollaron:

- agricultura subtropical;

- pesca;

- depósitos de agua;

- reparación naval;

- observación astronómica;

- intercambio con el litoral africano;

- navegación hacia el Atlántico sur.

Su posición permitió que las técnicas mediterráneas y norteñas confluyeran antes de la expansión oceánica septentrional.

##### Mediterráneo occidental y central

El Mediterráneo se desarrolló como espacio de intercambio, no como territorio de colonización directa. Sicilia, Malta, Chipre, Creta, el Egeo, Egipto, Alejandría y las ciudades levantinas fueron centros de:

- comercio;

- traducción;

- medicina;

- astronomía;

- matemáticas;

- derecho mercantil;

- construcción naval;

- administración;

- conservación documental.

Las factorías y estaciones valinari fueron pequeñas y dependieron de acuerdos con autoridades locales. No alteraron la soberanía de las ciudades mediterráneas.

##### Egipto y el mar Rojo

Egipto conectó las rutas mediterráneas con África, Arabia y el océano Índico. El delta del Nilo y Alejandría proporcionaron:

- centros de traducción;

- conocimientos hidráulicos;

- medicina;

- astronomía;

- calendarios;

- administración fiscal;

- rutas caravaneras.

Desde Egipto se exploró el mar Rojo y posteriormente el Bab el-Mandeb, Adén y Socotra. En 50 d. C. esta red era comercial y científica, no un dominio territorial continuo.

##### Tol Eressëa

Descubierta entre 20 y 40 d. C., Tol Eressëa fue el primer gran asentamiento oceánico occidental de los Valinari. Sus primeras instalaciones incluyeron:

- puerto de abrigo;

- estación de agua;

- almacenes;

- taller de reparación;

- observatorio;

- santuario marítimo;

- archivo de navegación.

Tol Eressëa se desarrolló como comunidad insular autónoma y como puente hacia la exploración de Groenlandia. No era todavía una provincia plenamente integrada ni formaba parte de una estructura territorial que incluyera Valinor.

##### Organización política, administrativa y territorial

Entre 650 a. C. y 50 d. C. la organización valinari no constituye todavía un Estado territorial uniforme. Es una monarquía pactista y marítima formada por dominios de Casas, comunidades rurales, ciudades portuarias, santuarios, estaciones navales y rutas protegidas.

##### Niveles de autoridad

Familia y aldea. La unidad básica es el hogar ampliado, vinculado a una aldea, granja, taller o comunidad pesquera. Administra tierras de uso familiar, obligaciones laborales, almacenamiento de alimentos y protección local. Los conflictos menores se resuelven mediante costumbre, mediación familiar o autoridad del santuario.

Comunidad y distrito. Varias aldeas forman una comunidad territorial. Sus representantes organizan caminos, graneros, turnos de vigilancia, mantenimiento de embarcaciones, reparto de agua y contribuciones. El distrito puede estar bajo una Casa Mayor, una Casa Menor o una autoridad religiosa reconocida.

Santuario. Los santuarios cumplen funciones religiosas, jurídicas, educativas y documentales. Registran nacimientos, matrimonios, defunciones, pactos, deudas, tierras, genealogías y juramentos. También actúan como lugares neutrales durante disputas entre Casas.

Dominio de Casa. Cada Casa administra un conjunto de tierras, aldeas, talleres, graneros, puertos menores y caminos. El dominio no es propiedad absoluta de la Casa: está condicionado por obligaciones de protección, justicia, abastecimiento y respeto a los pactos.

Ciudad portuaria. Las ciudades portuarias tienen estatutos propios. Se organizan mediante un gobernador o magistrado, un consejo mercantil, representantes de las Casas, autoridades religiosas y funcionarios de la Corona. Regulan:

- entrada y salida de naves;

- impuestos portuarios;

- almacenes;

- pesos y medidas;

- tribunales mercantiles;

- seguridad;

- contratación de tripulaciones;

- reparación naval;

- cuarentenas;

- protección de extranjeros.

Estación o factoría. Las estaciones exteriores son asentamientos limitados, no provincias. Pueden incluir almacén, muelle, santuario, taller, residencia de agentes y pequeña guarnición. Su autoridad deriva de un tratado, concesión real o acuerdo con una comunidad local.

Red marítima. Los puertos y estaciones se agrupan en redes de navegación. La Corona coordina convoyes, suministros, señales, pilotos, reparaciones y defensa. Una red puede atravesar varios dominios sin convertirlos en una unidad territorial única.

##### La Corona

La Corona Telcontar se consolida como autoridad de coordinación superior, no como administración directa de cada comunidad. Sus competencias principales son:

- arbitraje entre Casas;

- defensa exterior;

- protección de rutas;

- acuñación o validación monetaria;

- tratados internacionales;

- registro de puertos;

- custodia de archivos estratégicos;

- regulación de convoyes;

- reconocimiento de nuevos asentamientos;

- garantía de graneros y santuarios neutrales.

La Corona no puede confiscar arbitrariamente tierras de las Casas ni imponer tributos sin pacto. Su legitimidad depende de preservar rutas, mercados, santuarios, cosechas, seguridad y continuidad documental.

##### Consejo de las Casas

El Consejo de las Casas representa a las Casas Mayores y, progresivamente, a Casas Menores y autoridades portuarias. Sus funciones son:

- aprobar contribuciones extraordinarias;

- ratificar guerras importantes;

- validar sucesiones disputadas;

- negociar matrimonios políticos;

- resolver conflictos territoriales;

- supervisar la defensa común;

- establecer normas para puertos neutrales;

- reconocer nuevos dominios.

La participación no es democrática en sentido moderno. La representación depende de rango, riqueza, antigüedad, población, función militar y control de rutas. Sin embargo, los acuerdos requieren negociación y la Corona no gobierna de forma absoluta.

##### Administración fiscal

La fiscalidad se organiza por obligaciones diferenciadas:

- contribución de grano;

- servicio naval;

- servicio militar;

- mantenimiento de caminos;

- tasas portuarias;

- contribución de talleres;

- alojamiento de funcionarios y tripulaciones;

- aportes extraordinarios para expediciones.

Las cargas se registran en santuarios, archivos de Casa y oficinas portuarias. En los territorios centrales se utilizan medidas estandarizadas, pero las regiones exteriores conservan prácticas locales.

##### Administración militar

La fuerza militar se divide en:

- guardias de las Casas;

- milicias rurales;

- guarniciones portuarias;

- convoyes armados;

- patrullas costeras;

- ingenieros de fortificación;

- tripulaciones de la Corona;

- exploradores y pilotos.

La Corona puede convocar fuerzas comunes, pero la mayor parte de los efectivos continúa vinculada a las Casas. Las campañas exteriores requieren pactos de financiación y reparto de botín, suministros y responsabilidades.

##### Clasificación territorial en 50 d. C.

En 50 d. C. los territorios se clasifican de la siguiente manera:

| Categoría | Ejemplos | Situación política |
| --- | --- | --- |
| Patria ancestral | Escania, Helsingborg | Fuera del centro político, pero vinculada por memoria, propiedades y parentesco |
| Núcleo administrado | Systreyjar, Nosselië Toliva | Bajo autoridad valinaria directa y pactista |
| Dominio de Casa | Tierras agrícolas, talleres y puertos menores | Administrado por una Casa bajo obligaciones reales |
| Puerto asociado | Sicilia, Malta, Chipre, Alejandría | Autoridad local conservada; acuerdos comerciales y navales |
| Factoría | Estaciones mediterráneas y del mar Rojo | Presencia limitada, almacenes y agentes |
| Estación oceánica | Tol Eressëa | Comunidad insular temprana en 50 d. C.; descubrimiento 20–40. A092-R01. |
| Ruta reconocida | Groenlandia futura, costas americanas futuras | Sin soberanía ni administración permanente |
| Territorio no incorporado | Númenor, Arnor, América continental, Valinor | Fuera del dominio territorial valinario |

##### Principio de no proyección territorial

Una ruta, una escala, un tratado o una factoría no convierten automáticamente un territorio en provincia. La incorporación exige población permanente, administración reconocida, abastecimiento, defensa, registro legal y aceptación de una autoridad política. Este principio evita proyectar las fronteras federales de 2026 sobre el periodo antiguo.

##### Desarrollo operativo de la administración

El Consejo de las Casas actúa como una asamblea pactista de Casas Mayores, Casas Menores, autoridades portuarias, custodios de santuarios, escribas y representantes de comunidades productivas. Ratifica al monarca, aprueba guerras importantes, valida sucesiones, autoriza tributos extraordinarios, resuelve disputas territoriales y reconoce nuevos dominios. No es un parlamento moderno y su representación depende de rango, antigüedad, riqueza, población, función militar y control de rutas.

La fiscalidad combina grano, ganado, hierro, madera, sal, pescado seco, textiles, caballos, trabajo, servicio naval, servicio militar y tasas portuarias. Los puertos recaudan por entrada de naves, almacenamiento, reparación, tránsito, protección de convoyes, uso de muelles y arbitraje comercial. Los ingresos se distribuyen entre ciudad, Casa y Corona según pactos registrados en santuarios y archivos.

Las ciudades portuarias poseen fueros propios. Un magistrado, un consejo mercantil, representantes de las Casas, un comandante portuario, un custodio del santuario, escribas fiscales y representantes de artesanos regulan comercio, seguridad, cuarentenas, contratación de tripulaciones, pesos, medidas y tribunales mercantiles. La ciudad no es completamente independiente ni una posesión privada absoluta de una Casa.

Las Casas conservan autonomía sobre tierras, aldeas, talleres, graneros, caminos locales, escuelas, santuarios familiares, tropas y puertos menores. Sus límites son el respeto a los santuarios neutrales, los graneros comunes, los convoyes reales, los prisioneros, los mensajeros y la prohibición de iniciar guerras generales sin autorización.

La fuerza militar se divide entre guardias de las Casas, milicias rurales, guarniciones portuarias, convoyes armados, patrullas costeras, ingenieros, tripulaciones reales y exploradores. La Corona controla directamente las flotas de largo alcance, la guardia real, las fuerzas de intervención, los ingenieros navales y las estaciones exteriores; las campañas requieren contribuciones pactadas de las Casas.

La clasificación territorial vigente para 50 d. C. distingue patria ancestral, núcleo administrado, dominio de Casa, ciudad portuaria, puerto asociado, factoría, estación marítima, comunidad exploratoria y territorio reconocido. Escania es patria ancestral; Systreyjar y Nosselië Toliva son núcleos administrados; Tol Eressëa es comunidad oceánica autónoma; Sicilia, Malta, Chipre y Alejandría son puertos asociados o factorías; Groenlandia, Númenor, Arnor, América continental y Valinor son territorios aún no incorporados.

Una ruta, escala, tratado o factoría no convierte automáticamente un territorio en provincia. La incorporación exige población permanente, administración reconocida, abastecimiento, defensa, registro legal y aceptación política. Las categorías de Estado federal, provincia autónoma, ciudadanía federal y ministerio no deben proyectarse sobre la Antigüedad.

##### Espacios aún no desarrollados en 50 d. C.

En esta fecha todavía no se habían desarrollado como territorios valinari estables:

- Groenlandia, conocida solo después de 55–75 d. C.;

- Númenor/Terranova: expediciones en 400–500 d. C. y asentamiento permanente en 920–980, según la cronología maestra.

- Arnor y la América continental, incorporados en fases posteriores;

- Valinor: descubrimiento formal en 650–750 d. C. y primeros asentamientos permanentes en 750–850.

- las islas del Pacífico y Malaca como unidades federales.

La expansión posterior parte de esta red previa de conocimientos, puertos y comunidades, pero no debe proyectar sus fronteras modernas sobre el periodo antiguo.

Entre 650 y 550 a. C., las Casas organizaron una red marítima compuesta por puertos, graneros, talleres, astilleros, santuarios y depósitos documentales. El pacto de 550 a. C. consolidó la Corona Telcontar sobre una sociedad ya desplazada hacia sus territorios occidentales, sin borrar el origen escaniano y noruego de las Casas.

Entre 550 y 300 a. C., la Corona estabilizó las rutas del mar del Norte, el Atlántico oriental y el Mediterráneo. Se desarrollaron escuelas portuarias, registros de navegación, convoyes, factorías y acuerdos de protección. Las comunidades valinarias mantuvieron vínculos con Dinamarca, Noruega y Escania mediante comercio, matrimonios, reclutamiento marítimo y peregrinaciones ancestrales.

Entre 300 y 100 a. C., la exploración atlántica se extendió hacia las islas septentrionales. La navegación se apoyó en observación astronómica, conocimiento de corrientes, construcción naval, almacenes de agua y estaciones de reparación. Tol Eressëa todavía no había sido descubierta, pero las rutas que conducirían a ella empezaron a ser cartografiadas.

Entre 100 a. C. y 20 d. C., las expediciones combinaron navegación atlántica, comercio mediterráneo y reconocimiento de las islas del norte. Los puertos mediterráneos aportaron conocimientos de astronomía, medicina, escritura, matemáticas y administración, mientras que las tradiciones escandinavas aportaron navegación oceánica, madera, hierro, meteorología práctica y construcción naval.

Entre 20 y 40 d. C., los navegantes valinari descubrieron Tol Eressëa. La isla recibió estaciones iniciales de agua, reparación, observación, cartografía y archivo. Su integración posterior al núcleo de Valinor a Tyl fue gradual y autónoma.

Hacia 50 d. C., Tol Eressëa era el primer gran descubrimiento oceánico occidental de los Valinari. Groenlandia aún no había sido reconocida de forma estable; su exploración corresponde a la etapa posterior de 55–75 d. C.. Valinor, Númenor/Terranova y Arnor todavía no formaban parte de la administración valinaria.

VIGENTE A092-R01 y R01. La cronología atlántica principal prevalece: Tol Eressëa 20–40 d. C.; expediciones a Terranova 400–500; descubrimiento de Valinor 650–750; asentamientos permanentes en Valinor 750–850; asentamiento permanente de Númenor y fundación posterior de Armenelos 920–980. Los contactos caribeños anteriores siguen vigentes; no se impone una secuencia única a todas las rutas.

Tol Eressëa es el primer gran descubrimiento oceánico occidental, situado aproximadamente entre 20 y 40 d. C. por navegantes que exploraban las rutas de Islandia y las islas septentrionales. Se establecen estaciones de agua, reparación, observación, cartografía y archivo. Su incorporación posterior al núcleo de Valinor a Tyl es gradual y conserva un régimen insular autónomo; en 85 d. C. todavía no existe la estructura territorial completa de Valinor a Tyl.

Groenlandia se reconoce aproximadamente entre 55 y 75 d. C. y recibe estaciones estacionales entre 70 y 110 d. C.. En 85 d. C. ya es conocida y utilizada como paso noratlántico desde Tol Eressëa, pero no es una provincia federal ni una colonia plenamente consolidada. La colonización estable se desarrolla posteriormente, entre los siglos IV y VI d. C., y la integración política plena es muy posterior.

VIGENTE por precedencia de la cronología maestra V16.3-R01: las primeras expediciones a Terranova se sitúan en 400–500 d. C.; el asentamiento permanente de Númenor y la fundación posterior de Armenelos en 920–980. Las fechas de 140–180 y 180–240 del relato anterior quedan sustituidas en estos hitos.

VIGENTE por precedencia de la cronología maestra V16.3-R01: descubrimiento formal de Valinor en 650–750 d. C.; primeros asentamientos permanentes y desarrollo inicial de Nueva Tirion en 750–850. El reconocimiento de 350–450 y los asentamientos de los siglos V–VI quedan como antecedentes sustituidos para esos mismos hitos.

En 85 d. C. la administración valinaria comprende el núcleo de Systreyjar y Nosselië Toliva, junto con las primeras estaciones de Tol Eressëa. Groenlandia posee solo puestos estacionales; Númenor, Arnor, la América continental y el territorio de Valinor todavía no forman parte de la administración territorial valinaria. La población administrada o dependiente se estima en 1,68–1,75 millones, sin sumar automáticamente a las poblaciones locales de territorios explorados.

##### Mediterráneo y rutas meridionales

El Mediterráneo sigue una trayectoria distinta. No depende de la ruta Tol Eressëa–Groenlandia y no es descubierto después de América. Los Valinari reciben noticias, mercancías y conocimientos mediterráneos por intermediarios daneses, germánicos, atlánticos, fluviales y continentales desde la primera mitad del primer milenio a. C.

El reconocimiento del Mediterráneo occidental se sitúa aproximadamente hacia 930 a. C.. Entre los siglos IX y VI a. C. se desarrollan contactos comerciales indirectos y expediciones de reconocimiento, sin presencia territorial estable. Entre los siglos VI y I a. C. aparecen escalas temporales, acuerdos portuarios y agentes comerciales en el Mediterráneo occidental, pero no una provincia valinaria.

Durante los primeros siglos d. C. aumenta la presencia diplomática, científica y mercantil en puertos mediterráneos. Alejandría, Cartago, Constantinopla, Beirut y otros centros funcionan como nodos de intercambio de matemáticas, medicina, astronomía, derecho, cartografía y traducción. Esta presencia no convierte al Mediterráneo en territorio valinario: son puertos asociados, enclaves comerciales o ciudades extranjeras conectadas.

La expansión mediterránea y la expansión atlántica son, por tanto, procesos paralelos: el Mediterráneo ofrece conocimiento, comercio y diplomacia desde la Antigüedad; el Atlántico septentrional conduce a Tol Eressëa, Groenlandia, Númenor y finalmente Valinor mediante exploración marítima propia.

##### Desarrollo histórico mediterráneo

La presencia valinaria en el Mediterráneo evoluciona por niveles y no equivale desde el principio a soberanía territorial.

- 930 a. C.: reconocimiento del Mediterráneo occidental y contacto con redes fenicias, ibéricas y norteafricanas.

- 874 a. C.: primer desembarco documentado en Sicilia; se intercambian metales, sal, cereales, vino, tejidos y conocimientos náuticos.

- 823 a. C.: Malta es reconocida como escala marítima y punto de agua y reparación.

- 781 a. C.: Chipre abre las rutas hacia el Levante, Anatolia y Egipto.

- 742 a. C.: reconocimiento de Creta y del Egeo; se incorporan conocimientos sobre cabotaje, calendarios, pesos y construcción naval.

- 706 a. C.: primer acceso valinario a los puertos del delta del Nilo.

- 664 a. C.: tratado comercial con Alejandría, que se convierte en puerto asociado y centro de traducción, medicina, astronomía y administración.

- 621 a. C.: acuerdos con ciudades levantinas sobre madera, tintes, metales, vidrio, aceite, tejidos y derecho mercantil.

- 587 a. C.: Malta recibe una estación permanente de agua y reparación; sigue siendo factoría protegida, no provincia.

- 548 a. C.: tratado de navegación y defensa portuaria con Chipre; se reconoce su autonomía política.

- 512 a. C.: expediciones hacia el mar Rojo desde Egipto; se estudian vientos, corrientes, puertos y rutas caravaneras.

- 476 a. C.: reconocimiento de Bab el-Mandeb como conexión entre África y Arabia.

- 438 a. C.: primera factoría comercial estable en Adén.

- 401 a. C.: Socotra se incorpora a la cartografía valinaria como estación marítima, científica y botánica.

- 291 a. C.: reconocimiento de Musandam y Ormuz; se conecta el Mediterráneo con el golfo, India y las rutas orientales.

- 219 a. C.: acuerdos comerciales iniciales con el litoral mesopotámico y el área de Kuwait.

- 74 d. C.: reconocimiento del litoral occidental del Bab el-Mandeb y creación de una escala africana de tránsito.

- 129 d. C.: renovación del tratado con Alejandría y creación de una representación consular estable.

- 188 d. C.: convención de seguridad de convoyes en Adén; se establece un protectorado de facto limitado a la defensa de rutas.

- 247 d. C.: Socotra se convierte en protectorado marítimo con autonomía interna, religiosa y civil.

- 312 d. C.: tratado general de navegación con Omán, que queda como Estado aliado autónomo.

La cadena estratégica Mediterráneo → Egipto → mar Rojo → Adén → Socotra → Omán → Ormuz → Malaca se consolida gradualmente. Los puertos asociados, factorías y protectorados conservan autoridades locales; Valinor controla principalmente defensa exterior, tránsito, archivos de navegación y seguridad de convoyes. La formalización posterior de Harnen, Círdan, Harlond, Kheled-zâram, Alqualondë, Eglarest y Pelargir pertenece a etapas medievales y modernas, no a la primera expansión antigua.

El Mediterráneo funciona también como corredor de conocimiento. Las Casas de Traducción y Archivo intercambian astronomía, medicina, matemáticas, cartografía, escritura, hidráulica, filosofía, derecho comercial y técnicas de administración. Los Valinari adaptan y conservan conocimientos de sociedades fenicias, egipcias, griegas, levantinas, romanas, africanas, árabes, persas, indias y asiáticas; no se atribuyen esas contribuciones como descubrimientos exclusivamente valinarios.

En 85 d. C. Valinor posee una presencia mediterránea comercial, diplomática y científica más desarrollada que su presencia americana, pero no un imperio territorial mediterráneo. Alejandría, Malta, Chipre, Adén y otros puntos son puertos asociados, factorías o estaciones, no provincias federales.

##### Población y relación con el Imperio romano hacia 50 d. C.

La población del Imperio romano alrededor de la época de Augusto y las primeras décadas del siglo I d. C. se estima históricamente en aproximadamente 50–60 millones de habitantes. La cifra es una reconstrucción demográfica, no un censo completo y uniforme.

En el escenario valinari, la población bajo administración directa hacia 50 d. C. es de aproximadamente 475.000–545.000 habitantes: Systreyjar, Nosselië Toliva, Tol Eressëa, estaciones atlánticas y factorías menores. La red ampliada de comunidades vinculadas por origen, comercio y parentesco alcanza aproximadamente 800.000–1.050.000 personas, sin contar como población valinaria a las sociedades locales de Escania, Noruega, Dinamarca, el Mediterráneo, Egipto o el mar Rojo.

Roma es entre cien y ciento veinte veces más grande que la administración valinaria directa. Roma domina el Mediterráneo mediante provincias, impuestos, ejército, puertos y derecho imperial; Valinor opera como una red marítima menor, especializada en navegación septentrional, comercio de larga distancia, traducción y servicios portuarios.

En 50 d. C. no existe todavía un tratado imperial romano-valinari plenamente formalizado. La relación se desarrolla a través de intermediarios y puertos conectados: comerciantes egipcios, levantinos, griegos, norteafricanos y agentes de Alejandría. Las autoridades romanas pueden conocer a los Valinari como comerciantes y navegantes del extremo norte, pero no los consideran una potencia territorial comparable a Roma.

Los intereses romanos son el acceso a pieles, madera, hierro, ámbar, productos marítimos, rutas septentrionales y mercancías de lujo. Los intereses valinari son el acceso a Egipto y Alejandría, medicina, astronomía, matemáticas, escritura, administración, derecho comercial y rutas hacia África y Arabia.

La relación combina comercio, observación y cautela. Roma no intenta conquistar Escania o Systreyjar porque las conoce de forma indirecta y la rentabilidad de una campaña septentrional es baja. Los Valinari tampoco desafían militarmente a Roma: carecen de población, recursos y bases suficientes para sostener una guerra en el Mediterráneo.

La representación consular estable en Alejandría pertenece a una fase posterior, fijada en 129 d. C.. Antes de esa fecha puede haber agentes, intérpretes, comerciantes y acuerdos portuarios, pero no una embajada romano-valinari permanente.

### Valinor y Roma, 500 a. C.–500 d. C.

Los contactos republicanos tempranos son indirectos y los acuerdos mediterráneos dependen de la autoridad anfitriona. La delegación estable de Alejandría se sitúa en 129 d. C. Los servicios comerciales y logísticos no conceden soberanía ni una alianza militar automática.

#### Relación entre Valinor y Roma, 500 a. C.–500 d. C.

La relación entre Valinor y Roma se desarrolla como una asociación estratégica asimétrica. Roma domina progresivamente el Mediterráneo y las grandes masas terrestres, mientras Valinor conserva ventajas en navegación atlántica, cartografía oceánica, construcción naval, puertos insulares y conexión entre rutas septentrionales y mediterráneas.

##### Primer contacto y reconocimiento, 500–300 a. C.

Durante esta etapa, Roma todavía no es una potencia mediterránea plena. Los contactos se producen mediante comerciantes intermediarios, puertos sicilianos, ciudades griegas, Malta, Chipre y agentes fenicios o helenísticos. Valinor busca asegurar rutas, metales, madera naval, grano, sal, información política y acceso a mercados; Roma obtiene madera, hierro, pilotos, cartografía y conocimiento de las rutas atlánticas.

##### Guerras púnicas, 264–146 a. C.

Valinor no entra en las guerras púnicas como provincia romana ni como aliado subordinado. Su apoyo es limitado y selectivo: venta de madera, velas, brea, cuerda, hierro, grano y piezas navales; transporte de suministros; protección de convoyes; reparación de buques; información marítima y préstamo de pilotos.

Después de 146 a. C., la destrucción de Cartago facilita el acceso valinari al Mediterráneo occidental, Sicilia, Malta, Egipto y el Levante. La cooperación no implica una ocupación valinaria de Cartago ni una alianza militar permanente.

##### República tardía y primer Imperio

El comercio incluye madera naval, hierro, herramientas, pieles, cera, sal, pescado conservado, ámbar, lino, armas, herrajes, instrumentos de navegación, mapas y conocimiento marítimo. Roma exporta moneda, vino, aceite, cerámica, vidrio, tejidos, bienes agrícolas, herramientas y artículos de lujo.

Los tratados establecen inmunidad comercial, protección de embajadas, arbitraje, derecho de reparación de buques, cooperación contra la piratería y reconocimiento de estaciones portuarias. Roma reconoce a los comerciantes valinari como comunidades organizadas, pero no ejerce soberanía sobre las comunidades atlánticas de Valinor.

##### Cooperación durante el periodo imperial, 27 a. C.–200 d. C.

Valinor aporta pilotos, convoyes, exploradores marítimos, barcos auxiliares, transporte de tropas y suministros, materiales navales e informes sobre piratería. No envía ejércitos masivos al interior romano: su apoyo militar es principalmente naval, logístico y técnico.

Roma aporta protección de puertos, presión contra piratas, suministro de armas, instructores de ingeniería, información estratégica y protección jurídica para comerciantes valinari. El apoyo romano no es automático y depende de la importancia de las rutas, puertos o intereses imperiales involucrados.

##### Crisis del siglo III

Las guerras civiles, epidemias, piratería, crisis monetaria y reducción de la seguridad portuaria interrumpen parte del comercio. Valinor responde diversificando sus rutas atlánticas, fortaleciendo puertos insulares, creando reservas de grano, protegiendo convoyes propios y reduciendo su dependencia de los mercados romanos.

##### Imperio tardío y fragmentación occidental, 300–500 d. C.

Valinor negocia con las autoridades romanas orientales y occidentales acuerdos sobre grano, transporte naval, reparación de puertos, protección de comerciantes, información y lucha contra la piratería. La cristianización romana no elimina la cooperación: Valinor mantiene su religión, pero regula la presencia de comunidades cristianas en sus puertos mediterráneos.

Tras la fragmentación del Imperio romano occidental, la diplomacia valinari se adapta a Constantinopla, Sicilia, Egipto, ciudades italianas, reinos germánicos, autoridades episcopales y comunidades mercantiles. El comercio occidental disminuye, pero el vínculo con el Mediterráneo oriental continúa.

##### Balance estratégico

Roma supera a Valinor en población, recaudación fiscal, ejército terrestre, carreteras, profundidad territorial y capacidad de movilización. Valinor mantiene ventajas en navegación atlántica, construcción naval especializada, meteorología marítima, cartografía, puertos insulares, convoyes y conexión entre regiones distantes.

No existe una conquista romana de Valinor ni una conquista valinaria de Roma. La estabilidad se sostiene porque ambas potencias obtienen más beneficios del comercio, la cooperación técnica y el apoyo militar limitado que de una guerra abierta.

#### Factorías valinari bajo autoridad romana, siglo I d. C.

Las factorías valinari del siglo I d. C. no son colonias soberanas ni bases militares independientes. En territorios controlados por Roma funcionan como concesiones comerciales, almacenes arrendados, oficinas diplomáticas, talleres y barrios mercantiles autorizados por autoridades imperiales, provinciales o municipales.

No poseen soberanía territorial, ejército propio grande, derecho de acuñar moneda, capacidad de firmar tratados por cuenta propia ni autoridad sobre la población local. Cuando disponen de guardia, esta es pequeña y queda subordinada a la autoridad romana.

##### Factorías en territorio romano

- Sicilia: almacenes, contratación, reparación naval y comercio de madera, hierro, pescado y productos agrícolas bajo autorización provincial.

- Eglarest (Malta): almacén, estación de reparación y punto de convoyes bajo autorización romana.

- Alqualondë (Chipre): comunidad mercantil, almacén portuario, oficina diplomática y estación de navegación sometida a impuestos romanos.

- Pelargir (Alejandría): factoría bajo supervisión del prefecto de Egipto, con comerciantes, agentes, intérpretes, ingenieros y depósitos controlados.

- Levante: concesiones municipales y factorías comerciales reguladas por autoridades portuarias.

- Norte de África: establecimientos posibles en Cartago, Hipona, Leptis Magna, Mauritania y escalas vinculadas a Hispania.

- Atlántico europeo romano: factorías en puertos de Hispania, la Galia y Britania para madera, metales, pesca, reparación e información.

##### Factorías fuera del control romano directo

- Mar Rojo: factorías autorizadas por Roma en puertos imperiales y pactadas con autoridades locales en puertos independientes.

- Adén: estación comercial o puerto aliado bajo tratado local, tolerado por Roma si favorece el comercio y combate la piratería.

- Socotra: estación comercial y naval bajo pacto local, sin ser provincia romana ni posesión valinaria plenamente integrada.

##### Condiciones romanas

Roma controla especialmente el espionaje, el contrabando, el apoyo a piratas, el traslado de armas, el reclutamiento no autorizado, la financiación de rebeliones, los mapas militares, las fortificaciones, el contacto con enemigos y la evasión fiscal.

Las factorías aceptan inspecciones, registros, límites de personal y control de mercancías estratégicas. Roma permite su existencia porque obtiene impuestos, productos, pilotos, información y seguridad marítima; Valinor las mantiene porque obtiene acceso a mercados, protección jurídica y continuidad comercial.

La relación queda definida como cooperación regulada: Roma protege la presencia mercantil valinari, pero impide que una factoría se convierta en colonia soberana o base militar independiente.

## Organización territorial y capitales

### Estructura política

La arquitectura política queda definida en cinco niveles:

1. Valinor a Tyl (núcleo insular atlántico): Valinor, Tol Eressëa y Systreyjar.

2. Aranath Valinor (el Reino constituyente): Valinor a Tyl más sus territorios americanos, caribeños y atlánticos directos, incluida Nosselië Toliva.

3. Gwaith Valinor (la Federación): el Reino completo y sus territorios, más las unidades federales externas vinculadas directamente al gobierno federal.

4. Beleg Valinor (Gran Valinor): la Federación más enclaves y protectorados.

5. Gwaith Aear (Unión Marítima): Gran Valinor más aliados extranjeros.

Aranath Valinor es un reino constituyente de Gwaith Valinor. Sus territorios forman parte de la Federación a través del Reino, pero no son por ello miembros federales directos. Los territorios expresamente federales fuera del Reino se vinculan directamente al gobierno federal. Gwaith Aear no convierte a sus aliados en provincias valinarias.

### Territorios directos

La Unión Valinoreana administra o incorpora:

- Valinor.

- Tol Eressëa.

- Arnor.

- Númenor.

- Nosselië Toliva, equivalente a Canarias.

- Sírënandë.

- Venezuela Federal.

- Provincia del Orinoco.

- Calenardhon Austral.

- Colombia Costera.

- Panamá Federal.

- Trinidad.

- Tobago.

- Bahamas.

- Bermudas.

- Barbados.

- Malaca.

- Hawái.

- Fiyi.

- Polinesia.

- Micronesia.

- Systreyjar.

### Arnor

Arnor es la gran provincia septentrional y lacustre. Se subdivide en:

- Arnor Oriental: Ontario.

- Cardolan: Quebec.

- Forochel: Labrador.

- Arthedain: Nueva Escocia.

- Rhudaur: Nuevo Brunswick y Maine.

- Tolfalas: Isla del Príncipe Eduardo.

- Númenor: Terranova.

Capital provincial de Arnor: Annúminas (Toronto).

Ciudades principales: Annúminas (Toronto), Fornost (Montreal), Cardolan (Québec), Amon Sûl (Ottawa), Hithlum (Halifax), Rhûn (Saint John), Etten (Labrador City), Bree (Portland), Tolfalas (Charlottetown), Hamilton, Tyrn Gorthad (Kingston), Emyn Uial (Thunder Bay) y Calenhad (Windsor). Cardolan (Québec) queda dentro de la provincia de Quebec; Hamilton pertenece a Ontario.

Población de Arnor en 2026: 145 millones. PIB provincial estimado: 18–22 billones de dólares PPA, con un valor central ECON-03 de 20 billones. Arnor concentra fabricación de chips, radares, motores y electrónica industrial, junto con finanzas, ingeniería, energía y servicios urbanos. La apartado «Cierre ECON-03» fija 131,5 millones urbanos, 13,5 rurales/dispersos y las cuentas sectoriales propias; las distribuciones provinciales y urbanas allí prevalecen sobre estimaciones anteriores.

##### Economía de Arnor en 2026

Sus especializaciones estratégicas son:

- acero, maquinaria y vehículos;

- minería de hierro, níquel, cobre y cobalto;

- energía hidroeléctrica, eólica y nuclear;

- construcción naval y aeronáutica;

- agricultura templada y biotecnología;

- madera, papel y productos forestales;

- inteligencia artificial, OceanNet y servicios financieros;

- transporte ferroviario, lacustre y oceánico.

Estas actividades se contabilizan dentro de las categorías ECON-03 de agricultura y silvicultura, minería y energía, manufactura, transporte, finanzas e información. No representan adiciones independientes al PIB provincial.

### Calenardhon Austral

Calenardhon Austral corresponde a Río Grande do Sul y Santa Catarina. Su superficie de referencia es de 281.700 km².

- Capital provincial: Pelargir Austral (Porto Alegre).

- Capital administrativa regional y base naval de Santa Catarina: Calenport (Florianópolis).

Ciudades principales:

- Pelargir Austral (Porto Alegre).

- Calenport (Florianópolis).

- Rómenna Austral (Rio Grande).

- Esgaroth Austral (Pelotas).

- Dol Amroth Austral (Joinville).

- Barad Calen (Caxias do Sul).

- Minas Tirith Austral (Santa Maria).

- Osgiliath del Sur (Passo Fundo).

- Edhellond Austral (Itajaí).

- Forlond Austral (São José do Norte).

- Calenost (Chapecó).

Población 2026: 88 millones. PIB PPA fijado: 11,5 billones, equivalente a aproximadamente 130.682 dólares PPA por habitante. La primera estimación de VAB y la cuña fiscal uniforme de el apartado «Método ECON-03».8 quedan sustituidas por la cuenta sectorial propia de el apartado «Cierre ECON-03». El perfil refleja su base agroindustrial y alimentaria, metalurgia, astilleros, turbinas, generadores, motores navales, electrónica de potencia, ferrocarriles, energía y defensa austral.

### Sírënandë

Sírënandë comprende los territorios completos de Guyana, Surinam y Guayana Francesa; excluye Brasil. No incorpora una cuarta franja fronteriza.

Se organiza en:

- Provincia de Guyana.

- Provincia de Surinam.

- Provincia de Guayana Oriental.

Ciudades principales: Sirion (Georgetown), Erellond Sur (Paramaribo), Calasir (Cayena), Demerion (New Amsterdam), Kourondë (Kourou), Eldalondë Oriental (Saint-Laurent-du-Maroni), Sarnath (Lelydorp), Rómennar (Moengo), Barad Calen (Matoury), Amon Rûdh Oriental (Remire-Montjoly), Esequielond (Bartica) y Calenport Sur (Albina).

Superficie de referencia: 462.323 km². Población 2026: 55 millones. PIB PPA fijado: 3,5 billones, equivalente a aproximadamente 63.636 dólares PPA por habitante. La apartado «Cierre ECON-03» fija la cuenta sectorial, impuestos y subvenciones propios; la matriz uniforme de 33.8 queda como antecedente. El perfil presupone minería, energía hidroeléctrica, refinación y procesamiento local de cobre, aluminio, níquel y tierras raras, manufactura, puertos y logística. El límite corresponde a Guyana, Surinam y Guayana Francesa completos, sin una franja adicional.

### Nosselië Toliva

Nosselië Toliva corresponde a Canarias y pertenece al Reino, no es una unidad exterior separada.

- Superficie: 7.493 km².

- Población canónica 2026: 10 millones.

- PIB PPA aproximado: 1 billón de dólares.

- Función: escala atlántica, agricultura subtropical, puertos, observatorios, comunicaciones y OceanNet.

### Enclaves y protectorados

##### Federación directa

- Eryndor (Baréin).

##### Protectorados de Beleg Valinor

- Harnen (Omán).

- Rhunost (Musandam), como provincia autónoma interna de Harnen.

- Kheled-zâram (Kuwait).

- Círdan (Socotra).

- Harlond (Adén).

- Amon Rûdh (Yibuti).

##### Puertos y Estados asociados

- Alqualondë (Chipre).

- Eglarest (Malta).

- Pelargir (Alejandría).

##### Andúnië Austral

Andúnië Austral es una ciudad científica arrendada bajo soberanía chilena, situada en el entorno del estrecho de Magallanes. Su régimen no la convierte en provincia, estado federal, territorio directo ni protectorado valinoriano. Está vinculada cooperativamente a Gwaith Aear como nodo oceanográfico, antártico, meteorológico y logístico del extremo sur.

Su administración se rige por acuerdos bilaterales de arrendamiento, cooperación científica, seguridad portuaria y comunicación. Chile conserva la soberanía territorial, la jurisdicción general y la representación internacional; Valinor participa en la infraestructura científica, OceanNet, los programas antárticos, la logística naval cooperativa y los sistemas de observación.

La ciudad queda catalogada en Obsidian como enclave y territorio asociado, fuera del catálogo territorial directo de la Federación. Sus instalaciones principales son el puerto científico, el Instituto Austral de Oceanografía, el observatorio meteorológico y sísmico, los centros de alerta de tsunamis y volcanes, el aeropuerto científico y el nodo OceanNet austral.

### Resolución canónica — Nosselië Toliva

Nosselië Toliva (Canarias) forma parte de Aranath Valinor y, por medio del Reino, de Gwaith Valinor. No es una unidad exterior independiente ni un miembro federal directo. Su superficie de referencia es de 7.493 km², su población canónica industrializada de 2026 es de 10 millones y su PIB PPA aproximado es de 1 billón.

Su evolución histórica se organiza así: reconocimiento atlántico entre 900–750 a. C.; primer registro en 720 a. C.; desembarco estacional en 680 a. C.; estación de agua y reparación en 620 a. C.; factoría permanente en 540 a. C.; integración en la navegación atlántica en 430 a. C.; rutas meridionales hacia el Atlántico africano en 250 a. C.; conexión documentada con el Caribe en 150 a. C.; expansión agrícola y portuaria entre 1–300 d. C.; consolidación de la administración valinoriana y del Reino histórico del Oeste entre 500–900; industrialización entre 1700–1900; redes precursoras de OceanNet entre 1954–1958; funcionamiento operativo inicial de OceanNet en 1959; y expansión contemporánea entre 1960–2026.

Sus funciones incluyen escala atlántica, agua, reparación, observación meteorológica y astronómica, traducción, agricultura intensiva, industria naval, desalinización, comunicaciones, satélites y OceanNet. Las denominaciones definitivas de sus ciudades canarias permanecen pendientes de asignación individual conforme a la regla primordial de nomenclatura urbana.

### Ficha geográfica canónica — Valinor a Tyl

Estado: [CANON] — ficha incorporada el 30 de octubre de 2026.

##### Valinor

- Centro: 30,00° N, 38,00° O.

- Vértices del polígono ficticio:

1. 30,80° N, 38,70° O

2. 30,90° N, 37,40° O

3. 29,80° N, 37,10° O

4. 28,90° N, 37,70° O

5. 28,80° N, 38,80° O

6. 29,60° N, 39,00° O

- Ciudades: Nueva Tirion (30,10° N, 38,00° O); Armenelos (29,85° N, 37,75° O); Alqualondë (30,35° N, 38,45° O); Tirion del Sur (29,55° N, 38,20° O).

- Nueva Tirion es la capital de Valinor y la principal sede política del núcleo Valinor a Tyl. Su población canónica en 2026 es de 6,50 millones.

### Retcon canónico — escala territorial, demográfica y cultural consolidada

Estado: [CANON VIGENTE — RETCON AUTORIZADO] — incorporación expresa del autor, 30 de octubre de 2026.

La presente resolución es la escala demográfica y política vigente del sistema. Sustituye completamente la recalibración de 245.050.000 habitantes; esa versión queda archivada únicamente como antecedente editorial y no tiene autoridad canónica. Las cifras de esta sección son acumulativas: una entidad superior contiene a las inferiores y sus poblaciones no deben sumarse entre niveles.

##### Nosselië Toliva

Nosselië Toliva (Canarias) forma parte de Aranath Valinor, el Reino.

- Superficie: 7.493 km².

- Población 2026: 10 millones.

- PIB PPA: aproximadamente 1 billón de dólares.

- Función: escala atlántica, centro naval, agrícola, meteorológico, científico y de comunicaciones.

- La superficie provisional de 55.000 km² queda sustituida por la superficie real de Canarias.

##### Escala acumulativa de las entidades

| Entidad | Componentes | Superficie aproximada | Población 2026 |
| --- | --- | --- | --- |
| Valinor | Isla y territorio histórico | 32.800 km² | 16 millones |
| Valinor a Tyl | Valinor, Tol Eressëa y Systreyjar | 53.200 km² | 26 millones |
| Aranath Valinor | Valinor a Tyl, Nosselië Toliva y América y Caribe directos | 5,4–5,5 millones km² | 481 millones |
| Gwaith constitucional / ECON-03 operativo | Reino más ocho externas federales; Harnen solo en el ámbito operativo | Superficie total no conciliada; septentrionales incluidos en su cuenta | 515,5 constitucionales; 523,5 operativos |
| Beleg Valinor | Federación más protectorados y enclaves | Perímetro extendido; superficie pendiente de conciliación | 724,5–879,5 millones; rango rector con residuo por asignar |
| Gwaith Aear | Gran Valinor más aliados extranjeros | Sin frontera única | No conciliada; los rangos heredados son escenarios. A092-R04. |

##### Composición política

Valinor a Tyl incluye Valinor, Tol Eressëa (8.400 km²; 5 millones) y Systreyjar (12.000 km²; 5 millones). Su PIB PPA de referencia es de 3,1 billones.

Aranath Valinor es el Reino constituyente de Gwaith Valinor e incluye Valinor a Tyl, Arnor (con Númenor/Terranova dentro de Arnor), Sírënandë, Venezuela Federal, Provincia del Orinoco, Calenardhon Austral, Colombia Costera, Panamá Federal, Trinidad, Tobago, Bahamas, Bermudas, Barbados y Nosselië Toliva. Su PIB PPA vigente de referencia es 55–62 billones, con centro contable de 58,5 billones.

Gwaith Valinor constitucional comprende el Reino completo y ocho unidades federales externas: Malaca, Hawái, Fiyi, Polinesia, Micronesia, Eryndor, Islandia y Groenlandia. Cuenta 515,5 millones y 64,98 billones PPA. Harnen es protectorado de Beleg, con Rhunost dentro; al incluir su cuenta una sola vez se obtiene el agregado operativo ECON-03 de 523,5 millones y 65,50 billones. A092-R03.

Beleg Valinor (Gran Valinor) comprende Gwaith Valinor más los enclaves y protectorados exteriores: Harnen (Omán), Kheled-zâram (Kuwait), Círdan (Socotra), Harlond (Adén), Amon Rûdh (Yibuti), Alqualondë (Chipre), Eglarest (Malta) y Pelargir (Alejandría). Rhunost (Musandam) es una provincia autónoma interna de Harnen y no se agrega por separado. Eryndor forma parte de Gwaith Valinor; Harnen se incorpora en este nivel como protectorado. Su PIB PPA indicativo es de aproximadamente 73–93 billones, sujeto a revisar las contribuciones de los protectorados. No es un Estado unitario: combina provincias, enclaves, protectorados, puertos asociados y Estados autónomos bajo defensa valinoriana.

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados. Gwaith Aear (Unión Marítima) reúne Gran Valinor y aliados soberanos. Su superficie es variable; su población aproximada es de 1.115,5–1.515,5 millones y su PIB PPA indicativo es de aproximadamente 98–128 billones, sujeto a revisar el valor añadido de los aliados. No posee frontera única ni ciudadanía común.

##### Política cultural de la expansión oriental

Desde el primer contacto, la expansión oriental incorpora una política cultural sistemática basada en:

- intercambio de lenguas y escrituras;

- traducción de textos;

- medicina y botánica;

- astronomía y matemáticas;

- derecho y administración;

- religión y filosofía;

- navegación y cartografía;

- bibliotecas y Casas de Traducción.

La red de convenios y contactos incluye, en sus períodos históricos correspondientes, escuelas fenicias, Mileto, Nínive, Cos, Atenas, Alejandría, Pérgamo, Beirut, Cartago, Antioquía, Constantinopla, Gundeshapur, Al-Azhar, Bayt al-Hikma, Al-Qarawiyyin, Bolonia, Toledo, París, Cambridge, Padua, Salamanca, Lovaina, Coimbra, Harvard, la Royal Society y universidades japonesas, rusas y norteamericanas.

La expansión oriental queda definida doctrinalmente como:

comercio + diplomacia + ciencia + traducción + educación + archivo + navegación

Los convenios se fecharán según la época de cada institución; no se interpreta la lista como una red simultánea. Esta resolución refuerza el Principio de las Siete Copias y la acumulación continua de conocimiento.

##### Precedencia

Esta resolución es la única versión vigente de los totales demográficos y territoriales. La cifra de 245.050.000 y su distribución quedan fuera del canon operativo y no deben utilizarse en cálculos posteriores.

### Retcon administrativo — Eryndor federal y Harnen protectorado

Estado: [CANON VIGENTE — RETCON AUTORIZADO] — 30 de octubre de 2026.

Eryndor (Baréin) es una unidad federal directa de Gwaith Valinor. Harnen (Omán) es un protectorado de Beleg Valinor. Rhunost (Musandam) se mantiene como provincia autónoma estratégica dentro de Harnen, con administración local y estatuto naval especial.

Esta modificación añade Eryndor como unidad federal externa al Reino y confirma Harnen como protectorado de Beleg Valinor. Sus poblaciones y su producción se cuentan una vez dentro del ámbito político y del agregado operativo correspondiente; no se añaden al PIB del Reino.

##### Eryndor (Baréin)

- Superficie: 765 km².

- Población 2026: 2,0 millones.

- PIB PPA 2026: 0,18 billones de dólares.

- Capital: Manama.

- Funciones: banca, seguros, refinación, comercio del Golfo, telecomunicaciones, arbitraje mercantil y servicios navales.

##### Harnen (Omán)

- Protectorado de Beleg Valinor: Omán completo bajo administración interna propia.

- Superficie de referencia: 309.500 km².

- Población 2026: 8,0 millones.

- PIB PPA 2026: 0,52 billones de dólares.

- Capital federal: Mascate.

- Funciones: energía, puertos del mar Arábigo, astilleros, minería, logística hacia India y defensa marítima.

##### Rhunost (Musandam)

Rhunost conserva una administración autónoma dentro de Harnen:

- Superficie aproximada: 1.800 km².

- Población 2026: 0,45 millones, incluida en Harnen.

- Función: control del estrecho de Ormuz, vigilancia naval, puertos y seguridad energética.

##### Curva histórica de urbanización y economía

Eryndor y Harnen siguen una secuencia de urbanización coordinada, adaptada a sus economías portuarias y energéticas:

| Año | Población conjunta | Urbanización | PIB PPA conjunto | Fase económica |
| --- | --- | --- | --- | --- |
| 1850 | 0,45 millones | 18 % | 0,01 billones | Puertos, pesca, agricultura y comercio regional |
| 1900 | 0,75 millones | 25 % | 0,02 billones | Aduanas, navegación a vapor y primeras refinerías |
| 1950 | 1,65 millones | 42 % | 0,06 billones | Petróleo, carreteras, electricidad y expansión portuaria |
| 2000 | 5,20 millones | 72 % | 0,34 billones | Petroquímica, finanzas, aviación y logística |
| 2026 | 10,00 millones | 86 % | 0,70 billones | Energía avanzada, banca, astilleros, tecnología y defensa marítima |

La urbanización se concentra en Manama, Mascate, Sohar, Salalah, Khasab y los corredores industriales costeros. El interior mantiene densidades menores y funciones mineras, energéticas, agrícolas y de conservación.

##### Estructura sectorial en 2026

| Sector | Participación conjunta |
| --- | --- |
| Energía, refinación y petroquímica | 28 % |
| Finanzas, seguros y servicios empresariales | 20 % |
| Puertos, logística y transporte marítimo | 18 % |
| Industria, astilleros y mantenimiento naval | 14 % |
| Turismo, educación y servicios | 10 % |
| Minería, pesca y agricultura | 10 % |

La federalización convierte el Golfo y el mar Arábigo en un eje industrial y logístico directo de Gwaith Valinor. Eryndor aporta densidad financiera; Harnen aporta territorio, energía, puertos y profundidad estratégica.

### Colombia Costera: límites, población y economía

Estado: [CANON VIGENTE — delimitación y distribución urbana fijadas] — 31 de octubre de 2026.

##### Límites administrativos

Colombia Costera comprende íntegramente las unidades administrativas colombianas enumeradas abajo. Su límite terrestre es la suma de los límites departamentales oficiales de esas unidades; no se trazan fronteras internas nuevas ni se fragmenta ningún departamento. La base de equivalencia es el Atlas político-administrativo del IGAC, edición 2024. La denominación «Costera» describe la orientación bicostera y comercial del Estado, que incluye su hinterland andino conectado por corredores logísticos.

| Región administrativa de Colombia Costera | Departamentos o distrito comprendidos | Población 2026 |
| --- | --- | --- |
| Caribe y archipiélago | Atlántico, Bolívar, Cesar, Córdoba, La Guajira, Magdalena, San Andrés, Providencia y Santa Catalina, Sucre | 16,0 millones |
| Pacífico | Cauca, Chocó, Nariño, Valle del Cauca | 10,5 millones |
| Antioquia y Eje Cafetero | Antioquia, Caldas, Quindío, Risaralda | 11,0 millones |
| Corredor Andino Oriental | Bogotá D.C., Boyacá, Cundinamarca, Huila, Norte de Santander, Santander, Tolima | 15,5 millones |
| Total Colombia Costera | 22 departamentos y Bogotá D.C. | 53,0 millones |

La Provincia del Orinoco queda fuera de Colombia Costera y no hay solapamiento entre ambas. Su sector colombiano comprende Arauca, Casanare, Meta, Vichada, Guaviare, Guainía, Vaupés, Amazonas, Caquetá y Putumayo. «Provincia del Orinoco» es el nombre político de la macroregión oriental y amazónica; no afirma que todos sus departamentos pertenezcan a la cuenca hidrográfica del Orinoco. Las zonas marítimas siguen la delimitación federal y no se suman como territorios terrestres adicionales.

##### Capitales, núcleos urbanos e industria

Vinyamar (Barranquilla) queda fijada como capital administrativa y principal centro portuario caribeño. Mithrim (Bogotá–Sabana) es el núcleo de servicios profesionales, investigación, educación superior y coordinación financiera. Los nombres canónicos preceden a sus equivalencias geográficas, conforme a la regla de nomenclatura urbana.

| Región | Núcleos urbanos e industriales y población asignada | Población regional |
| --- | --- | --- |
| Caribe y archipiélago | Vinyamar (Barranquilla–Soledad), 4,8 M; Brithombar (Cartagena), 2,8 M; Tharbad (Santa Marta–Ciénaga), 2,1 M; Eryn Vorn (Montería–Sincelejo), 2,0 M; Doriath Norte (Valledupar–Riohacha), 2,1 M; centros insulares y otras ciudades, 2,2 M | 16,0 M |
| Pacífico | Nargothrond (Cali–Yumbo–Palmira), 4,8 M; Lond Daer (Buenaventura), 1,6 M; Himring del Sur (Pasto–Popayán), 2,2 M; Amon Ereb (Tumaco), 0,9 M; Quibdó, 0,5 M; otras ciudades, 0,5 M | 10,5 M |
| Antioquia y Eje Cafetero | Ost-in-Edhil (Medellín–Valle de Aburrá), 5,4 M; Eglador (Rionegro y Oriente antioqueño), 1,4 M; Forlindon (Turbo–Apartadó), 1,3 M; Mithlond del Café (Pereira), 1,2 M; Rathlóriel (Manizales), 0,9 M; Nimrodel del Quindío (Armenia), 0,6 M; otras ciudades, 0,2 M | 11,0 M |
| Corredor Andino Oriental | Mithrim (Bogotá–Sabana), 7,3 M; Caras Galadhon (Bucaramanga), 2,2 M; Minas Ithil (Cúcuta), 1,8 M; Talath Dirnen (Ibagué), 1,1 M; Taur-im-Duinath (Neiva), 0,8 M; Tirith Aear (Tunja–Duitama–Sogamoso), 1,4 M; otras ciudades, 0,9 M | 15,5 M |
| Total | Los cuatro sistemas regionales incluyen 49,2 M en núcleos urbanos principales y 3,8 M en otras ciudades y asentamientos | 53,0 M |

Los corredores industriales prioritarios son: (1) Barranquilla–Cartagena–Santa Marta, con petroquímica, metalurgia, construcción y reparación naval, alimentos, fertilizantes y energía; (2) Cali–Buenaventura, con manufactura, electrónica, maquinaria, agroindustria, logística y puerto de aguas profundas; (3) Medellín–Rionegro–Urabá, con maquinaria, dispositivos médicos, software, aeronáutica, alimentos y salida portuaria; y (4) Bogotá–Sabana–Bucaramanga, con finanzas, administración, investigación, industria eléctrica, química, salud y servicios profesionales.

### Panamá Federal: territorio, población y economía local

Estado: [CANON VIGENTE — estructura territorial y productiva fijada] — 31 de octubre de 2026.

##### Territorio y centros urbanos

Panamá Federal comprende el territorio completo de la República de Panamá, incluidas sus provincias, comarcas indígenas, islas y el corredor del canal. El canal y sus instalaciones son infraestructura panameña: no constituyen un enclave externo ni una unidad que se sume por separado. La base administrativa de referencia es la división provincial y comarcal recogida por el INEC de Panamá.

La población de referencia es 17,0 millones. Se distribuye entre estos sistemas urbanos y productivos: Tirion del Istmo (Panamá–San Miguelito), 5,6 M; Mithlond del Caribe (Colón–Portobelo), 1,4 M; Forlindon del Istmo (Arraiján–La Chorrera), 2,0 M; Barad Nimras (David–Chiriquí), 1,5 M; Sarn Athrad (Santiago–Veraguas), 0,8 M; Amon Dîn (Chitré–Las Tablas), 0,9 M; Nimbrethil (Changuinola–Almirante), 0,7 M; Rathlóriel del Centro (Penonomé–Aguadulce), 0,7 M; Calenost Oriental (Metetí–Darién), 0,35 M; otros centros urbanos, 1,85 M; población rural, comarcal y dispersa, 1,2 M. La suma es 17,0 millones; las poblaciones de las comarcas se asignan a su región y no se vuelven a agregar.

### Red oriental de enclaves, protectorados y puertos asociados

La expansión oriental de la Unión Valinoriana mantiene una arquitectura escalonada: comercio, factoría, puerto asociado, alianza naval, protectorado y, únicamente en casos excepcionales, enclave federal directo. La Federación no incorpora directamente toda la península arábiga ni todo Oriente Medio.

##### Estructura vigente

- Federación directa: Eryndor (Baréin).

- Protectorado de Beleg Valinor: Harnen (Omán), incluido Musandam.

- Provincia autónoma interna de Harnen: Rhunost (Musandam), no unidad federal separada.

- Protectorados de Beleg Valinor: Kheled-zâram (Kuwait), Círdan (Socotra), Harlond (Adén) y Amon Rûdh (Yibuti).

- Puertos y Estados asociados de Gwaith Aear: Alqualondë (Chipre), Eglarest (Malta) y Pelargir (Alejandría).

Harnen conserva gobierno y administración interna propios; la protección valinoriana comprende defensa exterior, navegación, infraestructura estratégica y cooperación económica. Amon Rûdh se clasifica como protectorado portuario, no como Estado asociado independiente. Rhunost mantiene régimen autónomo interno dentro de Harnen.

La cadena estratégica es: Mediterráneo → Egipto → mar Rojo → Adén → Socotra → Omán → Ormuz → Malaca.

##### Secuencia histórica de desarrollo

- 1000–450 a. C.: exploración mediterránea, contactos comerciales, cartografía y acuerdos portuarios.

- 450–150 a. C.: acceso al mar Rojo, Adén, Socotra y rutas de Arabia meridional.

- 150 a. C.–500: alianzas de navegación, estaciones de convoyes y consolidación de las rutas hacia Omán y Ormuz.

- 500–1300: integración comercial entre Mediterráneo, mar Rojo, océano Índico y Malaca.

- 1300–1700: formalización progresiva de protectorados y enclaves estratégicos.

- 1536: Eryndor (Baréin) se incorpora como territorio federal directo.

- 1611: Rhunost (Musandam) queda constituido como provincia autónoma interna de Harnen, con régimen naval especial.

- 1700–1950: navegación industrial, redes telegráficas, depósitos, diques, astilleros y estaciones de carbón.

- 1954–1958: las redes orientales se integran progresivamente en el programa OceanNet y sus redes precursoras.

- 1959: funcionamiento operativo inicial de OceanNet en la red federal.

- 1960–2026: expansión de radar, aviación, satélites, comunicaciones, logística energética y coordinación de protectorados y aliados.

Las fechas más detalladas de descubrimientos, tratados y convenios permanecen como cronología histórica ampliada y no modifican por sí solas el estatus territorial vigente.

### Evolución de las capitales hasta 1200

La capitalidad histórica y jurídica de Forostar se distingue del desplazamiento demográfico desde Escania, del centro administrativo de Nueva Tirion y del mando naval de Armenelos. Londres comerciales o sedes provinciales no se convierten por esa función en capital general. Lond Calad es la capital administrativa de Nosselië Toliva.

#### Evolución de las capitales valinari, 1000 a. C.–1200 d. C.

##### Forostar (Helsingborg)

Forostar es el centro del Concilio de 990 a. C. y mantiene la capitalidad política, jurídica y defensiva durante la formación del Reino. Entre 560 y 350 a. C. se convierte en la capital de la Casa Telcontar y sede de la Corona, el Consejo, los arsenales, los graneros, los tribunales, los santuarios y los archivos.

Entre 350 y 500 d. C. conserva la capitalidad formal mientras se desarrollan los centros oceánicos. Entre 500 y 800 d. C. permanece como capital histórica y constitucional. Entre 800 y 1200 d. C. sigue siendo la sede de la legitimidad dinástica, los pactos de las Casas y los archivos principales, aunque ya no concentra toda la administración marítima.

##### Armenelos

Armenelos es la capital histórica de Númenor. El asentamiento permanente de Númenor en Terranova y la fundación posterior de Armenelos se sitúan en 920–980 d. C. por precedencia V16.3-R01; la atribución de estas funciones a 140–180 d. C. queda sustituida.

Las funciones de Armenelos como capital naval, arsenal, archivo, escuela y centro de convoyes se desarrollan después de su fundación. El calendario anterior que las proyectaba sobre 180–800 d. C. queda como ANTECEDENTE sustituido; no modifica la capitalidad histórica y constitucional de Forostar.

##### Avallónë

Tol Eressëa se descubre entre 20 y 40 d. C. y comienza como estación oceánica. Avallónë se desarrolla como su principal puerto y asentamiento permanente entre los siglos I y V.

Entre 500 y 1200 d. C. Avallónë es la capital administrativa, cultural y marítima de Tol Eressëa, con consejo insular, archivo de rutas, astilleros, santuarios y academias. Su estatus es insular y autónomo dentro del sistema, no capital general del Reino.

##### Nueva Tirion

Valinor se descubre en 650–750 d. C. Los primeros asentamientos permanentes y el desarrollo inicial de Nueva Tirion corresponden a 750–850, por precedencia V16.3-R01.

Las funciones administrativas y políticas de Nueva Tirion se desarrollan después de su establecimiento en 750–850 d. C. La consolidación en 450–700 queda como ANTECEDENTE sustituido; Forostar conserva la capitalidad histórica y constitucional conforme a las disposiciones no sustituidas.

##### Capitales provinciales

- Annúminas (Toronto): capital provincial de Arnor.

- Calenport (Florianópolis): capital provincial de Calenardhon Austral.

- Sirion (Georgetown): capital de la Provincia de Guyana.

- Erellond Sur (Paramaribo): capital de la Provincia de Surinam.

- Calasir (Cayena): capital de la Provincia de Guayana Oriental.

Estas capitales administran provincias y no sustituyen a Forostar, Nueva Tirion o Armenelos.

##### Capitales portuarias y asociadas

- Alqualondë (Chipre): centro administrativo del puerto asociado.

- Eglarest (Malta): centro portuario y de escala.

- Pelargir (Alejandría): capital de la comunidad comercial valinari en Alejandría, no capital de Egipto.

- Adén: centro del puerto o enclave meridional según la fase histórica.

- Socotra: centro del protectorado o estación insular según su estatus.

- Esgal Nénar: capital administrativa del protectorado fluvial africano tras su incorporación.

##### Capitalidad múltiple hacia 1200 d. C.

Hacia 1200 d. C. el sistema distingue:

- Forostar: capital histórica, dinástica y constitucional.

- Nueva Tirion: capital política y administrativa de Valinor.

- Armenelos: capital naval y oceánica.

- Avallónë: capital de Tol Eressëa.

- Annúminas: capital provincial de Arnor.

- Calenport: capital provincial de Calenardhon Austral.

- Sirion, Erellond Sur y Calasir: capitales provinciales de Sírënandë.

Lond Calad (Las Palmas de Gran Canaria) es la capital administrativa de Nosselië Toliva; Rómenlond (Santa Cruz de Tenerife) cumple la función militar y portuaria complementaria.

#### Capital de Nosselië Toliva, 900 a. C.–1200 d. C.

##### Lond Calad (Las Palmas de Gran Canaria)

La capital administrativa, comercial y documental de Nosselië Toliva queda fijada como Lond Calad (Las Palmas de Gran Canaria). El nombre significa “Puerto de Luz” y relaciona la navegación, la observación astronómica y la función de guía atlántica del archipiélago.

Lond Calad concentra gobernador territorial, tribunal insular, archivo de rutas, aduana, mercado principal, graneros, depósitos de agua, arsenal, academia náutica, observatorio, oficinas diplomáticas, registro de barcos y estación de señales.

##### Rómenlond (Santa Cruz de Tenerife)

Rómenlond (Santa Cruz de Tenerife) queda fijada como capital militar y puerto de defensa oriental. Sus funciones son convoyes, vigilancia de rutas, comunicación con África, reparación naval, patrullas y defensa del acceso oriental.

##### Otras ciudades y distritos

- Calenport Toliva (Santa Cruz de La Palma): reparación, agua y navegación de altura.

- Eressëa Nén (San Sebastián de La Gomera): estación de navegación y escala occidental.

- Taur-en-Calad (La Orotava): centro agrícola y de abastecimiento interior.

- Nimmir (Arrecife): puerto de agua, sal y pesca.

- Círdanost Toliva (Puerto del Rosario): vigilancia, reparación y conexión con rutas africanas.

Los distritos principales son el Distrito de Lond Calad, el Distrito de Caladwest, el Distrito de Amon Rûdh Toliva, el Distrito de Eryn Toliva y el Distrito de Rómenlond.

##### Evolución histórica

- 900–750 a. C.: reconocimiento de rutas atlánticas orientales.

- 720 a. C.: registro del archipiélago.

- 680 a. C.: desembarcos estacionales.

- 620 a. C.: estaciones de agua y reparación.

- 540 a. C.: factorías permanentes y acuerdos locales.

- 430 a. C.: integración en la red atlántica.

- 250 a. C.: conexión con rutas meridionales.

- 1–100 d. C.: consolidación de Lond Calad como puerto administrativo.

- 100–300 d. C.: murallas, graneros, torres, talleres y observatorios.

- 300–500 d. C.: integración plena en el Reino.

- 500–800 d. C.: gobernador, tribunales, archivos, fiscalidad y academias.

- 800–1200 d. C.: consolidación como capital atlántica oriental y nodo con Sírënandë, Númenor y Valinor.

##### Capitalidad diferenciada

La estructura capitalina queda definida así:

- Forostar (Helsingborg): capital histórica y constitucional.

- Nueva Tirion: capital política y administrativa de Valinor.

- Armenelos: capital naval y oceánica.

- Avallónë: capital de Tol Eressëa.

- Lond Calad: capital de Nosselië Toliva.

- Rómenlond: capital militar oriental de Nosselië Toliva.

- Annúminas: capital provincial de Arnor.

- Calenport: capital provincial de Calenardhon Austral.

- Sirion, Erellond Sur y Calasir: capitales provinciales de Sírënandë.

Nosselië Toliva continúa siendo una unidad del Reino y no un territorio exterior independiente.

## Corona, gobierno y administración

### Registro dinástico de la Casa Telcontar

La Casa Telcontar inicia su reinado en 560 a. C. El Pacto de la Corona Telcontar de 550 a. C. establece una sucesión hereditaria preferente, limitada por el Consejo de las 24 Casas, los fueros territoriales y los pactos de protección. La siguiente lista queda fijada como registro dinástico canónico.

| Nº | Monarca | Nacimiento | Coronación | Abdicación | Muerte |
| --- | --- | --- | --- | --- | --- |
| 1 | Harald II Telcontar | 590 a. C. | 560 a. C. | — | 528 a. C. |
| 2 | Eärendur II | 563 a. C. | 530 a. C. | — | 498 a. C. |
| 3 | Aranwë I | 532 a. C. | 500 a. C. | — | 468 a. C. |
| 4 | Elendur I | 500 a. C. | 468 a. C. | — | 436 a. C. |
| 5 | Thalion I | 468 a. C. | 435 a. C. | — | 402 a. C. |
| 6 | Calion I | 438 a. C. | 402 a. C. | — | 366 a. C. |
| 7 | Amdir I | 405 a. C. | 370 a. C. | — | 334 a. C. |
| 8 | Erestor I | 372 a. C. | 337 a. C. | — | 301 a. C. |
| 9 | Vorondir I | 340 a. C. | 305 a. C. | — | 269 a. C. |
| 10 | Meneldor I | 307 a. C. | 272 a. C. | — | 236 a. C. |
| 11 | Haldir I | 275 a. C. | 240 a. C. | — | 204 a. C. |
| 12 | Eärnil I | 243 a. C. | 208 a. C. | — | 172 a. C. |
| 13 | Baranor I | 211 a. C. | 176 a. C. | — | 140 a. C. |
| 14 | Círdan I | 180 a. C. | 145 a. C. | — | 109 a. C. |
| 15 | Falastur I | 149 a. C. | 114 a. C. | — | 78 a. C. |
| 16 | Calenhir I | 118 a. C. | 83 a. C. | — | 47 a. C. |
| 17 | Arathorn I | 87 a. C. | 52 a. C. | — | 16 a. C. |
| 18 | Elessar I | 55 a. C. | 20 a. C. | — | 18 d. C. |
| 19 | Hador I | 8 a. C. | 12 d. C. | — | 43 d. C. |
| 20 | Galdor I | 20 d. C. | 45 d. C. | — | 76 d. C. |
| 21 | Eäron I | 52 d. C. | 78 d. C. | — | 109 d. C. |
| 22 | Thalion II | 84 d. C. | 111 d. C. | — | 142 d. C. |
| 23 | Aranwë II | 116 d. C. | 144 d. C. | — | 176 d. C. |
| 24 | Elendur II | 149 d. C. | 177 d. C. | — | 208 d. C. |
| 25 | Calion II | 181 d. C. | 210 d. C. | — | 241 d. C. |
| 26 | Amdir II | 214 d. C. | 243 d. C. | — | 274 d. C. |
| 27 | Vorondir II | 247 d. C. | 276 d. C. | — | 307 d. C. |
| 28 | Erestor II | 280 d. C. | 309 d. C. | — | 341 d. C. |
| 29 | Meneldor II | 313 d. C. | 342 d. C. | — | 374 d. C. |
| 30 | Haldir II | 346 d. C. | 375 d. C. | — | 407 d. C. |
| 31 | Eärnil II | 379 d. C. | 408 d. C. | 430 d. C. | 447 d. C. |
| 32 | Baranor II | 414 d. C. | 441 d. C. | — | 475 d. C. |
| 33 | Círdan II | 447 d. C. | 474 d. C. | — | 509 d. C. |
| 34 | Falastur II | 480 d. C. | 507 d. C. | — | 542 d. C. |
| 35 | Calenhir II | 513 d. C. | 540 d. C. | — | 576 d. C. |
| 36 | Arathorn II | 546 d. C. | 573 d. C. | — | 610 d. C. |
| 37 | Elessar II | 579 d. C. | 606 d. C. | — | 644 d. C. |
| 38 | Hador II | 612 d. C. | 639 d. C. | — | 678 d. C. |
| 39 | Galdor II | 645 d. C. | 672 d. C. | — | 711 d. C. |
| 40 | Eäron II | 678 d. C. | 705 d. C. | — | 744 d. C. |
| 41 | Thalion III | 711 d. C. | 738 d. C. | — | 777 d. C. |
| 42 | Aranwë III | 744 d. C. | 771 d. C. | — | 810 d. C. |
| 43 | Elendur III | 777 d. C. | 804 d. C. | — | 829 d. C. |
| 44 | Thalion IV | 805 d. C. | 833 d. C. | Monarca vigente | — |

En 833 d. C., Thalion IV Telcontar ocupa la Corona en Nueva Tirion. La Casa Real conserva el número 25 y no obtiene un voto adicional en el Consejo.

Hacia 826 d. C., Thalion IV, entonces heredero, contrajo matrimonio dinástico con Gilwen, nacida hacia 800 d. C. en la [[09_Politica/Casas Mayores/Casa Mithlond|Casa Mithlond]]. Tras la coronación de Thalion en 833, Gilwen fue reconocida como reina consorte. La unión reforzó los vínculos de la Corona con las rutas marítimas septentrionales y la [[09_Politica/Casas Mayores/Casa Mithlond|Casa Mithlond]].

La reina consorte ejerce patronazgo y funciones ceremoniales, pero no recibe soberanía independiente ni un voto adicional en el Consejo. La [[09_Politica/Casas Mayores/Casa Mithlond|Casa Mithlond]] conserva su asiento propio como una de las 24 Casas Mayores. Las fechas de nacimiento y matrimonio de Gilwen son aproximadas. Véase su ficha.

### Historia constitucional de las Casas y la Corona

La tradición constitucional de Valinari comienza con el Concilio de Forostar, celebrado en 990 a. C. en las tierras ancestrales de las Casas. Las 24 Casas reconocen obligaciones compartidas, pero conservan sus autoridades, bienes, títulos y dominios propios. El poder común reside inicialmente en el Consejo de las Veinticuatro Casas, con un asiento y un voto por Casa.

El Colegio de Varda interpreta las obligaciones religiosas del Juramento y los Heraldos del Tengwar registran los acuerdos. Estas instituciones no sustituyen al Consejo ni ejercen por sí mismas soberanía política.

En 980 a. C., el Pacto de la Corona Occidental crea la dignidad de Alto Rey. La Corona nace como magistratura vitalicia y electiva: dirige las flotas comunes, ejecuta los acuerdos del Consejo, representa a las Casas, arbitra disputas, protege rutas y santuarios y administra las contribuciones aprobadas. No sustituye a las Casas ni se convierte en propietaria de sus dominios.

Harald I Eärond es el primer Alto Rey documentado. La elección requiere 18 de los 24 votos del Consejo. La unanimidad de su elección es una circunstancia fundacional y no una exigencia permanente. La Casa Telcontar aparece posteriormente como Casa Real número 25; la Corona no recibe por ello un vigésimo quinto voto adicional en el Consejo.

En 975 a. C. Harald I dirige la Primera Marcha. En 950 a. C., el Pacto de Forlond limita y precisa las competencias de la Corona: las contribuciones ordinarias, la guerra ofensiva, las obligaciones generales y los cambios de competencias reales requieren aprobación del Consejo. Los bienes de la Corona se registran separadamente de los bienes de la Casa soberana.

La dignidad de Alto Rey no es automáticamente hereditaria. A la muerte, abdicación o destitución del titular, el Consejo elige sucesor por 18 votos. La destitución exige investigación, derecho de respuesta y una mayoría de 18 votos. Durante la vacancia, tres custodios de Casas distintas administran los asuntos ordinarios.

El Reino del Oeste es el nombre histórico de esta unión ancestral. No designa todavía a Aranath Valinor ni a Gwaith Valinor, que son desarrollos políticos posteriores. La unión se entiende como una talasocracia compuesta por dominios directos, señoríos vasallos, comunidades protegidas y pueblos aliados.

Las categorías políticas no son equivalentes: fundar un puerto, recibir fidelidad, establecer protección y firmar una alianza producen derechos diferentes. La soberanía se determina por carta, tratado, juramento o incorporación reconocida; la presencia naval no convierte automáticamente una comunidad en provincia.

Las cifras históricas de la Primera Marcha y de los censos antiguos pertenecen a series demográficas separadas. No sustituyen las cifras contemporáneas de 481 millones para el Reino, 523,5 millones para la Federación operativa ni las cuentas ECON-03 de 2026.

##### Normalización de capitales y ciudades principales

La capital federal operativa de Gwaith Valinor es Tirith Gwaith (Nueva Tirion), ubicada en la capital territorial de Valinor. Barad Valinor es la sede política de Aranath Valinor, también en Nueva Tirion. Esta distinción no crea ciudades adicionales ni modifica las cuentas de población.

| Entidad | Capital canónica o administrativa | Equivalencia real |
| --- | --- | --- |
| Valinor | Nueva Tirion | Nueva Tirion |
| Tol Eressëa | Avallónë | Avallónë |
| Systreyjar | Taur-en-Mor | Tórshavn |
| Arnor | Annúminas | Toronto |
| Calenardhon Austral | Pelargir Austral | Porto Alegre |
| Sírënandë | Sirion | Georgetown |
| Colombia Costera | Vinyamar | Barranquilla |
| Panamá Federal | Tirion del Istmo | Ciudad de Panamá |
| Venezuela Federal | Tirith Anor | Caracas |
| Provincia del Orinoco | Barad Oron | Puerto Ordaz |
| Nosselië Toliva | Eressëa Menel | Las Palmas |
| Eryndor | Manama | Manama |
| Harnen | Harnost | Mascate |

Se confirman las siguientes capitales y sedes administrativas conforme al estatus de cada entidad: Osgiliath del Este (Kuala Lumpur), Alqualondë del Pacífico (Honolulu), Eglarest Austral (Suva), Eressëa del Sur (Papeete) y Rhunost del Mar (Hagåtña) para Malaca, Hawái, Fiyi, Polinesia y Micronesia, respectivamente; Harnost (Mascate), Khazad-dûm Oriental (Ciudad de Kuwait), Círdanost (Hadibu), Harlond Oriental (Adén) y Amon Rûdh (Yibuti) para los protectorados Harnen, Kheled-zâram, Círdan, Harlond y Amon Rûdh; Eryn Galen (Nicosia), Eglarest (La Valeta) y Pelargir del Norte (Alejandría) como sedes administrativas de los puertos asociados Alqualondë, Eglarest y Pelargir. La confirmación no convierte protectorados o puertos asociados en Estados federados ni altera sus fronteras.

Las capitales y ciudades principales son subdivisiones urbanas de sus territorios. Sus poblaciones y actividades económicas ya están incluidas en ECON-03 y no se agregan nuevamente al PIB ni a la población territorial.

La cadena estratégica es: Mediterráneo → Egipto → mar Rojo → Adén → Socotra → Omán → Ormuz → Malaca.

### Aparición histórica de la Casa Telcontar

La Casa Telcontar aparece como solución a la crisis sucesoria de los siglos VII–VI a. C. La rotación de Altos Reyes entre las Casas había garantizado el equilibrio inicial, pero comenzó a producir disputas electorales, interrupciones de la política exterior y rivalidades entre puertos, flotas y linajes. Telcontar, originaria de Helsingborg y vinculada a redes marítimas y comerciales, ofrece continuidad dinástica sin eliminar el Consejo de las 24 Casas.

Hacia 575 a. C. la Casa Telcontar emerge como candidata de compromiso; hacia 560 a. C. su primer monarca es reconocido por el Consejo; y hacia 550 a. C. el Pacto de la Corona Telcontar convierte la sucesión preferente de la Casa en una institución pactada. Telcontar conserva la condición de Casa Real número 25, sin voto adicional en el Consejo. El monarca debe jurar los fueros de las 24 Casas, respetar los límites fiscales y proteger santuarios, graneros, mercados y puertos neutrales.

La tradición genealógica vincula a Telcontar con Eärendur Haraldsson, hijo mayor de Harald I Eärond. El mito fundacional describe su unión con una mujer considerada Maiar por las crónicas religiosas; esta figura se interpreta como símbolo de sabiduría, belleza y memoria, no como prueba de una especie sobrenatural. La reconstrucción histórica identifica a sus descendientes como una rama bastarda excluida de la sucesión, que se autoexilió en las tierras bálticas equivalentes a la actual Finlandia. Allí conservaron archivos, redes marítimas y alianzas septentrionales hasta regresar durante la crisis sucesoria. El retorno aportó legitimidad genealógica, flotas y liderazgo, y permitió su reconocimiento como Casa Real. Los rasgos físicos atribuidos a Telcontar se explican históricamente por herencia poligénica, migraciones, concentración familiar y matrimonios dinásticos, no por un genotipo sobrenatural.

### Regulación de la guerra entre Casas, 990–500 a. C.

Después del Concilio de Forostar de 990 a. C., las guerras privadas entre Casas no desaparecen de inmediato, pero quedan progresivamente limitadas por pactos comunes. Se reconocen compensaciones, arbitrajes, rehenes nobles, matrimonios de reconciliación y devolución de prisioneros. La ejecución deliberada de prisioneros queda prohibida como norma política y religiosa de la unión.

También se prohíbe atacar santuarios, saquear graneros y mercados, y quebrantar la neutralidad de los puertos reconocidos. Las Casas deben proteger las reservas alimentarias, respetar los puertos neutrales y abstenerse del saqueo mutuo. Estas reglas buscan transformar la rivalidad armada en competencia regulada, potenciar la unidad y favorecer la cooperación entre las Casas.

Entre 990 y 500 a. C. la guerra pasa gradualmente de ser un derecho privado de los linajes a una actividad regulada por el Consejo, los pactos religiosos, los acuerdos portuarios y la autoridad del Alto Rey. La aplicación es desigual y admite incumplimientos, pero establece la base jurídica de la talasocracia monárquica pactada.

### Regencia de la Corona, 430–441 d. C.

Tras la abdicación de Eärnil II Telcontar en 430 d. C., la sucesión no se resuelve mediante una coronación inmediata. Baranor II, heredero reconocido, todavía no asume formalmente la Corona hasta 441 d. C.

Durante estos once años gobierna una Regencia del Consejo de la Corona, integrada por representantes del Consejo de las 24 Casas, la Casa Telcontar, la Guardia Real, los principales puertos y los custodios de los archivos y santuarios reales. La Regencia mantiene la continuidad administrativa, protege las rutas y convoca la confirmación sucesoria.

Baranor II puede ejercer funciones militares, diplomáticas y ceremoniales durante la regencia, pero su coronación oficial se produce en 441 d. C. El periodo no constituye un reinado adicional ni una interrupción del orden dinástico.

### Sucesión de la Corona valinari, 500 a. C.–500 d. C.

La sucesión valinari funciona como una monarquía hereditaria condicionada. La pertenencia a la Casa Real abre el derecho sucesorio, pero no garantiza por sí sola el acceso efectivo a la Corona.

##### Legitimidad

El heredero legítimo debe pertenecer a la Casa Real, descender de una línea reconocida, aceptar los pactos fundamentales y recibir confirmación institucional. Puede perder legitimidad si rompe juramentos, entrega puertos a una potencia extranjera, ataca santuarios, destruye graneros, inicia guerras privadas o amenaza la continuidad del Reino.

##### Orden sucesorio

El orden preferente es:

1. descendiente directo del monarca;

2. hermano o hermana del monarca;

3. descendiente de una rama colateral;

4. miembro adoptado o reconocido de la Casa Real;

5. candidato pactado por las Casas en una crisis.

La sucesión no establece una prohibición absoluta contra las mujeres. La pertenencia a la Casa Real, la capacidad política y el reconocimiento institucional son más importantes que el sexo del heredero, aunque en los primeros siglos las prácticas puedan favorecer a varones con experiencia militar.

##### Reconocimiento del heredero

El heredero es presentado antes de la muerte o abdicación del monarca mediante genealogía, juramento, entrega del estandarte y promesa de respetar graneros, rutas, santuarios y pactos.

El Consejo de las Casas confirma normalmente al heredero. Los principales santuarios certifican genealogías y juramentos; las guarniciones juran obediencia; y las ciudades portuarias reconocen la continuidad mediante la apertura de sus puertas, la entrega de llaves y la renovación de privilegios.

##### Regencia

La regencia se activa por minoría de edad, enfermedad, ausencia o disputa sucesoria. Puede estar formada por un miembro adulto de la Casa Real, dos Casas Mayores, un representante de los santuarios, un comandante y una ciudad portuaria.

El regente no puede cambiar la sucesión, ceder territorios, modificar pactos fundamentales ni imponer tributos permanentes sin autorización del Consejo.

##### Abdicación y deposición

La abdicación requiere declaración pública, testigos, confirmación del Consejo, registro en santuarios, entrega del estandarte y reconocimiento del sucesor.

La deposición es excepcional y solo procede por traición grave, ruptura sistemática de pactos, entrega del Reino, destrucción de santuarios, uso deliberado del hambre, asesinato de miembros del Consejo o abandono de la defensa.

El procedimiento incluye acusación formal, investigación, audiencia, pronunciamiento religioso, decisión del Consejo, control de arsenales y reconocimiento del nuevo monarca.

##### Matrimonio y reconciliación

Un matrimonio entre ramas rivales puede resolver una crisis sucesoria. Debe acompañarse de renuncias formales, garantías territoriales, distribución de cargos, amnistía, devolución de bienes y juramentos públicos.

Los hijos nacidos fuera de un matrimonio reconocido no poseen automáticamente derecho a la Corona. Pueden ser reconocidos, incorporados a la Casa, recibir títulos, fundar ramas menores o actuar como candidatos de compromiso. Para aspirar a la Corona necesitan reconocimiento del monarca, la Casa Real, el Consejo y los santuarios.

##### Coronación

La coronación tiene tres fases: confirmación política por el Consejo, juramento religioso ante los santuarios e investidura militar con espada, estandarte, sello, corona, llave de la ciudadela y registro de pactos.

La coronación completa exige que Forostar, las principales Casas, las ciudades portuarias y los mandos militares reconozcan al nuevo soberano.

##### Evolución histórica

- 500–300 a. C.: elección confirmada dentro de la Casa Real y gran influencia del Consejo.

- 300–50 a. C.: fortalecimiento de la herencia dinástica por la expansión territorial y comercial.

- 50 a. C.–200 d. C.: designación más estable del heredero y juramento de los mandos navales.

- 200–500 d. C.: reglas más precisas sobre regencias, archivos, sucesión y reconocimiento territorial.

La fórmula sucesoria queda establecida así:

La sangre abre el derecho; el juramento lo legitima; el Consejo lo confirma; los santuarios lo registran; las ciudades y las guarniciones lo hacen efectivo.

### Instituciones económicas y relaciones exteriores

##### Integración por etapas

El desarrollo de las instituciones económicas y de las relaciones exteriores se incorpora como una evolución posterior de la monarquía compuesta. Las oficinas federales modernas no se proyectan sobre el periodo 500 a. C.–500 d. C.

Durante la etapa antigua, la administración económica se apoya en el Consejo de las Casas, tesorerías portuarias, escribas reales y provinciales, santuarios registrales, factores comerciales, gobernadores de puerto y registros de grano, tributos y servicio naval.

La Corona coordina defensa, rutas, arsenales y reservas, mientras las Casas conservan competencias sobre tierras, talleres, aldeas, santuarios y milicias. La fiscalidad se cobra mediante grano, ganado, metales, madera, trabajo limitado, servicio naval y derechos portuarios.

##### Administración Real

La Administración Real se desarrolla gradualmente desde oficinas informales de navegación, tesorerías y archivos de Casa. En su etapa madura comprende el Consejo Supremo de Oficinas, la Tesorería de Navegación, el Cuerpo de Factores Reales, el servicio naval de Oficinas y oficinas regionales de comercio, información y administración territorial.

Las oficinas regionales administran redes policéntricas: Oficina Africana, Oficina Oriental, Oficina Occidental, Oficina Interoceánica y Oficina del Gran Océano. Sus fechas de creación deben diferenciarse de sus antecedentes informales. No son compañías soberanas: actúan bajo mandatos, fiscalización y jurisdicción de la Corona y de los gobiernos territoriales.

##### Bibliotecas y Doctrina de las Siete Copias

Las bibliotecas son infraestructura cívica, administrativa y científica. La Doctrina de las Siete Copias continúa siendo la norma canónica: el conocimiento técnico, jurídico, médico, náutico, agrícola y administrativo esencial debe conservarse en siete copias o depósitos independientes cuando la capacidad material lo permita.

Los fondos esenciales se conservan en siete copias completas distribuidas en siete sedes independientes. La selección de fondos de consulta inmediata no reduce ese mínimo de custodia. Los catálogos registran integridad, cotejo y reposición de cada copia, y la pérdida de una sede activa su restauración desde las otras.

La Ley de Custodia Compartida obliga a registrar y compartir el conocimiento técnico. Solo admite excepciones temporales para códigos militares activos, claves diplomáticas, información personal, procedimientos peligrosos y conocimientos rituales restringidos. Estas excepciones no permiten monopolios técnicos permanentes de una Casa.

##### Especialización regional

Númenor se especializa en navegación e ingeniería naval; Valinor, en memoria, cultura y enseñanza; Tol Eressëa, en archivo y traducción; Panamá Federal, en tránsito, agua e ingeniería; el Orinoco y Sírënandë, en ciencias tropicales, hidrología y navegación fluvial; el Caribe, en meteorología, energía y logística; y Malaca, en lenguas, comercio y conocimientos índicos y asiáticos.

Estas especializaciones no excluyen la práctica de otras ciencias en cada región.

##### Constitucionalización y relaciones modernas

La Carta de 1705 y sus reformas posteriores fortalecen el presupuesto representativo, la responsabilidad gubernamental, la auditoría, la justicia administrativa y los límites de mandato. No originan todos los controles, sino que consolidan antecedentes procedentes de los pactos de las Casas, la fiscalidad registrada y los archivos reales.

La reorganización de 1958 transforma oficinas comerciales, navales y técnicas en agencias y gobiernos coordinados. No convierte retrospectivamente a las compañías reguladas en autoridades soberanas.

Las relaciones exteriores modernas distinguen comercio, inversión estratégica, representación gubernamental y cooperación militar. Las concesiones no implican soberanía perpetua; la deuda no entrega aduanas, policía ni territorio al acreedor; y los peajes del canal se distinguen de los aranceles comerciales.

La alianza con Chile se desarrolla desde 1828–1844, el tratado de 15 de noviembre de 1844, la coordinación austral y los protocolos del canal. Punta Arenas participa desde 1848. Los depósitos comerciales no son bases soberanas y la ayuda humanitaria no exige pago previo. La cooperación de 1941–1945 mantiene el mando separado; desde 1958 se amplía a ciencia, salud, cultura y desastres.

##### Parlamento y gobiernos territoriales

El Senado de 74 miembros, la Cámara Popular y los gobiernos territoriales pertenecen al orden constitucional moderno. Los Estados poseen constitución, primer ministro, parlamento, tribunal superior y presupuesto. Los distritos tienen asamblea, administrador federal y tribunal regional, pero no constitución estatal propia.

Estas instituciones no se confunden con el Consejo de las Casas, las Casas Mayores, las Casas Menores, las Casas Vasallas ni la Casa Real.

### Administración política y territorial antigua

#### Política valinari, 500 a. C.–500 d. C.

##### Monarquía pactista

Valinor evoluciona desde una confederación de Casas hacia una monarquía pactista cada vez más centralizada. La Corona no elimina la autonomía de las Casas: la integra mediante obligaciones militares, fiscales, religiosas y comerciales.

La autoridad se sostiene en juramentos, genealogías, memoria ancestral, protección militar, graneros, arbitraje, defensa de rutas y reconocimiento de privilegios.

##### Corona y Consejo de las Casas

La Corona dirige la diplomacia exterior, la guerra general, la defensa naval, los arsenales, la protección de rutas, el nombramiento de gobernadores, la validación monetaria, el arbitraje entre Casas, los archivos estratégicos y los puertos principales.

Durante 500–300 a. C., Forostar (Helsingborg) es la capital política y defensiva. Allí se concentran la Corona, el Consejo, el archivo de tratados, el arsenal, los graneros reales, el santuario de pactos, los tribunales y el puerto militar.

El Consejo aprueba guerras generales, distribuye obligaciones, ratifica tratados, confirma sucesiones, protege santuarios y supervisa graneros. No es un parlamento moderno: la representación depende del estatus de cada Casa.

##### Autonomía y obligaciones de las Casas

Las Casas Mayores administran tierras, tribunales internos, milicias, santuarios, talleres, puertos y derechos de explotación. A cambio aportan soldados, barcos, grano, madera, metales, impuestos y participación en campañas.

No pueden declarar una guerra general, atacar santuarios, destruir graneros, impedir rutas comunes, ceder territorio a una potencia extranjera ni acuñar moneda sin autorización.

Las Casas Menores aportan exploradores, pilotos, cartógrafos, intérpretes, mercaderes y protección de rutas. Las Casas Vasallas administran territorios subordinados y entregan parte de su producción y tropas a una Casa tutelar.

##### Centralización, 300–50 a. C.

La expansión hacia el Báltico, el mar del Norte y el Mediterráneo impulsa oficinas portuarias, registros de barcos, tribunales mercantiles, inspectores de arsenales, depósitos reales, mandos regionales y escuelas administrativas.

Forostar continúa como capital. Los nuevos puertos reciben instrucciones y recursos desde la capital, pero conservan estatutos diferenciados como provincia, puerto asociado, factoría, estación o territorio explorado.

##### Capital política y capital naval

Entre 50 a. C. y 200 d. C., Forostar continúa siendo la capital política y jurídica. Númenor se convierte en capital naval oceánica, con astilleros, escuelas, cartografía, depósitos y mando de convoyes. Systreyjar funciona como enlace septentrional; Nosselië Toliva como escala atlántica oriental; y Tol Eressëa como estación avanzada.

Númenor no sustituye jurídicamente a Forostar. Esta división evita trasladar prematuramente la Corona a territorios recién incorporados.

##### Estatutos territoriales

El sistema distingue entre Reino central, provincia, puerto asociado, factoría, estación y territorio explorado. La clasificación depende de población permanente, administración, fiscalidad, guarnición, soberanía y representación.

Esta diferencia impide convertir toda escala visitada en una provincia y evita proyectar las fronteras federales modernas sobre la Antigüedad.

##### Política social y religiosa

La sociedad distingue Casa Real, Casas Mayores, Casas Menores, Casas Vasallas, sacerdocios, mercaderes, oficiales, artesanos, campesinos libres, dependientes, libertos y esclavizados.

Los santuarios registran pactos, genealogías, deudas, derechos de agua, contratos y acuerdos de paz. También arbitran conflictos y protegen refugiados. La religión legitima la Corona, pero limita la ruptura de juramentos, la destrucción de santuarios, el uso deliberado del hambre, la tortura y el asesinato de prisioneros.

##### Crisis, 200–500 d. C.

Las epidemias, guerras, piratería, interrupción de rutas y pérdida de archivos debilitan a algunas Casas y fortalecen a gobernadores militares, puertos y administradores de la Corona.

La respuesta incluye recuperación de rutas, inventarios, restauración de archivos, consejos regionales, guarniciones reforzadas, protección de mercados y redistribución de alimentos. La crisis no destruye la monarquía, pero acelera la centralización de la defensa, la fiscalidad y la administración portuaria.

##### Relación con Roma y resultado político

Valinor reconoce el predominio romano en el Mediterráneo, pero mantiene soberanía sobre sus territorios atlánticos, independencia religiosa, autonomía militar y capacidad diplomática propia.

Hacia 500 d. C., Valinor es una monarquía compuesta con Corona hereditaria, Consejo de las Casas, autonomía nobiliaria, burocracia portuaria, armada oceánica, ejército mixto, ciudades estatutarias y territorios de integración desigual.

La tensión política fundamental queda definida así:

Las Casas controlan la tierra y las comunidades; la Corona controla la guerra exterior, las rutas y la unidad del Reino.

#### Secuencia política valinari, 500 a. C.–500 d. C.

##### Sucesión de la Corona

La Corona es hereditaria, pero no absolutamente automática. El heredero debe ser reconocido por la Casa Real, el Consejo de las Casas, los principales santuarios, las guarniciones y las ciudades portuarias.

El principio preferente es la primogenitura, aunque el Consejo puede rechazar a un heredero incapaz, menor de edad o acusado de romper los pactos fundamentales. Las soluciones posibles son reconocimiento, regencia, elección entre ramas, matrimonio de reconciliación, pacto entre Casas, abdicación o deposición excepcional.

##### Ascenso de la Casa Telcontar

La Casa Telcontar se convierte en Casa Real durante la crisis del siglo VI a. C. Su legitimidad combina descendencia del linaje real anterior, vínculos con Helsingborg, retorno del autoexilio finlandés, capacidad militar, apoyo de varias Casas y el pacto de 550 a. C.

La Casa Telcontar no elimina a las Casas Mayores. Su ascenso se legaliza mediante acuerdos y le concede el mando de la defensa exterior, la custodia de arsenales, la representación diplomática, la coordinación fiscal, la protección de rutas y el arbitraje entre Casas.

##### Constitución pactista

La monarquía se organiza mediante pactos acumulativos que establecen límites del poder real, obligaciones de las Casas, sucesión, contribuciones militares, derechos portuarios, protección de santuarios, prohibición de guerras privadas ilimitadas y respeto a graneros y mercados.

La Corona puede responder inmediatamente a una agresión, pero necesita apoyo del Consejo para guerras prolongadas, conquistas, contribuciones extraordinarias, modificación de derechos, cesión de puertos o tratados de subordinación.

##### Administración territorial

La administración distingue Reino central, provincia, distrito, puerto asociado, factoría, estación y territorio explorado. Cada categoría implica un nivel distinto de población permanente, fiscalidad, guarnición, soberanía, representación y administración.

La secuencia habitual de incorporación es: exploración, contacto, intercambio, estación, factoría, puerto asociado, guarnición, asentamiento permanente y provincia o territorio integrado. No todos los territorios alcanzan la última fase.

##### Ciudadanía y justicia

La ciudadanía se divide en ciudadanía de linaje, de Casa, territorial, portuaria y protegida. También existen las condiciones de extranjero, dependiente y esclavizado.

Los tribunales se distribuyen entre Casas, ciudades, puertos, Corona, santuarios y ejército. Los conflictos entre Casas o entre una Casa y la Corona pueden trasladarse al Consejo o a los tribunales reales.

##### Relaciones exteriores

La política exterior combina tratados comerciales, embajadas, matrimonios, rehenes políticos, reconocimiento territorial, arbitraje, intercambio de prisioneros, escolta de convoyes, lucha contra piratería, venta de armas y apoyo logístico.

Con Roma, Valinor mantiene una asociación estratégica sin subordinación política. Reconoce el predominio romano en el Mediterráneo, pero conserva soberanía atlántica, independencia religiosa, autonomía militar y capacidad diplomática propia.

##### Crisis y reformas

Las disputas sucesorias, rivalidades entre Casas, guerras privadas, crisis de graneros, conflictos portuarios, epidemias, pérdida de rutas, rebeliones y aislamiento de estaciones impulsan la creación de regencias, tribunales reales, inspectores, depósitos reales, gobernadores, consejos regionales, guarniciones permanentes y pactos sucesorios.

Entre 300 y 50 a. C. aumenta la administración comercial. Entre 50 a. C. y 200 d. C. se fortalece el mando naval y la diplomacia. Entre 200 y 500 d. C. la crisis acelera la centralización defensiva y fiscal.

##### Resultado hacia 500 d. C.

Valinor se convierte en una monarquía compuesta con Casa Real hereditaria, Consejo de las Casas, aristocracia territorial, ciudades estatutarias, provincias, puertos asociados, estaciones ultramarinas, justicia plural, ciudadanía jerarquizada, ejército mixto, armada oceánica y diplomacia comercial.

La evolución política queda resumida así:

Confederación de Casas → monarquía pactista → monarquía marítima → administración territorial → monarquía compuesta centralizada.

#### Ascenso de la Casa Telcontar, siglo VI a. C.

##### Crisis política y militar

Entre aproximadamente 590 y 550 a. C., Valinor atraviesa una crisis que combina guerras privadas, disputas sucesorias, ataques contra puertos, interrupción de rutas, pérdida de graneros, rivalidad por arsenales, aislamiento de comunidades noruegas y debilitamiento de la autoridad real.

Las Casas navales podían proteger sus puertos, pero no toda la red; las Casas agrícolas podían sostener graneros, pero necesitaban protección; y las Casas interiores podían movilizar soldados, pero dependían del comercio marítimo. La crisis demuestra que el sistema necesita una autoridad común más fuerte.

##### Linaje y autoexilio

La Casa Telcontar reivindica su descendencia del linaje real anterior a través del hijo mayor de Harald I Eärond. La interpretación histórica del canon establece que era una rama humana descendiente de un hijo bastardo del linaje real.

Tras perder una lucha sucesoria, la rama se exilia en las regiones de la actual Finlandia. Allí desarrolla experiencia en guerra de bosques, defensa de pasos, movilidad terrestre, fortalezas pequeñas, vigilancia septentrional y negociación con comunidades periféricas.

El retorno se produce cuando Valinor está en peligro. La Casa vuelve vinculada a Helsingborg, no como fuerza conquistadora, sino como defensora del orden común.

##### Regreso y coalición

Telcontar demuestra su utilidad mediante defensa de pasos, recuperación de fortalezas, escolta de graneros, coordinación de milicias, negociación entre Casas y protección de Helsingborg.

Recibe apoyo de Casas navales interesadas en la seguridad de puertos y convoyes, Casas agrícolas que necesitan proteger graneros, Casas de estudio que buscan preservar archivos y Casas militares que valoran su disciplina y experiencia fronteriza.

##### Proclamación de 560 a. C.

En 560 a. C., la Casa Telcontar es proclamada Casa Real. La proclamación establece que recupera la dignidad real, que su jefe puede ejercer funciones de Corona y que la defensa común queda bajo su coordinación.

La proclamación no elimina el Consejo, no confisca los dominios de las Casas y no convierte automáticamente a la monarquía en una autoridad absoluta. Es una solución de emergencia que necesita legalización posterior.

##### Pacto de la Corona de 550 a. C.

El pacto de 550 a. C. transforma la proclamación en un sistema constitucional. Reconoce la sucesión hereditaria preferente, limita el poder real, mantiene el Consejo, protege los fueros territoriales, entrega a la Corona el mando de la defensa exterior y obliga a respetar puertos neutrales, santuarios, graneros, prisioneros y arbitrajes.

La Corona no puede convertir el Reino en propiedad personal de Telcontar. Debe gobernar dentro del orden pactista.

##### Competencias de la Casa Real

La Casa Real obtiene el mando de la defensa exterior, la custodia de arsenales, la representación diplomática, la coordinación fiscal, la protección de rutas y el arbitraje entre Casas.

También supervisa:

- armada común;

- fortalezas estratégicas;

- convoyes;

- movilización general;

- depósitos de madera e hierro;

- registros de barcos;

- graneros de emergencia;

- nombramiento de gobernadores;

- tratados con potencias extranjeras.

##### Límites de la Corona

La Corona no puede confiscar tierras sin procedimiento, abolir una Casa sin juicio, imponer tributos ilimitados, controlar todos los santuarios, iniciar guerras ofensivas sin autorización, modificar unilateralmente la sucesión ni cerrar puertos por razones privadas.

El Consejo, los santuarios, las ciudades portuarias y las guarniciones actúan como contrapesos.

##### Consecuencias institucionales

Después de 550 a. C. se consolidan registros de Casas, censos militares, inventarios de grano, listas de barcos, archivos de pactos, mapas de fortificaciones, rutas oficiales y gobernadores regionales.

La Casa Telcontar transforma la defensa en un sistema coordinado mediante guardia real, arsenal central, guarniciones permanentes, convoyes comunes, torres de señales, mandos regionales, tropas de reacción y fuerzas anfibias.

##### Resultado histórico

El ascenso de Telcontar es una transformación constitucional y no una simple conquista dinástica. La Casa recibe la Corona; las Casas conservan sus dominios; el Consejo conserva su función; los santuarios garantizan la legitimidad; y los puertos sostienen la nueva monarquía.

Hacia 500 a. C., Valinor deja de ser una confederación inestable y se convierte en una monarquía pactista capaz de coordinar defensa, comercio, fiscalidad y diplomacia.

#### Constitución monárquica pactista, 500 a. C.–500 d. C.

La monarquía valinari no se organiza mediante una constitución única, sino mediante pactos acumulativos, juramentos, decisiones del Consejo, fueros territoriales, tratados portuarios y registros de santuarios.

##### Fuentes de autoridad

Las fuentes constitucionales son los pactos fundacionales, el Pacto de la Corona de 550 a. C., los fueros territoriales, los tratados portuarios, los juramentos religiosos y los precedentes sucesorios. Una decisión nueva debe ser compatible con ellos o modificarlos mediante un procedimiento reconocido.

##### Límites del poder real

La Corona no puede confiscar tierras sin procedimiento, abolir una Casa sin juicio, ejecutar prisioneros por decisión unilateral, cerrar un puerto por razones privadas, destruir santuarios, impedir mercados, imponer tributos ilimitados, transferir un territorio sin consulta, iniciar guerras ofensivas sin autorización ni alterar la sucesión por capricho.

Puede ordenar una respuesta defensiva inmediata, pero debe justificarla posteriormente ante el Consejo.

##### Competencias de la Corona

La Corona posee autoridad directa sobre defensa exterior, armada común, arsenales reales, diplomacia general, tratados con grandes potencias, protección de rutas, guarniciones estratégicas, movilización general, archivos reales y distribución de reservas en crisis.

Requieren cooperación con el Consejo la creación de impuestos, conquistas, fundación de provincias, concesión de puertos, nombramiento de gobernadores, modificación de fueros, traslado de población, tratados de subordinación y nuevos monopolios.

##### Consejo de las Casas

El Consejo aprueba guerras generales, sucesiones disputadas, contribuciones extraordinarias, incorporación de territorios, revisión de fueros, protección de santuarios y tratados que afectan al Reino.

La representación depende de antigüedad, función, población, riqueza, capacidad militar y control de puertos. La Casa Real preside o convoca, pero no posee una superioridad absoluta en todas las decisiones.

##### Guerra y movilización

La respuesta defensiva inmediata puede ser ordenada por el rey. Una guerra ofensiva limitada requiere informe militar, evaluación de recursos y autorización. Una conquista o campaña prolongada exige aprobación del Consejo porque implica impuestos, ocupación, pérdida de trabajadores, interrupción comercial y riesgos para los graneros.

Las contribuciones extraordinarias deben ser temporales, registradas, proporcionales, justificadas y revisables.

##### Puertos, santuarios, graneros y mercados

La Corona controla seguridad, convoyes, arsenales y entrada de flotas enemigas. Las autoridades locales conservan mercados, contratación, tribunales comerciales y costumbres.

Los santuarios protegen archivos, refugiados y juramentos. Los graneros no pueden ser destruidos deliberadamente. Los mercados neutrales permiten abastecimiento, intercambio de prisioneros, negociación y continuidad económica.

##### Justicia y sanciones

La eliminación o reducción de derechos de una Casa exige acusación, investigación, audiencia, pruebas, intervención del Consejo, decisión y registro. Las sanciones incluyen multas, pérdida temporal de privilegios, reducción de representación, entrega de rehenes, administración real temporal, pérdida de un puerto o confiscación parcial.

La abolición completa de una Casa es excepcional.

##### Tratados de subordinación

Un tratado que subordine Valinor a una potencia extranjera requiere aprobación de la Corona y del Consejo, consulta a las Casas afectadas, validación religiosa, evaluación militar y garantías sobre puertos y rutas.

Una alianza comercial no equivale a subordinación. La subordinación existe si una potencia extranjera obtiene control militar, fiscal, sucesorio, gubernamental o monopolístico sobre el Reino.

##### Crisis constitucionales

Las crisis principales son sucesiones disputadas, minorías de edad, rechazo de contribuciones, cierre de puertos, guerras entre Casas, apropiación de graneros, ataque a santuarios, tratados secretos, rebeliones de guarniciones e intentos de convertir la Corona en autoridad absoluta.

Entre 500 y 300 a. C. predominan costumbre, juramentos y autoridad del Consejo. Entre 300 y 50 a. C. se formalizan impuestos y estatutos portuarios. Entre 50 a. C. y 200 d. C. la armada impulsa la centralización. Entre 200 y 500 d. C. las crisis obligan a registrar con mayor precisión los límites del poder real.

La fórmula constitucional queda establecida así:

La Corona gobierna por pacto, la Casa conserva por juramento, el Consejo limita por memoria y el Reino permanece unido por defensa y reciprocidad.

#### Administración territorial en profundidad, 500 a. C.–500 d. C.

##### Gobernadores y delegados

Los gobernadores representan a la Corona en provincias y distritos. No sustituyen automáticamente a las autoridades de las Casas, sino que coordinan funciones que afectan al conjunto del Reino.

Sus competencias son:

- recaudar contribuciones;

- mantener caminos;

- proteger graneros;

- coordinar milicias;

- supervisar guarniciones;

- registrar población y recursos;

- aplicar decisiones reales;

- informar sobre conflictos;

- proteger mercados;

- administrar almacenes estratégicos.

Los gobernadores son asistidos por escribas, jueces, administradores de graneros, oficiales militares, sacerdotes registradores y representantes de las ciudades.

##### Consejos locales

Cada provincia o puerto importante posee un consejo local formado por:

- representante de la Casa dominante;

- gobernador o delegado real;

- magistrados urbanos;

- sacerdocio del santuario principal;

- comandante de la guarnición;

- mercaderes reconocidos;

- representantes de comunidades agrícolas;

- escribas de archivo.

El consejo resuelve asuntos cotidianos, pero no puede contradecir los pactos del Reino ni los fueros provinciales.

##### Administración de recursos

Los administradores registran:

- tierras cultivadas;

- cosechas;

- rebaños;

- minas;

- barcos;

- talleres;

- población;

- trabajadores dependientes;

- reservas de grano;

- agua disponible;

- obligaciones militares.

El registro no es un censo moderno exacto. Es una herramienta para fiscalidad, defensa, distribución de alimentos y sucesión de derechos.

##### Fiscalidad territorial

Las obligaciones se adaptan a la economía local:

- regiones agrícolas: grano, animales y semillas;

- regiones forestales: madera, resina y carbón vegetal;

- regiones mineras: hierro, cobre y herramientas;

- puertos: aranceles, reparación y servicio naval;

- estaciones: agua, alojamiento y vigilancia;

- ciudades: moneda, trabajo especializado y administración;

- Casas militares: tropas, caballos, armas y fortificaciones.

La Corona intenta evitar la doble imposición. Una Casa no puede cobrar tributos locales y permitir que un gobernador real vuelva a exigir la misma contribución sin autorización.

##### Justicia local y apelación

La justicia comienza en el nivel más cercano al conflicto. Un problema de lindes se resuelve primero ante la autoridad local o la Casa. Un contrato portuario se tramita ante el tribunal mercantil. Una disputa entre Casas pasa al Consejo o a un tribunal real.

El sistema reconoce apelaciones por:

- abuso de autoridad;

- falsificación de registros;

- apropiación de tierras;

- retención de graneros;

- violencia de guarniciones;

- incumplimiento de pactos;

- corrupción de jueces.

Los santuarios certifican documentos y juramentos, pero no monopolizan toda la justicia.

##### Integración de comunidades locales

La administración puede seguir tres modelos:

1. integración directa: gobernador, impuestos y tribunales valinari;

2. administración indirecta: autoridades locales conservadas bajo tributo y supervisión;

3. administración portuaria: control del puerto y de las rutas, con escasa intervención en el interior.

La elección depende de la resistencia, densidad de población, utilidad económica, existencia de élites cooperantes y capacidad militar.

##### Comunidades no pertenecientes al linaje valinari

Las comunidades locales, mestizas, portuarias, germánicas orientales y extranjeras pueden conservar:

- lenguas;

- costumbres;

- cultos;

- autoridades comunitarias;

- formas de propiedad;

- sistemas de parentesco.

Su reconocimiento no implica igualdad inmediata con las Casas ni incorporación al linaje valinari. Pueden acceder progresivamente a ciudadanía territorial, portuaria o protegida.

##### Control de territorios remotos

Las estaciones y factorías remotas dependen de un sistema de relevos y convoyes. Un representante local puede administrar el puesto, pero sus decisiones estratégicas requieren autorización de la base regional.

Las bases remotas deben mantener:

- inventario de agua;

- registro de barcos;

- reservas alimentarias;

- lista de personal;

- señales de emergencia;

- rutas de evacuación;

- autoridad de sustitución.

Si una estación pierde comunicación, el mando regional puede enviar un convoy, reducir la presencia o declarar suspendida temporalmente la administración.

##### Costos administrativos

La expansión territorial genera costos permanentes:

- salarios y raciones;

- transporte;

- reparación de fortificaciones;

- protección de convoyes;

- traducción;

- enfermedades;

- mantenimiento de archivos;

- construcción de caminos;

- reemplazo de guarniciones;

- compensación a autoridades locales.

Un territorio con pocos recursos puede seguir siendo útil si controla una ruta, pero también puede convertirse en una carga si requiere más defensa que ingresos.

##### Integración y pérdida de estatus

Un territorio asciende de estación a factoría, puerto asociado o provincia cuando aumenta su población permanente, comercio, producción, seguridad y conexión administrativa.

Puede perder estatus por:

- despoblación;

- epidemia;

- rebelión;

- pérdida del puerto;

- destrucción del granero;

- interrupción de rutas;

- falta de agua;

- costos militares excesivos.

Esta reversibilidad hace que la administración territorial sea histórica y no una lista fija de posesiones.

##### Resultado administrativo

Hacia 500 d. C., el sistema valinari administra territorios de manera desigual pero coordinada. La Corona controla las funciones estratégicas; las Casas administran la base económica y social; las ciudades sostienen mercados y puertos; los santuarios preservan los registros; y los gobernadores conectan las decisiones centrales con la vida local.

#### Administración política en profundidad, 500 a. C.–500 d. C.

##### Estructura central

La administración central se compone de la Casa Real, el Consejo de las Casas, la Cancillería Real, las oficinas fiscales, los arsenales, los archivos y los tribunales superiores.

La Casa Real dirige diplomacia, defensa exterior, armada, arsenales, tratados, sucesión, nombramiento de altos gobernadores, protección de rutas y reservas estratégicas.

El Consejo revisa guerras, sucesiones, contribuciones extraordinarias, reformas, incorporación territorial, modificaciones de fueros y tratados de subordinación.

##### Oficinas de la Cancillería

La Cancillería conserva y produce decretos, cartas, tratados, registros fiscales, censos militares, mapas, inventarios y órdenes de movilización.

Sus oficinas especializadas son la Oficina de la Corona, la Oficina de Pactos, la Oficina Portuaria, la Oficina Militar, la Oficina de Graneros y la Oficina de Tierras.

##### Gobernadores y funcionarios

Los gobernadores representan a la Corona sin sustituir automáticamente a las autoridades de las Casas. Supervisan recaudación, caminos, graneros, milicias, guarniciones, registros, conflictos y aplicación de decisiones reales.

Son asistidos por escribas, jueces, administradores, sacerdotes registradores, oficiales militares y representantes urbanos.

La rotación, la duración limitada, las auditorías, las fianzas y la separación de funciones impiden que un gobernador controle simultáneamente impuestos, ejército, justicia, graneros y puerto.

##### Consejos provinciales y ciudades

Los consejos locales incluyen gobernador, Casa dominante, magistrados urbanos, comandante, sacerdocio, mercaderes, administradores de graneros, comunidades agrícolas y escribas.

Administran presupuestos, obras, reservas, mercados y conflictos, pero no pueden declarar guerra, ceder territorios, modificar la sucesión ni romper tratados reales.

Las ciudades portuarias poseen estatutos especiales y pueden administrar muelles, mercados, tribunales mercantiles, contratación, almacenes y guardias. A cambio mantienen murallas, abastecen guarniciones y permiten el uso militar del puerto.

##### Administración rural y de Casas

Las aldeas administran cultivos, pastos, agua, bosques, molinos, caminos y graneros. Las Casas controlan tierras, talleres, santuarios, milicias, archivos y obligaciones familiares.

Los informes registran población, cosechas, animales, soldados, armas, deudas, conflictos, puertos y obras. Estos registros sirven para fiscalidad, defensa y sucesión, aunque no son censos modernos exactos.

##### Fiscalidad y no duplicación

Las regiones agrícolas entregan grano, animales y semillas; las forestales, madera, resina y carbón; las mineras, hierro, cobre y herramientas; los puertos, aranceles, reparación y servicio naval; las ciudades, moneda y trabajo especializado.

La Corona intenta evitar la doble imposición. Una Casa no puede cobrar tributos locales y permitir que un gobernador vuelva a exigir la misma contribución sin autorización.

##### Justicia administrativa

Los conflictos comienzan en el nivel más cercano: Casa, comunidad o tribunal urbano. Los contratos marítimos van a tribunales portuarios; las disputas entre Casas, a tribunales reales o al Consejo; los juramentos, matrimonios y genealogías se certifican en santuarios.

Se admiten apelaciones por corrupción, falsificación, apropiación de tierras, retención de graneros, violencia de guarniciones y abuso de autoridad.

##### Integración de comunidades

La administración aplica tres modelos: integración directa mediante gobernador y tribunales valinari; administración indirecta mediante autoridades locales bajo tributo y supervisión; y administración portuaria con control del puerto y escasa intervención interior.

Las comunidades pueden conservar lengua, costumbres, cultos, autoridades y formas de propiedad. Esto no implica igualdad inmediata con las Casas, pero permite ciudadanía territorial, portuaria o protegida.

##### Territorios remotos

Las estaciones y factorías dependen de relevos y convoyes. Deben conservar inventarios de agua, registros de barcos, reservas alimentarias, listas de personal, señales de emergencia, rutas de evacuación y autoridad de sustitución.

Si pierden comunicación, el mando regional puede enviar un convoy, reducir la presencia o suspender temporalmente la administración.

##### Costos y pérdida de estatus

La expansión implica salarios, raciones, mantenimiento de fortificaciones, convoyes, traducción, enfermedades, archivos, caminos y compensación a autoridades locales.

Un territorio puede ascender de estación a factoría, puerto asociado o provincia si aumenta su población, comercio, producción, seguridad y conexión administrativa. También puede retroceder por despoblación, epidemia, rebelión, pérdida del puerto, destrucción del granero, interrupción de rutas, falta de agua o costos militares excesivos.

##### Resultado

Hacia 500 d. C., la administración valinari es una burocracia pactista y territorialmente desigual. La Corona coordina, las Casas administran, las ciudades recaudan, los santuarios registran y las comunidades producen.

#### Organización territorial valinari en 5 d. C.

En 5 d. C. no se proyectan fronteras posteriores: Tol Eressëa se descubre en 20–40 d. C.; Groenlandia se reconoce en 55–75; las expediciones a Terranova corresponden a 400–500 y el descubrimiento formal de Valinor a 650–750. Descubrimiento, estación e incorporación política son actos distintos. A092-R01.

##### Reino central

El Reino central en 5 d. C. está formado por el núcleo histórico europeo y las unidades administradas de manera permanente:

- Escania, con Forostar (Helsingborg) como capital política;

- Noruega valinaria, organizada en distritos costeros y valles asociados;

- Systreyjar, ya integrada como territorio insular de escala y defensa;

- Nosselië Toliva (Canarias), integrada como territorio atlántico oriental del Reino;

- enclaves y puertos bajo administración directa en las rutas septentrionales y atlánticas orientales.

La integración no significa uniformidad. Escania concentra la Corona, el Consejo y los archivos; Noruega aporta madera, hierro, pesca y tripulaciones; Systreyjar conecta el norte con el Atlántico; y Nosselië Toliva sostiene las rutas entre el Mediterráneo, África occidental y el Atlántico.

##### Provincias y unidades equivalentes

En 5 d. C. las provincias plenamente desarrolladas son pocas. El núcleo se organiza principalmente mediante distritos de Casa y territorios reales. Las unidades con características provinciales son:

- Escania, como territorio central y sede de la Corona;

- Noruega costera, como conjunto de distritos bajo coordinación real;

- Systreyjar, como territorio insular integrado;

- Nosselië Toliva, como territorio atlántico administrado.

Arnor, Calenardhon Austral, Sírënandë, Venezuela Federal, Provincia del Orinoco, Colombia Costera, Panamá Federal, Trinidad, Tobago, Bahamas, Bermudas, Barbados, Hawái, Fiyi, Polinesia, Micronesia, Númenor, Tol Eressëa, Groenlandia y Valinor todavía no deben figurar como provincias o estados integrantes en esta fecha.

##### Gobernadores y autoridades

Forostar cuenta con una autoridad real central, no con un gobernador provincial independiente. En Noruega y Systreyjar existen delegados reales, comandantes de distrito y administradores de puerto. Nosselië Toliva puede estar dirigida por un gobernador de escala atlántica, subordinado a la Corona y con funciones civiles, navales y de abastecimiento.

Estos cargos administran impuestos, graneros, guarniciones, caminos y puertos, pero deben consultar a las Casas y a las autoridades locales.

##### Capitales

- Forostar (Helsingborg): capital política, jurídica y militar del Reino.

- Systreyjar: capital administrativa insular y estación de enlace septentrional.

- Nosselië Toliva: capital de escala atlántica oriental; su ciudad principal aún no posee una denominación canónica individual definitiva.

- Noruega: no tiene una capital única plenamente equivalente a Forostar; sus centros se distribuyen entre puertos y valles bajo Casas regionales.

Tol Eressëa, Númenor, Groenlandia y Valinor aún no tienen capitales valinarias en 5 d. C. porque todavía no han sido descubiertas o incorporadas en la secuencia canónica.

##### Distritos

Los distritos de 5 d. C. se concentran en:

- subzonas de Escania;

- valles y fiordos noruegos;

- puertos de Systreyjar;

- zonas agrícolas y portuarias de Nosselië Toliva;

- corredores del Báltico y el mar del Norte;

- rutas terrestres hacia arsenales y graneros.

Cada distrito administra cultivos, pastos, bosques, caminos, milicias, santuarios y depósitos.

##### Ciudades con estatuto

Las ciudades con estatuto en 5 d. C. se concentran en el núcleo antiguo:

- Forostar (Helsingborg): capital política y arsenal principal;

- Lund: centro religioso, educativo y de archivo regional;

- Ystad: puerto comercial y de cabotaje;

- Osby: nodo forestal y terrestre del noreste escaniano;

- Helsingør: estación de tránsito y control marítimo danés;

- principales puertos noruegos de las Casas;

- puerto principal de Systreyjar;

- puerto principal de Nosselië Toliva.

Estas ciudades tienen estatutos locales, pero no todas son capitales provinciales.

##### Puertos asociados

Los puertos mediterráneos asociados a la red valinari en 5 d. C. son:

- Alqualondë (Chipre);

- Eglarest (Malta);

- Pelargir (Alejandría);

- puertos aliados de Sicilia;

- estaciones comerciales del Levante;

- puertos de enlace del mar Rojo.

Su relación es comercial, diplomática y logística. No forman parte del Reino central ni están sujetos a administración provincial directa.

##### Factorías

Las factorías activas o posibles en 5 d. C. se sitúan en:

- Sicilia;

- Malta, antes de su consolidación como puerto asociado;

- Chipre, antes de la formalización de sus tratados;

- Alejandría, junto a la delegación portuaria;

- costas del Levante;

- puertos del mar Rojo;

- rutas de Adén y Socotra.

Las factorías contienen almacenes, talleres, comerciantes, intérpretes y guardias. No ejercen soberanía sobre el territorio circundante.

##### Estaciones

En 5 d. C. funcionan o se proyectan estaciones en:

- Systreyjar;

- Nosselië Toliva;

- cabos del mar del Norte;

- islas de escala atlántica oriental;

- puertos mediterráneos;

- entradas del mar Rojo;

- rutas hacia Adén y Socotra.

Tol Eressëa aún no es estación valinaria permanente en esta fecha, porque su descubrimiento se fija después.

##### Territorios explorados

En 5 d. C. son territorios explorados o conocidos indirectamente:

- costas atlánticas occidentales;

- rutas hacia Tol Eressëa;

- regiones septentrionales más allá de Systreyjar;

- posibles costas de Groenlandia, todavía no incorporadas;

- rutas oceánicas occidentales;

- costas americanas aún no alcanzadas por expediciones permanentes;

- interiores africanos más allá de los puertos;

- regiones orientales más allá del mar Rojo.

No se atribuye soberanía valinari a estas zonas.

##### Resumen de estatus en 5 d. C.

| Tipo | Territorios o lugares principales |
| --- | --- |
| Reino central | Escania, Noruega valinaria, Systreyjar, Nosselië Toliva |
| Capital política | Forostar (Helsingborg) |
| Distritos | subzonas de Escania, valles noruegos, puertos de Systreyjar y Nosselië Toliva |
| Ciudades con estatuto | Forostar, Lund, Ystad, Osby, Helsingør y puertos principales |
| Puertos asociados | Alqualondë, Eglarest, Pelargir y puertos aliados de Sicilia |
| Factorías | Sicilia, Malta, Chipre, Alejandría, Levante y mar Rojo |
| Estaciones | Systreyjar, Nosselië Toliva, mar del Norte y rutas mediterráneas |
| Territorios explorados | rutas hacia Tol Eressëa, Groenlandia futura, Atlántico occidental, interior africano y rutas orientales |

La organización de 5 d. C. es, por tanto, una red septentrional y atlántica oriental consolidada, todavía anterior a la expansión oceánica hacia Tol Eressëa, Groenlandia, Númenor, América y Valinor.

### Transición de los pactos a la monarquía constitucional

#### Autoridad común y autonomía territorial

La historia política valinari se explica por la necesidad de sostener obligaciones comunes entre territorios separados por el mar. Las Casas aportan tierras, talleres, redes familiares y contingentes; los puertos aportan aduanas, arsenales y servicios; la Corona coordina defensa exterior, arbitraje y representación. La autoridad crece cuando esas contribuciones dejan de depender de una negociación nueva para cada expedición y pasan a quedar registradas como compromisos recurrentes.

El Concilio de 990 a. C. y el reconocimiento de Telcontar en 560 a. C., consolidado por el pacto de 550 a. C., preceden a las instituciones modernas. La monarquía antigua gobierna efectivamente dentro de pactos y fueros. La existencia de consejos, archivos o arbitrajes tempranos no equivale todavía a un parlamento representativo contemporáneo.

#### Representación y acuerdos entre 1135 y 1512

Los Consejos Atlánticos permanentes de 1135 amplían la coordinación de rutas y contribuciones. A medida que crecen los puertos y las comunidades agrícolas, una decisión sobre convoyes afecta también a impuestos, salarios, abastecimiento y propiedad. Esa interdependencia permite desarrollar la crisis de representación de finales del siglo XV como una disputa sobre quién paga, quién decide y quién puede exigir cuentas.

El Acuerdo de Tol Eressëa de 1512 estabiliza el Congreso General, la Secretaría Común y los procedimientos de arbitraje. El acuerdo se celebra en Tol Eressëa con su equivalencia territorial vigente en V16; la identificación de esa isla con Terranova en la fuente v050 queda sustituida. El acuerdo da continuidad a autoridades existentes. Su efecto administrativo es que contribuciones, resoluciones y reclamaciones empiezan a circular mediante expedientes comparables entre territorios.

#### Administración y límites del poder entre 1512 y 1705

La expansión de las Oficinas Reales crea una tensión duradera. La Corona necesita información y recaudación regular para sostener puertos y fuerzas; las comunidades exigen saber qué pagan y cómo se emplean sus recursos. Los informes de los factores se cotejan con los de autoridades locales, tesorerías y capitanes. La conservación de una orden permite reclamar su ejecución y también atribuir responsabilidad por un abuso.

Las compañías de las Casas operan mediante contratos, concesiones y personalidad jurídica conforme a la evolución económica ya adoptada. Financiar una expedición o construir un muelle no confiere por sí solo potestad legislativa, justicia penal ni soberanía. La transformación de las Casas en empresas y fundaciones se desarrolla junto a la separación entre patrimonio familiar y funciones públicas.

La Carta de 1705 consolida presupuesto, responsabilidad del gobierno y controles representativos. La transición hacia la Corona ceremonial es gradual y depende de las reformas de cada periodo; el marco no atribuye al rey de 550 a. C. las limitaciones personales del monarca constitucional contemporáneo. La reorganización de 1958 hereda tratados, deudas, archivos e instituciones y precisa su reparto federal.

#### Representación contemporánea

Se adopta la distinción entre representación de población y representación territorial. El Consejo de las Casas conserva su función histórica dentro de su propio régimen; no se confunde con una cámara parlamentaria contemporánea elegida o territorial. El Senado conserva 74 escaños y la Cámara Popular queda fijada en 300. El Senado se elige en 37 circunscripciones territoriales de dos escaños, revisadas tras cada censo para continuidad geográfica y equilibrio de población; no se asigna un escaño a cada unidad contable de ECON-03. La Cámara Popular se elige por representación proporcional en distritos poblacionales, con mandato de cuatro años. El Senado tiene mandatos de seis años, renovándose 37 escaños cada tres. Los protectorados, incluido Harnen, no participan como Estados federados ni reciben escaños por esa condición. Las leyes ordinarias requieren aprobación de ambas cámaras; las presupuestarias se originan en la Cámara Popular. Si no hay acuerdo, una comisión paritaria dispone de 60 días y, si persiste el bloqueo presupuestario, continúa provisionalmente el presupuesto anterior por hasta 90 días, sujeto a control parlamentario. ECON-03 mantiene definición contable distinta del catálogo constitucional.

Desarrollo: 09_Politica/Historia Política/Transición de los pactos a la monarquía constitucional.

### Administración de nodos y continuidad territorial

#### Función y evolución

Un nodo es un servicio o instalación cuya interrupción afecta a otras comunidades: un puerto, un canal, una cámara de compensación, un archivo, una estación energética o un centro de comunicaciones. Su importancia se mide por las dependencias que sostiene, el número de personas afectadas y las alternativas disponibles. La categoría describe una función y puede aplicarse a una instalación situada en una provincia, un protectorado o un país asociado.

Las escalas de agua y reparación constituyen antecedentes prácticos. Las Oficinas Reales desarrollan coordinación más estable durante la expansión moderna. La administración contemporánea de nodos enlaza autoridades territoriales, operadores e instituciones del conocimiento mediante planes de continuidad. Su denominación moderna no se proyecta sobre las primeras navegaciones.

#### Responsabilidades de cada servicio

Las autoridades operativas mantienen tránsito, carga, mantenimiento y atención a usuarios. Los servicios comerciales tramitan documentación y canalizan controversias hacia el arbitraje o la justicia competente. Policía, guardacostas y protección civil organizan seguridad y emergencias. Archivos, universidades y servicios técnicos conservan planos, series, manuales y registros de fallos. Una instalación pequeña puede compartir servicios con otra sin crear cuatro organismos completos.

Los consejos de coordinación informan necesidades y acuerdan contingencias dentro de atribuciones existentes. No reciben automáticamente facultad para imponer impuestos, sentenciar, legislar o mandar a la Armada. El modelo porcentual de representación corporativa 40/20/20/20 contenido en v050 se conserva como alternativa de diseño; no se adopta como composición constitucional universal. Las decisiones que comprometen gasto corresponden a los órganos que lo autorizan legalmente.

#### Continuidad y financiación

Cada servicio debe identificar dependencias de agua, energía, repuestos, personal, transporte y comunicaciones. Un puerto puede seguir abierto con menor capacidad si pierde un muelle; un archivo requiere instalaciones separadas para que un incendio no destruya sus siete copias. Los planes contemplan interrupción, actividad reducida, traslado temporal y recuperación. Sus objetivos se fijan por servicio y no mediante una promesa uniforme de disponibilidad permanente.

COFOVAL financia ampliaciones y reposición dentro del sistema de proyectos ya establecido. El mantenimiento ordinario tiene partida propia: construir una instalación sin financiar dragado, personal y recambios desplaza el coste hacia los años siguientes y crea una fragilidad que la coordinación debe registrar.

#### Aplicación territorial y digital

Panamá coordina canal, cuenca, municipios y zona operativa con competencias diferenciadas. Malaca coopera en tránsito y emergencias dentro del espacio sujeto a su autoridad o a acuerdos; su posición no confiere dominio sobre ambas orillas. Los accesos mediterráneos y los protectorados conservan los estatutos de V16, incluido Harnen como protectorado y Rhunost como provincia interna.

OceanNet transmite información autorizada y conserva capacidad local de operación durante desconexiones. La Armada protege despliegues y transportes conforme a sus misiones; las autoridades civiles mantienen competencia sobre bancos, archivos, universidades y datos de usuarios. La continuidad de un servicio exige permisos, responsabilidades y límites de acceso identificables.

Desarrollo: 09_Politica/Administración de nodos y continuidad territorial.

## Casas e instituciones patrimoniales

### Nobleza de Valinari en 833 d.C.

La nobleza de Valinari queda organizada en 24 Casas Mayores, 24 Casas Menores, 35 Casas Vasallas y una Casa Real, la Casa Telcontar. Este orden corresponde a la situación política del año 833 d.C. y no altera la jerarquía territorial ni las cuentas ECON-03.

##### Casas nobles 1–24

1. Casa Noldor.

2. [[09_Politica/Casas Mayores/Casa Vanyar|Casa Vanyar]].

3. [[09_Politica/Casas Mayores/Casa Teleri|Casa Teleri]].

4. Casa Elwing.

5. Casa Círdan.

6. [[09_Politica/Casas Mayores/Casa Mithlond|Casa Mithlond]].

7. Casa Esgal.

8. Casa Calenhad.

9. Casa Fornost.

10. Casa Annúminas.

11. Casa Alqualondë.

12. Casa Armenelos.

13. Casa Eldalondë.

14. [[09_Politica/Casas Mayores/Casa Taur-en-Mor|Casa Taur-en-Mor]].

15. Casa Barad Calen.

16. Casa Dol Amroth.

17. [[09_Politica/Casas Mayores/Casa Pelargir|Casa Pelargir]].

18. [[09_Politica/Casas Mayores/Casa Harlond|Casa Harlond]].

19. [[09_Politica/Casas Mayores/Casa Minas Anor|Casa Minas Anor]].

20. Casa Eryn Lasgalen.

21. [[09_Politica/Casas Mayores/Casa Rhunost|Casa Rhunost]].

22. [[09_Politica/Casas Mayores/Casa Harnost|Casa Harnost]].

23. Casa Eressëa Menel.

24. Casa Calenor.

##### Casa Real

25. Casa Telcontar, Casa Real de Valinari.

La Casa Telcontar tiene su sede en Nueva Tirion. Ariadna Telcontar, Thalion Telcontar y Lothíriel Telcontar son miembros documentados de la casa en 833 d.C. Los blasones, estandartes, lemas en sindarin y transcripciones preparadas para alto tengwar se conservan en las fichas nobiliarias de Obsidian.

### Numeración de Casas

El sistema nobiliario vigente comprende 84 casas reconocidas: 24 Casas Mayores, 24 Casas Menores de Exploración y Comercio, 35 Casas Vasallas y la Casa Real Telcontar. Las primeras 49 forman el sistema principal; las 35 vasallas son linajes dependientes. Las Casas Mayores conservan los números 1–24. La Casa Telcontar es la Casa Real número 25 y no añade un voto al Consejo. Las Casas Menores de Exploración y Comercio utilizan una serie independiente de M-01 a M-24.

### Fenotipo de Casas Menores y Casa Real

Las 24 Casas Menores conservan su distribución geográfica y funcional. Sus tendencias fenotípicas incluyen cabello rubio claro, ceniza o dorado; Hallas, Thoron, Angren presentan cabello castaño claro y ojos verdes; ojos de tonalidad variable según cada ficha; piel clara, pecas variables y cabello liso u ondulado.

La Casa Telcontar presenta una frecuencia elevada de cabello plateado, rubio platino o rubio muy claro, piel muy clara y ojos celestes o azul zafiro. Este fenotipo cortesano es humano y poligénico. La inspiración Targaryen es estética, no una incorporación literal de esa genealogía al canon.

La variación interna se conserva por matrimonios, migraciones, adopciones y alianzas entre Casas.

### Fichas fenotípicas separadas

La representación fenotípica se organiza en tres fichas: Casa Real, Casas Mayores y Casas Menores. Telcontar utiliza una guía específica de cabello plateado o platino, ojos celestes, piel muy clara y rasgos angulosos, con base poligénica humana e inspiración estética Targaryen no literal.

### Casas Vasallas y autodenominación histórica

Las Casas posteriores que aparecen en las crónicas fundacionales no sustituyen a las 24 Casas Mayores ni a las 24 Casas Menores. Se clasifican como Casas Vasallas subordinadas a una Casa Mayor tutelar. La serie reconocida comprende 35 Casas Vasallas, entre ellas Calenard, Rúmilion, Harlind y Erellont. No poseen voto independiente en el Consejo de las 24 Casas.

En las fuentes religiosas y genealógicas antiguas, los descendientes de la primera migración se autodenominan Edain Sindarin. En el uso político y ciudadano posterior, el nombre colectivo predominante es Valinari. Edain Sindarin no designa una especie ni una etnia biológica distinta: es una autodenominación histórica, lingüística y religiosa de comunidades humanas.

La estructura nobiliaria queda, por tanto, diferenciada entre 24 Casas Mayores, 24 Casas Menores, 35 Casas Vasallas y la Casa Real Telcontar. Las Casas Vasallas pueden aumentar en el futuro, pero cada nueva casa deberá vincularse a una Casa Mayor tutelar y no podrá alterar las series existentes.

Las Casas Vasallas reconocidas en esta revisión son Calenard, Rúmilion, Harlind y Erellont. Sus nombres conservan la tradición de las crónicas antiguas; sus fichas actuales se encuentran en la carpeta política correspondiente y sus rasgos físicos se describen como tendencias poblacionales orientativas, nunca como genotipos obligatorios.

La adscripción tutelar de las 35 Casas Vasallas tiene carácter histórico y estructural: cada Casa Vasalla queda vinculada a una Casa Mayor concreta, de la que recibe protección, marco jurídico y representación indirecta. Esta relación se conserva en las propiedades, el contenido narrativo y los enlaces internos de cada ficha.

### Plantilla común de las fichas nobiliarias

Las 84 fichas individualizadas utilizan una organización común: estatus; Casa tutelar cuando corresponde; característica histórica; origen geográfico; régimen político; blasón; estandarte; lema en sindarin; carta heráldica y visual; personajes asociados; perfil fenotípico; referencias genéticas orientativas; relaciones; enlaces de gestión; referencias relacionadas; y matriz funcional y heráldica. Las diferencias entre Casas se limitan a su estatus, Casa tutelar, función, origen, personajes, perfil fenotípico y régimen político.

### Directriz visual común de las Casas

Las representaciones gráficas de las Casas deben conservar una estética cortesana valinoriana inspirada en vestuario y armaduras de alta fantasía histórica, con personajes humanos. Las alturas no serán homogéneas: los hombres se representan entre 1,77 y 2,02 metros y las mujeres entre 1,73 y 1,84 metros. Se combinan cortes de cabello, cabello suelto, trenzas, recogidos y longitudes diversas; los hombres pueden aparecer afeitados o con barba de distinta longitud.

Las armas se asignan por función y no son obligatorias para todos los personajes. Pueden repetirse espadas, hachas, lanzas y dagas entre Casas cuando resulte coherente. Las Casas dedicadas al estudio, los archivos, la astronomía, la cartografía, la ley o la administración deben portar libros, códices, mapas, astrolabios, instrumentos de medición, plumas, sellos y archivos portátiles. El nombre de la Casa y la traducción o transcripción de su lema al alto tengwar deben aparecer integrados en el estandarte.

##### Representación canónica de la Casa Real Telcontar

La referencia iconográfica adoptada es la imagen «Casa Telcontar.png»: dos representantes adultos humanos anónimos, un hombre y una mujer, con armaduras ceremoniales de inspiración tolkieniana. Predominan el negro, el gris acero y la plata, con bordados dorados. El hombre lleva armadura plateada, espada ceremonial envainada y capa de cuero negro por fuera y blanca por dentro; la mujer viste vestido-armadura, capa larga con el mismo exterior de cuero negro e interior blanco, y espada ceremonial envainada, con cabello largo trenzado. El forro blanco se muestra en el cuello, los bordes vueltos y los pliegues. Esta especificación de vestuario prevalece en el prompt y las nuevas representaciones sobre los forros de las imágenes anteriores.

Por decisión expresa del autor, el hombre mide 197 cm (1,97 m) y la mujer 188 cm (1,88 m); la diferencia es de 9 cm. Ambos tienen cabello rubio platinado y ojos azul zafiro, con piel muy clara conforme al perfil cortesano. El hombre aparece a la izquierda, con media melena ondulada y barba corta; la mujer, a la derecha, con trenzas de sien y dos trenzas delanteras. Se representan sobre el mismo pavimento y a igual profundidad. La altura femenina de 1,88 m constituye una excepción expresa al intervalo general de 1,73–1,84 m de la galería. Estas medidas y rasgos individuales prevalecen sobre versiones anteriores de esta pareja, manteniendo la variación humana y las referencias genéticas orientativas del linaje.

El blasón visual vigente de la Casa Real es un árbol blanco o plateado de raíces extendidas, coronado por una estrella de ocho puntas sobre campo negro. Se repite en estandartes, escudo ceremonial y bordados. Esta composición sustituye para Telcontar la representación anterior de estrella celeste sobre horizonte y corona en plata, azul celeste y oro pálido. El dorado se utiliza en cenefas, bordados y detalles.

La escena muestra una ciudadela montañosa de torres blancas, rodeada de bosques y montañas nevadas. El paisaje cumple una función iconográfica y su localización queda abierta. La composición expresa autoridad monárquica, tradición militar y legitimidad dinástica. La imagen existente guía el vestuario, el escenario y la heráldica; las medidas y pigmentación adoptadas aquí rigen el prompt y las nuevas representaciones.

El estandarte incorpora el nombre de la Casa y el lema registrado, cuya glosa es «El heredero sirve al reino», en escritura tengwar integrada en la tela. La forma latina conservada en la ficha es «I thain aran»; la composición gráfica debe revisarse a partir del lema registrado antes de considerarse validada. El prompt individual del catálogo de las 84 Casas desarrolla composición, escala corporal, materiales, iluminación, heráldica y rasgos físicos con calidad de ilustración de gran formato. Esta directriz es editorial e iconográfica y no modifica fechas de la cronología histórica.

Referencias de Obsidian: [[09_Politica/Prompts Visuales de las 84 Casas|Prompt individual de Casa Telcontar]] y [[09_Politica/Casa Real/Casa Telcontar|Ficha de Casa Telcontar]].

### Variación fenotípica y representantes de las Casas

La galería representa parejas humanas adultas de la nobleza valinari. El color natural de cabello se asigna a cada cónyuge por separado y permite matrimonios entre personas de distinto color. Los perfiles familiares describen tendencias con variación interna; el reparto individual vigente prevalece al representar a estas parejas. Se conservan ojos, piel, pecas y textura capilar de la ficha, además de alturas, complexiones, cortes, barbas, posturas, posiciones, objetos de oficio y heráldica. Las referencias genéticas siguen siendo orientativas y poligénicas. El cabello platinado blanco es una descripción visual de pigmentación y no determina un diagnóstico de albinismo.

Se conserva el sorteo de las nueve Casas Mayores pendientes: dos hombres y dos mujeres pelirrojos, siete hombres y siete mujeres de tonos rubios habituales. En las 24 Casas Menores hay tres mujeres y dos hombres pelirrojos; los dos hombres reemplazan dos de los tres casos castaño claro del reparto anterior, quedando un hombre y tres mujeres castaño claro. En las 35 Casas Vasallas se asignan cuatro mujeres y dos hombres pelirrojos, tres mujeres castaño claro, un hombre castaño oscuro y tres representantes de cabello rubio platinado blanco, dos mujeres y un hombre. Los demás representantes conservan tonos rubios habituales.

Los perfiles familiares de Hallas, Thoron y Angren mantienen su referencia castaño claro y ojos verdes; los de Fornost, Harnost y Mithlond mantienen sus tendencias pelirrojas y ojos celestes. El color de cabello de cada representante sigue la asignación individual de las tablas. Las quince Casas Mayores ya ilustradas y la Casa Real conservan su representación previa.

##### Casas Mayores pendientes de imagen

| Casa | Cabello del hombre | Cabello de la mujer |
| --- | --- | --- |
| [[09_Politica/Casas Mayores/Casa Harlond\|Casa Harlond]] | pelirrojo | rubio muy claro |
| [[09_Politica/Casas Mayores/Casa Harnost\|Casa Harnost]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Mayores/Casa Minas Anor\|Casa Minas Anor]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Mithlond\|Casa Mithlond]] | rubio oscuro | rubio dorado |
| [[09_Politica/Casas Mayores/Casa Pelargir\|Casa Pelargir]] | rubio ceniza | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Rhunost\|Casa Rhunost]] | pelirrojo | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Taur-en-Mor\|Casa Taur-en-Mor]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Teleri\|Casa Teleri]] | rubio platino | rubio oscuro |
| [[09_Politica/Casas Mayores/Casa Vanyar\|Casa Vanyar]] | rubio muy claro | rubio platino |

##### Casas Menores

| Casa | Cabello del hombre | Cabello de la mujer |
| --- | --- | --- |
| [[09_Politica/Casas Menores/Casa Aerandir\|Casa Aerandir]] | rubio claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Aglaran\|Casa Aglaran]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Angren\|Casa Angren]] | rubio dorado | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Baranor\|Casa Baranor]] | rubio platino | rubio claro |
| [[09_Politica/Casas Menores/Casa Belegor\|Casa Belegor]] | rubio dorado | pelirrojo |
| [[09_Politica/Casas Menores/Casa Celepharn\|Casa Celepharn]] | rubio dorado | rubio platino |
| [[09_Politica/Casas Menores/Casa Círdanir\|Casa Círdanir]] | rubio muy claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Duilin\|Casa Duilin]] | pelirrojo | rubio dorado |
| [[09_Politica/Casas Menores/Casa Elentir\|Casa Elentir]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Menores/Casa Erestor\|Casa Erestor]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Eärond\|Casa Eärond]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Menores/Casa Falastur\|Casa Falastur]] | rubio oscuro | rubio platino |
| [[09_Politica/Casas Menores/Casa Falathar\|Casa Falathar]] | pelirrojo | rubio oscuro |
| [[09_Politica/Casas Menores/Casa Gwindor\|Casa Gwindor]] | rubio claro | rubio dorado |
| [[09_Politica/Casas Menores/Casa Hallas\|Casa Hallas]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Menores/Casa Lindor\|Casa Lindor]] | rubio muy claro | rubio claro |
| [[09_Politica/Casas Menores/Casa Maethor\|Casa Maethor]] | rubio ceniza | pelirrojo |
| [[09_Politica/Casas Menores/Casa Meneldir\|Casa Meneldir]] | castaño claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Nimrodel\|Casa Nimrodel]] | rubio claro | rubio claro |
| [[09_Politica/Casas Menores/Casa Ostor\|Casa Ostor]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Menores/Casa Tarond\|Casa Tarond]] | rubio platino | rubio claro |
| [[09_Politica/Casas Menores/Casa Thoron\|Casa Thoron]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Menores/Casa Tumladen\|Casa Tumladen]] | rubio claro | rubio dorado |
| [[09_Politica/Casas Menores/Casa Voronwë\|Casa Voronwë]] | rubio ceniza | rubio muy claro |

##### Casas Vasallas

| Casa | Cabello del hombre | Cabello de la mujer |
| --- | --- | --- |
| [[09_Politica/Casas Vasallas/Casa Aegnor\|Casa Aegnor]] | rubio dorado | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Amdir\|Casa Amdir]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Amrod\|Casa Amrod]] | rubio ceniza | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Anardil\|Casa Anardil]] | rubio dorado | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Araphor\|Casa Araphor]] | rubio muy claro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Ardamir\|Casa Ardamir]] | rubio oscuro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Barahir\|Casa Barahir]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Belegund\|Casa Belegund]] | rubio muy claro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Brandir\|Casa Brandir]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Calenard\|Casa Calenard]] | pelirrojo | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Dírhael\|Casa Dírhael]] | rubio platinado blanco | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Ecthelion\|Casa Ecthelion]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Erchirion\|Casa Erchirion]] | rubio dorado | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Erellont\|Casa Erellont]] | rubio oscuro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Estelmo\|Casa Estelmo]] | rubio claro | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Findegil\|Casa Findegil]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Folcred\|Casa Folcred]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Forlong\|Casa Forlong]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Galdor\|Casa Galdor]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Hador\|Casa Hador]] | rubio ceniza | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Hareth\|Casa Hareth]] | rubio claro | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Harlind\|Casa Harlind]] | pelirrojo | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Imrahil\|Casa Imrahil]] | rubio claro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Iorlas\|Casa Iorlas]] | rubio muy claro | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Malbeth\|Casa Malbeth]] | rubio dorado | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Ohtar\|Casa Ohtar]] | castaño oscuro | rubio platinado blanco |
| [[09_Politica/Casas Vasallas/Casa Oropher\|Casa Oropher]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Rúmilion\|Casa Rúmilion]] | rubio muy claro | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Saeros\|Casa Saeros]] | rubio claro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Targon\|Casa Targon]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Tuor\|Casa Tuor]] | rubio muy claro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Vorondil\|Casa Vorondil]] | rubio muy claro | rubio platinado blanco |
| [[09_Politica/Casas Vasallas/Casa Wídfara\|Casa Wídfara]] | rubio dorado | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Yavannor\|Casa Yavannor]] | rubio oscuro | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Zirin\|Casa Zirin]] | rubio oscuro | rubio dorado |

### Alturas consolidadas de representación visual de las 84 Casas

Estas alturas pertenecen a la dirección artística de los prompts de imagen y no constituyen datos biográficos obligatorios ni rasgos genéticos. Se miden de planta a coronilla, sin calzado ni adornos; los dos representantes deben aparecer sobre el mismo plano de suelo. La Casa Telcontar conserva su excepción aprobada de 1,97 m y 1,88 m.

| Casa | Hombre | Mujer |
| --- | --- | --- |
| Casa Alqualondë | 1,95 m | 1,75 m |
| Casa Annúminas | 1,88 m | 1,82 m |
| Casa Armenelos | 2,02 m | 1,80 m |
| Casa Barad Calen | 1,97 m | 1,83 m |
| Casa Calenhad | 2,00 m | 1,84 m |
| Casa Calenor | 1,82 m | 1,80 m |
| Casa Círdan | 1,79 m | 1,81 m |
| Casa Dol Amroth | 1,78 m | 1,76 m |
| Casa Eldalondë | 1,83 m | 1,73 m |
| Casa Elwing | 1,98 m | 1,76 m |
| Casa Eressëa Menel | 2,01 m | 1,75 m |
| Casa Eryn Lasgalen | 1,80 m | 1,84 m |
| Casa Esgal | 1,93 m | 1,79 m |
| Casa Fornost | 1,81 m | 1,77 m |
| [[09_Politica/Casas Mayores/Casa Harlond\|Casa Harlond]] | 1,92 m | 1,74 m |
| [[09_Politica/Casas Mayores/Casa Harnost\|Casa Harnost]] | 1,94 m | 1,82 m |
| [[09_Politica/Casas Mayores/Casa Minas Anor\|Casa Minas Anor]] | 1,99 m | 1,79 m |
| [[09_Politica/Casas Mayores/Casa Mithlond\|Casa Mithlond]] | 1,86 m | 1,74 m |
| Casa Noldor | 1,77 m | 1,73 m |
| [[09_Politica/Casas Mayores/Casa Pelargir\|Casa Pelargir]] | 1,85 m | 1,81 m |
| [[09_Politica/Casas Mayores/Casa Rhunost\|Casa Rhunost]] | 1,87 m | 1,77 m |
| [[09_Politica/Casas Mayores/Casa Taur-en-Mor\|Casa Taur-en-Mor]] | 1,90 m | 1,78 m |
| [[09_Politica/Casas Mayores/Casa Teleri\|Casa Teleri]] | 1,91 m | 1,83 m |
| [[09_Politica/Casas Mayores/Casa Vanyar\|Casa Vanyar]] | 1,84 m | 1,78 m |
| [[09_Politica/Casas Menores/Casa Aerandir\|Casa Aerandir]] | 1,94 m | 1,80 m |
| [[09_Politica/Casas Menores/Casa Aglaran\|Casa Aglaran]] | 1,88 m | 1,80 m |
| [[09_Politica/Casas Menores/Casa Angren\|Casa Angren]] | 1,92 m | 1,84 m |
| [[09_Politica/Casas Menores/Casa Baranor\|Casa Baranor]] | 2,02 m | 1,78 m |
| [[09_Politica/Casas Menores/Casa Belegor\|Casa Belegor]] | 1,97 m | 1,81 m |
| [[09_Politica/Casas Menores/Casa Celepharn\|Casa Celepharn]] | 1,83 m | 1,84 m |
| [[09_Politica/Casas Menores/Casa Círdanir\|Casa Círdanir]] | 1,96 m | 1,78 m |
| [[09_Politica/Casas Menores/Casa Duilin\|Casa Duilin]] | 1,78 m | 1,74 m |
| [[09_Politica/Casas Menores/Casa Elentir\|Casa Elentir]] | 1,86 m | 1,84 m |
| [[09_Politica/Casas Menores/Casa Erestor\|Casa Erestor]] | 1,99 m | 1,77 m |
| [[09_Politica/Casas Menores/Casa Eärond\|Casa Eärond]] | 1,84 m | 1,76 m |
| [[09_Politica/Casas Menores/Casa Falastur\|Casa Falastur]] | 1,89 m | 1,73 m |
| [[09_Politica/Casas Menores/Casa Falathar\|Casa Falathar]] | 1,87 m | 1,75 m |
| [[09_Politica/Casas Menores/Casa Gwindor\|Casa Gwindor]] | 1,81 m | 1,75 m |
| [[09_Politica/Casas Menores/Casa Hallas\|Casa Hallas]] | 2,00 m | 1,82 m |
| [[09_Politica/Casas Menores/Casa Lindor\|Casa Lindor]] | 1,93 m | 1,77 m |
| [[09_Politica/Casas Menores/Casa Maethor\|Casa Maethor]] | 1,90 m | 1,76 m |
| [[09_Politica/Casas Menores/Casa Meneldir\|Casa Meneldir]] | 1,98 m | 1,74 m |
| [[09_Politica/Casas Menores/Casa Nimrodel\|Casa Nimrodel]] | 1,80 m | 1,82 m |
| [[09_Politica/Casas Menores/Casa Ostor\|Casa Ostor]] | 1,77 m | 1,83 m |
| [[09_Politica/Casas Menores/Casa Tarond\|Casa Tarond]] | 1,95 m | 1,73 m |
| [[09_Politica/Casas Menores/Casa Thoron\|Casa Thoron]] | 1,79 m | 1,80 m |
| [[09_Politica/Casas Menores/Casa Tumladen\|Casa Tumladen]] | 1,85 m | 1,79 m |
| [[09_Politica/Casas Menores/Casa Voronwë\|Casa Voronwë]] | 1,91 m | 1,81 m |
| [[09_Politica/Casas Vasallas/Casa Aegnor\|Casa Aegnor]] | 1,77 m | 1,81 m |
| [[09_Politica/Casas Vasallas/Casa Amdir\|Casa Amdir]] | 1,84 m | 1,74 m |
| [[09_Politica/Casas Vasallas/Casa Amrod\|Casa Amrod]] | 1,91 m | 1,79 m |
| [[09_Politica/Casas Vasallas/Casa Anardil\|Casa Anardil]] | 1,98 m | 1,84 m |
| [[09_Politica/Casas Vasallas/Casa Araphor\|Casa Araphor]] | 1,86 m | 1,82 m |
| [[09_Politica/Casas Vasallas/Casa Ardamir\|Casa Ardamir]] | 1,79 m | 1,77 m |
| [[09_Politica/Casas Vasallas/Casa Barahir\|Casa Barahir]] | 1,93 m | 1,75 m |
| [[09_Politica/Casas Vasallas/Casa Belegund\|Casa Belegund]] | 2,00 m | 1,80 m |
| [[09_Politica/Casas Vasallas/Casa Brandir\|Casa Brandir]] | 1,81 m | 1,73 m |
| [[09_Politica/Casas Vasallas/Casa Calenard\|Casa Calenard]] | 2,01 m | 1,73 m |
| [[09_Politica/Casas Vasallas/Casa Dírhael\|Casa Dírhael]] | 1,88 m | 1,78 m |
| [[09_Politica/Casas Vasallas/Casa Ecthelion\|Casa Ecthelion]] | 1,95 m | 1,83 m |
| [[09_Politica/Casas Vasallas/Casa Erchirion\|Casa Erchirion]] | 2,02 m | 1,76 m |
| [[09_Politica/Casas Vasallas/Casa Erellont\|Casa Erellont]] | 1,96 m | 1,76 m |
| [[09_Politica/Casas Vasallas/Casa Estelmo\|Casa Estelmo]] | 1,83 m | 1,81 m |
| [[09_Politica/Casas Vasallas/Casa Findegil\|Casa Findegil]] | 1,90 m | 1,74 m |
| [[09_Politica/Casas Vasallas/Casa Folcred\|Casa Folcred]] | 1,97 m | 1,79 m |
| [[09_Politica/Casas Vasallas/Casa Forlong\|Casa Forlong]] | 1,78 m | 1,84 m |
| [[09_Politica/Casas Vasallas/Casa Galdor\|Casa Galdor]] | 1,85 m | 1,77 m |
| [[09_Politica/Casas Vasallas/Casa Hador\|Casa Hador]] | 1,92 m | 1,82 m |
| [[09_Politica/Casas Vasallas/Casa Hareth\|Casa Hareth]] | 1,99 m | 1,75 m |
| [[09_Politica/Casas Vasallas/Casa Harlind\|Casa Harlind]] | 1,89 m | 1,83 m |
| [[09_Politica/Casas Vasallas/Casa Imrahil\|Casa Imrahil]] | 1,80 m | 1,81 m |
| [[09_Politica/Casas Vasallas/Casa Iorlas\|Casa Iorlas]] | 1,87 m | 1,73 m |
| [[09_Politica/Casas Vasallas/Casa Malbeth\|Casa Malbeth]] | 1,94 m | 1,78 m |
| [[09_Politica/Casas Vasallas/Casa Ohtar\|Casa Ohtar]] | 2,01 m | 1,83 m |
| [[09_Politica/Casas Vasallas/Casa Oropher\|Casa Oropher]] | 1,82 m | 1,76 m |
| [[09_Politica/Casas Vasallas/Casa Rúmilion\|Casa Rúmilion]] | 1,82 m | 1,78 m |
| [[09_Politica/Casas Vasallas/Casa Saeros\|Casa Saeros]] | 1,89 m | 1,81 m |
| [[09_Politica/Casas Vasallas/Casa Targon\|Casa Targon]] | 1,96 m | 1,74 m |
| [[09_Politica/Casas Vasallas/Casa Tuor\|Casa Tuor]] | 1,77 m | 1,79 m |
| [[09_Politica/Casas Vasallas/Casa Vorondil\|Casa Vorondil]] | 1,84 m | 1,73 m |
| [[09_Politica/Casas Vasallas/Casa Wídfara\|Casa Wídfara]] | 1,91 m | 1,77 m |
| [[09_Politica/Casas Vasallas/Casa Yavannor\|Casa Yavannor]] | 1,98 m | 1,82 m |
| [[09_Politica/Casas Vasallas/Casa Zirin\|Casa Zirin]] | 1,79 m | 1,75 m |
| Casa Telcontar | 1,97 m | 1,88 m |

### Evolución económica e institucional de las Casas

Las 84 Casas reconocidas comprenden 24 Mayores, 24 Menores, 35 Vasallas y la Casa Real Telcontar. El rango genealógico no fija el tamaño de sus empresas: una Casa Menor puede superar económicamente a una Mayor. La personalidad jurídica separada, la responsabilidad limitada de socios y la sociedad por acciones se incorporan en etapas distintas; la separación patrimonial medieval no equivale a responsabilidad limitada universal.

Desde el siglo XV se desarrollan casas mercantiles; durante los siglos XVI y XVII crecen compañías y banca; en los siglos XVIII y XIX se forman grupos industriales; durante el siglo XX se consolidan empresas reguladas, fundaciones y redes profesionales. La referencia de las fichas individuales a 833 d. C. conserva su contexto histórico; esta evolución posterior se identifica expresamente.

#### Marco común

Participan en:

- hierro;

- cobre;

- níquel;

- cobalto;

- carbón;

- hornos;

- laminadores;

- herramientas;

- artillería;

- ferrocarriles.

Administran:

- granjas;

- molinos;

- regadío;

- semillas;

- ganadería;

- almacenamiento;

- transporte de alimentos;

- investigación agraria.

Financian:

- bibliotecas;

- universidades;

- observatorios;

- laboratorios;

- hospitales;

- academias;

- traducción técnica;

- archivos.

Poseen mayor patrimonio, red internacional y capacidad de inversión. Suelen controlar varios sectores y participar en política nacional.

Se especializan en funciones concretas y suelen tener vínculos más estrechos con una ciudad, puerto, academia, industria o región.

Conservan funciones territoriales, empresariales o profesionales bajo la tutela histórica de una Casa Mayor. Su autonomía económica puede ser considerable, aunque su prestigio y acceso a determinados cargos dependen de la relación histórica.

No debe convertirse en el mayor conglomerado privado del Reino. Administra patrimonio de la Corona, fundaciones, academias y fondos culturales, pero sus recursos están separados de la hacienda pública y de las empresas privadas.

#### Evolución histórica

Desde el siglo XV, las Casas dejan de funcionar principalmente como nobleza territorial clásica y se convierten en organizaciones históricas complejas. Conservan linaje, patrimonio y títulos, pero su supervivencia depende cada vez más de su capacidad para administrar capital, producir bienes, financiar infraestructuras, formar profesionales y prestar servicios al Estado.

La Casa ya no es únicamente una familia con tierras. Puede incluir:

- fundaciones;

- bancos;

- empresas;

- astilleros;

- compañías comerciales;

- academias;

- arsenales;

- redes de administradores;

- hospitales;

- laboratorios;

- instituciones culturales;

- unidades militares bajo mando estatal.

Durante el siglo XV, las Casas Mayores empiezan a invertir directamente en:

- flotas mercantes;

- almacenes;

- compañías de seguros;

- rutas de especias;

- bancos de puerto;

- expediciones;

- factorías;

- transporte de metales;

- comercio de grano y madera.

Las Casas Menores actúan como agentes, capitanes, escribas, administradores de puertos y representantes comerciales. Las Casas Vasallas controlan depósitos locales, rutas interiores, talleres y comunidades agrícolas.

Durante el siglo XVI, algunas Casas se especializan en banca y crédito.

Sus actividades incluyen:

- préstamos navales;

- cambio de moneda;

- seguros marítimos;

- financiación de expediciones;

- crédito agrícola;

- deuda pública;

- inversión en puertos;

- compra de metales;

- financiación de arsenales.

Las Casas financieras no pueden acuñar moneda real ni emitir deuda pública sin autorización. Las tesorerías y cámaras competentes supervisan sus operaciones según el periodo; las funciones posteriores del Banco Real no se proyectan íntegramente sobre el siglo XVI.

Con el crecimiento de manufacturas, algunas Casas crean complejos productivos integrados:

- mina;

- fundición;

- taller;

- transporte;

- almacén;

- banco;

- vivienda obrera;

- escuela técnica;

- hospital.

Estos complejos aumentan la productividad, pero también generan dependencia laboral. El Estado comienza a regular jornadas, salarios, seguridad y deudas de trabajadores.

Las Casas no pueden tratar las aldeas productivas como propiedad personal absoluta. El alcance de los derechos territoriales, jurídicos y religiosos depende de la época y condición de las personas; la coerción laboral y la esclavitud persisten hasta sus reformas respectivas.

Las Casas más poderosas se transforman en grupos empresariales diversificados. Pueden controlar simultáneamente:

- minas;

- siderurgia;

- ferrocarriles tempranos;

- seguros;

- empresas de transporte;

- escuelas técnicas;

- periódicos;

- compañías de comercio.

Este modelo permite movilizar capital rápidamente, pero aumenta el riesgo de concentración económica. Por ello aparecen leyes contra:

- monopolios;

- información privilegiada;

- crédito político abusivo;

- control de aduanas;

- adquisición de tierras comunales;

- compañías armadas privadas.

La industrialización transforma la Casa en una entidad corporativa. El linaje permanece como autoridad simbólica, pero la gestión corresponde a:

- directores;

- ingenieros;

- contables;

- abogados;

- administradores;

- oficiales retirados;

- científicos;

- especialistas financieros.

La Casa puede tener una asamblea familiar, pero las empresas poseen directorios separados y deben responder ante accionistas, bancos, Estado y tribunales.

Durante el siglo XX, las Casas se convierten progresivamente en:

- empresas reguladas;

- universidades;

- museos;

- grupos industriales;

- redes diplomáticas;

- asociaciones profesionales;

- instituciones de memoria.

Su identidad histórica continúa, pero el poder jurídico depende de la ciudadanía, la ley y la propiedad registrada, no del linaje por sí solo.

Desde el siglo XV, las Casas pasan de ser aristocracias territoriales a instituciones económicas de larga duración. Su evolución puede resumirse así:

linaje territorial → Casa mercantil → banco y compañía → conglomerado industrial → fundación, empresa regulada y red profesional.

La nobleza clásica no desaparece de inmediato, pero deja de ser el centro exclusivo del poder. La Casa que sobrevive es la que transforma su patrimonio en conocimiento, capital, producción, servicio público y continuidad institucional.

- grupos empresariales regulados;

- centros de investigación;

Su nombre, blasón y patrimonio permanecen, pero la autoridad se basa en la ley, el contrato y la ciudadanía.

Una Casa puede perder poder por:

- quiebra;

- mala gestión;

- endeudamiento;

- atraso tecnológico;

- escándalos;

- pérdida de concesiones;

- conflictos sucesorios;

- competencia industrial;

- incumplimiento laboral.

Puede conservar identidad y título aunque sus empresas sean vendidas, nacionalizadas o convertidas en fundaciones.

Desde el siglo XV, las Casas pasan de ser titulares de derechos territoriales a convertirse en organizaciones de capital, conocimiento, producción y servicio.

Su secuencia histórica queda fijada así:

Casa territorial → Casa mercantil → compañía jurídica → banco y concesionaria → conglomerado industrial → fundación, empresa regulada y red profesional.

La supervivencia de una Casa depende de transformar su patrimonio histórico en capacidades contemporáneas sin recuperar privilegios soberanos privados.

#### Patrimonio y gobierno de la Casa

La riqueza de una Casa se divide en cuatro patrimonios:

1. patrimonio familiar: bienes privados de sus miembros;

2. patrimonio institucional: archivos, escudos, edificios, fundaciones y colecciones;

3. patrimonio productivo: minas, talleres, astilleros, tierras, bancos y empresas;

4. patrimonio público administrado: puertos, caminos, arsenales o concesiones que no pertenecen plenamente a la Casa.

La distinción evita que una Casa convierta una concesión pública en propiedad privada perpetua.

Desde la consolidación constitucional, las Casas no pueden:

- acuñar moneda sin autorización;

- poseer ejércitos independientes;

- ejercer justicia privada;

- recaudar impuestos no autorizados;

- controlar puertos públicos como propiedad absoluta;

- imponer trabajo personal ilimitado;

- comprar decisiones públicas;

- impedir auditorías;

- reservar todos los cargos por nacimiento.

Casas Mayores: grupos diversificados con capacidad financiera, industrial, diplomática y territorial.

Casas Menores: instituciones especializadas en ciudades, puertos, profesiones, ciencia, comercio o administración.

Casas Vasallas: entidades vinculadas históricamente a una Casa Mayor, con funciones territoriales, comerciales, militares o profesionales propias.

Casa Real: institución dinástica y constitucional, separada de los conglomerados privados y de la gestión ordinaria de COFOVAL.

La relevancia de una Casa moderna se evalúa por:

- empleo generado;

- inversiones;

- exportaciones;

- estudiantes formados;

- investigaciones financiadas;

- buques construidos;

- regiones desarrolladas;

- impuestos pagados;

- patrimonio conservado;

- servicios públicos prestados.

La antigüedad sigue otorgando prestigio, pero no garantiza capacidad económica.

#### Comercio, compañías y personalidad jurídica

Las Casas crean compañías con personalidad jurídica separada. Una compañía puede pertenecer parcialmente a:

- la Casa;

- comerciantes privados;

- bancos;

- ciudades;

- fondos de la Corona;

- cooperativas de trabajadores.

La separación legal protege el patrimonio familiar y permite financiar proyectos de alto riesgo sin comprometer todos los bienes de la Casa.

Las compañías deben registrar:

- capital;

- accionistas;

- deudas;

- administradores;

- contratos;

- concesiones;

- pérdidas;

- obligaciones laborales.

Se dedican a:

- exportación;

- importación;

- seguros;

- depósitos;

- logística;

- puertos;

- traducción;

- información de mercados.

Las Casas comerciales desarrollan oficinas permanentes en puertos, mercados y rutas. Cada oficina mantiene:

- agentes;

- almacenes;

- contables;

- traductores;

- pilotos;

- aseguradores;

- inspectores de carga;

- representantes jurídicos.

La Casa puede financiar una expedición, pero el barco, la carga y la tripulación se administran mediante contratos separados. Esto permite distribuir el riesgo entre armadores, bancos, comerciantes y la Casa.

Las Casas de navegación también recopilan información sobre:

- vientos;

- corrientes;

- precios;

- epidemias;

- piratería;

- rutas seguras;

- disponibilidad de agua y carbón.

La personalidad jurídica de las compañías permite separar a la Casa de la empresa. La compañía puede:

- contratar trabajadores;

- adquirir propiedades;

- endeudarse;

- demandar y ser demandada;

- emitir acciones;

- firmar concesiones;

- mantener reservas;

- quebrar sin destruir automáticamente a la familia fundadora.

Los estatutos definen:

- capital inicial;

- duración;

- objeto social;

- responsabilidad de accionistas;

- órganos de dirección;

- auditoría;

- distribución de beneficios;

- procedimiento de disolución.

#### Banca y financiación

Las Casas pueden ser propietarias de bancos, pero deben separar:

- cuentas familiares;

- fondos institucionales;

- recursos públicos;

- depósitos de clientes;

- inversiones militares;

- fondos de fundaciones.

La mezcla de recursos se considera una infracción grave. Los bancos de Casa deben publicar balances, mantener reservas y someterse a auditoría.

Las Casas financieras crean redes de crédito que conectan bancos urbanos, tesorerías reales y comerciantes. Sus productos incluyen:

- préstamos navales;

- crédito minero;

- financiación agrícola;

- letras de cambio;

- seguros;

- bonos;

- compra de deuda pública;

- fondos de emergencia;

- créditos de exportación.

La regulación exige separar depósitos de clientes, patrimonio familiar, fondos públicos y recursos de fundaciones.

Las Casas financieras pueden influir en la política, pero no pueden controlar simultáneamente la moneda, las aduanas, el ejército y la justicia.

#### Industria y cadenas productivas

Las Casas se especializan progresivamente según origen y función histórica.

Las Casas mineras deben coordinar:

- exploración;

- concesiones;

- seguridad;

- transporte;

- fundición;

- energía;

- vivienda;

- hospitales;

- escuelas técnicas.

La concesión minera no equivale a propiedad absoluta del subsuelo. El Estado conserva derechos de inspección, impuestos, expropiación por interés público y protección ambiental.

Las Casas agrícolas evolucionan desde grandes dominios hacia empresas agroindustriales y cooperativas asociadas.

Participan en:

- semillas;

- riego;

- graneros;

- maquinaria;

- ganadería;

- molienda;

- alimentos procesados;

- investigación de suelos.

Deben respetar contratos de arrendamiento, derechos de comunidades, salarios y normas de almacenamiento.

Los conglomerados aparecen cuando una Casa controla varias empresas relacionadas. Un grupo puede incluir:

- banco;

- mina;

- fábrica de maquinaria;

- ferrocarril;

- astillero;

- compañía de seguros;

- escuela técnica;

- hospital.

La integración vertical reduce costes, pero puede eliminar competencia. Por eso se establecen límites de concentración, separación contable y revisión de precios.

#### Astilleros, arsenales y servicio militar

Controlan o financian:

- astilleros;

- motores;

- velas;

- madera naval;

- anclas;

- cadenas;

- navegación;

- cartas marítimas;

- mantenimiento.

Se especializan en:

- oficiales;

- academias;

- arsenales;

- fortificaciones;

- logística;

- cartografía;

- artillería;

- construcción naval;

- inteligencia.

Desde el siglo XIX, las Casas dejan de mantener ejércitos privados permanentes. Su función militar se transforma en:

- oficiales profesionales;

- academias militares;

- industria de defensa;

- financiación de arsenales;

- investigación tecnológica;

- administración logística;

- diplomacia militar;

- tradición de servicio.

Los miembros de una Casa pueden ocupar cargos en la Armada o el Ejército, pero quedan sujetos a la cadena de mando estatal.

Una Casa puede dirigir un astillero o financiar un programa naval, pero no posee soberanía sobre los buques ni decide independientemente su empleo.

Las Casas navales participan en toda la cadena:

- bosques y madera;

- hierro y acero;

- armas;

- reparación;

- buques mercantes;

- buques militares.

Su ventaja consiste en conservar conocimiento técnico entre generaciones. Su riesgo es quedar atrapadas en diseños antiguos o utilizar la influencia política para impedir la competencia de astilleros nuevos.

Las Casas militares dejan de ser ejércitos familiares y se convierten en redes de servicio profesional.

Sus funciones incluyen:

- fortificación;

- administración de bases;

- formación de oficiales.

Los miembros de una Casa pueden ocupar cargos de alto rango, pero deben ser designados según formación, experiencia y autoridad legal.

Los astilleros privados pueden construir para la Armada mediante contratos. Los arsenales públicos conservan capacidades que el mercado no garantiza:

- reparación de emergencia;

- construcción de buques especiales;

- almacenamiento de armas;

- mantenimiento de submarinos y unidades estratégicas;

- producción durante guerra;

- formación técnica.

Las empresas estratégicas deben mantener reservas de repuestos, planes de movilización y capacidad de producción de emergencia.

#### Trabajo, educación e investigación

Las Casas financian escuelas, universidades y becas, pero no pueden controlar unilateralmente los planes de estudio.

Sus aportes pueden dirigirse a:

- ingeniería;

- medicina;

- navegación;

- metalurgia;

- derecho;

- administración;

- idiomas;

- ciencia;

- historia;

- artes.

Las Becas Reales y las becas públicas deben ser accesibles más allá de las familias nobles.

La transformación económica produce una relación laboral más contractual.

Los trabajadores pueden recibir:

- salario monetario;

- vivienda;

- alimentos;

- seguro;

- formación;

- pensión;

- participación en beneficios;

- compensación por accidente.

Las Casas pierden progresivamente el derecho a exigir trabajo personal sin contrato. Las obligaciones feudales se transforman en impuestos, salarios o servicios regulados.

Las Casas financian innovación mediante:

- laboratorios propios;

- contratos universitarios;

- patentes;

- talleres experimentales;

- premios técnicos;

- compra pública;

- expediciones científicas.

Los conocimientos de interés público deben integrarse en los archivos compartidos. Las Casas pueden proteger temporalmente una invención comercial o militar, pero no monopolizar indefinidamente una técnica esencial.

Las Casas científicas crean centros de conocimiento que combinan:

- biblioteca;

- laboratorio;

- taller;

- observatorio;

- escuela;

- archivo;

- imprenta;

- residencia de investigadores.

Los aportes de una Casa no le otorgan control absoluto sobre la investigación pública. La financiación puede reconocer patronazgo histórico, pero los resultados de interés general deben incorporarse a los archivos compartidos.

El paso de dependencia territorial a empleo industrial es gradual.

Las Casas deben reconocer:

- salario;

- jornada;

- descanso;

- seguridad;

- asociación laboral;

- vivienda cuando exista obligación contractual.

Las Casas pueden construir barrios y escuelas, pero no pueden convertir esos servicios en mecanismos de endeudamiento permanente o control personal.

Las empresas de Casa financian institutos para formar:

- ingenieros;

- mecánicos;

- capitanes;

- contables;

- químicos;

- médicos;

- administradores;

- inspectores;

- técnicos de mantenimiento.

Los títulos deben ser reconocidos por autoridades públicas y no solo por la Casa patrocinadora.

#### Regulación, concesiones y desarrollo territorial

Una Casa puede convertirse en agente de desarrollo regional mediante:

- construcción de caminos;

- creación de puertos;

- fundación de escuelas;

- instalación de hospitales;

- apertura de minas;

- ferrocarriles;

- viviendas;

- canales;

- creación de bancos locales.

A cambio recibe beneficios regulados, pero no soberanía ilimitada. Las infraestructuras estratégicas revierten al Estado si la concesión termina.

Los monopolios históricos pueden mantenerse solo si cumplen una función estratégica y tienen duración limitada.

Toda concesión debe incluir:

- territorio;

- plazo;

- obligaciones;

- tarifas;

- inversión mínima;

- derechos laborales;

- auditoría;

- reversión al Estado;

- causa de terminación.

No se admite que una concesión portuaria se convierta automáticamente en soberanía territorial.

#### Relación con COFOVAL

La creación de la Corporación General de Fomento Valinari transforma la relación entre Casas y economía.

Las Casas pueden participar como:

- accionistas;

- proveedoras;

- concesionarias;

- propietarias de terrenos;

- fundadoras de universidades;

- inversoras industriales;

- administradoras patrimoniales;

- socias tecnológicas.

Pero la asignación de fondos públicos queda sujeta a:

- concurso;

- evaluación técnica;

- auditoría;

- límites de concentración;

- publicación de contratos;

- legislación laboral;

- control parlamentario.

COFOVAL coordina a las Casas mediante contratos públicos, créditos y programas sectoriales. Las Casas pueden aportar:

- capital;

- suelo;

- conocimiento;

- redes internacionales;

- personal;

- instalaciones;

- patentes;

- experiencia administrativa.

COFOVAL aporta:

- financiación;

- garantías;

- infraestructura;

- investigación pública;

- compras estatales;

- formación;

- acceso a mercados.

La relación debe ser contractual, auditable y temporalmente revisable.

## Religión y memoria

### Religión valinari y relaciones interconfesionales

La religión valinari reconoce a Eru como principio creador y utiliza los relatos de Ainur y Maiar como categorías espirituales, literarias y culturales. No considera que existan especies sobrenaturales verificables. Su ética se basa en la dignidad humana, la protección de la vida, la custodia del conocimiento, el cumplimiento de los pactos y la responsabilidad comunitaria.

La expansión marítima convirtió a Valinor en una civilización plural. Las comunidades judías, católicas, musulmanas y budistas conservaron lugares de culto, escuelas, cementerios, festividades y autoridades religiosas. La ley federal prevalece en delitos, impuestos, defensa, ciudadanía y derechos civiles.

El judaísmo influyó en la memoria histórica, los pactos, la interpretación textual, la medicina, las finanzas y el comercio. El catolicismo aportó instituciones hospitalarias, diplomacia, archivos, arquitectura y derecho comparado. El islam fue decisivo en astronomía, matemáticas, medicina, cartografía, navegación, óptica, ingeniería hidráulica y comercio, especialmente en Egipto, el mar Rojo, Adén, Socotra, Omán, el golfo y Malaca. El budismo influyó en educación monástica, medicina, disciplina intelectual, compasión, traducción y conservación de manuscritos en las rutas del Índico y Asia.

En Harnen se reconocen instituciones islámicas locales y tribunales religiosos limitados. En los territorios asiáticos se protegen monasterios budistas y escuelas. Las comunidades judías y católicas conservan autonomía religiosa dentro de la ley federal. Los conflictos con otros poderes religiosos se interpretan como disputas políticas, comerciales o territoriales, no como guerras doctrinales inevitables.

Desde Forostar, la autoridad política, la autoridad sacerdotal y la investigación intelectual se distinguen institucionalmente. La Corona no puede declararse encarnación de Eru ni imponer una interpretación única. El principio canónico es el pluralismo pactado: Valinor mantiene una tradición propia sin absorber ni subordinar completamente a otros credos.

##### Organización interna de la religión valinari

La religión valinari no es una iglesia única. Está formada por templos locales, Casas de la Memoria, santuarios de las estrellas, órdenes de guardianes, capellanías navales y escuelas teológicas. Sus corrientes principales son la Tradición de la Unidad, la Tradición de los Guardianes, la Tradición de las Custodias y la Tradición Marítima.

La Tradición de la Unidad interpreta a Eru como fundamento moral y limita el poder real. La Tradición de los Guardianes relaciona a los Ainur con el conocimiento, los archivos, la medicina y la civilización. La Tradición de las Custodias interpreta a los Maiar como figuras humanas sacralizadas, especialmente sacerdotisas, astrónomas, sanadoras y maestras. La Tradición Marítima organiza bendiciones de barcos, memoria de los muertos en el mar, juramentos de tripulación y protección de viajeros.

##### Templos, órdenes y ceremonias

Los Templos de Eru celebran nacimientos, matrimonios y funerales, mantienen escuelas y prestan asistencia social. Las Casas de la Memoria conservan genealogías, tratados, mapas, registros de guerra y testimonios. Las órdenes de guardianes protegen archivos, hospitales, refugios, observatorios y rutas de rescate.

Los ritos de nacimiento, mayoría de edad, matrimonio y muerte poseen una dimensión religiosa y civil. El matrimonio requiere consentimiento, reconocimiento familiar y registro legal. Los funerales pueden realizarse en tierra, mediante cremación o en ceremonias marítimas reguladas. Ningún rito religioso sustituye la ciudadanía o la ley federal.

##### Calendario y fiestas

El calendario combina ciclos solares, agrícolas y marítimos. Sus principales celebraciones son el Día de la Primera Luz, la Fiesta de Forostar, la Noche de Elerwen, el Día de los Pactos, la Fiesta del Retorno, la Memoria de los Navegantes, el Día de las Casas de la Memoria y la Fiesta del Mar Abierto. Las comunidades judías, católicas, musulmanas y budistas conservan además sus calendarios propios.

##### Religión, Casas y Corona

Cada Casa desarrolla una tradición funcional: archivos en Noldor, ceremonial en Vanyar, navegación en Teleri, astronomía en Eressëa Menel, comercio en Harnost, exploración en Eäralindë y servicio de la Corona en Telcontar. Estas tradiciones no constituyen religiones separadas.

La Corona se considera legítima mientras preserve pactos, santuarios, graneros, mercados, rutas y comunidades. La fórmula tradicional sostiene que la Corona no gobierna por ser divina, sino mientras preserve el pacto. Los conflictos religiosos históricos se interpretan como disputas humanas por tierras, impuestos, escuelas, jurisdicción y privilegios, no como guerras inevitables entre credos.

Desde el siglo XVIII aumenta la secularización. En el siglo XIX los registros civiles, las universidades, los hospitales y los tribunales adquieren autonomía respecto de los templos. En 1956 y 2026 Valinor mantiene una identidad religiosa valinari, pero funciona como Estado pluralista con libertad de culto y separación entre religión, ciencia y administración.

##### Profundización doctrinal

La religión valinari se organiza alrededor de la custodia, la memoria y el pacto. Ninguna persona posee absolutamente aquello que administra: la Corona custodia el reino, las Casas custodian sus tierras, los templos custodian la memoria, los científicos custodian el conocimiento y los puertos custodian las rutas.

La memoria posee valor religioso. La pérdida de nombres, genealogías, leyes, mapas, canciones o relatos de fundación se considera una pérdida de la comunidad. Por ello, las Casas de la Memoria pueden revisar títulos, derechos de paso, acuerdos territoriales, matrimonios dinásticos y obligaciones de protección.

La naturaleza no se considera una divinidad literal, pero sí una realidad dotada de valor moral. La destrucción injustificada de bosques, mares, glaciares, fuentes de agua o santuarios naturales constituye una violación de la custodia. Esta doctrina influye en la pesca, la minería, la energía y la protección ambiental.

La religión admite cuatro grandes corrientes: los reformistas de la Custodia, que defienden igualdad y acceso público a los archivos; los secularistas del Mar, que separan ética y religión institucional; los tradicionalistas de Forostar, que protegen rituales y privilegios antiguos; y los universalistas de Eru, que consideran que otras religiones contienen fragmentos de una verdad común.

La guerra solo se considera legítima como defensa, rescate, protección de rutas, cumplimiento de una alianza o protección de una comunidad. Se condenan las guerras de conversión, el exterminio, la tortura, la ejecución de prisioneros, el saqueo de hospitales y los ataques contra templos. Las capellanías navales y militares atienden a heridos y prisioneros de cualquier credo.

El matrimonio combina consentimiento, reconocimiento familiar, pacto patrimonial y registro civil. Las diferencias religiosas pueden resolverse mediante ceremonias dobles o matrimonio civil. La disolución es aceptable en casos de violencia, abandono, persecución o ruptura grave del pacto.

En 2026 la religión valinari conserva funciones de identidad cultural, asistencia social, memoria histórica y ética pública, pero no controla tribunales, universidades, censos, ejército, economía ni política exterior. La fórmula doctrinal consolidada es: el mundo no pertenece por completo a quienes lo gobiernan; quienes gobiernan solo lo custodian para quienes vendrán después.

##### Desarrollo sistemático de la religión

1. Naturaleza: tradición espiritual, ética y cultural de origen escandinavo-atlántico; no es una iglesia única ni una religión étnica cerrada.

2. Eru: principio creador, fundamento de unidad y referencia moral; ninguna Corona puede declararse su encarnación.

3. Ainur: principios fundadores, fuerzas morales y figuras simbólicas; los Valar representan órdenes tutelares.

4. Maiar: categoría espiritual de la cosmología; algunas escuelas históricas interpretan determinados relatos como memoria de seres humanos sacralizados, entre ellos sacerdotisas, astrónomas, médicas, maestras y fundadoras.

5. Pacto: base de la ética y del derecho; el perjurio, el abandono de refugiados y el saqueo de santuarios son faltas religiosas y políticas.

6. Custodia: nadie posee absolutamente aquello que administra; Corona, Casas, templos, científicos y puertos tienen responsabilidades públicas.

7. Memoria: genealogías, tratados, mapas, registros y testimonios forman parte del patrimonio religioso y político.

8. Naturaleza: mares, bosques, glaciares, montañas y fuentes de agua poseen valor moral, aunque no sean divinidades literales.

9. Corrientes: Unidad, Guardianes, Custodias, Tradición Marítima, reformistas, secularistas del Mar, tradicionalistas de Forostar y universalistas de Eru.

10. Instituciones: Templos de Eru, Casas de la Memoria, Santuarios de las Estrellas, Órdenes de Custodia y Capellanías Navales.

11. Ritos: nacimiento, mayoría de edad, matrimonio, muerte y ceremonias de navegación poseen dimensión religiosa y civil.

12. Calendario: Primera Luz, Forostar, Elerwen, Pactos, Retorno, Navegantes, Casas de la Memoria y Mar Abierto.

13. Corona: su legitimidad depende de preservar pactos, santuarios, graneros, mercados, rutas, archivos y comunidades.

14. Casas: cada Casa posee una tradición funcional, pero ninguna constituye una religión independiente.

15. Guerra: solo es legítima como defensa, rescate, protección de rutas, aliados, comunidades o santuarios; se prohíben exterminio, tortura, saqueo y ejecución de prisioneros.

16. Pluralismo: judaísmo, catolicismo, islam y budismo conservan templos, escuelas, calendarios, autoridades y prácticas dentro de la ley federal.

17. Secularización: desde el siglo XVIII aumentan la autonomía de registros civiles, universidades, hospitales y tribunales respecto de los templos.

18. Estado moderno: en 2026 la religión conserva funciones culturales, éticas, ceremoniales y asistenciales, pero no controla la administración civil, la ciencia, la economía ni la defensa.

### Controversias religiosas y convivencia entre 430 y 864 d. C.

Las controversias se desarrollan dentro de una monarquía ya existente, con la Casa Telcontar al frente de la Corona desde 560 a. C. La religión ofrece lenguajes de legitimidad y protección, pero santuarios, Casas y comunidades discrepan sobre propiedad, enseñanza, culto y obligaciones públicas.

##### Controversia de las Potestades entre 430 y 525

La presencia de comunidades cristianas y las traducciones de sus doctrinas intensifican el debate sobre Eru, los Ainur, los Valar y los Maiar. Algunas escuelas buscan equivalencias entre tradiciones; otras rechazan interpretaciones que consideran incompatibles con su fe.

La disputa afecta a donaciones, edificios de culto, escuelas, herencias y conversiones. La regencia de 430–441 y los monarcas posteriores administran sus consecuencias sin que el conflicto interrumpa por sí mismo la continuidad dinástica. Existen violencia localizada, arbitrajes y acuerdos de protección con resultados desiguales.

La crónica distingue afirmaciones de los creyentes y hechos verificables: las categorías religiosas no demuestran la existencia material de seres sobrenaturales. La Crisis de la Custodia, relativa a esclavitud y dignidad humana, comparte escenarios y actores institucionales con esta controversia, pero conserva sus causas y reforma propias.

##### Acuerdos locales y límites de la recuperación

Hacia 525 se consolidan pactos locales que protegen determinadas comunidades, bienes de culto y fórmulas de compromiso. Su alcance depende de los pactantes y no establece una libertad religiosa constitucional uniforme.

Durante la Fragmentación, los archivos principales conservan el corpus de conocimiento depositado. Se dañan o pierden copias regionales y disminuye el acceso. La reconstrucción asociada a Sigrid Andersdotter y los Consejos de Recuperación vinculados a Björn Arnesen restablecen registros, rutas y asistencia bajo las autoridades del Reino.

##### Conflictos de imágenes entre 780 y 851

Las diferencias sobre representación de ancestros, santos, Valar y figuras de la memoria afectan a templos, escuelas y espacios ceremoniales. El conflicto enfrenta también a autoridades que disputan donaciones, custodia de obras y control de la enseñanza.

Los episodios de violencia de 808–820 y las disposiciones de 821 y 851 impulsan acuerdos de protección y restitución. No se atribuye una posición única a todos los cristianos ni a todos los practicantes valinari. La destrucción de una imagen o una copia local no se interpreta como desaparición del conocimiento de los archivos centrales.

##### Juramentos y Congreso de las Fórmulas

Entre 805 y 864, marinos, comerciantes y autoridades discuten si una obligación pública exige una fórmula religiosa particular. El Congreso de las Fórmulas de 842 reconoce la necesidad de expresiones equivalentes de compromiso verificable, con registro y testigos.

La objeción a una fórmula de culto no extingue deudas, deberes de rescate ni obligaciones aceptadas. Las autoridades examinan el cumplimiento del compromiso y los límites de su jurisdicción. La distinción avanza por acuerdos y prácticas, sin introducir retrospectivamente el régimen secular contemporáneo.

##### Pacto de las Dos Reverencias de 864

La Corona, las Casas y las comunidades adheridas adoptan un pacto de convivencia que diferencia adoración, veneración y conmemoración cívica. La denominación tradicional de Dos Reverencias no obliga a todas las religiones a aceptar la misma explicación teológica.

Se reconocen fórmulas alternativas de juramento, protección de lugares y objetos de culto y procedimientos de reclamación frente a coerción o destrucción. Las instituciones comunes pueden exigir el cumplimiento de obligaciones civiles sin imponer una declaración doctrinal idéntica a todos los pactantes.

El pacto mantiene competencias de la Corona, fueros y jurisdicciones históricas. Sus garantías se extienden gradualmente y conocen incumplimientos. Constituye un antecedente del pluralismo posterior; la igualdad jurídica contemporánea resulta de reformas adicionales.

### Teología valinari de Eru Ainur y Maiar

El proyecto transcurre en un mundo humano y realista. Eru, los Ainur y los Maiar no son especies ni entidades verificables. Forman parte de la teología, la literatura, la memoria religiosa y la identidad cultural valinari.

Eru es el nombre teológico del principio creador único. Las escuelas religiosas discrepan sobre si es un Dios personal, una inteligencia creadora, un principio abstracto o una metáfora de la unidad del universo. Eru fundamenta los juramentos, la moral de la Corona y los pactos entre Casas, pero ningún monarca puede presentarse como su encarnación absoluta.

Los Ainur son los “primeros pensamientos” de Eru en la tradición religiosa. Históricamente representan principios morales, instituciones fundadoras, sabios, héroes civilizadores y fuerzas de la naturaleza personificadas. Los Valar se interpretan como grandes órdenes tutelares o poderes simbólicos; los espíritus oscuros representan el desorden, la tiranía y la corrupción.

La lectura historicista interpreta ciertos relatos de Maiar como memoria de profetisas, guardianas de santuarios, maestras, astrónomas-sacerdotisas, consejeras de Casas y fundadoras de hospitales, escuelas o archivos. La cosmología doctrinal los clasifica como Ainur, sin que el narrador certifique su existencia sobrenatural. No son seres sobrenaturales documentados; muchos relatos conservan la memoria transformada de personas humanas de gran prestigio.

La tradición de Telcontar afirma que un antepasado se unió a una mujer considerada Maiar. La lectura religiosa la presenta como intermediaria divina; la histórica la interpreta como una noble de una rama sacerdotal, astrónoma o guardiana de archivos vinculada a las tierras bálticas y finlandesas. La genealogía de la Casa sigue siendo humana, hereditaria y poligénica.

### Profundización teológica de Ilúvatar, los Ainur, los Valar y los Maiar

En el mundo humano y realista del canon, Ilúvatar, los Ainur, los Valar y los Maiar pertenecen al lenguaje religioso, literario y cultural valinari. No son especies, entidades verificables ni actores sobrenaturales documentados.

##### Ilúvatar

Ilúvatar es el nombre tradicional del principio creador y fundamento último del orden. Las escuelas valinari discrepan sobre si debe entenderse como un Dios personal, una inteligencia creadora, un principio abstracto o una metáfora de la unidad del universo. En todos los casos, su función política es limitar el poder humano: ningún rey puede proclamarse encarnación de Ilúvatar ni convertir sus decisiones en voluntad divina incuestionable.

La doctrina de la custodia sostiene que la Corona, las Casas, los templos, los científicos y los puertos administran bienes que deberán ser entregados a las generaciones siguientes. El sufrimiento no se interpreta como castigo automático; la obligación religiosa consiste en reparar daños, proteger a los vulnerables y conservar memoria de las pérdidas.

##### Ainur

Los Ainur son los “primeros pensamientos” de Ilúvatar en la tradición religiosa. Representan principios morales, instituciones fundadoras, sabios, héroes civilizadores y fuerzas de la naturaleza personificadas. No toda comunidad los representa como personas: pueden aparecer como constelaciones, árboles, montañas, animales, colores, instrumentos musicales o patrones rituales.

##### Valar

Los Valar son grandes órdenes tutelares o ámbitos simbólicos de la creación. Manwë representa cielo, vientos y coordinación; Varda, estrellas, orientación y navegación; Ulmo, mares, ríos y fuentes; Aulë, metalurgia, artesanía y construcción; Yavanna, agricultura, bosques y semillas; Námo, muerte y memoria; Vairë, escritura y archivos; Estë, descanso y sanación; Nienna, compasión y duelo; Tulkas, defensa y resistencia; Oromë, caminos y exploración; e Irmo, sueños, imaginación e intuición.

Estas asociaciones orientan ceremonias, oficios y deberes comunitarios, pero no sustituyen la observación natural ni la explicación técnica de los fenómenos.

##### Maiar

En la lectura historicista, ciertos Maiar se interpretan como intermediarios y figuras ejemplares de la tradición; la lectura cosmológica los considera una categoría de Ainur. El término puede designar guardianas de santuarios, sacerdotisas, astrónomas, maestras, sanadoras, consejeras, navegantes y fundadoras de archivos, hospitales o escuelas. Muchos relatos de Maiar conservan la memoria transformada de personas humanas de gran prestigio.

La sacralización de un Maia es un proceso histórico: se conserva el nombre, se asocia a un lugar, se atribuye una función protectora, se incorpora a juramentos y se celebra una fecha de memoria. Ninguna de estas prácticas demuestra una naturaleza sobrenatural.

##### Instituciones y pluralidad

La tradición no forma una iglesia única. Conviven templos locales, Casas de la Memoria, Santuarios de las Estrellas, órdenes de guardianes, capellanías navales y escuelas teológicas. Las corrientes principales son la Unidad, los Guardianes, las Custodias y la Tradición Marítima.

Los sacerdocios pueden validar juramentos, custodiar archivos, mediar entre Casas, proteger graneros y denunciar abusos, pero no controlan por sí solos el ejército, los impuestos, la justicia civil ni la Corona. El Concilio de Forostar reconoce esta separación y evita convertir la religión en teocracia.

##### Telcontar y el mito fundacional

La tradición de Telcontar afirma que un antepasado se unió a una mujer considerada Maiar. La lectura religiosa la presenta como intermediaria divina; la histórica la interpreta como una noble de una rama sacerdotal, astrónoma o guardiana de archivos vinculada a las tierras bálticas y finlandesas. La genealogía de la Casa continúa siendo humana, hereditaria y poligénica.

##### Principio canónico

La religión valinari sostiene que el mundo no pertenece por completo a quienes lo gobiernan: quienes gobiernan solo lo custodian para quienes vendrán después. Este principio vincula teología, protección de la naturaleza, archivos, pactos, graneros, hospitales, navegación y límites al poder de la Corona.

### Religión valinari, 1000–500 a. C.

La religión valinari de este periodo es una tradición común, pero todavía no constituye una iglesia centralizada. Sus prácticas proceden de las comunidades humanas de Escania y Noruega y se organizan alrededor de la memoria, la naturaleza, los juramentos y la protección de la comunidad.

La tradición reconoce a Eru como principio creador y fundamento último del orden, pero no existe todavía una teología sistemática ni una doctrina única. Los nombres de los Ainur y Maiar se interpretan como figuras sagradas, principios cósmicos, antepasados ejemplares o intermediarios simbólicos. No se consideran seres visibles que gobiernen directamente la política cotidiana.

### Culto a la memoria ancestral

La memoria de los antepasados cumple una función religiosa y política. Las familias conservan:

- genealogías;

- relatos de migración;

- pactos antiguos;

- nombres de fundadores;

- victorias y derrotas;

- obligaciones entre linajes.

Los antepasados no son necesariamente dioses. Son modelos de conducta, testigos simbólicos de los juramentos y garantes de la continuidad de la comunidad.

Las Casas nobles utilizan esta memoria para justificar:

- derechos sobre tierras;

- custodia de puertos;

- precedencia ceremonial;

- obligaciones militares;

- alianzas matrimoniales;

- autoridad sobre determinados santuarios.

La legitimidad de una Casa depende tanto de su genealogía como de su capacidad para proteger a la comunidad.

### Naturaleza y lugares sagrados

La naturaleza se considera un ámbito donde se manifiesta el orden de la creación. Bosques, montañas, costas, ríos y fuentes pueden adquirir carácter sagrado por su importancia para la supervivencia.

Los lugares de mayor importancia religiosa son:

- fuentes de agua potable;

- bosques antiguos;

- colinas de reunión;

- islas;

- desembocaduras de ríos;

- promontorios costeros;

- piedras de juramento;

- túmulos de antepasados.

La sacralidad no implica que todo el territorio sea intocable. La explotación de madera, pesca, agricultura y minería se permite cuando respeta los límites rituales y comunitarios.

La destrucción deliberada de una fuente, un bosque ritual o un santuario se considera una agresión contra toda la comunidad, no solamente contra una Casa.

### Calendario religioso

El calendario combina observación astronómica, ciclos agrícolas y navegación.

Las principales ceremonias se celebran en torno a:

- solsticio de invierno;

- equinoccio de primavera;

- solsticio de verano;

- equinoccio de otoño;

- primera siembra;

- primera cosecha;

- regreso de las flotas;

- apertura y cierre de la temporada marítima;

- conmemoración de los muertos.

Las ceremonias incluyen fuegos rituales, procesiones, comidas comunales, recitación de genealogías, ofrendas de grano, libaciones de agua y renovación de juramentos.

No existe una fecha única ni una liturgia idéntica para todas las Casas. Las prácticas regionales varían según el clima y la economía local.

### Santuarios

Los santuarios son espacios religiosos, pero también cumplen funciones civiles.

En ellos pueden conservarse:

- registros de nacimientos y muertes;

- genealogías;

- acuerdos entre Casas;

- calendarios;

- inventarios de grano;

- reservas de semillas;

- contratos;

- objetos rituales;

- mapas costeros;

- listas de tripulaciones;

- registros de deudas y compensaciones.

El santuario funciona como lugar de confianza porque se considera protegido por la obligación religiosa del juramento. La violación de sus archivos o depósitos se interpreta como sacrilegio y como ruptura del orden político.

Los santuarios mayores pueden disponer de graneros, pozos, refugios, talleres y embarcaderos. Durante crisis o guerras, se espera que protejan a civiles, heridos, niños y viajeros.

### Sacerdocios

No existe una casta sacerdotal única. Cada región mantiene sus propias autoridades religiosas.

Los principales cargos son:

- guardianes de santuario;

- custodios de genealogías;

- intérpretes de calendarios;

- oficiantes de juramentos;

- mediadores entre Casas;

- cuidadoras y cuidadores de fuentes;

- escribas rituales;

- observadores astronómicos.

Algunos cargos son hereditarios; otros son elegidos por una comunidad, una Casa o un consejo local. La autoridad religiosa no siempre coincide con la nobleza. Un sacerdote puede pertenecer a una familia humilde y, sin embargo, custodiar un santuario de gran importancia.

Las mujeres participan en la custodia de genealogías, rituales funerarios, medicina, conservación de semillas, observación astronómica y administración de depósitos. La participación concreta varía según la región y la Casa.

### Religión y Casas nobles

Cada Casa desarrolla una tradición funcional asociada a su historia:

- las Casas agrícolas protegen ciclos de siembra y graneros;

- las Casas marítimas veneran rutas, vientos y fuentes costeras;

- las Casas guerreras custodian santuarios fronterizos y juramentos de defensa;

- las Casas de estudio conservan calendarios, archivos y conocimientos;

- las Casas comerciales protegen mercados, contratos y puertos neutrales;

- las Casas exploradoras realizan ceremonias antes de las expediciones.

Estas diferencias no constituyen religiones separadas. Son expresiones regionales y funcionales de una misma tradición valinari.

La Casa Telcontar, antes de convertirse en casa real, vincula su legitimidad a la protección de los pactos, la reunificación de las comunidades y la defensa de los santuarios durante las crisis.

### Juramentos y derecho

El juramento religioso es uno de los instrumentos jurídicos más importantes del periodo.

Puede utilizarse para confirmar:

- tratados;

- límites de tierras;

- treguas;

- matrimonios;

- devolución de prisioneros;

- protección de comerciantes;

- neutralidad de puertos;

- custodia de menores;

- distribución de agua;

- obligaciones militares.

Un juramento válido debe pronunciarse ante testigos y, preferentemente, en un santuario o lugar reconocido. Romperlo no significa únicamente incumplir una promesa: implica perder reputación, derechos de comercio y confianza política.

Las sanciones pueden incluir:

- compensación económica;

- exclusión temporal de mercados;

- pérdida de precedencia;

- restitución de tierras;

- expulsión ritual;

- aislamiento diplomático.

La pena religiosa no sustituye siempre al castigo civil. Con el tiempo, ambos sistemas se integran en los procedimientos del Concilio de Forostar.

### Muerte y memoria funeraria

Las prácticas funerarias varían entre las regiones costeras, agrícolas y montañosas.

Pueden incluir:

- enterramiento en túmulos;

- sepulturas familiares;

- cremación;

- depósitos de objetos personales;

- estelas con genealogías;

- ceremonias marítimas;

- cantos de memoria;

- conservación del nombre en los archivos del santuario.

El objetivo no es solamente despedir al muerto, sino preservar su lugar dentro de la comunidad. Las familias nobles mantienen listas de antepasados y conmemoran especialmente a quienes fundaron puertos, defendieron graneros o mediaron en guerras.

Los muertos no son considerados dueños automáticos de las tierras. La memoria ancestral sirve para legitimar obligaciones, pero no elimina la necesidad de acuerdos vivos entre comunidades.

### Diferencias regionales

##### Escania

Predominan los santuarios de colina, bosque y costa. Las ceremonias están vinculadas a la agricultura, la navegación del Øresund y la memoria de los fundadores.

##### Noruega

La religión incorpora una relación más intensa con montañas, fiordos, tormentas, pesca y navegación de altura. Los santuarios costeros tienen funciones de refugio y protección de marineros.

##### Dinamarca

Las comunidades danesas participan de la tradición valinari mediante contactos comerciales, matrimonios y migraciones. Conservan ritos propios y no quedan subordinadas religiosamente a los santuarios de Escania.

##### Báltico occidental

Los santuarios se relacionan con islas, ámbar, pesca, navegación y pactos entre comunidades portuarias. Las prácticas son más móviles y pueden trasladarse entre asentamientos estacionales.

### Crisis religiosa y política

Entre 1000 y 990 a. C., las crisis de abastecimiento y las rivalidades entre Casas provocan disputas sobre:

- control de santuarios;

- acceso a fuentes;

- custodia de archivos;

- uso de graneros;

- legitimidad de genealogías;

- interpretación de antiguos juramentos.

El Concilio de Forostar, en 990 a. C., no crea una iglesia nacional. Su función es establecer una base común:

- protección de santuarios;

- reconocimiento de juramentos;

- neutralidad de ciertos mercados;

- custodia compartida de archivos;

- prohibición de destruir graneros rituales;

- mediación entre sacerdocios regionales;

- separación parcial entre autoridad religiosa y mando militar.

Así, la religión se convierte en una institución de cohesión política sin transformarse en una teocracia.

### Desarrollo hasta 500 a. C.

Entre 950 y 850 a. C., los santuarios recuperan archivos, calendarios y genealogías dañados durante las crisis.

Entre 850 y 700 a. C., el contacto comercial amplía el conocimiento astronómico, náutico y médico. Las Casas de estudio comienzan a copiar textos extranjeros y adaptarlos a la tradición valinari.

Entre 700 y 600 a. C., las crisis de rutas y abastecimiento generan nuevas disputas entre sacerdocios, puertos y Casas nobles. La religión mantiene la memoria común, pero no impide conflictos políticos.

Entre 600 y 550 a. C., el retorno de la Casa Telcontar fortalece la idea de que la Corona debe proteger los santuarios, garantizar los pactos y mantener abiertas las rutas.

Hacia 500 a. C., la religión valinari ya posee:

- calendarios regionales coordinados;

- santuarios con archivos permanentes;

- sacerdocios reconocidos;

- rituales comunes de juramento;

- normas funerarias compartidas;

- protección legal de fuentes y bosques;

- una tradición teológica básica centrada en Eru;

- autonomía suficiente para conservar diferencias regionales.

La religión continúa siendo descentralizada, pero deja de ser únicamente una suma de cultos locales. Se convierte en una tradición común capaz de sostener la Corona, el derecho de pactos y la identidad histórica de los Valinari.

21:09

### Crisis religiosa de la Custodia y reforma doctrinal

La expansión y el uso de trabajo esclavizado provocan una crisis religiosa entre los siglos III y V d. C., durante la consolidación de rutas africanas, americanas, caribeñas e insulares. La crisis se conoce como Crisis de la Custodia.

##### Causas

- contradicción entre la protección de la vida y la propiedad de personas;

- venta de niños separados de sus familias;

- explotación sexual de mujeres esclavizadas;

- conversión religiosa bajo coerción;

- uso de santuarios para ocultar cautivos;

- participación de Casas religiosas en beneficios comerciales;

- guerras justificadas como pacificación;

- desigualdad entre ciudadanos valinari y poblaciones locales.

Las corrientes religiosas se dividen. La Tradición Imperial afirma que la Corona debe imponer orden y que el trabajo obligatorio puede ser legítimo después de una guerra. La Tradición de la Custodia sostiene que ningún ser humano puede convertirse plenamente en propiedad porque toda persona participa de la creación y de la memoria común.

##### Reforma de la Custodia

La crisis culmina en una reforma doctrinal y jurídica gradual entre 450 y 500 d. C.. No elimina de inmediato la esclavitud, pero establece límites que luego permiten la abolición progresiva.

La reforma fija que:

1. ninguna persona protegida por un tratado puede ser esclavizada;

2. los prisioneros deben registrarse y no pueden desaparecer de los archivos;

3. la venta de menores de doce años queda prohibida;

4. madres y niños pequeños no deben separarse;

5. se prohíben tortura, mutilación, asesinato arbitrario y violación;

6. la explotación sexual y el concubinato coercitivo se consideran delitos religiosos y civiles;

7. toda persona esclavizada puede solicitar manumisión ante un santuario;

8. el trabajo obligatorio debe tener duración, alimentación y condiciones registradas;

9. la conversión religiosa no puede ser condición de libertad;

10. los hijos de personas liberadas nacen libres;

11. los comerciantes deben acreditar el origen de los cautivos;

12. los santuarios pueden conceder refugio temporal a personas perseguidas.

La reforma no es aplicada uniformemente. Las Casas fronterizas, factorías distantes y mercados vinculados a Roma mantienen abusos. Sin embargo, la doctrina transforma la esclavitud en una institución moralmente sospechosa y jurídicamente limitada.

### Religión valinari y concordancia cosmológica

La tradición valinari reconoce a Eru Ilúvatar como único increado y origen de toda existencia. Los Ainur son criaturas espirituales; Valar y Maiar son categorías doctrinales dentro de ellos. Los relatos atribuyen a los Valar participación en el ordenamiento, formación y cuidado del mundo, pero no creación independiente. Melkor es descrito como un Ainu rebelde: la rebeldía define su conducta y relación con el orden, no una categoría ontológica distinta. La Música de los Ainur se conserva como relato cosmológico primordial y admite lecturas literales, simbólicas y filosóficas; el canon histórico no decide la realidad objetiva de los seres sobrenaturales.

Las 24 Casas Mayores proceden de las 15 provincias noruegas y 9 subzonas escanianas fijadas en la matriz nobiliaria. Dinamarca aporta migración general, y Finlandia interviene en fases posteriores específicas; ninguna de ellas sustituye los orígenes fundacionales de esas 24 Casas. Esto no significa que toda la inmigración exterior del periodo fuera nórdica: la corriente no nórdica continental y oriental existió como población portuaria, artesanal, agrícola, mercantil, dependiente y mixta, sin fundar las Casas Mayores ni incorporarse automáticamente a la ciudadanía de linaje.

Entre 1000 y 700 a. C. la religión es principalmente doméstica, oral y comunitaria. Se transmiten relatos de origen, memoria de antepasados, funerales, cantos, prácticas estacionales, protección de fuentes y bosques, juramentos y ceremonias de navegación. No existe todavía un libro sagrado cerrado, una liturgia uniforme ni una iglesia común.

El Camino del Oeste, o tradición de la tierra prometida al oeste, expresa la búsqueda de renovación, memoria, navegación y comunidad. No es una concesión divina literal de territorios ni autoriza automáticamente la conquista. El descubrimiento solo adquiere legitimidad mediante pactos, protección de comunidades, abastecimiento, límites al saqueo, respeto de santuarios y cumplimiento de obligaciones.

Entre 700 y 300 a. C. las prácticas se adaptan a hogares, puertos y oficios. Los hogares conservan genealogías, nacimientos, uniones y funerales; las comunidades administran fiestas, graneros, reconciliaciones y fuentes; los navegantes realizan despedidas, ceremonias de regreso, memoria de desaparecidos y deberes de auxilio. Estas prácticas no crean una autoridad sacerdotal única.

Entre 300 a. C. y 350 d. C. los contactos mediterráneos y atlánticos incorporan traducciones, debates y préstamos conceptuales. La presencia cristiana se intensifica aproximadamente entre 150 y 350 d. C. La semejanza entre Eru y el Dios cristiano facilita el diálogo, pero no resuelve Cristo, Trinidad, revelación, encarnación ni autoridad eclesiástica. Las religiones de las poblaciones residentes permanecen y no se presume conversión general.

Entre 350 y 430 d. C. se desarrollan las primeras controversias sobre plegarias a los Valar, imágenes, juramentos y fiestas. Entre 430 y 525 d. C. la Controversia de las Potestades formaliza esos conflictos. La escuela conciliadora reserva adoración a Eru y distingue veneración, memoria e intercesión respecto de los Ainur, pero no obtiene unanimidad. Las analogías entre Ainur y ángeles, o entre Melkor y Satanás, pertenecen a escuelas concretas y no constituyen identidad ontológica universal.

Entre 525 y 800 d. C. santuarios, hogares y autoridades cooperan en refugio, enseñanza, archivos, cuidado de enfermos y abastecimiento, pero también compiten por tierras, donaciones, prestigio y autoridad. La reforma educativa del siglo VII y la codificación aproximada de 702 amplían la comparación de tradiciones sin crear una doctrina única.

La violencia sobre imágenes de 808–820, los edictos de 821 y 851, el Congreso de las Fórmulas de 842 y el Pacto de las Dos Reverencias de 864 forman una secuencia de convivencia negociada. El Pacto distingue conciencia, adoración, veneración y conmemoración cívica, y permite fórmulas públicas alternativas. No establece todavía neutralidad constitucional moderna ni elimina coerción, desigualdad o conflictos.

Hacia 1000 d. C. coexisten la tradición de Eru y los Ainur, escuelas conciliadoras, cristianismos locales, religiones de poblaciones anteriores y prácticas domésticas. La Corona puede custodiar acuerdos de convivencia, pero no imponer una religión, decidir la verdad teológica ni convertir el Camino del Oeste en título territorial.

No quedan fijados por esta integración la realidad objetiva de los seres sobrenaturales, la fecha exacta de composición de los textos, las lenguas litúrgicas, las confesiones mayoritarias por territorio, el destino después de la muerte, los nombres de órdenes sacerdotales ni la relación detallada con cada religión residente.

Religión valinari y Camino del Oeste

## Población, hogares y trabajo

### Trabajo y protección social valinari

La historia laboral comprende agricultura, pesca, talleres, navegación, cuidados, administración, industria y servicios. Las condiciones dependen de la época, el territorio y la situación jurídica. La protección de un noble, un trabajador libre, un dependiente y una persona esclavizada no es equivalente en la sociedad antigua.

##### Hogares Casas y aprendizaje

Entre 1000 a. C. y 700 d. C., hogares, talleres, santuarios y tripulaciones transmiten conocimientos mediante aprendizaje acompañado. La formación combina trabajo productivo, manutención y obligaciones personales; su reconocimiento depende de autoridades de Casa y comunidades locales.

Las Casas agrícolas aportan alimentos y reservas; las metalúrgicas, herramientas y reparación; las marítimas y comerciales, embarcaciones y contratos; las dedicadas al estudio, registros y formación. Las Casas Vasallas actúan dentro de sus relaciones tutelares. Estas funciones no conceden a ninguna Casa un monopolio técnico permanente.

Las redes de parentesco, oficio y tripulación sostienen fondos y ayudas para accidentes, enfermedad, viudedad, orfandad y entierro. Su alcance es local y desigual. El trabajo de cuidados, desarrollado en hogares y establecimientos comunitarios, sostiene la producción aunque aparezca poco en las cuentas.

##### Esclavitud dependencia y reforma

La expansión incluye trabajo esclavizado, obligaciones de servicio, deudas y otras formas de coerción. Deben registrarse por separado del empleo libre y del tributo territorial. Las disposiciones religiosas y pactistas no prueban por sí solas su cumplimiento.

La Crisis de la Custodia de los siglos III–V y la reforma de 450–500 d. C. limitan la esclavización, protegen a personas amparadas por tratados, regulan registros y manumisión y condenan la coerción sexual. La reforma no equivale a una abolición inmediata. La abolición se establece por etapas entre 1768 y 1856; el calendario territorial y sus límites están fijados en «Resoluciones canónicas acumulativas V16.2».

La condición de ciudadano, la pertenencia de linaje, la afiliación a una Casa y la libertad personal se distinguen en los expedientes. La ampliación de derechos laborales no altera automáticamente las reglas matrimoniales y genealógicas adoptadas para cada periodo.

##### Profesiones marítimas y mutualidad entre 700 y 1705

La ampliación de academias, astilleros y convoyes favorece la especialización de pilotos, carpinteros de ribera, calafates, intérpretes, médicos, cargadores y contables. Las ordenanzas de viaje regulan anticipos, alimentación, reparto de cargas y responsabilidad por pérdidas.

El capitán puede adoptar medidas urgentes para salvar la nave; al regresar, sus decisiones pueden ser examinadas en puerto. Los fondos de tripulación y oficio evolucionan hacia mutualidades con cuotas, prestaciones limitadas y registros. Su desarrollo depende de excedentes y continuidad de las rutas.

En los territorios de expansión persisten trabajo forzoso, abusos contractuales y obligaciones comunitarias. Un contrato traducido de manera incompleta o una deuda registrada por una sola parte no equivalen a consentimiento libre.

##### Industrialización y organización laboral

Desde aproximadamente 1740, la concentración de talleres, fábricas hidráulicas, minería y máquinas térmicas modifica jornadas y riesgos. Accidentes, trabajo infantil, vivienda y remuneración se convierten en asuntos de inspección, compensación y debate político.

Las obras interoceánicas de 1845–1872 reúnen personal de distintos territorios. Los impagos, errores de identidad, desplazamientos y condiciones sanitarias favorecen asociaciones de trabajadores y mecanismos de reclamación. Desde 1872 se amplían sindicatos, mutualidades e iniciativas públicas; las prestaciones siguen siendo desiguales y su exigibilidad crece mediante reformas sucesivas.

##### Derechos públicos y portabilidad

Las guerras mundiales y la crisis de 1929 amplían movilización, empleo público y protección de hogares. La posguerra desarrolla sanidad, educación, pensiones y cobertura de desempleo. La reforma federal de 1958 coordina competencias y facilita la portabilidad de derechos entre territorios, sin convertir a los protectorados en Estados federados.

La digitalización transforma las tareas y la formación continua. La vigilancia laboral, los sistemas de contratación y la evaluación automatizada requieren reglas de acceso, explicación y revisión humana. La historia del trabajo conserva sus diferencias de clase, género y territorio; los derechos contemporáneos no se atribuyen retrospectivamente a la Antigüedad.

### Hogar, parentesco y matrimonio

#### hogar, parentesco y matrimonio

El hogar valinari se define como unidad de sustento, cuidado, producción, transmisión patrimonial y continuidad de linaje. Puede incluir parejas, varias generaciones, parientes, personas acogidas y aprendices, sin que compartir vivienda otorgue idénticos derechos sobre los bienes ni implique ascendencia común.

El parentesco conecta hogares mediante descendencia, uniones reconocidas, adopción social, tutela y recepción de migrantes autorizados. La comunidad regula agua, campos, bosques, pastos, caminos, desembarcaderos, reservas, herramientas y embarcaciones. Uso, administración, propiedad y herencia son facultades diferentes y pueden entrar en conflicto.

##### Endogamia valinari

La endogamia valinari queda definida como una norma religiosa, política y social. Los valinari y sus descendientes reconocidos deben contraer matrimonios reconocidos dentro del ámbito valinari, incluyendo las migraciones nórdicas aceptadas por el canon. La regla conserva continuidad de culto, patrimonio, obligaciones de Casa, educación familiar y legitimidad de linaje.

La norma no exige matrimonios entre parientes cercanos. La movilidad entre Escania, Noruega, Dinamarca, Finlandia y los asentamientos valinari permite ampliar la red matrimonial y evitar que la endogamia equivalga a aislamiento de un único pueblo local. La autoridad de una Casa puede reconocer o rechazar una unión por motivos religiosos, patrimoniales, políticos o genealógicos.

##### Continuidad hereditaria y fenotipo

El canon adopta que la endogamia y la selección matrimonial mantuvieron deliberadamente una continuidad genética y fenotípica dentro de las líneas valinari. Los rasgos asociados a pigmentación clara, ojos claros, cabello rubio o rojizo y determinadas complexiones se transmiten con mayor frecuencia en el núcleo valinari que en las poblaciones exteriores, reforzados por ascendencia compartida, migración nórdica autorizada y matrimonios entre linajes compatibles.

Esta continuidad es un rasgo poblacional y genealógico del escenario: no convierte cada característica en obligatoria para todos los individuos, no asigna un genotipo único a cada Casa y no implica superioridad biológica, intelectual o moral. Las fichas fenotípicas pueden describir tendencias hereditarias, variación familiar y frecuencia relativa sin presentar un rasgo como garantía absoluta.

##### Poblaciones exteriores, esclavitud y descendencia

Las poblaciones locales conquistadas o incorporadas conservan una historia diferenciada. Pueden existir esclavización, desplazamiento, trabajo forzoso, dependencia doméstica, manumisión, comunidades libres y población mestiza o portuaria. La liberación no produce automáticamente ciudadanía valinari ni pertenencia a una Casa.

Los hijos de personas esclavizadas o de uniones no reconocidas se clasifican según la legislación y el reconocimiento territorial de cada época. Pueden formar parte de comunidades locales, mestizas, portuarias, dependientes o liberadas. Solo ingresan en el ámbito matrimonial valinari mediante un procedimiento expreso de pertenencia, adopción de Casa o reconocimiento de linaje; la conversión religiosa o la residencia no bastan por sí solas.

La migración nordgermánica y de Europa oriental posterior se integra principalmente en las poblaciones mestizas y portuarias, no en las Casas Mayores ni en la Casa Real. La pertenencia valinari se conserva como una categoría de linaje, matrimonio, reconocimiento social y estatus político.

##### Administración doméstica y movilidad marítima

Durante las ausencias navales, cónyuges, parientes, tutores u otras personas reconocidas administran campos, talleres, deudas, reparaciones, reservas, herencias provisionales y cuidado de menores. La autoridad práctica puede recaer en hombres o mujeres, pero su alcance depende de época, Casa, patrimonio y reconocimiento jurídico.

La recepción de migrantes requiere vivienda, alimentos, herramientas y oportunidades de sustento. Ayuda, préstamo, deuda, servidumbre, cautiverio y esclavitud deben registrarse por separado. La existencia de archivos o pactos no demuestra que las relaciones fueran justas ni que la coerción hubiera desaparecido.

##### Correcciones territoriales y cronológicas

Númenor corresponde a Terranova; Tol Eressëa es una entidad diferenciada y no recibe automáticamente la geografía, población, ganadería o recursos de Terranova. Las comunidades residentes, los contactos, la conquista y la integración deben describirse por territorio y fecha. No se proyectan instituciones escandinavas intactas sobre los asentamientos americanos.

La secuencia social se mantiene: hogares y parentescos entre 1000 y 800 a. C.; consolidación de acogida y recursos entre 800 y 300 a. C.; movilidad marítima y contactos exteriores entre 300 a. C. y 350 d. C.; fragmentación, desigualdad y recuperación entre 350 y 700; y ampliación de registros, enseñanza y reconocimiento territorial entre 700 y 1000.

### Conquista y esclavitud en África, América, el Caribe e islas atlánticas

En África, América, el Caribe y en aquellas islas atlánticas donde existieran comunidades anteriores a la llegada valinari, sí pudieron producirse procesos de conquista, subordinación, desplazamiento y esclavización. La presencia valinaria no fue uniforme: combinó comercio y alianzas con campañas militares, imposición tributaria y control de puertos, tierras, agua y rutas.

La secuencia más coherente es:

1. reconocimiento y comercio;

2. alianza con autoridades locales;

3. instalación de factorías y guarniciones;

4. competencia por puertos, agua y tierras fértiles;

5. guerra contra comunidades resistentes;

6. captura de prisioneros;

7. imposición de tributos y trabajo obligatorio;

8. desplazamiento de comunidades;

9. integración de élites colaboradoras;

10. formación de una administración colonial o pactista según el territorio.

La esclavitud pudo afectar a:

- prisioneros de guerra;

- personas capturadas durante incursiones;

- comunidades derrotadas;

- deudores;

- niños separados de sus familias;

- mujeres y hombres vendidos por intermediarios locales;

- trabajadores destinados a agricultura, minas, puertos, astilleros y servicio doméstico.

En las islas atlánticas, la regla histórica es explícita: si existía población local antes de la llegada valinari, esa población debe incluirse en el relato de conquista, negociación, desplazamiento, mestizaje, resistencia y esclavitud. No debe asumirse automáticamente que las islas estaban despobladas. Cuando el canon no determine la existencia de comunidades previas, el asunto queda abierto y no se inventa una población ni se la elimina por conveniencia narrativa.

Las islas con población previa pueden experimentar:

- pérdida de tierras agrícolas;

- control valinari de fuentes y puertos;

- tributos en alimentos y trabajo;

- toma de rehenes;

- deportaciones;

- incorporación de familias locales a las Casas;

- matrimonios políticos;

- rebeliones;

- epidemias;

- conversión religiosa o sincretismo;

- desaparición parcial de lenguas y registros;

- supervivencia de comunidades autónomas en zonas periféricas.

La esclavitud no debe presentarse como idéntica en todos los territorios. En unas regiones fue doméstica y portuaria; en otras, agrícola, minera o naval. En América y el Caribe pudo adquirir una escala mayor con la expansión de plantaciones, puertos y rutas interinsulares. En África se relacionó con rutas terrestres, comercio costero, minería, agricultura y control de corredores fluviales.

La Corona podía prohibir la tortura, el asesinato arbitrario, la violación, la explotación sexual abierta, el sacrificio humano y la captura de personas protegidas por tratados. Sin embargo, tales prohibiciones no eliminaban la esclavitud ni garantizaban su cumplimiento. Las Casas, comerciantes y guarniciones podían ocultar abusos, falsificar registros o convertir la explotación sexual y el trabajo coercitivo en prácticas privadas toleradas.

La diferencia canónica queda establecida así:

- Sicilia, Malta, Chipre, Egipto y el Levante: predominio de comercio, tratados, alianzas y cooperación, sin conquista valinaria sistemática de sus poblaciones.

- África, América y el Caribe: combinación de comercio, alianzas, conquista, tributos, desplazamiento y esclavización de poblaciones locales.

- Islas atlánticas con población previa: aplicación de la misma combinación de alianza, conquista, resistencia, desplazamiento y esclavitud, según el territorio.

- Islas sin población previa comprobada: no se inventa una sociedad local; se describe únicamente la colonización valinari documentada o propuesta.

El comercio con Roma se alimentó principalmente de capturas y mercados del Mediterráneo y África, pero no todas las personas esclavizadas fueron capturadas directamente por Valinor. Los Valinari pudieron actuar como conquistadores, intermediarios, transportistas o compradores, según la región y el periodo. Esta distinción permite explicar la relación económica con Roma sin convertir toda expansión valinaria en una campaña uniforme de exterminio o esclavización.

### Causas históricas de la conquista y la esclavitud valinari

La conquista y la esclavitud no se explican por una única causa ni por una supuesta naturaleza valinari. Su desarrollo responde a una combinación de pragmatismo político, estrategia militar, necesidad económica, competencia entre Casas, colonización, presión demográfica, religión y demanda de mercados exteriores.

##### Pragmatismo político

Las autoridades y las Casas podían considerar necesario controlar puertos, fuentes de agua, tierras agrícolas, minas, rutas fluviales, astilleros y pasos marítimos. La lógica política era que el control territorial garantizaba la seguridad de las rutas y la continuidad del Estado.

##### Estrategia militar

La toma de rehenes, el desplazamiento de familias, la división de comunidades, la instalación de guarniciones y la incorporación de jóvenes a talleres podían utilizarse para impedir nuevas rebeliones. La conquista no implicaba necesariamente exterminio: la explotación de una población sometida podía resultar más rentable que su destrucción.

##### Necesidad económica

La agricultura, la minería, la construcción naval, los caminos, las fortificaciones, los puertos y los almacenes requerían mano de obra. La venta de prisioneros, trabajadores capturados y personas adquiridas a intermediarios podía financiar expediciones, armadas, colonias y fortificaciones.

##### Competencia entre Casas

Una Casa que controlaba un puerto, una mina, una isla, una población tributaria o un mercado podía aumentar su riqueza y prestigio. Esta dinámica incentivaba guerras privadas y obligaba a la Corona a regular la captura de personas, los tributos y la propiedad de los cautivos.

##### Demografía y colonización

Las colonias con poca población valinari, elevada mortalidad, escasez de agricultores o falta de artesanos podían trasladar personas sometidas para sostener la economía. Esta política produjo desplazamientos de agricultores, trabajadores portuarios, artesanos, mujeres dedicadas a tareas domésticas y textiles y menores separados de sus familias.

##### Religión y contradicción moral

La doctrina de custodia, pacto, memoria y responsabilidad ante las generaciones futuras podía utilizarse para condenar abusos, pero también podía reinterpretarse para justificar la dominación como pacificación o tutela. La historia valinari desarrolla una tensión entre una tradición imperial, que defiende la imposición del orden, y una tradición de custodia, que afirma que ningún pueblo debe ser tratado como propiedad.

Esta contradicción genera santuarios de refugio, rescates, denuncias de comerciantes, conflictos entre sacerdotes y Casas y movimientos abolicionistas posteriores. Las prohibiciones religiosas y legales contra tortura, asesinato arbitrario, violación y explotación sexual no eliminan por sí solas la esclavitud ni garantizan su cumplimiento.

##### Diferencia entre el Mediterráneo y otros territorios

En Sicilia, Malta, Chipre, Egipto y el Levante, la existencia de ciudades organizadas, ejércitos, burocracias, religiones institucionalizadas y potencias regionales hacía más rentable la negociación que la conquista directa. En África, América, el Caribe y algunas islas atlánticas, la menor centralización política en ciertas zonas o la distancia respecto de los centros de poder podía facilitar campañas de sometimiento, desplazamiento y esclavización.

Esta diferencia no debe entenderse como una valoración de los pueblos locales, sino como una diferencia en capacidad militar, organización política, geografía y coste de la conquista.

##### Influencia de Roma

Roma no origina la esclavitud valinari, pero aumenta su rentabilidad al ofrecer un mercado enorme, crédito, transporte, seguridad portuaria, demanda agrícola y militar y reconocimiento jurídico de la esclavitud. Los Valinari pueden actuar como conquistadores, compradores, intermediarios, transportistas o certificadores según el territorio y el periodo.

El circuito económico queda resumido así:

captura o compra local → transporte valinari → certificación portuaria → venta a intermediarios → mercados romanos → reinversión en naves, tierras, puertos y fortificaciones.

La relación con Roma se fortalece materialmente, pero también produce conflictos sobre cautivos protegidos, menores, mujeres, piratería, falsificación de registros, confiscaciones y abuso de comerciantes.

##### Formulación canónica acumulativa

La conquista y la esclavitud valinari surgieron de la combinación de seguridad de rutas, competencia entre Casas, necesidad de mano de obra, colonización, extracción económica, rivalidad política y demanda de mercados mediterráneos. La religión y la ley establecieron límites y condenas parciales, pero fueron aplicadas de manera desigual. La contradicción entre la ideología de custodia y la explotación de poblaciones conquistadas se convirtió en uno de los conflictos centrales de la historia valinari.

### Sometimiento productivo, esclavitud y población local

La estrategia valinaria en territorios conquistados no buscaba normalmente exterminar a toda la población. Desde el punto de vista de una Casa, la población local representaba una reserva de trabajo, conocimiento y producción. La destrucción completa habría significado perder agricultores, pescadores, artesanos, mineros, constructores, intérpretes y administradores.

La práctica más rentable consistía en someter la población, apropiarse de una parte de sus excedentes, controlar sus tierras y utilizar trabajo obligatorio o esclavizado en sectores estratégicos. Esto podía combinarse con alianzas con élites locales, matrimonios políticos, adopción de funcionarios, tributación y reconocimiento de comunidades autónomas.

##### Grados de sometimiento

La población local podía quedar en una de varias situaciones:

1. aliada: conservaba autonomía y pagaba contribuciones negociadas;

2. tributaria: mantenía tierras y autoridades, pero entregaba grano, metales, trabajo o soldados;

3. dependiente: perdía capacidad diplomática y quedaba bajo supervisión de una Casa;

4. desplazada: era trasladada por razones militares, agrícolas o portuarias;

5. esclavizada: perdía libertad jurídica y quedaba bajo propiedad de una persona, Casa, templo o institución;

6. integrada: obtenía derechos graduales mediante servicio, matrimonio, manumisión o adopción comunitaria.

##### Edades y destino de las personas esclavizadas

No se establece que todos los niños desde los cinco años fueran vendidos ni que existiera una cuota uniforme. La práctica varía según guerra, región, Casa y mercado.

La distribución más coherente es:

- adultos prisioneros: agricultura, minería, construcción, puertos, transporte y servicio militar auxiliar;

- adolescentes: talleres, navegación auxiliar, agricultura, servicio doméstico y formación forzada en oficios;

- niños pequeños: servicio doméstico, adopción coercitiva, talleres y separación de familias; su venta aparece como práctica abusiva y especialmente controvertida;

- mujeres adultas: agricultura, textiles, almacenes, servicio doméstico, cuidado, producción alimentaria y trabajo portuario;

- mujeres y niñas: podían sufrir explotación sexual clandestina o concubinato coercitivo, aunque la ley religiosa y real lo prohibiera.

Antes de la reforma doctrinal, algunos mercados aceptan cautivos de edades muy tempranas. Después de la reforma, la venta de menores de doce años queda prohibida formalmente, aunque persisten incumplimientos en zonas fronterizas. La venta de adolescentes continúa en ciertos circuitos de trabajo hasta reformas posteriores.

##### Población utilizada para aumentar la producción

La mayoría de la población sometida no se vendía fuera del territorio. Era utilizada localmente para:

- mantener cultivos;

- ampliar terrazas y canales;

- extraer metales;

- construir caminos y fortificaciones;

- cargar y reparar barcos;

- producir alimentos;

- trabajar en talleres;

- conservar almacenes;

- servir como intérpretes y guías.

Esto explica por qué las Casas preferían conservar comunidades productivas. La esclavitud de exportación afectaba a una fracción menor pero muy visible y rentable; la extracción local de trabajo afectaba a una parte mucho mayor de la población conquistada.

##### Endogamia valinari y población esclavizada

El carácter endogámico valinari debe tratarse como una norma social, matrimonial y política de las Casas, no como una división biológica absoluta. Las Casas protegen sus genealogías, herencias y derechos de ciudadanía mediante matrimonios internos, pero eso no implica que todas las personas esclavizadas sean consideradas biológicamente inferiores.

En la práctica se forman tres categorías:

- ciudadanía de Casa: reservada a linajes reconocidos y sus ramas legítimas;

- población libre local o asociada: protegida por pactos y con derechos variables;

- población esclavizada: sin plena personalidad jurídica, aunque sujeta a límites religiosos y legales.

La manumisión permite que una persona esclavizada obtenga libertad, residencia y, después de varias generaciones, ciudadanía local o integración en una comunidad. La adopción, el servicio militar, el matrimonio reconocido y el patrocinio de un santuario pueden acelerar esa transición, pero las Casas nobles suelen impedir el acceso inmediato a sus genealogías principales.

Los hijos de uniones entre valinari y población esclavizada generan conflictos jurídicos. La solución más coherente es que el estatus no dependa exclusivamente del aspecto físico o del origen biológico, sino del reconocimiento legal, la libertad de la madre, el registro del santuario y la decisión de la comunidad. Las uniones coercitivas no producen legitimidad dinástica.

La endogamia ralentiza la integración de la población local, pero no la hace imposible. Con el tiempo produce comunidades mixtas, ramas libres, familias de servicio, Casas menores y linajes urbanos que conservan rasgos culturales locales junto con lengua, religión o educación valinari.

### Modelo demográfico valinari 1000 aC 800 dC

La población se calcula mediante un modelo territorial por cohortes: población final = población inicial + nacimientos + inmigración + reclasificación − defunciones − emigración − desplazamientos netos. La reclasificación jurídica se mantiene separada del crecimiento natural.

La inmigración acumulada se fija en 2.072.000 llegadas brutas: 1.295.000 nórdicas y 777.000 no nórdicas. La corriente no nórdica equivale al 60 % de la nórdica, no al 60 % de la población total. La versión anterior del 30 % queda como antecedente histórico. La migración nórdica procede principalmente de Dinamarca, Escania y Noruega, con aportes posteriores limitados de Finlandia. La corriente no nórdica procede sobre todo de Europa germánica continental y Europa oriental y se incorpora principalmente a puertos, talleres, agricultura, navegación y comunidades mixtas.

El censo distingue población valinari de linaje, migración reciente, población local superviviente, población mixta y portuaria, población territorial, personas esclavizadas o dependientes, personas liberadas, extranjeros residentes y contingentes temporales. Estas categorías pueden ser jurídicas, económicas o administrativas, no únicamente étnicas.

La fecundidad media permanece alrededor de tres hijos por mujer, pero la supervivencia efectiva se sitúa entre 2,2 y 2,8 hijos supervivientes por mujer debido a mortalidad infantil, mortalidad materna, viudez, enfermedades, guerras, hambrunas y ausencia de tripulaciones.

La esperanza de vida en zonas centrales y bien administradas alcanza aproximadamente 32–42 años entre 1000–500 a. C., 35–45 entre 500–50 a. C., 37–49 entre 50 a. C.–500 d. C. y 42–55 entre 500–800 d. C. Las estaciones oceánicas, fronteras, enclaves mineros y territorios recién incorporados mantienen medias inferiores, de aproximadamente 28–44 años según el periodo. Las cifras corresponden a esperanza de vida al nacer.

Hospitales y santuarios reducen la mortalidad mediante aislamiento, baños, herbolaria, atención obstétrica básica, cuidado de heridas, alimentación de enfermos y conservación de registros. No son hospitales modernos ni eliminan epidemias. Se mantiene como referencia una epidemia importante cada 100–150 años y crisis alimentarias locales cada 30–60 años, con reducciones regionales aproximadas del 3–12 %.

La categoría de población local desaparece aproximadamente cien años después del descubrimiento o incorporación de cada territorio como categoría censal separada, no como afirmación de desaparición física total. Los supervivientes y sus descendientes pueden ser registrados como población mixta, portuaria, territorial, liberada o dependiente.

La población mixta y portuaria incluye descendientes de población local y migrante, migración continental, comerciantes asentados, familias bilingües, trabajadores liberados, tripulaciones asentadas y comunidades urbanas. Su proporción orientativa es de 15–25 % en territorios rurales, 25–40 % en puertos activos y hasta 40–50 % en capitales y nodos comerciales.

La población máxima sostenible depende de superficie cultivable, cereales, legumbres, ganadería, pesca, irrigación, terrazas, agrosilvicultura, graneros, transporte marítimo, importaciones y seguridad de las rutas. La capacidad institucional —censos, archivos, registros, cuarentenas, caminos, tribunales, graneros y redistribución— permite un crecimiento más estable sin eliminar guerras ni epidemias.

Para 800 d. C., aproximadamente 55–60 % de la población vive en territorios centrales, 20–25 % en provincias agrícolas recientes, 10–15 % en ciudades y puertos y 5–10 % en estaciones, fronteras y enclaves.

| Fecha | Población central recomendada | Rango plausible |
| --- | --- | --- |
| 1000 a. C. | 180.000 | 160.000–200.000 |
| 500 a. C. | 480.000 | 430.000–520.000 |
| 50 d. C. | 1.800.000 | 1.600.000–1.950.000 |
| 500 d. C. | 5.200.000 | 4.800.000–5.600.000 |
| 800 d. C. | 8.000.000 | 7.600.000–8.150.000 |

La cifra canónica central para 800 d. C. es aproximadamente 8 millones de habitantes. Los 8,15 millones quedan como escenario técnico alto cuando se incluyen puertos asociados, estaciones, población dependiente y comunidades recientemente reclasificadas.

Sobre la cifra central de 8 millones en 800 d. C., la composición de referencia es: 55 % de linaje valinari y ciudadanía de Casa, aproximadamente 4.400.000 personas; 40 % de población mixta, portuaria y territorial, aproximadamente 3.200.000; y 5 % de población esclavizada o dependiente, aproximadamente 400.000. La composición es una estructura censal de referencia, no una clasificación biológica uniforme.

La escala es coherente porque combina migración sostenida, crecimiento natural moderado, supervivencia infantil mejorada, agricultura mixta, navegación, graneros, cuarentenas, archivos, urbanización, integración territorial y recuperación posterior a crisis. El crecimiento no es lineal: se expande, se contrae regionalmente y se recupera según la capacidad agrícola, sanitaria, militar y administrativa.

### Epidemias trabajo y reconstrucción territorial

#### Contacto y vulnerabilidad

La expansión conecta comunidades con experiencias epidemiológicas distintas. Las pérdidas dependen de enfermedad, nutrición, desplazamientos, condiciones de alojamiento, trabajo y acceso a cuidados. La religión puede interpretar la crisis y organizar auxilio, pero una explicación de los creyentes no constituye la causa biológica certificada por la narración.

Las regiones americanas e insulares conservan sus cronologías de contacto e incorporación según V16. La crisis americana de los siglos XIII–XV descrita en v050 puede desarrollarse como una fase regional posterior, sin convertirse en la primera llegada de los Valinari a América ni en una epidemia simultánea en todos los territorios.

#### Población y categorías

Los expedientes distinguen muertes, desplazamiento, pérdida de hogares, esclavización, dependencia, liberación y reclasificación. El descenso de una categoría local no demuestra por sí solo que todos sus integrantes hayan muerto. Los supervivientes y sus descendientes continúan dentro de otras categorías del censo. Cada territorio necesita su propia fecha de contacto y su serie de población.

La explotación coercitiva agrava riesgos cuando rompe abastecimiento, sobrecarga trabajo o separa familias. Las prohibiciones formales de tortura, asesinato o saqueo no garantizan cumplimiento. Los archivos conservan denuncias, decisiones y responsabilidades cuando existen, y la narrativa distingue norma, práctica y reforma. La integración no fija una fecha general de abolición todavía ausente del canon.

#### Respuestas y límites sanitarios

Las respuestas incluyen agua más limpia, saneamiento, separación de enfermos, alimentación, descanso, observación y registro. Su aplicación es desigual y puede reducir daños antes de que exista una explicación médica completa. El canon conserva sus fechas tecnológicas sin convertir los santuarios antiguos en hospitales contemporáneos.

La reconstrucción repone semillas, herramientas y ganado, reabre rutas, forma personal y restablece viviendas. La conservación del conocimiento en los archivos principales permite recuperar instrucciones, pero no reemplaza a un maestro, una cosecha o una familia perdida. Ese límite material vincula salud, educación y fomento territorial.

#### Responsabilidad y memoria

Los registros permiten seguir salarios, accidentes, personas a cargo y reclamaciones. En las etapas modernas se fortalecen inspección, asociaciones de trabajadores y procedimientos públicos. Sus garantías se desarrollan con el sistema político de cada siglo, sin atribuir igualdad constitucional completa a las comunidades antiguas.

La memoria de las crisis reúne testimonios de familias locales, migrantes, personas dependientes y autoridades. La historiografía puede conservar interpretaciones distintas y aun así identificar qué decisiones empeoraron abastecimiento, exposición o coerción. Esa documentación conecta la Crisis de la Custodia y las reformas religiosas con cambios jurídicos posteriores, evitando dar por resuelta toda desigualdad mediante un solo pacto.

Desarrollo: 13_Sociedad/Epidemias trabajo y reconstrucción territorial.

### Industrialización ciudadanía y Estado social

#### Trabajo y urbanización

La mecanización y la expansión del crédito concentran población en puertos, astilleros, minas y ciudades. La producción depende cada vez más de horarios coordinados, vivienda, agua, transporte y mantenimiento. El salario monetario amplía mercados y expone a las familias a suspensiones de trabajo y variaciones de precios. La educación técnica eleva capacidades cuando los hogares pueden sostener los años de aprendizaje.

Las Casas comerciales e industriales participan como propietarias, financiadoras, fundaciones y redes profesionales según su transformación ya adoptada. Su función económica no da a una familia atribución automática para juzgar a sus trabajadores. Las reformas laborales, los contratos y la inspección limitan progresivamente la dependencia personal, con aplicación distinta entre regiones.

#### Crisis y garantías

Las crisis financieras afectan producción y empleo a través de crédito, pedidos y pagos. Las autoridades distinguen ayuda a hogares, liquidez de empresas y reconocimiento de pérdidas patrimoniales. Un fondo de emergencia requiere reglas de acceso y financiación, además de la voluntad política de intervenir. Esta continuidad enlaza la crisis de Armenelos con debates posteriores sin atribuir a todos los siglos el mismo sistema bancario.

La historia de guerras y emergencias se desarrolla según la posición diplomática vigente de Valinor. Los materiales v050 sobre requisas, censura, detenciones, objeción y acceso a expedientes aportan problemas institucionales, pero no aprueban por sí solos nuevas campañas, alianzas o estados de beligerancia. La revisión de poderes extraordinarios examina duración, control, reclamaciones y reparación.

#### Reforma federal y bienestar

La reforma de 1958 reorganiza autoridades y obligaciones existentes. La portabilidad permite que trabajo, formación y residencia en territorios distintos no obliguen a reconstruir cada derecho desde cero. Educación, salud, vivienda, transporte y protección del ingreso requieren cooperación entre gobiernos territoriales y órganos comunes, con financiación identificada.

El sistema de fomento conecta inversión industrial con servicios que la sostienen. Un astillero necesita escuelas, viviendas, agua y atención sanitaria para mantener su plantilla; una región remota requiere transporte de personas y mercancías para que una beca o un hospital sean accesibles. Las decisiones se evalúan también por capacidad de mantenimiento y distribución territorial de sus beneficios.

#### Continuidad contemporánea

Las crisis financieras, ambientales y sanitarias recientes se integran como experiencias de coordinación, límites de acceso y recuperación. Los nuevos tratados, leyes, nombres de organismos o cifras de impacto que solo aparezcan en v050 permanecen sujetos a revisión particular. Se adopta la relación causal entre instituciones, trabajo y bienestar, preservando los agregados económicos y territoriales ya fijados por V16.

Desarrollo: 08_Historia/Industrialización ciudadanía y Estado social.

## Economía, agricultura y cuentas territoriales

### Población y economía federal

##### Educación valinari en 1492

En 1492 Valinor dispone de una red educativa desarrollada, pero todavía premoderna y desigual. La educación depende de la Corona, las Casas, los santuarios, las ciudades portuarias, los gremios, las universidades y las comunidades religiosas. No existe aún educación universal, gratuita y obligatoria.

La enseñanza elemental comprende lectura, escritura, aritmética, calendario, historia de los pactos, ética, higiene, agricultura, navegación básica y normas comerciales. Los gremios y talleres forman herreros, constructores navales, impresores, cartógrafos, médicos, escribas, comerciantes, contables, ingenieros hidráulicos y traductores. Las academias especializadas se concentran en navegación, astronomía, cartografía, medicina, derecho, diplomacia, ingeniería naval, agricultura, lenguas y administración.

Las universidades enseñan derecho civil y marítimo, medicina, filosofía, matemáticas, astronomía, ingeniería, teología, historia, lenguas, administración y comercio internacional. Su gestión puede corresponder a ciudades, Casas, órdenes religiosas o corporaciones académicas, sin dependencia uniforme de la Corona.

El acceso es mayor entre nobles, clérigos, comerciantes, funcionarios, marinos, artesanos especializados y familias urbanas. Las mujeres acceden especialmente a medicina, administración patrimonial, comercio, traducción, archivos, enseñanza, astronomía y diplomacia, aunque la continuidad educativa depende de la región, la familia y la institución. Las zonas rurales y periféricas presentan menor cobertura.

La imprenta está en expansión y produce manuales náuticos, calendarios, libros religiosos, tratados médicos, mapas, textos legales, libros de cuentas y materiales escolares. Las redes documentales preparan la posterior Secretaría Común de 1512, pero todavía no existe una normalización completa.

La educación se financia mediante rentas de la Corona, impuestos urbanos, contribuciones de las Casas, cuotas gremiales, donaciones religiosas, ingresos portuarios, fundaciones familiares y pagos directos. Las becas reales ya existen como antecedente de las futuras Becas Reales de Educación, pero todavía no constituyen un sistema federal unificado.

La alfabetización general de 1492 se sitúa aproximadamente entre 50 % y 65 %, con diferencias territoriales, sociales y de género. Esta cifra es una estimación de plausibilidad, no una matriz demográfica definitiva.

La educación de 1492 permite sostener rutas marítimas, administración territorial, archivos, navegación, cartografía, integración lingüística y transmisión técnica, pero no debe confundirse con el sistema público federal moderno. La universalización, gratuidad y obligatoriedad se desarrollan progresivamente entre los siglos XIX y XX.

##### Financiación educativa vigente

En 2026 la inversión pública educativa equivale al 6 % del PIB federal. Sobre un PIB PPA federal de 65,5 billones, el gasto educativo total es de 3,93 billones PPA: 75 % estatal federal (2,9475 billones), 24 % territorial (0,9432 billones) y 1 % de la Corona (0,0393 billones, aproximadamente 39.300 millones PPA).

El aporte de la Corona corresponde a las Becas Reales de Educación, junto con programas patrimoniales, científicos y culturales. El Fondo Federal de Becas atiende acceso, permanencia, transporte, residencia, alimentación, formación técnica, investigación, posgrado y regiones vulnerables. La Autoridad Federal de Becas administra el fondo con criterios públicos y auditoría; la representación de la Corona no posee mayoría de voto. Las Casas pueden mantener fundaciones, pero no sustituir la educación pública ni condicionar becas por linaje.

Con Arnor y Calenardhon Austral integrados, la Unión Valinoreana alcanza aproximadamente:

- Población 2026: 523,5 millones.

- PIB PPA: 65,50 billones de dólares en la conciliación territorial central (redondeado a 66). El rango 60,85–70,20 billones se conserva como intervalo macroeconómico de planificación, no como resultado de sumar cuentas territoriales.

- PIB nominal estimado: 45–52 billones; valor central: aproximadamente 48,5 billones.

- Urbanización federal canónica ECON-03: 89,6 %. La cifra de aproximadamente 80 % queda como estimación preliminar no operativa.

La economía combina industria pesada, agricultura templada y tropical, minería, energía, construcción naval, finanzas, biotecnología, inteligencia artificial, OceanNet y transporte intercontinental.

### Actualización económica por industria militar y exportaciones estratégicas

Estado: [CANON VIGENTE, actualizado al 31 de octubre de 2026]. Las magnitudes de exportación y participación industrial de esta sección se revisan conforme al cierre ECON-03.

La industria militar, aeroespacial y electrónica forma parte de la producción federal. El valor añadido de buques, aeronaves, motores, turbinas, procesadores, circuitos, mantenimiento y licencias se contabiliza una sola vez; su impacto está incluido en los agregados de PIB revisados.

##### Indicadores macroeconómicos revisados

| Entidad | Población | PIB PPA | PIB nominal estimado |
| --- | --- | --- | --- |
| Aranath Valinor (Reino) | 481 millones | 55–62 billones | 42–48 billones |
| Agregado operativo ECON-03 | 523,5 millones | 60,85–70,20 billones | 45–52 billones |

Se fija como centro de referencia 58,5 billones PPA para el Reino y 65,50 billones PPA para la Federación. El centro nominal federal es aproximadamente 48,5 billones. Son valores de planificación del mundo ficticio, no conversiones directas entre PPA y PIB nominal.

El rango anterior de 67–81 billones PPA (centro 74) queda sustituido. La conciliación territorial ECON-03 fija como referencia central 58,50 billones para el Reino más 7,00 billones para las unidades federales externas: 65,50 billones PPA para la Federación, redondeados a 66. Las cuentas territoriales actualizadas incorporan Islandia y Groenlandia; las matrices preliminares conservan valor histórico solo cuando no contradicen esta sección. Son estimaciones canónicas del mundo ficticio, no estadísticas observadas; sus supuestos contables y límites de precisión permanecen explícitos.

El rango 60,85–70,20 billones expresa incertidumbre macroeconómica de planificación; el punto de conciliación territorial central es 65,50. Las exportaciones se registran como ventas brutas y no se suman de nuevo al PIB, que mide valor añadido.

##### Industria militar y aeroespacial

La industria militar, aeroespacial y electrónica es una actividad estratégica incluida en las cuentas sectoriales ECON-03, sin sumar su producción por segunda vez. Las cifras anteriores de aproximadamente 12 % del PIB y 5–8 billones PPA de exportaciones se conservan como estimaciones históricas de planificación, no como magnitudes validadas por las cuentas territoriales vigentes. Las exportaciones estratégicas comprenden:

- destructores, fragatas y corbetas;

- portaeronaves y buques logísticos;

- helicópteros y aviones de transporte;

- aeronaves de patrulla y combate;

- drones aéreos, navales y terrestres;

- motores, turbinas y generadores;

- procesadores, circuitos, radares y sensores;

- mantenimiento, formación, licencias y modernización de flotas.

##### Distribución sectorial federal revisada

La antigua distribución porcentual macroeconómica queda sustituida por las matrices territoriales A–J de los apartados de Venezuela, Orinoco y Caribe y del cierre ECON-03. No se fuerza un porcentaje federal único para actividades que atraviesan varios sectores: defensa, electrónica, astilleros y agroindustria se clasifican según la actividad productiva efectivamente realizada. Cada valor añadido se registra una sola vez.

##### Especialización territorial

- Valinor: diseño, investigación, inteligencia artificial, criptografía y sistemas estratégicos.

- Arnor: motores, aviación, procesadores, blindados y electrónica industrial.

- Calenardhon Austral: astilleros, turbinas, buques pesados y generadores.

- Malaca: producción masiva, drones, microelectrónica y robótica.

- Hawái: satélites, aviación y vigilancia oceánica.

- Harnen: motores navales, energía, puertos y mantenimiento.

- Eryndor: banca, seguros, financiación y servicios de exportación militar.

La doctrina económica queda resumida así: la Federación diseña, produce, exporta y mantiene sistemas completos, mientras Gran Valinor coordina bases, reparación y cadenas de suministro.

### ECON-03: cálculo del valor añadido por sector y territorio

Estado: [MARCO Y PRIMERAS MATRICES — cifras iniciales conservadas como antecedentes; las matrices vigentes y la conciliación actual constan en los apartados de Venezuela, Orinoco y Caribe y del cierre ECON-03] — 31 de octubre de 2026.

##### Unidad de cálculo

ECON-03 construye una matriz para el año de referencia 2026. Cada fila es un territorio económico sin solapamientos y cada columna un sector productor. El VAB sectorial equivale a producción a precios básicos menos consumo intermedio. El PIB territorial equivale a la suma del VAB más los impuestos sobre los productos menos las subvenciones sobre los productos, registrados en una línea separada.

Se atribuye la producción al lugar donde se presta el servicio o se realiza la actividad. PPA 2026 y PIB nominal se mantienen en series separadas. Cuando falten datos directos, se permiten estimaciones modeladas siempre que sus participaciones, supuestos fiscales, límites y confianza queden declarados; no se describen como observaciones ni como cuentas completas de producción.

##### Clasificación común y límites de cada sector

Cada actividad se asigna una sola vez según la actividad productora. La tabla delimita los casos que podían mezclarse en los perfiles anteriores.

| Código | Sector | Se incluye | Se excluye o se asigna a |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | Cultivo, ganadería, pesca, acuicultura y explotación forestal primaria | Alimentos procesados: C |
| B | Minería y energía | Extracción minera y de hidrocarburos; generación y transmisión eléctrica; suministro de gas y agua | Refinación y procesamiento industrial: C |
| C | Manufactura y reparación | Alimentos procesados, refinación, química, metales, electrónica, maquinaria, vehículos, buques y aeronaves; reparación de equipos y producción militar | Construcción civil de obras e infraestructura: D; administración de defensa: J |
| D | Construcción e infraestructura | Edificación, obras civiles, construcción o ampliación de canales, puertos, caminos, redes y plantas | Operación del canal, puertos y transporte: F; reparación de equipos: C |
| E | Comercio, alojamiento y servicios personales | Comercio mayorista y minorista, hoteles, restaurantes, turismo y recreación | Transporte, almacenamiento y manipulación de carga: F |
| F | Transporte y logística | Transporte de pasajeros y carga, almacenamiento, manipulación portuaria, operación y servicios del canal | Valor de la carga transportada o en tránsito; construcción de infraestructura: D |
| G | Finanzas, seguros y servicios empresariales | Comisiones y servicios bancarios, seguros, asesoría legal, contable, administrativa y profesional | Depósitos, préstamos y activos financieros como montos; software y telecomunicaciones: H |
| H | Información, telecomunicaciones, software e I+D | Telecomunicaciones, centros de datos, software, investigación, ingeniería tecnológica y licencias producidas localmente | Consultoría no tecnológica: G; ingresos por licencias producidas en otro territorio |
| I | Servicios inmobiliarios | Alquileres efectivos e imputados y servicios de intermediación inmobiliaria | Venta de terrenos, plusvalías y revalorización de activos |
| J | Administración y servicios sociales | Gobierno, educación, salud, seguridad, cultura y otros servicios colectivos | Bienes militares fabricados: C; construcción de edificios públicos: D |

La industria militar, aeroespacial y electrónica se etiqueta como subsector transversal y se cuenta dentro de C o H según la actividad productora. Nunca se suma de nuevo como una columna aparte. La operación del canal y la construcción del canal quedan separadas en F y D.

##### Reglas contra doble conteo

- El Reino se calcula sumando sus territorios constituyentes. La Federación se calcula sumando el Reino completo y las unidades federales externas. Nosselië Toliva se cuenta dentro del Reino y solo por esa vía dentro de la Federación.

- Las ventas brutas, exportaciones, valor de carga en tránsito, depósitos bancarios, capitalización de activos y valor nominal de préstamos no son VAB. Se incluyen únicamente los márgenes y servicios producidos localmente.

- Los bienes intermedios se descuentan como consumo intermedio; la producción de cada etapa se cuenta como valor añadido de esa etapa. Las importaciones no son producción doméstica.

- La construcción o ampliación del canal y los puertos se registra en D; su operación, tránsito y logística en F. La infraestructura no se vuelve a sumar por su valor de reposición.

- Los impuestos netos sobre productos se registran en una línea de ajuste separada. No se reparten arbitrariamente entre sectores ni territorios.

##### Formato de entrega y confianza

Cada territorio tendrá columnas A–J, subtotal VAB, ajuste de impuestos netos sobre productos, PIB PPA, población, PIB por habitante, método y confianza. La conciliación sumará primero territorios del Reino y luego Reino más unidades federales externas. Las matrices iniciales de Colombia Costera, Panamá Federal, Arnor, Calenardhon Austral y Sírënandë se conservan como primera pasada. los apartados de Venezuela, Orinoco y Caribe y del cierre ECON-03 fijan cuentas territoriales propias para las 21 unidades; las tablas de esta sección son antecedentes de la primera ronda.

### ECON-03 integrado: territorios, población, PIB y cuentas modeladas

Las cuentas territoriales vigentes son las de Venezuela, Orinoco y Caribe y el cierre ECON-03 de las unidades restantes. Producción bruta menos consumo intermedio equivale a VAB; VAB más impuestos netos equivale a PIB. Los cuadros iniciales quedan como antecedentes editoriales en el respaldo.

### Actualización canónica de Venezuela, Orinoco y Caribe

Estado: [CANON VIGENTE — jurisdicciones, población, urbanización y cuentas territoriales fijadas por decisión del autor] — 31 de octubre de 2026. Esta sección reemplaza las propuestas y cuentas genéricas de las secciones 34.1, 34.4 y 34.5 para Venezuela Federal, Provincia del Orinoco, Trinidad, Tobago, Bahamas, Bermudas y Barbados. Las cuentas aquí fijadas son cifras del mundo ficticio, construidas como cuentas territoriales propias; no son estadísticas de los países reales equivalentes.

##### Límites territoriales aprobados

Venezuela Federal comprende Distrito Capital y los estados Aragua, Barinas, Carabobo, Cojedes, Falcón, Lara, Mérida, Miranda, Nueva Esparta, Portuguesa, Sucre, Táchira, Trujillo, Yaracuy, Zulia y La Guaira. Provincia del Orinoco comprende Amazonas, Bolívar, Delta Amacuro, Anzoátegui, Monagas, Guárico y Apure en Venezuela; y Arauca, Casanare, Meta, Vichada, Guaviare, Guainía, Vaupés, Amazonas, Caquetá y Putumayo en Colombia. Los límites son los de las unidades administrativas completas; no se superponen con Colombia Costera.

Trinidad, Tobago, Bahamas, Bermudas y Barbados se contabilizan por sus territorios insulares terrestres; las zonas marítimas y aguas jurisdiccionales no se agregan como suelo o población.

##### Población y distribución urbana-rural fijadas

| Jurisdicción | Población 2026 | Población urbana | Población rural/dispersa | Urbanización |
| --- | --- | --- | --- | --- |
| Venezuela Federal | 50,00 M | 46,00 M | 4,00 M | 92,0 % |
| Provincia del Orinoco | 15,00 M | 11,50 M | 3,50 M | 76,7 % |
| Trinidad | 8,00 M | 7,20 M | 0,80 M | 90,0 % |
| Tobago | 1,00 M | 0,75 M | 0,25 M | 75,0 % |
| Bahamas | 6,00 M | 5,40 M | 0,60 M | 90,0 % |
| Bermudas | 2,00 M | 1,90 M | 0,10 M | 95,0 % |
| Barbados | 5,00 M | 4,50 M | 0,50 M | 90,0 % |
| Total | 87,00 M | 77,25 M | 9,75 M | 88,8 % |

| Sector de la Provincia del Orinoco | Población | Urbana | Rural/dispersa |
| --- | --- | --- | --- |
| Estados venezolanos | 10,00 M | 8,00 M | 2,00 M |
| Departamentos colombianos | 5,00 M | 3,50 M | 1,50 M |
| Total Orinoco | 15,00 M | 11,50 M | 3,50 M |

La distribución urbana se fija en núcleos funcionales y no implica que cada municipio real conserve su población actual. Las cifras de ciudades y otros centros se consideran población urbana; el remanente rural agrupa asentamientos menores, áreas agrícolas, forestales y comunidades dispersas.

| Jurisdicción | Núcleo urbano o área | Población |
| --- | --- | --- |
| Venezuela Federal | Tirion Federal (Caracas) | 12,00 M |
| Venezuela Federal | Mithlond Occidental (Maracaibo) | 6,00 M |
| Venezuela Federal | Ost-in-Edhil (Valencia) | 5,50 M |
| Venezuela Federal | Fornost Venezolana (Barquisimeto) | 4,50 M |
| Venezuela Federal | Caras Galadhon Norte (Maracay) | 3,40 M |
| Venezuela Federal | Minas Ithil Federal (San Cristóbal) | 2,20 M |
| Venezuela Federal | Minas Anor Andina (Mérida) | 1,60 M |
| Venezuela Federal | Harlond (Punto Fijo) | 1,50 M |
| Venezuela Federal | Coro Federal (Coro) | 1,20 M |
| Venezuela Federal | Alqualondë Federal (Porlamar–La Asunción) | 1,20 M |
| Venezuela Federal | Calenost Occidental (San Felipe–Acarigua) | 1,50 M |
| Venezuela Federal | Otros centros urbanos | 5,40 M |
| Venezuela Federal | Población rural y dispersa | 4,00 M |
| Provincia del Orinoco | Puerto Ordaz–Ciudad Guayana | 2,50 M |
| Provincia del Orinoco | Ciudad Bolívar | 1,40 M |
| Provincia del Orinoco | Maturín | 1,30 M |
| Provincia del Orinoco | Barcelona–Puerto La Cruz | 1,10 M |
| Provincia del Orinoco | San Fernando de Apure | 1,00 M |
| Provincia del Orinoco | Tucupita | 0,30 M |
| Provincia del Orinoco | Otros centros venezolanos | 0,40 M |
| Provincia del Orinoco | Villavicencio | 1,55 M |
| Provincia del Orinoco | Florencia | 0,42 M |
| Provincia del Orinoco | Yopal | 0,42 M |
| Provincia del Orinoco | Arauca | 0,22 M |
| Provincia del Orinoco | San José del Guaviare | 0,20 M |
| Provincia del Orinoco | Leticia | 0,16 M |
| Provincia del Orinoco | Mocoa | 0,14 M |
| Provincia del Orinoco | Inírida | 0,10 M |
| Provincia del Orinoco | Mitú | 0,07 M |
| Provincia del Orinoco | Puerto Carreño | 0,08 M |
| Provincia del Orinoco | Otros centros colombianos | 0,14 M |
| Provincia del Orinoco | Población rural y dispersa | 3,50 M |
| Trinidad | Puerto España–Chaguanas | 4,20 M |
| Trinidad | San Fernando | 1,40 M |
| Trinidad | Arima | 0,55 M |
| Trinidad | Point Fortin | 0,25 M |
| Trinidad | Otros centros urbanos | 0,80 M |
| Trinidad | Población rural y dispersa | 0,80 M |
| Tobago | Scarborough | 0,38 M |
| Tobago | Crown Point | 0,15 M |
| Tobago | Roxborough | 0,10 M |
| Tobago | Otros centros urbanos | 0,12 M |
| Tobago | Población rural y dispersa | 0,25 M |
| Bahamas | Nassau–New Providence | 4,20 M |
| Bahamas | Freeport–Grand Bahama | 0,65 M |
| Bahamas | Marsh Harbour | 0,15 M |
| Bahamas | George Town | 0,10 M |
| Bahamas | Otros centros urbanos | 0,30 M |
| Bahamas | Población rural y dispersa | 0,60 M |
| Bermudas | Hamilton | 0,95 M |
| Bermudas | St. George | 0,25 M |
| Bermudas | Royal Naval Dockyard | 0,25 M |
| Bermudas | Somerset | 0,20 M |
| Bermudas | Otros centros urbanos | 0,25 M |
| Bermudas | Población rural y dispersa | 0,10 M |
| Barbados | Bridgetown–Greater Bridgetown | 1,60 M |
| Barbados | Speightstown | 0,55 M |
| Barbados | Oistins | 0,45 M |
| Barbados | Holetown | 0,40 M |
| Barbados | Warrens | 0,65 M |
| Barbados | Otros centros urbanos | 0,85 M |
| Barbados | Población rural y dispersa | 0,50 M |

Venezuela Federal 50 millones, Orinoco 15 y las cinco cuentas caribeñas 22 suman 87. El Reino mantiene 481 millones. Las externas federales son 34,5 y las externas operativas 42,5 al incluir Harnen. Los totales constitucional y operativo son 515,5 y 523,5 millones. A092-R03.

##### Cuentas propias de producción e insumos

Para estas siete jurisdicciones se retiran las tasas fiscales genéricas y los coeficientes técnicos compartidos. Cada cuenta sectorial fija producción a precios básicos e insumos intermedios propios del territorio; VAB = producción − consumo intermedio. El ajuste al PIB se presenta aparte como impuestos sobre productos menos subvenciones. Importaciones, ventas brutas y carga en tránsito no se cuentan como producción local. Las cantidades se expresan en billones PPA 2026.

| Jurisdicción | PIB objetivo | Impuestos sobre productos | Subvenciones sobre productos | Impuestos netos | VAB total | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Venezuela Federal | 4,50 | 0,25000 | 0,03400 | 0,21600 | 4,28400 | 7,80535 | 3,52135 |
| Provincia del Orinoco | 2,20 | 0,11000 | 0,03960 | 0,07040 | 2,12960 | 4,02206 | 1,89246 |
| Trinidad | 1,20 | 0,08200 | 0,02800 | 0,05400 | 1,14600 | 2,05231 | 0,90631 |
| Tobago | 0,10 | 0,00800 | 0,00250 | 0,00550 | 0,09450 | 0,15858 | 0,06408 |
| Bahamas | 0,80 | 0,07500 | 0,02300 | 0,05200 | 0,74800 | 1,19785 | 0,44985 |
| Bermudas | 0,40 | 0,02800 | 0,00800 | 0,02000 | 0,38000 | 0,55659 | 0,17659 |
| Barbados | 0,50 | 0,04400 | 0,01500 | 0,02900 | 0,47100 | 0,76192 | 0,29092 |

| Jurisdicción | Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- | --- |
| Venezuela Federal | A | Agricultura, silvicultura y pesca | 0,50400 | 0,16128 | 0,34272 |
| Venezuela Federal | B | Minería y energía | 1,10793 | 0,46533 | 0,64260 |
| Venezuela Federal | C | Manufactura y reparación | 2,63631 | 1,60815 | 1,02816 |
| Venezuela Federal | D | Construcción e infraestructura | 0,56581 | 0,26593 | 0,29988 |
| Venezuela Federal | E | Comercio, alojamiento y servicios personales | 0,64260 | 0,25704 | 0,38556 |
| Venezuela Federal | F | Transporte y logística | 0,63467 | 0,29195 | 0,34272 |
| Venezuela Federal | G | Finanzas, seguros y servicios empresariales | 0,62832 | 0,15708 | 0,47124 |
| Venezuela Federal | H | Información, telecomunicaciones, software e I+D | 0,52726 | 0,18454 | 0,34272 |
| Venezuela Federal | I | Servicios inmobiliarios | 0,18360 | 0,05508 | 0,12852 |
| Venezuela Federal | J | Administración y servicios sociales | 0,37485 | 0,07497 | 0,29988 |
| Provincia del Orinoco | A | Agricultura, silvicultura y pesca | 0,34348 | 0,13052 | 0,21296 |
| Provincia del Orinoco | B | Minería y energía | 1,06480 | 0,51110 | 0,55370 |
| Provincia del Orinoco | C | Manufactura y reparación | 1,17128 | 0,70277 | 0,46851 |
| Provincia del Orinoco | D | Construcción e infraestructura | 0,27104 | 0,12197 | 0,14907 |
| Provincia del Orinoco | E | Comercio, alojamiento y servicios personales | 0,17174 | 0,06526 | 0,10648 |
| Provincia del Orinoco | F | Transporte y logística | 0,33405 | 0,16369 | 0,17036 |
| Provincia del Orinoco | G | Finanzas, seguros y servicios empresariales | 0,15211 | 0,04563 | 0,10648 |
| Provincia del Orinoco | H | Información, telecomunicaciones, software e I+D | 0,20609 | 0,07831 | 0,12778 |
| Provincia del Orinoco | I | Servicios inmobiliarios | 0,06173 | 0,01914 | 0,04259 |
| Provincia del Orinoco | J | Administración y servicios sociales | 0,24572 | 0,05405 | 0,19167 |
| Trinidad | A | Agricultura, silvicultura y pesca | 0,08426 | 0,02696 | 0,05730 |
| Trinidad | B | Minería y energía | 0,34380 | 0,17190 | 0,17190 |
| Trinidad | C | Manufactura y reparación | 0,54571 | 0,31651 | 0,22920 |
| Trinidad | D | Construcción e infraestructura | 0,11019 | 0,05289 | 0,05730 |
| Trinidad | E | Comercio, alojamiento y servicios personales | 0,15280 | 0,06112 | 0,09168 |
| Trinidad | F | Transporte y logística | 0,29638 | 0,12448 | 0,17190 |
| Trinidad | G | Finanzas, seguros y servicios empresariales | 0,19100 | 0,05348 | 0,13752 |
| Trinidad | H | Información, telecomunicaciones, software e I+D | 0,14105 | 0,04937 | 0,09168 |
| Trinidad | I | Servicios inmobiliarios | 0,08426 | 0,02696 | 0,05730 |
| Trinidad | J | Administración y servicios sociales | 0,10285 | 0,02263 | 0,08022 |
| Tobago | A | Agricultura, silvicultura y pesca | 0,01620 | 0,00486 | 0,01134 |
| Tobago | B | Minería y energía | 0,01303 | 0,00547 | 0,00756 |
| Tobago | C | Manufactura y reparación | 0,02700 | 0,01566 | 0,01134 |
| Tobago | D | Construcción e infraestructura | 0,01031 | 0,00464 | 0,00567 |
| Tobago | E | Comercio, alojamiento y servicios personales | 0,02835 | 0,01134 | 0,01701 |
| Tobago | F | Transporte y logística | 0,02062 | 0,00928 | 0,01134 |
| Tobago | G | Finanzas, seguros y servicios empresariales | 0,01080 | 0,00324 | 0,00756 |
| Tobago | H | Información, telecomunicaciones, software e I+D | 0,01145 | 0,00389 | 0,00756 |
| Tobago | I | Servicios inmobiliarios | 0,01112 | 0,00356 | 0,00756 |
| Tobago | J | Administración y servicios sociales | 0,00969 | 0,00213 | 0,00756 |
| Bahamas | A | Agricultura, silvicultura y pesca | 0,03300 | 0,01056 | 0,02244 |
| Bahamas | B | Minería y energía | 0,02720 | 0,01224 | 0,01496 |
| Bahamas | C | Manufactura y reparación | 0,14248 | 0,08264 | 0,05984 |
| Bahamas | D | Construcción e infraestructura | 0,08160 | 0,03672 | 0,04488 |
| Bahamas | E | Comercio, alojamiento y servicios personales | 0,24129 | 0,09169 | 0,14960 |
| Bahamas | F | Transporte y logística | 0,24933 | 0,09973 | 0,14960 |
| Bahamas | G | Finanzas, seguros y servicios empresariales | 0,15370 | 0,04150 | 0,11220 |
| Bahamas | H | Información, telecomunicaciones, software e I+D | 0,11164 | 0,03684 | 0,07480 |
| Bahamas | I | Servicios inmobiliarios | 0,06411 | 0,01923 | 0,04488 |
| Bahamas | J | Administración y servicios sociales | 0,09350 | 0,01870 | 0,07480 |
| Bermudas | A | Agricultura, silvicultura y pesca | 0,00543 | 0,00163 | 0,00380 |
| Bermudas | B | Minería y energía | 0,00000 | 0,00000 | 0,00000 |
| Bermudas | C | Manufactura y reparación | 0,04222 | 0,02322 | 0,01900 |
| Bermudas | D | Construcción e infraestructura | 0,02764 | 0,01244 | 0,01520 |
| Bermudas | E | Comercio, alojamiento y servicios personales | 0,07355 | 0,02795 | 0,04560 |
| Bermudas | F | Transporte y logística | 0,06230 | 0,02430 | 0,03800 |
| Bermudas | G | Finanzas, seguros y servicios empresariales | 0,19000 | 0,04560 | 0,14440 |
| Bermudas | H | Información, telecomunicaciones, software e I+D | 0,06514 | 0,01954 | 0,04560 |
| Bermudas | I | Servicios inmobiliarios | 0,04282 | 0,01242 | 0,03040 |
| Bermudas | J | Administración y servicios sociales | 0,04750 | 0,00950 | 0,03800 |
| Barbados | A | Agricultura, silvicultura y pesca | 0,03413 | 0,01058 | 0,02355 |
| Barbados | B | Minería y energía | 0,00812 | 0,00341 | 0,00471 |
| Barbados | C | Manufactura y reparación | 0,13144 | 0,07492 | 0,05652 |
| Barbados | D | Construcción e infraestructura | 0,05233 | 0,02407 | 0,02826 |
| Barbados | E | Comercio, alojamiento y servicios personales | 0,15443 | 0,06023 | 0,09420 |
| Barbados | F | Transporte y logística | 0,09745 | 0,04093 | 0,05652 |
| Barbados | G | Finanzas, seguros y servicios empresariales | 0,07850 | 0,02198 | 0,05652 |
| Barbados | H | Información, telecomunicaciones, software e I+D | 0,06926 | 0,02216 | 0,04710 |
| Barbados | I | Servicios inmobiliarios | 0,05383 | 0,01615 | 0,03768 |
| Barbados | J | Administración y servicios sociales | 0,08242 | 0,01648 | 0,06594 |

La igualdad contable se cumple en cada sector y territorio. Los impuestos netos suman 0,44690 billones; el VAB conjunto de estas jurisdicciones es 9,25310 y el PIB conjunto 9,70000 billones. El PIB de Trinidad y Tobago se contabiliza por separado; no se incluye doblemente en una unidad caribeña agregada.

##### Conciliación del Reino y estado de aceptación

El total territorial del Reino sigue cerrando en 58,50 billones PPA. Las siete jurisdicciones de esta sección aportan 9,700 billones, con población de 87 millones; las otras siete unidades del Reino aportan 48,800 billones y 394 millones. La Federación incorpora el agregado externo actualizado de 7,00 billones: 58,50 + 7,00 = 65,50 billones PPA, redondeados a 66.

Quedan aprobados como canon sus límites, poblaciones, distribución urbana/rural, objetivos de PIB y cuentas de producción e insumos indicados aquí. La actualización de estos siete territorios queda cerrada. La apartado «Cierre ECON-03» completa las cuentas territoriales pendientes: siete unidades del Reino, seis unidades federales directas y el protectorado de Harnen. En las secciones 33 y 34, las matrices y coeficientes anteriores se conservan solo como antecedentes.

| Ámbito | PIB PPA | Impuestos netos | VAB | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- | --- |
| Siete territorios de esta sección | 9,70000 | 0,44690 | 9,25310 | 16,55465 | 7,30155 |
| Resto del Reino | 48,80000 | 2,25700 | 46,54300 | 78,92502 | 32,38200 |
| Reino | 58,50000 | 2,70390 | 55,79610 | 95,47967 | 39,68355 |
| Unidades externas | 7,00000 | 0,26820 | 5,78180 | 10,26838 | 4,48651 |
| Federación | 65,50000 | 3,02210 | 62,47790 | 107,20049 | 44,72259 |

### ECON-03 cerrado de las cuentas territoriales pendientes

Estado: [CANON VIGENTE — geografía económica, población urbana/rural y matrices de producción e insumos completadas para las cuentas territoriales pendientes] — 31 de octubre de 2026. Los datos son parámetros canónicos de un mundo ficticio, no estadísticas observadas de los territorios equivalentes.

Esta sección no incorpora una adición posterior al canon. Completa la desagregación económica de territorios que ya forman parte de la estructura política acumulativa. Las cuentas se organizan en tres grupos: siete unidades del Reino; seis unidades federales directas; y Harnen, que es un protectorado de Beleg Valinor. Harnen se incluye en el agregado operativo de la Federación por su vinculación fiscal, monetaria, defensiva y comercial, pero no se convierte por ello en miembro federal directo.

##### Límites operativos y población urbana/rural

Los límites se fijan con unidades insulares, administrativas o nacionales completas cuando están identificadas en el canon. Los recuentos urbanos se refieren a áreas funcionales; los remanentes rurales incluyen localidades menores, áreas productivas y población dispersa. M significa millones de personas.

Valinor a Tyl. Valinor, Tol Eressëa y Systreyjar, con las áreas insulares descritas en las fichas geográficas del canon; aguas jurisdiccionales excluidas de suelo y población.

Arnor. Ontario (Arnor Oriental), Quebec (Cardolan), Labrador continental (Forochel), Nueva Escocia (Arthedain), Nuevo Brunswick y Maine (Rhudaur), Isla del Príncipe Eduardo (Tolfalas) y Terranova insular (Númenor), conforme a la división territorial vigente; sin extender Forochel a Terranova.

Calenardhon Austral. Estados brasileños completos de Rio Grande do Sul y Santa Catarina; sin incorporar Paraná ni territorios vecinos. Superficie de referencia del canon: 281.700 km².

Sírënandë. Territorios completos de Guyana, Surinam y Guayana Francesa; excluye Brasil. La referencia superficial de 462.323 km² corresponde a estas tres unidades. No se crea una cuarta franja fronteriza sin polígono ni se superpone con la Provincia del Orinoco.

Colombia Costera. Los 22 departamentos y Bogotá D.C. ya fijados en la sección 31.1, con límites administrativos completos. Los diez departamentos orientales y amazónicos permanecen en Provincia del Orinoco.

Panamá Federal. Todo el territorio de la República de Panamá, incluidas provincias, comarcas, islas e infraestructura del canal. El canal no es enclave ni unidad económica separada.

Nosselië Toliva. Archipiélago canario completo conforme a la equivalencia territorial vigente; superficie 7.493 km². Se cuenta dentro de Aranath Valinor y del Reino, no como miembro federal externo.

Malaca. Península malaya completa y Singapur como distrito portuario integrado; excluye Sabah y Sarawak. El estrecho no se cuenta como superficie terrestre.

Hawái. Archipiélago hawaiano completo, con sus islas principales y menores asignadas al estado federal; no incluye otros archipiélagos polinesios.

Fiyi. Archipiélago completo de Fiyi, incluidas islas habitadas periféricas; se excluyen Tonga, Samoa y demás territorios polinesios.

Polinesia. Samoa, Tonga, Islas Cook, Polinesia Francesa, Wallis y Futuna, Tuvalu, Niue, Tokelau y Samoa Americana. Excluye Hawái y Fiyi, contabilizados como unidades independientes.

Micronesia. Guam, Islas Marianas del Norte, Palaos, Estados Federados de Micronesia, Islas Marshall y Kiribati. Excluye Samoa Americana, Fiji y demás territorios polinesios.

Eryndor. Archipiélago de Baréin completo, delimitado por sus islas y territorio emergido; no incluye aguas jurisdiccionales como suelo.

Harnen. Sultanato de Omán en su extensión terrestre completa, incluida la gobernación de Musandam. Rhunost es una provincia autónoma interna y no una unidad federal que se agregue aparte.

| Unidad | Población | Urbana | Rural/dispersa | Urbanización |
| --- | --- | --- | --- | --- |
| Valinor a Tyl | 26,00 M | 23,00 M | 3,00 M | 88,5 % |
| Arnor | 145,00 M | 131,50 M | 13,50 M | 90,7 % |
| Calenardhon Austral | 88,00 M | 80,00 M | 8,00 M | 90,9 % |
| Sírënandë | 55,00 M | 48,00 M | 7,00 M | 87,3 % |
| Colombia Costera | 53,00 M | 47,30 M | 5,70 M | 89,2 % |
| Panamá Federal | 17,00 M | 15,80 M | 1,20 M | 92,9 % |
| Nosselië Toliva | 10,00 M | 9,00 M | 1,00 M | 90,0 % |
| Malaca | 16,00 M | 14,80 M | 1,20 M | 92,5 % |
| Hawái | 4,00 M | 3,80 M | 0,20 M | 95,0 % |
| Fiyi | 3,00 M | 2,25 M | 0,75 M | 75,0 % |
| Polinesia | 2,50 M | 1,80 M | 0,70 M | 72,0 % |
| Micronesia | 1,50 M | 1,00 M | 0,50 M | 66,7 % |
| Eryndor | 2,00 M | 1,95 M | 0,05 M | 97,5 % |
| Harnen | 8,00 M | 6,60 M | 1,40 M | 82,5 % |
| Islandia | 3,5 M | 3,22 M | ,28 M | 92,0 % (hipótesis A092) |
| Groenlandia | 2 M | 1,70 M | ,30 M | 85,0 % (hipótesis A092) |

El límite pendiente de Sírënandë queda resuelto en tres territorios completos (Guyana, Surinam y Guayana Francesa), con la superficie de referencia de 462.323 km². Se elimina la cuarta franja fronteriza indeterminada; Brasil queda excluido y no hay solapamiento con Orinoco. Malaca se define para esta cuenta como la península malaya y Singapur, excluyendo Sabah y Sarawak. Polinesia y Micronesia quedan delimitadas por los grupos insulares enumerados, con Hawái y Fiyi separados.

##### Ciudades y distribución urbana

| Unidad o subregión | Núcleo urbano | Población |
| --- | --- | --- |
| Valinor a Tyl — Valinor | Nueva Tirion | 6,50 M |
| Valinor a Tyl — Valinor | Armenelos | 3,00 M |
| Valinor a Tyl — Valinor | Alqualondë | 2,20 M |
| Valinor a Tyl — Valinor | Tirion del Sur | 2,80 M |
| Valinor a Tyl — Tol Eressëa | Eldalondë | 2,80 M |
| Valinor a Tyl — Tol Eressëa | Avallónë | 1,50 M |
| Valinor a Tyl — Systreyjar | Taur-en-Mor | 3,10 M |
| Valinor a Tyl — Systreyjar | Otros núcleos insulares | 1,10 M |
| Valinor a Tyl | Población rural y dispersa | 3,00 M |
| Arnor — Ontario | Annúminas (Toronto) | 20,00 M |
| Arnor — Quebec | Fornost (Montreal) | 15,00 M |
| Arnor — Quebec | Cardolan (Québec) | 6,00 M |
| Arnor — Ontario | Amon Sûl (Ottawa) | 8,00 M |
| Arnor — Nueva Escocia | Hithlum (Halifax) | 5,00 M |
| Arnor — Nuevo Brunswick–Maine | Rhûn (Saint John) | 3,00 M |
| Arnor — Labrador | Etten (Labrador City) | 2,00 M |
| Arnor — Nuevo Brunswick–Maine | Bree (Portland) | 4,00 M |
| Arnor — Isla del Príncipe Eduardo | Tolfalas (Charlottetown) | 1,50 M |
| Arnor — Ontario | Hamilton | 5,00 M |
| Arnor — Ontario | Tyrn Gorthad (Kingston) | 3,00 M |
| Arnor — Ontario | Emyn Uial (Thunder Bay) | 2,50 M |
| Arnor — Ontario | Calenhad (Windsor) | 4,00 M |
| Arnor — Arnor | Otros núcleos urbanos | 52,50 M |
| Arnor | Población rural y dispersa | 13,50 M |
| Calenardhon Austral — Rio Grande do Sul | Pelargir Austral (Porto Alegre) | 8,50 M |
| Calenardhon Austral — Santa Catarina | Calenport (Florianópolis) | 4,50 M |
| Calenardhon Austral — Rio Grande do Sul | Rómenna Austral (Rio Grande) | 2,80 M |
| Calenardhon Austral — Rio Grande do Sul | Esgaroth Austral (Pelotas) | 2,60 M |
| Calenardhon Austral — Santa Catarina | Dol Amroth Austral (Joinville) | 3,50 M |
| Calenardhon Austral — Rio Grande do Sul | Barad Calen (Caxias do Sul) | 3,00 M |
| Calenardhon Austral — Rio Grande do Sul | Minas Tirith Austral (Santa Maria) | 2,20 M |
| Calenardhon Austral — Rio Grande do Sul | Osgiliath del Sur (Passo Fundo) | 1,80 M |
| Calenardhon Austral — Santa Catarina | Edhellond Austral (Itajaí) | 1,90 M |
| Calenardhon Austral — Rio Grande do Sul | Forlond Austral (São José do Norte) | 1,00 M |
| Calenardhon Austral — Santa Catarina | Calenost (Chapecó) | 1,60 M |
| Calenardhon Austral — Ambos | Otros centros urbanos | 46,60 M |
| Calenardhon Austral | Población rural y dispersa | 8,00 M |
| Sírënandë — Guyana | Sirion (Georgetown) | 10,00 M |
| Sírënandë — Guyana | Demerion (New Amsterdam) | 2,50 M |
| Sírënandë — Guyana | Esequielond (Bartica) | 1,00 M |
| Sírënandë — Guyana | Otros centros | 8,50 M |
| Sírënandë — Surinam | Erellond Sur (Paramaribo) | 7,50 M |
| Sírënandë — Surinam | Sarnath (Lelydorp) | 2,40 M |
| Sírënandë — Surinam | Rómennar (Moengo) | 1,20 M |
| Sírënandë — Surinam | Calenport Sur (Albina) | 0,70 M |
| Sírënandë — Surinam | Otros centros | 2,20 M |
| Sírënandë — Guayana Francesa | Calasir (Cayena) | 4,50 M |
| Sírënandë — Guayana Francesa | Kourondë (Kourou) | 2,10 M |
| Sírënandë — Guayana Francesa | Eldalondë Oriental (Saint-Laurent) | 1,80 M |
| Sírënandë — Guayana Francesa | Barad Calen (Matoury) | 1,40 M |
| Sírënandë — Guayana Francesa | Amon Rûdh Oriental (Remire-Montjoly) | 1,00 M |
| Sírënandë — Guayana Francesa | Otros centros | 1,20 M |
| Sírënandë | Población rural y dispersa | 7,00 M |
| Colombia Costera — Caribe y archipiélago | Vinyamar (Barranquilla–Soledad) | 4,32 M |
| Colombia Costera — Caribe y archipiélago | Brithombar (Cartagena) | 2,52 M |
| Colombia Costera — Caribe y archipiélago | Tharbad (Santa Marta–Ciénaga) | 1,89 M |
| Colombia Costera — Caribe y archipiélago | Eryn Vorn (Montería–Sincelejo) | 1,80 M |
| Colombia Costera — Caribe y archipiélago | Doriath Norte (Valledupar–Riohacha) | 1,89 M |
| Colombia Costera — Caribe y archipiélago | Otros centros urbanos | 1,98 M |
| Colombia Costera — Pacífico | Nargothrond (Cali–Yumbo–Palmira) | 4,11 M |
| Colombia Costera — Pacífico | Lond Daer (Buenaventura) | 1,37 M |
| Colombia Costera — Pacífico | Himring del Sur (Pasto–Popayán) | 1,89 M |
| Colombia Costera — Pacífico | Amon Ereb (Tumaco) | 0,77 M |
| Colombia Costera — Pacífico | Quibdó | 0,43 M |
| Colombia Costera — Pacífico | Otros centros urbanos | 0,43 M |
| Colombia Costera — Antioquia y Eje Cafetero | Ost-in-Edhil (Medellín–Valle de Aburrá) | 4,86 M |
| Colombia Costera — Antioquia y Eje Cafetero | Eglador (Rionegro y Oriente antioqueño) | 1,26 M |
| Colombia Costera — Antioquia y Eje Cafetero | Forlindon (Turbo–Apartadó) | 1,17 M |
| Colombia Costera — Antioquia y Eje Cafetero | Mithlond del Café (Pereira) | 1,08 M |
| Colombia Costera — Antioquia y Eje Cafetero | Rathlóriel (Manizales) | 0,81 M |
| Colombia Costera — Antioquia y Eje Cafetero | Nimrodel del Quindío (Armenia) | 0,54 M |
| Colombia Costera — Antioquia y Eje Cafetero | Otras ciudades | 0,18 M |
| Colombia Costera — Corredor Andino Oriental | Mithrim (Bogotá–Sabana) | 6,60 M |
| Colombia Costera — Corredor Andino Oriental | Caras Galadhon (Bucaramanga) | 1,99 M |
| Colombia Costera — Corredor Andino Oriental | Minas Ithil (Cúcuta) | 1,63 M |
| Colombia Costera — Corredor Andino Oriental | Talath Dirnen (Ibagué) | 0,99 M |
| Colombia Costera — Corredor Andino Oriental | Taur-im-Duinath (Neiva) | 0,72 M |
| Colombia Costera — Corredor Andino Oriental | Tirith Aear (Tunja–Duitama–Sogamoso) | 1,27 M |
| Colombia Costera — Corredor Andino Oriental | Otras ciudades | 0,80 M |
| Colombia Costera | Población rural y dispersa | 5,70 M |
| Panamá Federal — Panamá | Tirion del Istmo (Panamá–San Miguelito) | 5,60 M |
| Panamá Federal — Colón | Mithlond del Caribe (Colón–Portobelo) | 1,40 M |
| Panamá Federal — Panamá Oeste | Forlindon del Istmo (Arraiján–La Chorrera) | 2,00 M |
| Panamá Federal — Chiriquí | Barad Nimras (David–Chiriquí) | 1,50 M |
| Panamá Federal — Veraguas | Sarn Athrad (Santiago) | 0,80 M |
| Panamá Federal — Herrera–Los Santos | Amon Dîn (Chitré–Las Tablas) | 0,90 M |
| Panamá Federal — Bocas del Toro | Nimbrethil (Changuinola–Almirante) | 0,70 M |
| Panamá Federal — Coclé | Rathlóriel del Centro (Penonomé–Aguadulce) | 0,70 M |
| Panamá Federal — Darién | Calenost Oriental (Metetí–Darién) | 0,35 M |
| Panamá Federal — Panamá | Otros centros urbanos | 1,85 M |
| Panamá Federal | Población rural y dispersa | 1,20 M |
| Nosselië Toliva — Gran Canaria | Eressëa (Las Palmas) | 4,50 M |
| Nosselië Toliva — Tenerife | Caladhrim (Santa Cruz de Tenerife) | 3,20 M |
| Nosselië Toliva — Tenerife | La Laguna | 0,50 M |
| Nosselië Toliva — Lanzarote | Arrecife | 0,45 M |
| Nosselië Toliva — Fuerteventura | Puerto del Rosario | 0,35 M |
| Nosselië Toliva | Población rural y dispersa | 1,00 M |
| Malaca — Malaca | Kuala Lumpur–Klang | 5,20 M |
| Malaca — Singapur | Tirion Malaca (Singapur) | 4,30 M |
| Malaca — Penang | George Town | 1,50 M |
| Malaca — Johor | Johor Bahru | 1,40 M |
| Malaca — Malaca | Ciudad de Malaca | 0,70 M |
| Malaca — Perak | Ipoh | 0,60 M |
| Malaca — Pahang | Kuantan | 0,40 M |
| Malaca — Península | Otros centros urbanos | 0,70 M |
| Malaca | Población rural y dispersa | 1,20 M |
| Hawái — Oʻahu | Honolulu–Pearl Harbor | 2,40 M |
| Hawái — Hawaiʻi | Hilo | 0,40 M |
| Hawái — Maui | Kahului | 0,30 M |
| Hawái — Hawaiʻi | Kailua-Kona | 0,20 M |
| Hawái — Archipiélago | Otros centros urbanos | 0,50 M |
| Hawái | Población rural y dispersa | 0,20 M |
| Fiyi — Viti Levu | Suva–Nasinu | 0,70 M |
| Fiyi — Viti Levu | Nadi | 0,35 M |
| Fiyi — Viti Levu | Lautoka | 0,30 M |
| Fiyi — Vanua Levu | Labasa | 0,20 M |
| Fiyi — Viti Levu | Ba | 0,15 M |
| Fiyi — Archipiélago | Otros centros urbanos | 0,55 M |
| Fiyi | Población rural y dispersa | 0,75 M |
| Polinesia — Polinesia Francesa | Papeete | 0,65 M |
| Polinesia — Samoa | Apia | 0,30 M |
| Polinesia — Tonga | Nukuʻalofa | 0,20 M |
| Polinesia — Cook | Avarua | 0,15 M |
| Polinesia — Tuvalu | Funafuti | 0,10 M |
| Polinesia — Polinesia | Otros centros urbanos | 0,40 M |
| Polinesia | Población rural y dispersa | 0,70 M |
| Micronesia — Guam | Hagåtña–Tamuning | 0,35 M |
| Micronesia — Marshall | Majuro | 0,18 M |
| Micronesia — Micronesia | Palikir–Kolonia | 0,15 M |
| Micronesia — Palaos | Koror | 0,12 M |
| Micronesia — Kiribati | Tarawa Sur | 0,12 M |
| Micronesia — Marianas del Norte | Saipán | 0,08 M |
| Micronesia | Población rural y dispersa | 0,50 M |
| Eryndor — Baréin | Manama | 0,95 M |
| Eryndor — Baréin | Muharraq | 0,35 M |
| Eryndor — Baréin | Riffa | 0,30 M |
| Eryndor — Baréin | Isa Town | 0,15 M |
| Eryndor — Baréin | Otros centros urbanos | 0,20 M |
| Eryndor | Población rural y dispersa | 0,05 M |
| Harnen — Mascate | Mascate–Seeb | 2,20 M |
| Harnen — Dhofar | Salalah | 0,90 M |
| Harnen — Al Batinah | Sohar | 0,80 M |
| Harnen — Ad Dakhiliyah | Nizwa | 0,50 M |
| Harnen — Ash Sharqiyah | Sur | 0,35 M |
| Harnen — Al Wusta | Duqm | 0,30 M |
| Harnen — Musandam/Rhunost | Khasab y núcleos | 0,45 M |
| Harnen — Omán | Otros centros urbanos | 1,10 M |
| Harnen | Población rural y dispersa | 1,40 M |

La distribución de Arnor conserva sus siete provincias canónicas: Arnor Oriental/Ontario 66 M, Cardolan/Quebec 41 M, Forochel/Labrador continental 5 M, Arthedain/Nueva Escocia 9 M, Rhudaur/Nuevo Brunswick y Maine 13 M, Tolfalas/Isla del Príncipe Eduardo 2 M y Númenor/Terranova 9 M. La población urbana conjunta es 131,5 M y la rural/dispersa 13,5 M.

La población de Colombia Costera se reparte por regiones en 16 M para Caribe y archipiélago (14,4 urbanos; 1,6 rurales), 10,5 M para Pacífico (9,0; 1,5), 11 M para Antioquia y Eje Cafetero (9,9; 1,1) y 15,5 M para el Corredor Andino Oriental (14,0; 1,5). Total: 47,3 M urbanos y 5,7 M rurales/dispersos. Las cifras de núcleos urbanos en esta sección sustituyen la asignación anterior que distribuía la población regional completa entre centros y no separaba explícitamente la población rural.

Panamá Federal conserva los núcleos y cifras de la sección 32.1: sus centros urbanos reúnen 15,8 M y la población rural, comarcal y dispersa 1,2 M. En Valinor a Tyl, los subtotales urbanos son 14,5 M en Valinor, 4,3 M en Tol Eressëa y 4,2 M en Systreyjar.

##### Criterio de cuentas territoriales

Para cada territorio se fija de manera independiente la composición sectorial A–J, los impuestos sobre productos, las subvenciones sobre productos y la relación entre VAB sectorial y producción. La cuenta usa producción a precios básicos menos consumo intermedio igual a VAB; el PIB PPA equivale a VAB más impuestos netos sobre productos. Los valores están en billones PPA 2026. Los coeficientes implícitos propios quedan expresados en cada par de producción e insumos; no se aplica una tasa fiscal ni un coeficiente técnico común.

Las ventas de bienes intermedios, importaciones, valor nominal de depósitos o préstamos, carga en tránsito y valor bruto del canal no constituyen VAB local. Márgenes y comisiones se atribuyen al territorio donde se produce el servicio. La construcción se registra en D, la operación y logística en F; manufactura y reparación en C; I+D y software en H. Cada actividad se cuenta una vez.

##### Origen de insumos intermedios y márgenes comerciales

El consumo intermedio de cada matriz se divide entre insumos de origen interno e insumos importados según el perfil de abastecimiento propio de cada territorio. Las importaciones de esta tabla son compras intermedias; no se registran como producción ni PIB local. Los márgenes comerciales son producción de servicios del sector E incluida en su producción bruta y VAB; el indicador de margen se presenta como desglose informativo y no se suma de nuevo. Transporte, almacenamiento y manejo portuario permanecen en F. Los montos están en billones PPA 2026.

| Unidad | Insumos internos | Insumos importados | Consumo intermedio total | Margen comercial incluido en E | Producción total de E |
| --- | --- | --- | --- | --- | --- |
| Valinor a Tyl | 1,37027 | 0,30079 (18 %) | 1,67106 | 0,10362 (28 % de E) | 0,37006 |
| Arnor | 9,99227 | 1,76334 (15 %) | 11,75561 | 0,44520 (22 % de E) | 2,02364 |
| Calenardhon Austral | 6,75859 | 1,90627 (22 %) | 8,66486 | 0,28579 (23 % de E) | 1,24256 |
| Sírënandë | 1,85178 | 0,79362 (30 %) | 2,64540 | 0,06734 (20 % de E) | 0,33670 |
| Colombia Costera | 3,77994 | 1,46998 (28 %) | 5,24992 | 0,19623 (25 % de E) | 0,78492 |
| Panamá Federal | 1,15008 | 0,61927 (35 %) | 1,76935 | 0,15103 (38 % de E) | 0,39746 |
| Nosselië Toliva | 0,42554 | 0,20026 (32 %) | 0,62580 | 0,05513 (35 % de E) | 0,15750 |
| Malaca | 1,46290 | 1,05934 (42 %) | 2,52224 | 0,09816 (30 % de E) | 0,32719 |
| Hawái | 0,48524 | 0,29741 (38 %) | 0,78265 | 0,05434 (34 % de E) | 0,15981 |
| Fiyi | 0,16581 | 0,13567 (45 %) | 0,30148 | 0,02353 (29 % de E) | 0,08115 |
| Polinesia | 0,11088 | 0,13552 (55 %) | 0,24640 | 0,03606 (35 % de E) | 0,10302 |
| Micronesia | 0,07740 | 0,11611 (60 %) | 0,19351 | 0,01581 (38 % de E) | 0,04160 |
| Eryndor | 0,03764 | 0,03764 (50 %) | 0,07527 | 0,00560 (24 % de E) | 0,02332 |
| Harnen | 0,24817 | 0,11679 (32 %) | 0,36496 | 0,00836 (20 % de E) | 0,04182 |

La producción de comercio, alojamiento y servicios personales no comprende el valor bruto de los bienes revendidos. Solo incorpora los márgenes y servicios producidos localmente; por eso ni el valor de las importaciones ni el valor de la carga en tránsito se añade a las cuentas como producto territorial.

##### Matrices de producción e insumos por territorio

##### Valinor a Tyl

Población: 26,00 M; urbana: 23,00 M; rural/dispersa: 3,00 M. PIB objetivo: 3,10. Impuestos sobre productos: 0,18000; subvenciones: 0,04050; impuestos netos: 0,13950; VAB: 2,96050 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04486 | 0,01525 | 0,02961 |
| B | Minería y energía | 0,18797 | 0,06955 | 0,11842 |
| C | Manufactura y reparación | 1,18420 | 0,65131 | 0,53289 |
| D | Construcción e infraestructura | 0,28466 | 0,13664 | 0,14802 |
| E | Comercio, alojamiento y servicios personales | 0,37006 | 0,13322 | 0,23684 |
| F | Transporte y logística | 0,48533 | 0,18928 | 0,29605 |
| G | Finanzas, seguros y servicios empresariales | 0,77908 | 0,18698 | 0,59210 |
| H | Información, telecomunicaciones, software e I+D | 0,80014 | 0,20804 | 0,59210 |
| I | Servicios inmobiliarios | 0,21662 | 0,03899 | 0,17763 |
| J | Administración y servicios sociales | 0,27864 | 0,04180 | 0,23684 |
| Total |  | 4,63156 | 1,67106 | 2,96051 |

##### Arnor

Población: 145,00 M; urbana: 131,50 M; rural/dispersa: 13,50 M. PIB objetivo: 20,00. Impuestos sobre productos: 1,10000; subvenciones: 0,18000; impuestos netos: 0,92000; VAB: 19,08000 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,82957 | 0,25717 | 0,57240 |
| B | Minería y energía | 2,27821 | 0,75181 | 1,52640 |
| C | Manufactura y reparación | 11,13000 | 5,78760 | 5,34240 |
| D | Construcción e infraestructura | 2,12000 | 0,97520 | 1,14480 |
| E | Comercio, alojamiento y servicios personales | 2,02364 | 0,68804 | 1,33560 |
| F | Transporte y logística | 2,15419 | 0,81859 | 1,33560 |
| G | Finanzas, seguros y servicios empresariales | 3,76579 | 0,90379 | 2,86200 |
| H | Información, telecomunicaciones, software e I+D | 4,50500 | 1,26140 | 3,24360 |
| I | Servicios inmobiliarios | 0,69805 | 0,12565 | 0,57240 |
| J | Administración y servicios sociales | 1,33116 | 0,18636 | 1,14480 |
| Total |  | 30,83561 | 11,75561 | 19,08000 |

##### Calenardhon Austral

Población: 88,00 M; urbana: 80,00 M; rural/dispersa: 8,00 M. PIB objetivo: 11,50. Impuestos sobre productos: 0,62000; subvenciones: 0,12550; impuestos netos: 0,49450; VAB: 11,00550 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 1,64261 | 0,54206 | 1,10055 |
| B | Minería y energía | 2,03178 | 0,71112 | 1,32066 |
| C | Manufactura y reparación | 8,19014 | 4,66838 | 3,52176 |
| D | Construcción e infraestructura | 1,48151 | 0,71112 | 0,77039 |
| E | Comercio, alojamiento y servicios personales | 1,24256 | 0,47217 | 0,77039 |
| F | Transporte y logística | 1,49227 | 0,61183 | 0,88044 |
| G | Finanzas, seguros y servicios empresariales | 1,25777 | 0,37733 | 0,88044 |
| H | Información, telecomunicaciones, software e I+D | 1,13292 | 0,36253 | 0,77039 |
| I | Servicios inmobiliarios | 0,41271 | 0,08254 | 0,33017 |
| J | Administración y servicios sociales | 0,78611 | 0,12580 | 0,66031 |
| Total |  | 19,67038 | 8,66486 | 11,00552 |

##### Sírënandë

Población: 55,00 M; urbana: 48,00 M; rural/dispersa: 7,00 M. PIB objetivo: 3,50. Impuestos sobre productos: 0,22000; subvenciones: 0,08700; impuestos netos: 0,13300; VAB: 3,36700 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,62160 | 0,21756 | 0,40404 |
| B | Minería y energía | 1,35766 | 0,51591 | 0,84175 |
| C | Manufactura y reparación | 1,84383 | 1,06942 | 0,77441 |
| D | Construcción e infraestructura | 0,47138 | 0,23569 | 0,23569 |
| E | Comercio, alojamiento y servicios personales | 0,33670 | 0,13468 | 0,20202 |
| F | Transporte y logística | 0,48100 | 0,21164 | 0,26936 |
| G | Finanzas, seguros y servicios empresariales | 0,29709 | 0,09507 | 0,20202 |
| H | Información, telecomunicaciones, software e I+D | 0,27153 | 0,10318 | 0,16835 |
| I | Servicios inmobiliarios | 0,08524 | 0,01790 | 0,06734 |
| J | Administración y servicios sociales | 0,24637 | 0,04435 | 0,20202 |
| Total |  | 6,01240 | 2,64540 | 3,36700 |

##### Colombia Costera

Población: 53,00 M; urbana: 47,30 M; rural/dispersa: 5,70 M. PIB objetivo: 7,20. Impuestos sobre productos: 0,48000; subvenciones: 0,12000; impuestos netos: 0,36000; VAB: 6,84000 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 1,30286 | 0,48206 | 0,82080 |
| B | Minería y energía | 1,23344 | 0,48104 | 0,75240 |
| C | Manufactura y reparación | 3,83707 | 2,26387 | 1,57320 |
| D | Construcción e infraestructura | 0,68400 | 0,34200 | 0,34200 |
| E | Comercio, alojamiento y servicios personales | 0,78492 | 0,30612 | 0,47880 |
| F | Transporte y logística | 1,24364 | 0,55964 | 0,68400 |
| G | Finanzas, seguros y servicios empresariales | 1,17257 | 0,35177 | 0,82080 |
| H | Información, telecomunicaciones, software e I+D | 0,91881 | 0,30321 | 0,61560 |
| I | Servicios inmobiliarios | 0,25333 | 0,04813 | 0,20520 |
| J | Administración y servicios sociales | 0,65928 | 0,11208 | 0,54720 |
| Total |  | 12,08992 | 5,24992 | 6,84000 |

##### Panamá Federal

Población: 17,00 M; urbana: 15,80 M; rural/dispersa: 1,20 M. PIB objetivo: 2,50. Impuestos sobre productos: 0,21000; subvenciones: 0,05500; impuestos netos: 0,15500; VAB: 2,34500 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,18038 | 0,06313 | 0,11725 |
| B | Minería y energía | 0,15129 | 0,05749 | 0,09380 |
| C | Manufactura y reparación | 1,05525 | 0,63315 | 0,42210 |
| D | Construcción e infraestructura | 0,23450 | 0,11725 | 0,11725 |
| E | Comercio, alojamiento y servicios personales | 0,39746 | 0,16296 | 0,23450 |
| F | Transporte y logística | 0,86852 | 0,39952 | 0,46900 |
| G | Finanzas, seguros y servicios empresariales | 0,68396 | 0,19151 | 0,49245 |
| H | Información, telecomunicaciones, software e I+D | 0,34485 | 0,11035 | 0,23450 |
| I | Servicios inmobiliarios | 0,11439 | 0,02059 | 0,09380 |
| J | Administración y servicios sociales | 0,08375 | 0,01340 | 0,07035 |
| Total |  | 4,11435 | 1,76935 | 2,34500 |

##### Nosselië Toliva

Población: 10,00 M; urbana: 9,00 M; rural/dispersa: 1,00 M. PIB objetivo: 1,00. Impuestos sobre productos: 0,10000; subvenciones: 0,04500; impuestos netos: 0,05500; VAB: 0,94500 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,15242 | 0,05792 | 0,09450 |
| B | Minería y energía | 0,15750 | 0,06300 | 0,09450 |
| C | Manufactura y reparación | 0,27659 | 0,16319 | 0,11340 |
| D | Construcción e infraestructura | 0,11571 | 0,05901 | 0,05670 |
| E | Comercio, alojamiento y servicios personales | 0,15750 | 0,06300 | 0,09450 |
| F | Transporte y logística | 0,23211 | 0,09981 | 0,13230 |
| G | Finanzas, seguros y servicios empresariales | 0,10800 | 0,03240 | 0,07560 |
| H | Información, telecomunicaciones, software e I+D | 0,12694 | 0,04189 | 0,08505 |
| I | Servicios inmobiliarios | 0,08269 | 0,01654 | 0,06615 |
| J | Administración y servicios sociales | 0,16134 | 0,02904 | 0,13230 |
| Total |  | 1,57080 | 0,62580 | 0,94500 |

##### Malaca

Población: 16,00 M; urbana: 14,80 M; rural/dispersa: 1,20 M. PIB objetivo: 2,97. Impuestos sobre productos: 0,18000; subvenciones: 0,06120; impuestos netos: 0,11880; VAB: 2,85120 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,12960 | 0,04406 | 0,08554 |
| B | Minería y energía | 0,36790 | 0,13980 | 0,22810 |
| C | Manufactura y reparación | 2,57966 | 1,49620 | 1,08346 |
| D | Construcción e infraestructura | 0,39917 | 0,19958 | 0,19959 |
| E | Comercio, alojamiento y servicios personales | 0,32719 | 0,12760 | 0,19959 |
| F | Transporte y logística | 0,61097 | 0,26883 | 0,34214 |
| G | Finanzas, seguros y servicios empresariales | 0,31680 | 0,08870 | 0,22810 |
| H | Información, telecomunicaciones, software e I+D | 0,46869 | 0,12655 | 0,34214 |
| I | Servicios inmobiliarios | 0,10560 | 0,02006 | 0,08554 |
| J | Administración y servicios sociales | 0,06789 | 0,01089 | 0,05700 |
| Total |  | 5,37347 | 2,52224 | 2,85120 |

##### Hawái

Población: 4,00 M; urbana: 3,80 M; rural/dispersa: 0,20 M. PIB objetivo: 1,35. Impuestos sobre productos: 0,10000; subvenciones: 0,02845; impuestos netos: 0,07155; VAB: 1,27845 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,03934 | 0,01377 | 0,02557 |
| B | Minería y energía | 0,09988 | 0,03596 | 0,06392 |
| C | Manufactura y reparación | 0,58111 | 0,32542 | 0,25569 |
| D | Construcción e infraestructura | 0,16885 | 0,07936 | 0,08949 |
| E | Comercio, alojamiento y servicios personales | 0,15981 | 0,05753 | 0,10228 |
| F | Transporte y logística | 0,26002 | 0,10661 | 0,15341 |
| G | Finanzas, seguros y servicios empresariales | 0,19264 | 0,05201 | 0,14063 |
| H | Información, telecomunicaciones, software e I+D | 0,29886 | 0,06874 | 0,23012 |
| I | Servicios inmobiliarios | 0,07795 | 0,01403 | 0,06392 |
| J | Administración y servicios sociales | 0,18264 | 0,02922 | 0,15342 |
| Total |  | 2,06110 | 0,78265 | 1,27844 |

##### Fiyi

Población: 3,00 M; urbana: 2,25 M; rural/dispersa: 0,75 M. PIB objetivo: 0,42. Impuestos sobre productos: 0,03500; subvenciones: 0,01400; impuestos netos: 0,02100; VAB: 0,39900 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,11774 | 0,04592 | 0,07182 |
| B | Minería y energía | 0,06191 | 0,02600 | 0,03591 |
| C | Manufactura y reparación | 0,14323 | 0,08737 | 0,05586 |
| D | Construcción e infraestructura | 0,05819 | 0,03026 | 0,02793 |
| E | Comercio, alojamiento y servicios personales | 0,08115 | 0,03327 | 0,04788 |
| F | Transporte y logística | 0,08705 | 0,03917 | 0,04788 |
| G | Finanzas, seguros y servicios empresariales | 0,03023 | 0,01028 | 0,01995 |
| H | Información, telecomunicaciones, software e I+D | 0,03069 | 0,01074 | 0,01995 |
| I | Servicios inmobiliarios | 0,02046 | 0,00450 | 0,01596 |
| J | Administración y servicios sociales | 0,06983 | 0,01397 | 0,05586 |
| Total |  | 0,70048 | 0,30148 | 0,39900 |

##### Polinesia

Población: 2,50 M; urbana: 1,80 M; rural/dispersa: 0,70 M. PIB objetivo: 0,35. Impuestos sobre productos: 0,03000; subvenciones: 0,01075; impuestos netos: 0,01925; VAB: 0,33075 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,08133 | 0,03172 | 0,04961 |
| B | Minería y energía | 0,03482 | 0,01497 | 0,01985 |
| C | Manufactura y reparación | 0,08704 | 0,05396 | 0,03308 |
| D | Construcción e infraestructura | 0,05630 | 0,02984 | 0,02646 |
| E | Comercio, alojamiento y servicios personales | 0,10302 | 0,04018 | 0,06284 |
| F | Transporte y logística | 0,09188 | 0,04226 | 0,04962 |
| G | Finanzas, seguros y servicios empresariales | 0,03405 | 0,01090 | 0,02315 |
| H | Información, telecomunicaciones, software e I+D | 0,03456 | 0,01140 | 0,02316 |
| I | Servicios inmobiliarios | 0,01696 | 0,00373 | 0,01323 |
| J | Administración y servicios sociales | 0,03721 | 0,00746 | 0,02975 |
| Total |  | 0,57717 | 0,24640 | 0,33075 |

##### Micronesia

Población: 1,50 M; urbana: 1,00 M; rural/dispersa: 0,50 M. PIB objetivo: 0,26. Impuestos sobre productos: 0,01700; subvenciones: 0,00660; impuestos netos: 0,01040; VAB: 0,24960 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04092 | 0,01596 | 0,02496 |
| B | Minería y energía | 0,03807 | 0,01561 | 0,02246 |
| C | Manufactura y reparación | 0,08960 | 0,05466 | 0,03494 |
| D | Construcción e infraestructura | 0,03640 | 0,01893 | 0,01747 |
| E | Comercio, alojamiento y servicios personales | 0,04160 | 0,01664 | 0,02496 |
| F | Transporte y logística | 0,09984 | 0,04493 | 0,05491 |
| G | Finanzas, seguros y servicios empresariales | 0,02569 | 0,00822 | 0,01747 |
| H | Información, telecomunicaciones, software e I+D | 0,03353 | 0,01106 | 0,02247 |
| I | Servicios inmobiliarios | 0,01280 | 0,00282 | 0,00998 |
| J | Administración y servicios sociales | 0,02465 | 0,00467 | 0,01998 |
| Total |  | 0,44310 | 0,19351 | 0,24958 |

##### Eryndor

Población: 2,00 M; urbana: 1,95 M; rural/dispersa: 0,05 M. PIB objetivo: 0,18. Impuestos sobre productos: 0,02500; subvenciones: 0,01600; impuestos netos: 0,00900; VAB: 0,17100 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,00132 | 0,00046 | 0,00086 |
| B | Minería y energía | 0,00276 | 0,00105 | 0,00171 |
| C | Manufactura y reparación | 0,02036 | 0,01181 | 0,00855 |
| D | Construcción e infraestructura | 0,01644 | 0,00789 | 0,00855 |
| E | Comercio, alojamiento y servicios personales | 0,02332 | 0,00793 | 0,01539 |
| F | Transporte y logística | 0,02948 | 0,01238 | 0,01710 |
| G | Finanzas, seguros y servicios empresariales | 0,09427 | 0,02074 | 0,07353 |
| H | Información, telecomunicaciones, software e I+D | 0,03279 | 0,00885 | 0,02394 |
| I | Servicios inmobiliarios | 0,01460 | 0,00263 | 0,01197 |
| J | Administración y servicios sociales | 0,01094 | 0,00154 | 0,00940 |
| Total |  | 0,24628 | 0,07527 | 0,17101 |

##### Harnen

Población: 8,00 M; urbana: 6,60 M; rural/dispersa: 1,40 M. PIB objetivo: 0,52. Impuestos sobre productos: 0,06000; subvenciones: 0,04180; impuestos netos: 0,01820; VAB: 0,50180 billones PPA.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04632 | 0,01621 | 0,03011 |
| B | Minería y energía | 0,25090 | 0,09032 | 0,16058 |
| C | Manufactura y reparación | 0,22173 | 0,12638 | 0,09535 |
| D | Construcción e infraestructura | 0,06887 | 0,03375 | 0,03512 |
| E | Comercio, alojamiento y servicios personales | 0,04182 | 0,01673 | 0,02509 |
| F | Transporte y logística | 0,11445 | 0,04921 | 0,06524 |
| G | Finanzas, seguros y servicios empresariales | 0,04301 | 0,01290 | 0,03011 |
| H | Información, telecomunicaciones, software e I+D | 0,03690 | 0,01181 | 0,02509 |
| I | Servicios inmobiliarios | 0,01255 | 0,00251 | 0,01004 |
| J | Administración y servicios sociales | 0,03023 | 0,00516 | 0,02507 |
| Total |  | 0,86678 | 0,36496 | 0,50181 |

##### Coherencia territorial y conciliación final

Distribución 2026 A092: Reino 431,85 millones urbanos y 49,15 rurales; constitucional 462,37 y 53,13; operativo 468,97 y 54,53. Se añaden como hipótesis septentrional 3,22 urbanos y 0,28 rurales de Islandia, y 1,70 y 0,30 de Groenlandia. Los totales son 481, 515,5 y 523,5 millones respectivamente.

| Unidad | Población | PIB PPA | PIB por habitante (USD PPA) |
| --- | --- | --- | --- |
| Valinor a Tyl | 26,00000 M | 3,10000 | 119.231 |
| Arnor | 145,00000 M | 20,00000 | 137.931 |
| Calenardhon Austral | 88,00000 M | 11,50000 | 130.682 |
| Sírënandë | 55,00000 M | 3,50000 | 63.636 |
| Colombia Costera | 53,00000 M | 7,20000 | 135.849 |
| Panamá Federal | 17,00000 M | 2,50000 | 147.059 |
| Nosselië Toliva | 10,00000 M | 1,00000 | 100.000 |
| Malaca | 16,00000 M | 2,97000 | 185.625 |
| Hawái | 4,00000 M | 1,35000 | 337.500 |
| Fiyi | 3,00000 M | 0,42000 | 140.000 |
| Polinesia | 2,50000 M | 0,35000 | 140.000 |
| Micronesia | 1,50000 M | 0,26000 | 173.333 |
| Eryndor | 2,00000 M | 0,18000 | 90.000 |
| Harnen | 8,00000 M | 0,52000 | 65.000 |
| Islandia | 3,5 M | ,55 | 157143 |
| Groenlandia | 2 M | ,40 | 200000 |

| Unidad | Impuestos netos | VAB | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- |
| Valinor a Tyl | 0,13950 | 2,96050 | 4,63156 | 1,67106 |
| Arnor | 0,92000 | 19,08000 | 30,83561 | 11,75561 |
| Calenardhon Austral | 0,49450 | 11,00550 | 19,67038 | 8,66488 |
| Sírënandë | 0,13300 | 3,36700 | 6,01240 | 2,64540 |
| Colombia Costera | 0,36000 | 6,84000 | 12,08992 | 5,24992 |
| Panamá Federal | 0,15500 | 2,34500 | 4,11435 | 1,76935 |
| Nosselië Toliva | 0,05500 | 0,94500 | 1,57080 | 0,62580 |
| Malaca | 0,11880 | 2,85120 | 5,37347 | 2,52227 |
| Hawái | 0,07155 | 1,27845 | 2,06110 | 0,78265 |
| Fiyi | 0,02100 | 0,39900 | 0,70048 | 0,30148 |
| Polinesia | 0,01925 | 0,33075 | 0,57717 | 0,24642 |
| Micronesia | 0,01040 | 0,24960 | 0,44310 | 0,19350 |
| Eryndor | 0,00900 | 0,17100 | 0,24628 | 0,07528 |
| Harnen | 0,01820 | 0,50180 | 0,86678 | 0,36498 |
| Islandia | 0,03000 | 0,52000 | 0,83597 | 0,31597 |
| Groenlandia | 0,02000 | 0,38000 | 0,61650 | 0,23650 |

| Ámbito | Población | PIB PPA | Impuestos netos | VAB | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- | --- | --- |
| Resto del Reino | 394,00000 M | 48,80000 | 2,25700 | 46,54300 | 78,92502 | 32,38202 |
| Unidades externas | 42,50000 M | 7,00000 | 0,31820 | 6,68180 | 11,72085 | 5,03905 |
| Reino | 481,00000 M | 58,50000 | 2,70390 | 55,79610 | 95,47964 | 39,68354 |
| Agregado operativo ECON-03 | 523,50000 M | 65,50000 | 3,02210 | 62,47790 | 107,20049 | 44,72259 |

A092 regulariza 23 cuentas y 230 registros sectoriales: 14 unidades del Reino, ocho federales externas y Harnen como protectorado operativo. Los objetivos son 481 millones y 58,50 billones del Reino; 515,5 y 64,98 constitucionales; 523,5 y 65,50 operativos. Islandia y Groenlandia tienen matrices nuevas de planificación. Los resúmenes anteriores de 21 cuentas no constituyen el cierre vigente.

A092 regulariza 23 cuentas y 230 registros sectoriales: 14 unidades del Reino, ocho federales externas y Harnen como protectorado operativo. Los objetivos son 481 millones y 58,50 billones del Reino; 515,5 y 64,98 constitucionales; 523,5 y 65,50 operativos. Islandia y Groenlandia tienen matrices nuevas de planificación. Los resúmenes anteriores de 21 cuentas no constituyen el cierre vigente.

### Agricultura valinari, 1000–500 a. C.

La agricultura es la base demográfica y política valinari. Se concentra en Escania, el Oslofjord, el sur de Noruega y Trøndelag; el norte complementa con pesca, ganadería, pieles y productos forestales.

### Cultivos y ganadería

Se cultivan cebada, trigo, centeno, avena, habas, guisantes, lentejas, lino, cebollas, coles, hierbas medicinales y plantas tintóreas. La cebada resiste mejor; el trigo exige mejores tierras; el lino proporciona fibras, cuerdas, redes, velas, aceites y vendajes.

Se crían bovinos, ovejas, caballos, cerdos, cabras, aves y abejas. El ganado aporta carne, leche, cuero, lana, tiro, estiércol, miel y cera. Los caballos se reservan también para transporte, mensajería, exploración y guerra.

### Regiones y técnicas

El suroeste de Escania produce cereales, lino, legumbres y ganado; el noreste combina agricultura, bosques, humedales, sal y pesca; el sureste articula cereales, pesca y comercio báltico. El Oslofjord, Vestfold, Østfold, Agder y Rogaland combinan cultivos, pesca y madera; Hordaland, Sogn y Møre dependen de valles, terrazas y ganado; Trøndelag es un centro agrícola septentrional.

Se utilizan arados, rejas, hoces, azadas, hachas, palas, rastrillos, trillos, carros y yugos. Las técnicas incluyen rotación parcial, barbecho, estiércol, quema controlada, drenaje, cercas, almacenamiento elevado y animales de tiro. La productividad sigue limitada por clima, suelo, mano de obra y herramientas.

### Tierra, graneros y autoridad

La tierra se distribuye entre familias, aldeas, Casas, santuarios, comunidades portuarias, pastos compartidos y bosques regulados. Las Casas Mayores deben mantener caminos, defensas, fuentes, graneros, semillas y ganado reproductor.

Los graneros comunales almacenan cereal, legumbres, semillas, sal, carne seca, pescado, aceite, herramientas y forraje. Exigen inventarios, pesos, supervisión y reservas de invierno; también funcionan como crédito de semillas y alimentos.

Una Casa puede controlar reservas para alimentar puertos, sostener ejércitos y negociar apoyo, pero no puede utilizar legítimamente el hambre como arma. Se protegen graneros, campesinos, fuentes, semillas, animales reproductores, mercados y rutas. El saqueo o la retención deliberada se sancionan como abuso y ruptura del pacto.

### Religión, comercio y crisis

Los santuarios custodian semillas, registran tierras, protegen fuentes, bendicen la siembra, median disputas y distribuyen reservas. Escania exporta cereales, lino, ganado y lácteos; Noruega aporta pescado, pieles, madera y grasa; Dinamarca intermedia entre Báltico y mar del Norte.

Entre 1000 y 990 a. C. las guerras interrumpen siembra, semillas y graneros. Después de Forostar se protegen fuentes y reservas; entre 950 y 700 a. C. se recuperan tierras e intercambios; entre 700 y 550 a. C. el abastecimiento se vuelve estratégico. Desde 550 a. C. la Corona coordina graneros, rutas y reservas durante emergencias, respetando derechos locales.

La agricultura es regional, intensiva en trabajo y dependiente del clima, pero sostiene la población, los puertos, las Casas y la monarquía pactista posterior.

### Producción agrícola valinari, 500 a. C.–500 d. C.

La producción agrícola constituye la base material de la sociedad valinari durante todo el periodo. Aunque el poder estratégico depende de la navegación, ninguna armada, ciudad o fortaleza puede sostenerse sin cereales, ganado, fibras, madera, agua y reservas de emergencia.

##### Organización de la producción

La tierra se distribuye entre:

- explotaciones familiares;

- tierras comunales;

- dominios de las Casas;

- granjas de santuarios;

- tierras de la Corona;

- colonias agrícolas portuarias;

- huertos urbanos;

- pastos de uso compartido.

Las Casas administran tierras y cobran parte de la producción, pero los pactos limitan su capacidad de destruir cosechas, impedir el acceso al agua o utilizar el hambre como arma política. Los santuarios registran lindes, deudas, herencias, calendarios y derechos de riego.

##### Cultivos principales

Los cultivos fundamentales son:

- cebada;

- trigo;

- centeno;

- avena;

- legumbres;

- lino;

- cáñamo;

- hortalizas;

- frutas resistentes al clima;

- plantas medicinales;

- forraje.

La cebada y el centeno son esenciales en las regiones septentrionales porque toleran mejor los suelos y estaciones frías. El trigo tiene mayor valor ceremonial y comercial, pero exige mejores tierras y condiciones más favorables. La avena sirve para alimentación humana y forraje animal.

Las legumbres complementan los cereales y reducen la dependencia de una sola cosecha. El lino y el cáñamo se destinan a telas, redes, cuerdas, velas y materiales de navegación.

##### Ganadería

La ganadería aporta alimentos, transporte, fuerza de trabajo y materiales.

Se crían principalmente:

- bovinos;

- ovejas;

- caballos;

- cerdos;

- cabras;

- aves de corral.

El ganado bovino proporciona carne, leche, cuero y fuerza de tiro. Las ovejas aportan lana y carne. Los caballos se reservan para mensajería, transporte, reconocimiento y caballería limitada. Los cerdos son importantes en zonas boscosas, donde pueden alimentarse con bellotas y residuos.

La ganadería se combina con la agricultura: los animales aportan estiércol, y los campos producen forraje y residuos aprovechables.

##### Agricultura en Escania

Escania es el principal núcleo agrícola del periodo inicial. Sus tierras producen cereales, lino, legumbres y ganado. La cercanía de Forostar permite llevar rápidamente alimentos a:

- la capital;

- las guarniciones;

- los astilleros;

- los mercados;

- las expediciones navales.

La agricultura escaniana tiene alto valor político porque sostiene la capital y permite movilizar ejércitos sin depender completamente de importaciones.

##### Agricultura en Noruega

Noruega dispone de menos tierras cultivables continuas, pero aprovecha:

- valles;

- laderas bajas;

- fiordos;

- pequeñas llanuras costeras;

- pastos de verano;

- huertos protegidos.

Su producción se orienta a cebada, avena, hortalizas, ganado, ovejas, pescado y productos lácteos. La agricultura noruega se complementa con pesca, madera, pieles y navegación.

##### Agricultura en Dinamarca y el Báltico

Dinamarca y el Báltico funcionan como corredores agrícolas y comerciales. Producen cereales, ganado, lino, miel, pescado y madera. Las comunidades valinari utilizan estos territorios principalmente mediante comercio, tránsito, pactos y asentamientos, sin convertirlos automáticamente en origen de una Casa Mayor.

Los puertos bálticos redistribuyen:

- grano hacia el norte;

- madera hacia los astilleros;

- pescado hacia ciudades interiores;

- pieles y cera hacia mercados mediterráneos;

- herramientas hacia comunidades rurales.

##### Agricultura atlántica

En las islas atlánticas se introducen cultivos adaptados a cada clima. La prioridad inicial no es producir excedentes enormes, sino asegurar:

- agua;

- alimentos para tripulaciones;

- semillas;

- animales reproductores;

- huertos;

- forraje;

- reservas de emergencia.

Nosselië Toliva desarrolla agricultura subtropical, cultivos de huerta, frutales, pesca y ganadería adaptada. Tol Eressëa depende inicialmente de pesca, almacenamiento y pequeños cultivos. Groenlandia mantiene una agricultura muy limitada y depende de pesca, caza, productos marinos y convoyes.

Númenor combina agricultura, ganadería, huertos, pesca y producción naval. Su posición le permite recibir semillas, animales y herramientas de distintas regiones.

##### Agricultura de Valinor

Valinor desarrolla una producción más diversificada después de su incorporación progresiva. Sus principales actividades son:

- cereales templados;

- legumbres;

- ganadería;

- huertos;

- lino;

- madera;

- pesca costera;

- producción de forraje;

- agricultura alrededor de puertos y ríos.

Las primeras explotaciones se concentran cerca de la costa y de los ríos navegables. Con el tiempo, las comunidades agrícolas avanzan hacia valles y zonas interiores protegidas por fortalezas y caminos.

##### Tecnología agrícola

Durante el periodo se utilizan:

- arados de madera reforzada;

- rejas de hierro;

- azadas;

- hoces;

- rastrillos;

- carros;

- molinos manuales;

- molinos de agua en regiones adecuadas;

- graneros elevados;

- cercas;

- canales pequeños;

- cisternas;

- terrazas agrícolas.

La mejora más importante no es una sola invención, sino la acumulación de prácticas: rotación parcial, selección de semillas, uso de estiércol, almacenamiento seco, control de plagas y diversificación de cultivos.

##### Agua y riego

El control del agua es una función económica y política. Las comunidades construyen:

- pozos;

- cisternas;

- canales;

- presas pequeñas;

- estanques;

- drenajes;

- fuentes protegidas.

Los santuarios custodian algunas fuentes y regulan su uso mediante calendarios y pactos. Las Casas que controlan ríos o lagos pueden aumentar su poder, pero deben respetar los acuerdos de abastecimiento de aldeas, puertos y fortalezas.

##### Graneros y reservas

Los graneros se clasifican en:

- graneros familiares;

- graneros comunales;

- graneros de Casa;

- graneros militares;

- graneros de la Corona;

- depósitos portuarios.

Los graneros militares abastecen fortalezas y expediciones. Los graneros reales se utilizan durante hambrunas, guerras, malas cosechas o interrupciones del comercio.

El almacenamiento requiere:

- elevación sobre el suelo;

- ventilación;

- protección contra roedores;

- vigilancia;

- secado previo;

- registro de entradas y salidas.

Los archivos registran la cantidad, origen, calidad y destino del grano.

##### Fiscalidad agrícola

La Corona y las Casas reciben contribuciones en:

- grano;

- animales;

- lino;

- lana;

- madera;

- trabajo;

- transporte;

- servicio militar.

El impuesto no es uniforme. Las zonas agrícolas entregan principalmente alimentos; los puertos pagan tasas; las regiones mineras entregan metal; las Casas navales aportan barcos, tripulaciones y madera.

En años de malas cosechas, los tributos pueden reducirse o aplazarse. El incumplimiento deliberado de una Casa rica puede provocar arbitraje, sanciones o intervención de la Corona.

##### Trabajo agrícola

La producción combina:

- familias campesinas;

- trabajadores contratados;

- aprendices;

- dependientes de las Casas;

- comunidades comunales;

- personas esclavizadas;

- prisioneros de guerra;

- libertos y descendientes de libertos.

Las personas esclavizadas se utilizan especialmente en grandes dominios, trabajos pesados, canteras, drenajes, transporte y explotaciones intensivas. La religión y los pactos limitan progresivamente el trato, la separación familiar y la explotación extrema, pero no eliminan la institución durante todo el periodo.

##### Crisis agrícolas

Las principales crisis son:

- inviernos prolongados;

- sequías;

- lluvias excesivas;

- plagas;

- enfermedades del ganado;

- guerras;

- incendios de graneros;

- interrupción de rutas;

- pérdida de semillas;

- desplazamientos de población.

Las respuestas incluyen abrir graneros, importar alimentos, redistribuir ganado, reducir tributos, proteger convoyes, trasladar familias y recuperar tierras abandonadas.

##### Agricultura y ejército

La agricultura sostiene directamente la defensa. Las bases militares necesitan grano, carne, forraje, cuero, madera y animales. Por ello, las fortalezas se construyen cerca de:

- ríos;

- graneros;

- zonas ganaderas;

- rutas de transporte;

- puertos;

- valles agrícolas.

Una campaña militar que destruye cosechas puede ser una derrota estratégica aunque gane batallas. La doctrina valinari intenta proteger graneros y comunidades productivas, porque la capacidad de continuar la guerra depende de ellas.

##### Resultado económico

Entre 500 a. C. y 500 d. C., la agricultura valinari pasa de un sistema local y descentralizado a una red coordinada de granjas, graneros, puertos, rutas y depósitos militares. No se convierte en una agricultura industrial ni elimina las crisis, pero alcanza suficiente diversidad para sostener ciudades, armadas, guarniciones y expediciones oceánicas.

La siguiente distribución de llegadas forma parte del modelo: 87.500 entre 1000–650 a. C.; 35.000 entre 650–550 a. C.; 325.000 entre 550–50 a. C.; 472.500 entre 50–500 d. C.; y 375.000 entre 500–800 d. C. Estas cifras son una escala canónica de planificación, no una cuota migratoria obligatoria ni un censo documental exacto.

### Canal de Panamá y crisis de construcción entre 1845 y 1872

El Canal de Panamá es una obra de Panamá Federal (Panamá), territorio integrante de Aranath Valinor. El canal, su autoridad operativa y su cuenca tienen funciones diferenciadas dentro de ese marco político. Ninguna concesión comercial o deuda transfiere soberanía a una compañía o potencia extranjera.

##### Estudios y preparación entre 1845 y 1862

Entre 1845 y 1852 se realizan estudios, levantamientos, ensayos y organización inicial de las obras. Las intervenciones preparatorias se distinguen de la excavación principal. Entre 1852 y 1862 se amplían ferrocarriles de servicio, muelles, talleres, campamentos, depósitos y drenajes.

El reclutamiento reúne trabajadores de varios territorios con contratos y condiciones diferentes. El Estatuto de Nombres y Continuidad Civil de 1850 introduce garantías de identificación, filiación documental, correspondencia de nóminas y reclamación. No sustituye nombres familiares por denominaciones impuestas ni modifica por sí solo la pertenencia a una Casa.

Los registros deben permitir comprobar identidad, salarios, obligaciones, accidentes y personas a cargo. Las expropiaciones y reasentamientos requieren expedientes territoriales y compensación conforme al régimen del periodo; su aplicación produce conflictos y abusos.

##### Crisis del Canal entre 1858 y 1868

Las dificultades aparecen antes de concluir la infraestructura preparatoria y continúan durante la excavación principal de 1862–1868. Los presupuestos iniciales subestiman drenaje, inestabilidad del terreno, enfermedad, vivienda, abastecimiento y mantenimiento de maquinaria.

Los retrasos, impagos y pérdidas sanitarias afectan a campamentos, proveedores y familias. La crisis comprende suspensiones y reorganizaciones parciales; no impone diez años de paralización total ni anula el calendario aprobado de obras.

Las asociaciones de trabajadores reclaman pago e identificación verificables, condiciones de alojamiento y atención a enfermos. Las autoridades territoriales cuestionan compensaciones, uso del agua y responsabilidades. La respuesta combina investigación financiera, revisión de contratos, intervención sanitaria y reorganización técnica.

Las medidas sanitarias se describen según el conocimiento disponible: agua potable, saneamiento, drenaje, vivienda y observación de enfermedades. Su eficacia puede preceder a una explicación completa de los mecanismos de transmisión; no se presume microbiología o medicina contemporánea plenamente desarrolladas.

##### Reorganización y pruebas entre 1868 y 1872

En 1868 se establece una autoridad operativa reorganizada para coordinar terminación, pruebas y mantenimiento. Sus competencias técnicas están sujetas a las autoridades políticas y territoriales. Se distinguen contratación y pagos, supervisión de seguridad, reclamaciones laborales y justicia civil.

Los costes se revisan para incorporar salud, vivienda, ferrocarril, reparación y reposición. La financiación combina recursos públicos, deuda autorizada y contratos regulados. Los acreedores no adquieren policía, aduanas ni jurisdicción territorial por financiar la obra.

Entre 1868 y 1872 se completan pruebas hidráulicas, formación, ajustes y tránsito controlado. La apertura operativa de 1872 inicia un servicio que requiere mantenimiento continuo y posteriores mejoras.

##### Peajes cuenca y participación territorial

Los ingresos atienden operación, deuda, reparación, dragado, reservas para averías y obligaciones territoriales. Las tarifas se publican y las excepciones requieren autorización; no se confunde peaje del canal con arancel comercial.

La cuenca abastece también a población, agricultura y ecosistemas. Su administración debe registrar demanda, reservas, sequías y daños, con mecanismos de participación y reclamación acordes al periodo. Las restricciones de agua, un accidente o una avería pueden reducir capacidad sin cerrar todo el corredor.

El control civil panameño continúa después de la apertura y de la reforma federal de 1958. La cooperación con Chile y la ruta de Magallanes complementan la red interoceánica bajo sus tratados propios. El desarrollo del canal refuerza comercio e industria, pero no modifica por sí solo los agregados económicos de 2026 ya conciliados en ECON-03.

### Consolidación de las actualizaciones acumulativas, 500 a. C.–500 d. C.

Estado: [CANON VIGENTE] — consolidación demográfica, militar, territorial y económica.

Se integran formalmente las actualizaciones acumulativas relativas a la relación con Roma, la talasocracia defensiva, el ejército territorial, las bases militares, Forostar (Helsingborg) como capital política, Númenor como capital naval oceánica, la agricultura, la fiscalidad, el comercio, el trabajo y la secuencia atlántica.

La consolidación no convierte automáticamente una estación comercial en provincia ni proyecta las fronteras federales modernas sobre la Antigüedad. Cada territorio conserva el estatus histórico correspondiente a su fase: estación, factoría, puerto asociado, enclave, protectorado, asentamiento o territorio incorporado.

##### Tipos de explotación agrícola conocidos

La red comercial permite que los valinari conozcan y adapten varios modelos: agricultura cerealista septentrional; agricultura mixta de cereales, legumbres, lino y ganadería; campos abiertos y rotación; agricultura de valles y fiordos; terrazas; regadío; huertos intensivos; agricultura de frontera; agrosilvicultura; ganadería trashumante; agricultura insular de subsistencia; y cultivos mediterráneos de vid, olivo, huerta y regadío.

Los conocimientos se transmiten mediante comercio, comunidades migrantes, matrimonios, observación, archivos agrícolas y adaptación local. Conocer un modelo no significa poder aplicarlo sin modificaciones: cada sistema depende del clima, el suelo, el agua, las herramientas y la mano de obra.

##### Modelo agrícola más eficiente

No existe un único sistema óptimo para todo Valinor. El modelo más eficiente es un sistema mixto regional, basado en cereales resistentes, rotación, legumbres, ganadería, huertos, agrosilvicultura, pesca y almacenamiento distribuido.

Su combinación principal es:

1. cereal resistente como base calórica;

2. legumbres para complementar la dieta y recuperar el suelo;

3. lino y cáñamo para telas, redes y velas;

4. ganado para carne, leche, cuero, estiércol y transporte;

5. huertos para semillas, vitaminas y plantas medicinales;

6. árboles y bosques productivos para madera, frutos y resinas;

7. graneros comunales, de Casa y militares;

8. pesca y conservación de alimentos como complemento marítimo.

| Región | Modelo más eficiente | Función principal |
| --- | --- | --- |
| Escania | agricultura mixta cerealista | abastecer Forostar y el núcleo político |
| Noruega | valles, pastos, ganadería y pesca | combinar recursos en un territorio fragmentado |
| Dinamarca y Báltico | campos abiertos y cereales | producir excedentes y sostener rutas |
| Nosselië Toliva | huerta intensiva y agricultura subtropical | alimentar puertos y convoyes |
| Systreyjar | agricultura insular mixta | asegurar agua, ganado y reservas |
| Tol Eressëa | cultivos resistentes, pesca y huertos | sostener una estación oceánica |
| Groenlandia | pesca, caza y horticultura protegida | sobrevivir en un clima severo |
| Númenor | agricultura mixta y producción portuaria | abastecer el principal centro naval |
| Valinor | cereal, ganadería, huerta y agrosilvicultura | aprovechar valles, costas y diversidad territorial |
| Malta y Chipre | regadío, olivo, vid y huerta | abastecer escalas mediterráneas |
| Egipto | regadío fluvial y cereal | obtener excedentes y comerciar con Roma |
| Adén y Socotra | oasis, huerta protegida y comercio | sostener escalas en rutas áridas |

##### Validación de coherencia

La integración es coherente si Forostar mantiene la capitalidad política hasta la consolidación occidental posterior, Númenor funciona como capital naval sin sustituir inmediatamente a la Corona, las estaciones atlánticas no se convierten automáticamente en provincias y la agricultura se adapta regionalmente.

La producción agrícola sostiene las cifras demográficas revisadas, pero las llegadas migratorias brutas no se suman mecánicamente a la población total. La población local cambia de categoría por territorio y por periodo, no simultáneamente en todo el sistema valinari.

### Logística, ganadería y recursos

#### logística, educación material, ganadería y recursos

##### Logística naval y escalas tempranas

La navegación valinari se analiza mediante cadenas materiales completas: casco, aparejo, tripulación, agua, alimentos, forraje, repuestos, carga, mantenimiento, escalas, regreso y recepción de personas. Se distinguen embarcaciones de servicio, mercantes regionales, mercantes de travesía, naves ligeras y naves de combate o transporte militar. Estas son funciones graduales, no clases reglamentadas desde 1000 a. C.

La disponibilidad de un casco no demuestra que una misión sea posible. Cada expedición debe distinguir reconocimiento, comercio, migración, auxilio, coerción, conquista y establecimiento. Una escala puede ofrecer agua, refugio, intercambio, reparación o información sin convertirse automáticamente en puerto principal, astillero, base naval o territorio soberano.

El cálculo de una misión futura debe registrar personas por función, peso y volumen de las cargas, reservas, animales, tiempos de navegación y espera, reposiciones, alternativas y obligaciones de llegada. No se incorporan retrospectivamente brújulas, cronómetros, cartas modernas, artillería posterior ni diseños históricos completos. La vela temprana es una divergencia técnica adoptada, pero su desarrollo concreto permanece gradual y sujeto a recursos.

##### Educación aplicada a la economía material

Las escuelas, academias, talleres, astilleros, observatorios, hospitales y universidades se integran en la producción de capacidades. La educación forma navegantes, hidrógrafos, meteorólogos, médicos, constructores navales, contables, técnicos, especialistas en mantenimiento, administradores de almacenes y responsables de calidad.

La continuidad educativa reduce pérdidas de conocimiento y acelera la adaptación, pero no elimina límites de madera, metal, combustible, alimentos, mano de obra, capital o transporte. La superioridad valinari procede de coordinar educación, investigación, producción, comercio y crédito, no de suponer que toda región o tecnología está igualmente adelantada.

##### Ganadería y abastecimiento

Vacunos, caprinos, ovinos y equinos se incorporan gradualmente según las necesidades y posibilidades de cada establecimiento. El traslado de animales exige espacio, estabilidad, agua, alimento, limpieza, manejo, forraje y recepción segura. Los animales reproductores, de trabajo y destinados al consumo cumplen funciones distintas y no deben contabilizarse como una sola reserva.

La ganadería complementa agricultura, pesca y conservación, pero compite por agua, pastos, bosques y mano de obra. La presencia de ganado no implica abundancia permanente de carne, caballos disponibles para toda expedición ni una dieta uniforme. Las crisis pueden obligar a sacrificar animales, conservar reproductores o priorizar animales de trabajo.

En islas y territorios con población previa se distinguirán especies locales, ganado introducido, apropiación de rebaños, intercambio, conquista y colonización. La llegada valinari no se describirá como un proceso idéntico en todos los territorios, y sus efectos sanitarios, ecológicos y sociales deberán analizarse por región.

##### Recursos naturales y metales

El catálogo económico separa seis estados: presencia geológica, conocimiento, accesibilidad, extracción, transformación y producción. Un yacimiento posible no equivale a una mina conocida; una mina conocida no equivale a producción sostenida; y la posesión de metal en un puerto no prueba extracción local.

Hierro y cobre sostienen herramientas, talleres y necesidades navales; estaño, plomo, plata y oro requieren rutas, técnicas y escalas de explotación específicas. La producción metalúrgica consume trabajadores, alimentos, combustible, madera, transporte y tiempo. La minería compite con agricultura, pastos, bosques y construcción, por lo que no se supone que los recursos sean ilimitados.

Se mantiene la corrección territorial: Númenor corresponde a Terranova y Tol Eressëa es una entidad distinta. No se trasladan automáticamente a Tol Eressëa los recursos de Terranova, Labrador u otras regiones continentales. Las fechas de descubrimiento, explotación, reservas y producción permanecen abiertas hasta una ficha regional específica.

### Economía antigua, 500 a. C.–500 d. C.

#### Economía valinari, 500 a. C.–500 d. C.

La economía valinari evoluciona desde un sistema descentralizado de Casas agrícolas y marítimas hacia una economía portuaria, naval y territorial. Sus cuatro bases permanentes son la agricultura, la ganadería, la metalurgia y el comercio marítimo.

##### 500–300 a. C.: Casas, graneros y producción local

Cada Casa controla una combinación de tierras, bosques, minas, talleres, aldeas, puertos y rutas. Forostar (Helsingborg) concentra la redistribución de grano, madera, hierro, pieles, sal, pescado, ganado, armas y herramientas.

La agricultura produce cebada, trigo, centeno, avena, legumbres y lino, además de ganado bovino, ovejas, caballos y cerdos. Los graneros comunales adquieren importancia política porque permiten financiar campañas, alimentar guarniciones y sostener ciudades durante malas cosechas.

La metalurgia produce arados, cuchillos, hachas, clavos, herrajes, armas, herramientas navales y piezas de reparación. La madera, la resina, la brea y el carbón vegetal son recursos estratégicos para viviendas, fortificaciones, carros y barcos.

##### 300–50 a. C.: expansión comercial

La expansión hacia el Báltico, el mar del Norte y el Mediterráneo aumenta los ingresos y la desigualdad entre Casas. Forostar se convierte en centro de tasas, almacenamiento, registros de mercancías, contratación de tripulaciones y financiación de expediciones.

Las exportaciones principales son madera naval, hierro, herramientas, armas, pieles, cera, pescado salado, sal, lino, ámbar, cuerdas, embarcaciones e instrumentos de navegación. Las importaciones incluyen vino, aceite, cerámica, vidrio, tejidos, especias, frutas mediterráneas, monedas, tintes y bienes de lujo.

##### Fiscalidad y obligaciones

La fiscalidad combina entregas de grano, animales, madera, hierro, servicio naval, servicio militar, peajes, tasas portuarias, derechos de mercado y contribuciones de las Casas. No existe todavía una administración uniforme: cada región conserva sus costumbres, pero la Corona y el Consejo exigen contribuciones para defensa, arsenales, puertos, caminos, santuarios y mensajería.

Las Casas intentan reducir sus obligaciones ocultando producción y población. Para limitarlo, los santuarios y archivos conservan inventarios, genealogías, contratos, derechos de propiedad, registros de barcos y deudas.

##### a. C.–200 d. C.: economía atlántica

La incorporación progresiva de Tol Eressëa, Groenlandia, Númenor y Valinor añade pesca, navegación de altura, reparación, cartografía, agricultura de frontera, almacenamiento y comercio de larga distancia.

Númenor concentra astilleros, escuelas de navegación, depósitos, mapas, formación de marineros y reexportación. Tol Eressëa funciona primero como estación de agua, pesca, reparación y observación. Groenlandia depende de convoyes para metal, madera, grano, herramientas y medicinas. Valinor inicia su desarrollo con pesca, agricultura costera, madera, minería, ganadería y puertos.

##### Comercio con Roma

Roma compra madera, hierro, herramientas, pieles, cera, pescado, ámbar, lino, piezas navales, pilotos e información marítima. Valinor recibe aceite, vino, cerámica, vidrio, moneda, tejidos, productos agrícolas, artículos de lujo y técnicas administrativas.

El comercio romano no subordina políticamente a Valinor. La relación proporciona acceso a mercados, moneda y productos mediterráneos, mientras Valinor conserva control sobre sus rutas atlánticas y recursos septentrionales.

##### Trabajo y dependencia

La economía utiliza campesinos libres, artesanos, aprendices, trabajadores contratados, siervos por deuda, prisioneros de guerra, personas esclavizadas y comunidades dependientes. La esclavitud se concentra en minería, canteras, agricultura intensiva, construcción, transporte, talleres, puertos y servicio doméstico.

Los pactos y la religión limitan progresivamente la tortura, el asesinato, la explotación sexual, la separación arbitraria de familias y la venta de niños, aunque estas prohibiciones no eliminan la esclavitud durante el periodo. La manumisión produce libertos urbanos, trabajadores protegidos, comunidades portuarias y población mestiza.

##### 200–300 d. C.: crisis y diversificación

Las epidemias, la piratería, las guerras civiles romanas, la interrupción de rutas y la escasez de metales reducen el comercio mediterráneo. Valinor responde con reservas de grano, rutas atlánticas alternativas, depósitos descentralizados, producción local de herramientas y reparación de barcos en bases regionales.

##### 300–500 d. C.: economía territorial

El núcleo septentrional produce hierro, madera, pieles, pescado, grano, ganado y herramientas. La red atlántica ofrece agua, reparación, transporte e información. Númenor produce buques, mapas, velas y bienes de redistribución. Valinor desarrolla agricultura, ganadería, minería, astilleros, ciudades portuarias y fortificaciones. El Mediterráneo y el mar Rojo suministran aceite, vino, textiles, especias, metales y mercados.

##### Especialización de las Casas

Las Casas agrícolas controlan graneros, ganado, tierras y semillas. Las metalúrgicas controlan minas, hornos, herrerías y armas. Las navales administran astilleros, madera, brea, velas y tripulaciones. Las Casas de estudio custodian archivos, mapas, calendarios y manuales. Las Casas exploratorias gestionan expediciones, estaciones, mercados y rutas.

La Casa Real Telcontar supervisa arsenales reales, rutas estratégicas, moneda, contribuciones, graneros de emergencia, bases militares y acuerdos comerciales.

##### Balance económico

Valinor no supera a Roma en población ni volumen económico total. Su ventaja reside en el control de rutas, puertos, productos navales y recursos estratégicos. La economía valinari es más pequeña, pero está diversificada y diseñada para resistir bloqueos mediante redes insulares, convoyes, depósitos y producción regional.

#### Profundización de la producción agrícola, 500 a. C.–500 d. C.

La agricultura valinari no utiliza un único modelo. La red comercial permite conocer sistemas septentrionales, mediterráneos, fluviales, insulares, de terrazas, de regadío y de plantación, pero cada uno se adapta al clima, al suelo, al agua, a la mano de obra y a la distancia de los mercados.

##### Modelos agrícolas conocidos

- Agricultura cerealista septentrional: cebada, centeno, avena y trigo resistente.

- Campos abiertos y rotación: parcelas familiares y de Casa, pastos comunes y barbecho parcial.

- Agricultura mixta: cereales, legumbres, lino, huerta, árboles y ganadería.

- Agricultura de valles y fiordos: cultivos pequeños combinados con pastos, pesca y ganado.

- Agricultura de terrazas: aprovechamiento de laderas mediante muros, drenajes y canales.

- Regadío: pozos, cisternas, acequias, estanques y canales en regiones secas o fluviales.

- Huertos intensivos: verduras, frutas, semillas y plantas medicinales cerca de ciudades y fortalezas.

- Agrosilvicultura: cultivos, pastos, árboles, frutos, resinas, leña y madera naval.

- Ganadería trashumante: traslado estacional entre llanuras, valles y pastos altos.

- Agricultura insular: cultivos resistentes, pesca, cabras, ovejas, aves y almacenamiento de agua.

- Agricultura mediterránea: vid, olivo, frutas, huerta y cereal de regadío.

- Agricultura de plantación: cultivos concentrados de exportación en territorios cálidos y portuarios.

- Agricultura de frontera: creación gradual de huertos, graneros, aldeas y campos alrededor de bases y puertos.

##### Aplicación territorial

| Región | Modelo dominante | Finalidad |
| --- | --- | --- |
| Escania | agricultura mixta cerealista y ganadería | abastecer Forostar y el núcleo político |
| Noruega | valles, pastos, ganadería y pesca | combinar recursos en un territorio fragmentado |
| Dinamarca y Báltico | campos abiertos, cereales y lino | producir excedentes y sostener rutas |
| Mar del Norte | agricultura costera y ganadería | asegurar comunidades expuestas al mar |
| Systreyjar | agricultura insular diversificada | mantener agua, ganado y reservas |
| Nosselië Toliva | huerta intensiva, regadío y cultivos subtropicales | alimentar puertos y convoyes |
| Tol Eressëa | pesca, huertos y cultivos resistentes | sostener una estación oceánica |
| Groenlandia | pesca, caza y horticultura protegida | sobrevivir en un clima severo |
| Númenor | agricultura mixta, bosques, pesca y ganadería | abastecer el centro naval |
| Valinor | cereales, legumbres, ganado, huerta y agrosilvicultura | aprovechar la diversidad territorial |
| Malta | regadío, olivo, vid y huerta | abastecer una escala mediterránea |
| Chipre | cereal, olivo, vid y frutales | sostener comercio y puertos orientales |
| Egipto | regadío fluvial y cereal | obtener excedentes exportables |
| Adén | oasis, huertas protegidas y comercio | abastecer rutas áridas |
| Socotra | huerta, ganado pequeño y comercio | mantener una estación insular |

##### Modelo agrícola más eficiente

El modelo más eficiente para el territorio valinari es un sistema mixto regional basado en:

1. cereales resistentes como base calórica;

2. legumbres para la dieta y la recuperación del suelo;

3. lino y cáñamo para telas, redes y velas;

4. ganado para alimentos, cuero, estiércol, transporte y tracción;

5. huertos para semillas, vitaminas y medicinas;

6. bosques productivos para madera, frutos, resinas y leña;

7. graneros familiares, comunales, militares y reales;

8. pesca y conservación de alimentos como complemento marítimo;

9. regadío localizado en regiones secas o fluviales;

10. rotación y agrosilvicultura para mantener la fertilidad.

Este modelo es más resistente que la agricultura de plantación o el monocultivo porque reduce el riesgo de hambruna, sostiene ciudades y ejércitos, distribuye la producción y permite resistir bloqueos. La eficiencia valinari no consiste en que cada provincia sea autosuficiente, sino en que el conjunto intercambie excedentes y compense déficits.

##### Agricultura, defensa y expansión

Las fortalezas se sitúan cerca de ríos, graneros, pastos, puertos y rutas. Una base militar sin alimentos cercanos depende demasiado de convoyes. Por eso las nuevas incorporaciones territoriales siguen una secuencia: reconocimiento de suelo y agua, huertos, animales, cereales, graneros, caminos, aldeas y conexión portuaria.

La destrucción de una cosecha puede constituir una derrota estratégica aunque se gane una batalla. La defensa agrícola es, por tanto, parte de la defensa militar y de la continuidad política del Reino.

### Agua alimentos y límites del poblamiento

#### Capacidad territorial

La superficie de una isla no determina por sí sola la población que puede sostener. Suelo, pendiente, lluvias, agua almacenable, herramientas, mano de obra y acceso al mar condicionan el cultivo. Los habitantes, el ganado, los talleres y los barcos compiten por la misma agua en las estaciones secas. La administración compara esos usos antes de asignar nuevas colonias o guarniciones.

La agricultura mixta regional ya adoptada combina cereales resistentes, legumbres, huertos, ganado, pesca y aprovechamiento forestal. Una técnica conocida por traducción o comercio solo se adopta cuando existen clima, materiales y trabajo adecuados. El olivo, la vid, los cereales templados y los cultivos tropicales requieren evaluaciones diferentes; la red marítima permite intercambiar alimentos y semillas sin convertir todas las provincias en autosuficientes.

#### Reservas y distribución

El granero registra entradas, humedad, plagas, rotación y pérdidas. Su existencia reduce el riesgo de una mala cosecha cuando contiene grano utilizable y puede transportarlo hasta quienes lo necesitan. Las reservas de semillas y forraje se separan del consumo inmediato. Usarlas para cubrir una emergencia sin reposición puede convertir una crisis de un año en dos cosechas deficitarias.

Puertos, caminos y depósitos conectan excedentes con zonas deficitarias. La importación estable de alimentos permite sostener ciudades especializadas, aunque aumenta la dependencia de convoyes y financiación. Los precios y las raciones deben observarse junto a las existencias: un almacén lleno puede coexistir con hambre si el acceso económico o jurídico impide distribuir su contenido.

#### Ganadería y asentamiento

Vacunos, ovinos, caprinos, equinos y otros animales del canon cumplen funciones de alimentación, transporte, abono, fibras y tracción. Su introducción depende de barcos, corrales, agua, reproducción y disponibilidad de pasto. La expansión de rebaños puede desplazar huertos, erosionar laderas o competir por reservas invernales. El rendimiento del conjunto se mide incluyendo esos costes.

#### Enlace con el modelo demográfico

Se conserva la cifra central adoptada de aproximadamente 8 millones en 800 d. C. y la migración no nórdica equivalente al 60 % de la nórdica. La reclasificación de una persona entre categorías censales cambia los subtotales, con efecto neto cero en la población total si no modifica el perímetro del censo. El crecimiento agregado procede de nacimientos, defunciones, entradas, salidas e incorporación de poblaciones residentes de nuevos territorios.

La distribución geográfica y el grado de urbanización se registran en ejes distintos: una ciudad puede estar dentro del territorio central. Los intervalos centrales, agrícolas, portuarios y periféricos del modelo son orientaciones, no cuatro porcentajes que deban sumarse sin revisar solapamientos. La serie demográfica de v050 para 1200 queda como antecedente sujeto al perímetro V16, sin reintroducir su mapa insular.

Desarrollo: 08_Economia/Agua alimentos y límites del poblamiento.

### Historia integrada del corredor interoceánico

#### Caminos antes del canal

El corredor panameño se desarrolla primero mediante puertos, caminos, depósitos, transbordo y servicios de reparación. El Camino Interoceánico de la etapa moderna temprana no es un canal navegable. La coordinación de cargamentos entre dos costas exige contratos, porteadores, animales, caminos y recepción portuaria, de modo que una mejora local puede aumentar el tránsito sin abrir todavía una vía acuática continua.

Panamá pertenece al marco territorial de Aranath Valinor definido por V16. Las fuentes sobre integración o cooperación no crean una independencia panameña ni una cesión automática de la cuenca a una compañía. Las instituciones comunes y territoriales conservan sus respectivas responsabilidades.

#### Estudios y construcción

Los antecedentes de estudio se desarrollan entre 1768 y 1800 y en las revisiones del siglo XIX. Desde 1845 se ejecutan levantamientos, pruebas e infraestructura preparatoria; ferrocarriles de servicio, talleres y drenajes sostienen después la excavación principal. La apertura canónica de 1872 se conserva dentro de la divergencia industrial ya adoptada.

La crisis de 1858–1868 revela presupuestos incompletos, terrenos inestables, enfermedad, dificultades de vivienda, impagos y reparación insuficiente. La respuesta combina revisión financiera, contratos, abastecimiento y reorganización técnica. El fracaso de una sección no implica diez años de paralización uniforme de toda la obra.

La autoridad reorganizada en 1868 coordina pruebas, formación, terminación y mantenimiento. Debe poder distinguir lo que ordena una empresa, lo que autoriza la autoridad territorial y lo que financia el gobierno común. Los acreedores tienen derechos de cobro sujetos a contrato; no adquieren policía, aduanas ni soberanía por financiar excavaciones.

#### Operación y cuenca

Los peajes cubren funcionamiento, deuda, dragado, reposición y reservas para averías conforme a las decisiones presupuestarias. El ingreso bruto del canal se diferencia del excedente disponible. La operación requiere personal entrenado y repuestos incluso cuando el tráfico cae.

La cuenca aporta agua a población, agricultura, ecosistemas y tránsito. El consejo hidrológico y los servicios técnicos proporcionan información; la autoridad operativa no absorbe por ese motivo la justicia municipal ni todos los derechos de uso del agua. Las sequías, accidentes o trabajos de mantenimiento pueden limitar el servicio y deben incorporarse a las previsiones de capacidad.

#### Dos rutas y continuidad

Panamá y la ruta austral ofrecen alternativas con costes y tiempos distintos. La cooperación con Chile sigue las fechas e instrumentos jurídicos del Canon V16; las fechas incompatibles del manuscrito v050 no las sustituyen. La coordinación logística no fusiona mandos nacionales ni añade buques a los inventarios. El efecto económico del corredor se explica por transporte, seguros, industria y servicios, sin alterar automáticamente las cuentas de 2026 conciliadas en ECON-03.

Desarrollo: 08_Economia/Historia integrada del corredor interoceánico.

## Moneda, banca y fomento

### Historia monetaria y fiscal valinari

La economía valinari combina producción doméstica, obligaciones de Casa, mercados y comercio marítimo. Su monetización avanza de manera desigual: un puerto puede liquidar contratos en metal mientras una aldea próxima paga contribuciones en grano o trabajo. La unidad de cuenta utilizada en un registro, la moneda entregada y la autoridad que garantiza el pago son realidades distintas.

##### Intercambio y obligaciones entre 1000 y 300 a. C.

Los hogares y las Casas intercambian alimentos, ganado, madera, hierro, tejidos y servicios. Las deudas se expresan mediante equivalencias locales y se acreditan con testigos, marcas y registros custodiados en santuarios. La Corona Occidental, el Concilio y, después de 560–550 a. C., la Casa Telcontar coordinan contribuciones pactadas. La existencia de esa autoridad común no significa que todo el Reino utilice una moneda uniforme.

Las contribuciones ordinarias sostienen graneros, arsenales, refugios y rutas; las extraordinarias requieren los acuerdos políticos correspondientes. Debe distinguirse el tributo registrado de la apropiación privada por un recaudador o una Casa.

##### Cuentas portuarias entre 300 a. C. y 700 d. C.

Los mercaderes emplean unidades de peso y cuenta para valorar cargamentos, anticipos y pérdidas. Circulan monedas extranjeras y medios de pago locales bajo equivalencias variables. Los escribas registran cantidad, calidad del metal, vencimiento y lugar de liquidación; los tribunales portuarios resuelven disputas sobre entrega y responsabilidad.

La Fragmentación reduce la circulación y el acceso regional a los registros. Los archivos principales conservan el conocimiento depositado mediante las Siete Copias. La recuperación restaura copias y conexiones, contrasta testimonios y revisa títulos, en lugar de considerar extinguida una obligación por la pérdida de un documento local.

##### Crédito marítimo entre 700 y 1512

Las expediciones combinan aportes de las Casas, participaciones mercantiles, anticipos sobre carga y convenios de reparto de pérdidas. Las primeras coberturas son acuerdos entre participantes, con exclusiones y garantías limitadas; su evolución hacia seguros especializados es gradual.

Capitanes, pilotos y financiadores disponen de información desigual. El registro de contratos, los inventarios de salida y llegada y el arbitraje portuario reducen ciertos abusos, aunque no eliminan naufragios, fraude ni insolvencia. Los Consejos Atlánticos permanentes desde 1135 coordinan rutas y contribuciones dentro de una monarquía ya existente.

##### Cajas comunes entre 1512 y 1705

Los acuerdos posteriores a 1512 amplían la Secretaría Común, las cuentas interterritoriales y los fondos para navegación, archivos y emergencias. Estos órganos desarrollan la administración de la Corona y los pactos territoriales. Los ingresos proceden de contribuciones autorizadas, derechos portuarios y servicios; no conceden soberanía a compañías o acreedores.

##### Normalización desde 1705 y Crisis Financiera de Armenelos

La Carta de 1705 fortalece reglas comunes de contabilidad, emisión, presupuesto y rendición de cuentas. La normalización admite una transición con monedas locales y equivalencias autorizadas; no se interpreta como la primera existencia de moneda o crédito valinari.

Entre 1736 y 1750, la expansión del crédito manufacturero y marítimo en Armenelos provoca una crisis financiera. Algunos intermediarios comprometen varias veces las mismas garantías, financian proyectos largos con depósitos exigibles y ocultan pérdidas. Los retrasos de pago afectan a talleres, salarios, abastecimiento y pequeños ahorradores.

##### Evolución financiera comparada

El sistema financiero valinari combina la banca mercantil y el crédito marítimo de Venecia, la inversión colectiva, los seguros y el comercio global de Holanda, la deuda pública y el Estado fiscal-militar de Inglaterra y la banca federal, la escala industrial, la investigación aplicada y el mercado continental de Estados Unidos. Sus equivalentes funcionales aparecen aproximadamente un siglo antes, gracias a la continuidad educativa, documental, portuaria y naval. Esta anticipación no significa que existan bancos modernos, bolsas contemporáneas o empresas industriales completas desde la Antigüedad.

La secuencia institucional es: reservas y obligaciones de Casa entre 1000 y 500 a. C.; crédito portuario entre 500 y 50 a. C.; finanzas marítimas entre 50 a. C. y 500 d. C.; tesorerías y administración fiscal entre 500 y 900; sociedades mercantiles y contabilidad entre 1000 y 1200; cámaras de compensación, seguros y compañías entre 1200 y 1400; deuda pública entre 1400 y 1512; Tesorería interterritorial entre 1512 y 1600; autoridad monetaria funcional entre 1600 y 1705; banca de desarrollo e industrialización desde 1705; y sistema financiero federal integrado desde 1958.

La ventaja valinari no consiste en inventar cada institución de manera aislada, sino en conectarla antes con educación, investigación, producción, comercio, industria y Armada. La comparación histórica queda fijada así: Venecia representa la banca mercantil urbana; Holanda, la inversión y el comercio global; Inglaterra, la deuda pública y la financiación naval; Estados Unidos, la banca federal, la industria de escala y la innovación tecnológica; Valinor integra las cuatro funciones dentro de una civilización marítima federal.

### Sistema Valinari de Fomento y Desarrollo

COFOVAL coordina instrumentos públicos de desarrollo. Los consejos de obras de 1200–1700, los fondos del siglo XVIII, las corporaciones del XIX y el sistema federal desde 1958 son fases diferentes. Los rangos temporales aprobados son ventanas de formación institucional, sin convertirlos en fechas exactas de promulgación. Los directorios representativos, la evaluación ambiental formal y los servicios universales corresponden a la organización contemporánea, con antecedentes parciales en siglos anteriores.

#### Marco común

La reforma federal transforma la COFOVAL en una red de corporaciones nacionales y territoriales coordinadas con bancos, universidades, gobiernos y OceanNet.

La Corporación de Ciencia y Tecnología financia tanto investigación básica como aplicada.

La investigación básica recibe recursos aunque su uso comercial no sea inmediato. La investigación aplicada se vincula a:

- energía;

- medicina;

- navegación;

- metalurgia;

- banca;

- agricultura;

- defensa;

- transporte;

- OceanNet.

Los laboratorios públicos mantienen archivos abiertos y bases de datos compartidas, excepto cuando existe una restricción militar o de seguridad.

La Corporación de Educación y Capital Humano calcula la necesidad futura de:

- ingenieros;

- médicos;

- maestros;

- pilotos;

- marinos;

- técnicos;

- contables;

- administradores;

- investigadores;

- especialistas en mantenimiento.

La planificación educativa no obliga a cada estudiante a seguir una profesión determinada. Ofrece becas, orientación y plazas, pero mantiene libertad de elección.

#### Formación histórica, 1200–1875

La Corona y las ciudades crean fondos para:

- canales;

- puertos;

- arsenales;

- caminos;

- escuelas técnicas;

- minas;

- graneros;

- hospitales.

Estos fondos todavía están separados y dependen de tesorerías, Casas y municipios.

La industrialización impulsa organismos de fomento para:

- ferrocarriles;

- siderurgia;

- astilleros;

- minería;

- energía hidráulica;

- educación técnica.

La expansión industrial exige una institución capaz de coordinar crédito, infraestructura, industria y ciencia. Se crea la COFOVAL como consejo de coordinación y fondo de inversión pública.

La corporación amplía su actividad hacia:

- electrificación;

- industria química;

- aeronáutica;

- telecomunicaciones;

- agricultura industrial;

- vivienda;

- salud;

- formación profesional.

El crecimiento urbano y portuario impulsa la creación de los Consejos de Obras y Abastecimiento. No son todavía corporaciones modernas, sino organismos mixtos de Corona, ciudades, Casas y comerciantes.

Sus responsabilidades incluyen:

- muelles;

- puentes;

- depósitos de madera;

- reparación de barcos;

- abastecimiento de ciudades.

Los consejos registran el coste de las obras, las fuentes de financiación y la mano de obra utilizada. Se crea el antecedente de la evaluación pública de proyectos.

Las ciudades portuarias establecen fondos permanentes para mantener:

- faros;

- rompeolas;

- almacenes;

- caminos costeros;

- estaciones de agua;

- talleres navales;

- puestos de vigilancia.

Los fondos se financian mediante peajes, derechos de atraque, impuestos sobre mercancías y aportes de comerciantes. La Corona comienza a igualar recursos entre puertos ricos y pobres.

La Corona crea la Cámara General de Obras del Reino para coordinar grandes proyectos que atraviesan varias jurisdicciones.

Sus primeras tareas son:

- normalizar medidas;

- coordinar carreteras;

- supervisar canales;

- registrar costes;

- resolver disputas territoriales;

- mantener rutas militares y comerciales.

La Cámara no ejecuta todas las obras. Aprueba proyectos, distribuye fondos y exige informes de las ciudades y Casas.

Las guerras, epidemias y pérdidas marítimas muestran que las ciudades no pueden financiar por sí solas la recuperación. Se crean los Fondos de Navegación y Crédito Público.

Financian:

- reparación de flotas;

- sustitución de embarcaciones;

- almacenes de emergencia;

- seguros marítimos;

- recuperación de puertos;

- préstamos a astilleros;

- protección de convoyes.

Los fondos se respaldan con aduanas, derechos portuarios y futuros ingresos fiscales.

La presión demográfica y las crisis alimentarias impulsan las primeras oficinas permanentes de fomento agrícola.

Sus funciones son:

- mejorar canales;

- registrar cosechas;

- distribuir semillas;

- proteger graneros;

- financiar molinos;

- mantener caminos rurales;

- estabilizar precios;

- organizar reservas.

Estas oficinas no sustituyen a las comunidades agrícolas. Coordinan asistencia, crédito y almacenamiento.

Los principales puertos crean Casas de Cambio y Crédito Territorial. Estas instituciones conectan:

- bancos urbanos;

- tesorerías reales;

- comerciantes;

- Casas nobles;

- agricultores;

- gobiernos locales.

El crédito deja de concentrarse exclusivamente en comercio marítimo y comienza a financiar obras terrestres, manufacturas, agricultura y vivienda urbana.

La expansión oceánica crea el Consejo de Comercio, Puertos y Manufacturas. Es el primer organismo que trata industria, navegación y comercio como un sistema común.

Sus tareas son:

- establecer normas técnicas;

- fomentar talleres;

- proteger astilleros;

- mejorar depósitos;

- apoyar manufacturas textiles y metalúrgicas;

- coordinar exportaciones;

- negociar tratados comerciales.

La Corona crea un fondo permanente para:

- hornos;

- maquinaria hidráulica;

- bombas de minas;

- talleres de precisión;

- formación de maestros.

Se financian proyectos de alto coste y retorno lento. El fondo exige que los diseños y procedimientos generales sean archivados y reproducidos según la Doctrina de las Siete Copias.

La expansión de carbón, hierro y metales estratégicos lleva a crear la Oficina de Minas, Energía y Recursos.

Sus responsabilidades comprenden:

- prospección;

- concesiones mineras;

- seguridad de minas;

- transporte de mineral;

- bosques para carbón vegetal;

- ríos industriales;

- reservas estratégicas;

- formación minera.

La Oficina comienza como organismo de registro y fiscalización, pero posteriormente se convierte en inversora directa.

En la segunda mitad del siglo XVII se crea el Banco de Desarrollo de la Corona.

- manufacturas;

- carreteras;

Su función no es competir con todos los bancos privados, sino financiar inversiones que requieren muchos años y que el crédito comercial ordinario no puede sostener.

La Corona reorganiza sus oficinas en una administración más estable. Se distinguen tres áreas:

- Obras y Transporte;

- Industria, Minas y Energía;

- Educación Técnica y Ciencia.

Se establecen presupuestos anuales, informes de ejecución y cuerpos técnicos profesionales.

Los proyectos dejan de depender exclusivamente de la voluntad de una Casa o del patrocinio de un monarca.

Se crea el Fondo General de Fomento, que reúne recursos de:

- aduanas;

- peajes;

- deuda pública;

- banca real;

- ingresos portuarios;

- rentas territoriales.

El fondo financia proyectos productivos y sociales. También establece mecanismos de compensación para territorios con menor recaudación.

La mecanización y los primeros ferrocarriles impulsan la creación de una corporación especializada en:

- locomotoras;

- raíles;

- máquinas de vapor;

- talleres;

- transporte de mercancías.

La institución actúa como financiadora, compradora pública y coordinadora de proveedores.

La industrialización naval hace necesario separar el fomento marítimo del comercio ordinario. Se crea la Corporación Naval y Oceánica.

- cascos de hierro;

- motores;

- calderas;

- buques mercantes;

- buques de guerra;

- estaciones de carbón;

- reparación;

- formación naval.

La corporación comienza a trabajar con programas plurianuales y piezas normalizadas.

La coordinación de industria, energía, transporte, educación, banca y defensa lleva a crear la Corporación General de Fomento Valinari —COFOVAL—.

Su creación no elimina las instituciones anteriores. Las integra en una red de corporaciones especializadas.

En 1875 COFOVAL coordina:

- industria y manufactura;

- Armada y astilleros;

- energía y recursos;

- agricultura y alimentación;

- infraestructura y transporte;

- ciencia y tecnología;

- desarrollo territorial;

- cultura y archivos;

- financiación pública.

En 1875 el sistema aún está en fase de consolidación. No es una administración económica completamente centralizada. Está compuesto por:

- COFOVAL;

- Banco Real;

- bancos de desarrollo;

- corporaciones navales;

- corporaciones industriales;

- oficinas territoriales;

- universidades;

- empresas públicas;

- empresas mixtas;

- bancos privados regulados;

La Corona conserva funciones patrimoniales y estratégicas, pero el Parlamento controla el presupuesto y la deuda. Los territorios participan en la propuesta, financiación y administración de proyectos.

La COFOVAL no posee todavía las herramientas de planificación digital del siglo XX. Utiliza:

- censos;

- registros fiscales;

- mapas;

- informes técnicos;

- telégrafo;

- estadísticas de producción;

- archivos de bancos;

- inspecciones presenciales.

Su ventaja reside en la acumulación histórica de datos y la coordinación institucional, no en el procesamiento instantáneo de información.

La estructura posterior podrá evolucionar hacia una red federal más amplia durante los siglos XX y XXI, incorporando OceanNet, investigación avanzada, automatización y planificación energética, pero sin proyectar esas capacidades retrospectivamente sobre 1200–1800.

#### Competencias de COFOVAL

Valinor desarrolla una red pública de fomento inspirada en una corporación estatal de desarrollo, pero adaptada a una monarquía constitucional, una federación territorial y una economía oceánica. No se crea una institución única que controle toda la economía. Se establece un sistema coordinado de corporaciones sectoriales con autonomía técnica, presupuesto público, participación territorial y supervisión parlamentaria.

El sistema recibe el nombre de Sistema Valinari de Fomento y Desarrollo (SVFD). Su función es convertir educación, banca, industria, ciencia, territorio, energía y defensa en capacidades productivas permanentes.

La Corporación General de Fomento Valinari (COFOVAL) coordina el sistema.

Sus funciones son:

- identificar sectores estratégicos;

- financiar proyectos de largo plazo;

- coordinar bancos de desarrollo;

- asociar Estado, territorios y empresas;

- reducir desigualdades regionales;

- crear capacidades industriales;

- apoyar investigación aplicada;

- proteger recursos críticos;

- evaluar resultados;

- evitar duplicación de inversiones.

COFOVAL no reemplaza a los ministerios, bancos, universidades ni gobiernos territoriales. Actúa como articulador, financiador y evaluador.

El Sistema Valinari de Fomento y Desarrollo permite que la educación, la banca, la industria, la agricultura, la energía, la ciencia, la salud, la vivienda, la cultura y la defensa se refuercen mutuamente.

Su fórmula queda establecida así:

El desarrollo valinari no depende de una sola corporación, sino de una red pública de fomento que convierte el crédito, el conocimiento, los recursos y la infraestructura en capacidades territoriales duraderas.

El Sistema Valinari de Fomento y Desarrollo se convierte en una arquitectura permanente de coordinación entre Estado, territorios, empresas, bancos, universidades, sindicatos, ciudades y Corona.

No constituye una economía completamente planificada ni un capitalismo sin regulación. Es una economía mixta de desarrollo estratégico, en la que el Estado crea capacidades que después pueden ser administradas por empresas públicas, privadas, mixtas o territoriales.

Entre 1200 y 1875, Valinor pasa de consejos locales de obras a un sistema moderno temprano de fomento.

La secuencia canónica es:

Consejos de Obras → Fondos de Puertos → Cámara General de Obras → Fondos de Navegación → Oficinas sectoriales → Banco de Desarrollo → Fondo General de Fomento → corporaciones industriales → COFOVAL.

La continuidad institucional explica cómo Valinor puede llegar a la industrialización con bancos, astilleros, escuelas, archivos y gobiernos capaces de coordinar proyectos de largo plazo.

#### Proyectos y evaluación

Los proyectos se evalúan por:

- productividad;

- empleo;

- impacto educativo;

- seguridad estratégica;

- sostenibilidad;

- conectividad;

- desarrollo regional;

- capacidad exportadora;

- independencia tecnológica;

- coste de mantenimiento.

No se financia una obra únicamente por prestigio político o interés de una Casa.

Todo proyecto financiado por el sistema sigue un ciclo común:

1. diagnóstico territorial o sectorial;

2. propuesta técnica;

3. evaluación económica;

4. análisis ambiental;

5. cálculo de impacto educativo y laboral;

6. revisión de seguridad estratégica;

7. decisión de financiación;

8. ejecución;

9. auditoría intermedia;

10. evaluación final;

11. continuidad, transferencia, reestructuración o cierre.

La aprobación política no sustituye la evaluación técnica. Un proyecto puede ser importante para la Corona o una Casa y aun así ser rechazado si carece de viabilidad, mantenimiento o utilidad pública.

La COFOVAL utiliza registros de:

- población;

- producción;

- ingresos fiscales;

- infraestructura;

- educación;

- salud;

- energía;

- transporte;

- recursos naturales;

- riesgos climáticos;

- capacidad industrial.

Los territorios presentan planes plurianuales, pero no pueden diseñar proyectos aislados de la red federal. Una carretera debe conectarse con ferrocarril, puerto, mercado o centro industrial; una escuela técnica debe relacionarse con las necesidades de empresas y servicios públicos.

Los proyectos se dividen en cinco categorías:

Productivos: aumentan la producción o reducen costes.

Sociales: mejoran salud, educación, vivienda y condiciones de vida.

Estratégicos: protegen energía, alimentos, tecnología, defensa o comunicaciones.

Territoriales: integran regiones aisladas y reducen desigualdades.

Culturales: conservan archivos, patrimonio, memoria y conocimiento.

Cada categoría puede usar instrumentos financieros distintos. Una línea ferroviaria puede generar ingresos directos; un hospital rural puede justificarse por su impacto social aunque no produzca beneficios comerciales.

Los proyectos se evalúan mediante:

- empleos creados;

- aumento de producción;

- reducción de costes;

- estudiantes formados;

- patentes o técnicas desarrolladas;

- reducción de mortalidad;

- conexión territorial;

- consumo energético;

- impacto ambiental;

- mantenimiento requerido;

- dependencia exterior reducida.

No todos los proyectos deben producir ganancias financieras. Deben demostrar utilidad pública, estratégica o territorial.

#### Instrumentos financieros y propiedad

Actúa como brazo financiero del sistema. Puede ofrecer:

- préstamos a largo plazo;

- garantías;

- seguros;

- bonos de desarrollo;

- participación temporal;

- refinanciación;

- fondos de emergencia;

- crédito para pequeñas empresas.

No debe competir de forma desleal con todos los bancos privados. Su función es financiar lo que el mercado no puede sostener por sí solo o considera demasiado arriesgado.

El sistema se financia mediante:

- presupuesto federal;

- impuestos territoriales;

- bonos públicos;

- banca de desarrollo;

- dividendos de empresas públicas;

- concesiones reguladas;

- fondos de pensiones;

- aportes de los territorios;

- inversión privada supervisada.

La Corona aporta principalmente mediante Becas Reales, patrimonio, archivos, academias y fondos culturales. No dirige el sistema económico ni asume su financiación principal.

Los proyectos pueden financiarse mediante una combinación de:

- aporte territorial;

- crédito de fomento;

- inversión privada;

- bonos;

- aportes municipales;

- cooperación internacional;

- patrimonio de la Corona.

La participación privada no concede automáticamente control de la infraestructura. Los contratos deben definir tarifas, mantenimiento, reversión, derechos laborales y fiscalización.

El sistema utiliza tres modelos.

Empresa pública: se aplica cuando el sector es estratégico, poco rentable o esencial para la soberanía.

Empresa mixta: el Estado aporta capital, infraestructura o tecnología y los privados aportan gestión o inversión.

Empresa privada apoyada: recibe crédito, garantía, formación o contratos, pero mantiene propiedad privada y competencia.

La modalidad se revisa periódicamente. Una empresa pública puede transformarse en mixta; una empresa mixta puede pasar a competencia abierta; una empresa privada puede ser intervenida si incumple obligaciones estratégicas.

#### Industria y desarrollo naval

Financia:

- siderurgia;

- maquinaria;

- vehículos;

- herramientas;

- fábricas;

- materiales avanzados;

- producción de bienes de capital.

Ofrece crédito a largo plazo, participa temporalmente en empresas estratégicas y ayuda a crear proveedores locales. Su objetivo no es mantener industrias ineficientes para siempre, sino construir capacidad hasta que puedan competir o cumplir una función estratégica.

- astilleros;

- motores navales;

- puertos;

- buques mercantes;

- buques auxiliares;

- reparación;

- navegación polar;

- infraestructura de carbón y combustible;

- investigación marítima.

Coordina con la Armada, pero no sustituye al Almirantazgo. La separación evita que la producción civil sea absorbida por necesidades militares.

La Corporación de Industria y Manufactura desarrolla una cadena completa:

- minería;

- refinación;

- motores;

- transporte;

- montaje;

- mantenimiento;

- exportación.

No basta con construir una fábrica. La corporación debe asegurar trabajadores, energía, proveedores, repuestos, transporte, crédito y demanda.

La Corporación Naval y Oceánica planifica por generaciones de buques. Cada programa considera:

- diseño;

- astillero;

- acero;

- artillería;

- tripulaciones;

- combustible;

- desguace;

- sustitución.

La finalidad es evitar que Valinor construya barcos modernos sin capacidad para mantenerlos durante décadas.

#### Energía, agricultura e infraestructura

Desarrolla:

- hidroeléctrica;

- carbón;

- petróleo;

- gas;

- energía geotérmica;

- energía nuclear;

- redes eléctricas;

- almacenamiento;

- minerales críticos.

Sus inversiones se distribuyen entre Arnor, Islandia, Groenlandia, Valinor, Sírënandë, Calenardhon Austral y Númenor.

Debe mantener reservas estratégicas y evitar dependencia absoluta de un solo territorio.

Financia:

- regadío;

- drenaje;

- semillas;

- maquinaria agrícola;

- fertilizantes;

- graneros;

- frigoríficos;

- puertos pesqueros;

- cadenas de alimentos;

- investigación agrobiológica.

También administra fondos de estabilización para evitar que una mala cosecha provoque hambre o quiebra generalizada.

Coordina:

- ferrocarriles;

- carreteras;

- puentes;

- canales;

- puertos;

- aeropuertos;

- almacenes;

- transporte lacustre y fluvial;

- redes logísticas.

La prioridad se determina por conectividad, desarrollo regional, defensa y acceso a mercados.

La Corporación de Energía debe equilibrar:

- precio;

- seguridad;

- disponibilidad;

- impacto ambiental;

- transporte;

- reservas;

- dependencia exterior.

Una región no recibe una gran central únicamente por su producción potencial. También se evalúan redes, agua, mantenimiento, demanda, almacenamiento y vulnerabilidad militar.

La Corporación Agrícola trabaja con ciclos de largo plazo:

- mejora de semillas;

- conservación del suelo;

- irrigación;

- rotación;

- mecanización;

- mercados;

- crédito;

- seguros.

El objetivo no es sustituir la agricultura familiar, sino aumentar productividad y resistencia a crisis. Las cooperativas pueden acceder a maquinaria y crédito colectivo.

#### Ciencia y educación

Financia:

- universidades;

- laboratorios;

- centros de cálculo;

- OceanNet;

- biotecnología;

- electrónica;

- inteligencia artificial;

- materiales;

- medicina;

- robótica;

- observatorios.

Utiliza contratos de investigación, becas, laboratorios compartidos y fondos competitivos. Los resultados de interés público deben publicarse; la información militar activa puede permanecer restringida temporalmente.

Apoya:

- educación primaria;

- secundaria técnica;

- formación profesional;

- institutos navales;

- escuelas de minería;

- academias de administración;

- becas territoriales;

- educación de adultos;

- reconversión laboral.

La financiación se asigna según población, necesidades regionales, sectores estratégicos y desigualdades históricas.

La Corona participa mediante Becas Reales y patrimonio educativo, pero no controla los planes de estudio ni la Autoridad Federal de Becas.

#### Salud, vivienda y ciudades

Financia:

- hospitales;

- centros rurales;

- investigación médica;

- prevención de epidemias;

- medicamentos;

- salud naval;

- vivienda sanitaria;

- agua potable;

- saneamiento.

La salud se considera una inversión productiva porque reduce mortalidad, mejora educación y aumenta la capacidad laboral.

- vivienda obrera;

- barrios portuarios;

- alcantarillado;

- calefacción;

- transporte urbano;

- renovación de barrios industriales;

- edificios públicos.

Debe evitar que el crecimiento industrial produzca ciudades sin servicios básicos.

La Corporación de Salud evalúa no solo hospitales, sino también:

- agua;

- alimentación;

- vivienda;

- contaminación;

- seguridad laboral;

- salud mental;

- transporte sanitario;

La inversión sanitaria se coordina con escuelas, fábricas, puertos y fuerzas armadas.

La Corporación de Vivienda evita el crecimiento desordenado de ciudades industriales. Los proyectos deben incluir:

- viviendas;

- escuelas;

- mercados;

- transporte;

- clínicas;

- espacios públicos;

- protección contra incendios;

- redes eléctricas;

- servicios de emergencia.

Las ciudades no reciben fondos solo para construir edificios monumentales. La prioridad es crear barrios habitables y productivos.

#### Territorio, cultura y memoria

Su objetivo es reducir la concentración en las capitales y grandes puertos. Financia proyectos en:

- Arnor interior;

- Groenlandia;

- Islandia;

- Calenardhon Austral;

- Sírënandë;

- islas del Pacífico;

- África occidental;

- territorios rurales y fronterizos.

Utiliza fondos diferenciados según clima, población, distancia, infraestructura y potencial económico.

Financia:

- archivos;

- bibliotecas;

- museos;

- patrimonio industrial;

- traducción;

- restauración documental;

- Casas de la Memoria;

- conservación de lenguas;

- difusión científica;

- patrimonio naval.

La Doctrina de las Siete Copias se integra en sus programas de archivo y conservación.

La Corporación Territorial utiliza fórmulas de compensación. Los territorios con menor población o menor recaudación reciben más apoyo por habitante, pero deben presentar proyectos sostenibles.

Las regiones remotas pueden recibir:

- infraestructura subsidiada;

- conectividad garantizada;

- crédito preferente;

- centros técnicos;

- hospitales regionales;

- incentivos de residencia;

- apoyo a industrias especializadas.

La Corporación de Cultura considera que archivos, bibliotecas y memoria técnica son activos estratégicos. Financia:

- archivos industriales;

- bibliotecas de ingeniería;

- museos de ciencia;

- traducción técnica;

- digitalización;

- reproducción en siete copias.

La cultura no queda reducida a ornamentación: conserva conocimientos necesarios para la continuidad institucional.

Los territorios:

- proponen proyectos;

- aportan suelo;

- financian parte de las obras;

- forman trabajadores;

- administran servicios;

- supervisan impactos locales.

No pueden alterar unilateralmente objetivos federales ni utilizar fondos de desarrollo para financiar guerras, campañas electorales o beneficios particulares.

#### Gobierno, supervisión y riesgos

Cada corporación posee:

- consejo técnico;

- representantes del Estado;

- representantes territoriales;

- representantes de universidades;

- representantes laborales;

- auditores;

- oficina de evaluación;

- comité de transparencia.

Las Casas pueden participar como inversoras, propietarias de tierras o socias industriales, pero no controlan unilateralmente las corporaciones públicas.

El sistema puede sufrir:

- corrupción;

- favoritismo regional;

- empresas ineficientes;

- endeudamiento;

- dependencia de contratistas;

- captura por Casas nobles;

- burocracia excesiva;

- sobreinversión;

- proyectos de prestigio;

- desigualdad entre regiones.

Para reducir estos riesgos se exigen:

- auditorías;

- publicación de contratos;

- límites de mandato;

- evaluación independiente;

- revisión de proyectos;

- concurso público;

- control parlamentario;

- incompatibilidades para directivos.

El Parlamento revisa:

- presupuesto anual;

- deuda acumulada;

- garantías públicas;

- grandes contratos;

- resultados de las corporaciones;

- distribución regional;

- salarios directivos;

- proyectos fallidos.

Los proyectos militares y de inteligencia se presentan en sesiones reservadas, pero no quedan fuera de toda supervisión.

Las Casas pueden contribuir mediante:

- tierras;

- capital;

- archivos;

- conocimiento técnico;

- redes comerciales;

- administración local;

- participación patrimonial.

Reciben beneficios económicos legítimos, pero deben competir bajo reglas transparentes. La pertenencia a una Casa no garantiza adjudicaciones.

La COFOVAL debe evitar que toda la inversión se concentre en:

- Nueva Tirion;

- Forostar;

- Númenor;

- grandes arsenales;

- puertos centrales.

La planificación debe reservar cuotas para regiones rurales, islas, protectorados, territorios polares, zonas mineras y ciudades secundarias.

### Rín valinari

El rín es una denominación monetaria propia del escenario, sin etimología sindarin certificada. Se distingue entre unidad de cuenta, pieza metálica y medio de pago. El rín de plata es la referencia ordinaria; las piezas de oro representan múltiplos y las de cobre fracciones valoradas por tablas del periodo. Peso en gramos, ley exacta, subdivisiones y salarios numéricos continúan sin fijación expresa; no se inventa una paridad estable con monedas modernas.

#### nombre y valor de la moneda valinari

##### Nombre oficial

La unidad monetaria común recibe el nombre de rín valinari. En documentos formales aparece como Rín del Reino, Rín de la Corona o Rín valinari, según el periodo y la autoridad emisora.

El término no designa una única pieza metálica. Es, ante todo, una unidad de cuenta basada en peso y pureza. Puede representarse mediante monedas de plata, múltiplos de oro, piezas menores de cobre o equivalentes en bienes.

En la vida cotidiana se utilizan las formas abreviadas rín, rines y unidad de rín. En los registros antiguos, antes de la reforma telcontar, puede aparecer como peso de Forostar o unidad de las Casas. Estas denominaciones se consideran antecedentes del rín, no monedas completamente idénticas.

##### Origen del nombre

El nombre se consolida después del Concilio de Forostar porque los registros de la ciudad utilizan el rín como referencia para comparar plata, grano, servicio naval y compensaciones. La reforma de 550 a. C. convierte la unidad en patrón real de cuenta.

La moneda conserva una relación simbólica con:

- el registro escrito;

- la medida justa;

- la memoria de los pactos;

- la obligación cumplida;

- la continuidad entre las Casas y la Corona.

No se presenta como riqueza creada por decreto. Su aceptación depende de que el metal, el peso, el registro y la autoridad sean confiables.

##### Composición monetaria

El sistema distingue tres formas principales:

Rín de plata: unidad normal de cuenta y comercio. Se utiliza para salarios, impuestos, contratos, herramientas, ganado, transporte y pagos militares.

Rín de oro: múltiplo de alto valor. Se usa para diplomacia, adquisición de barcos, grandes cargamentos, tratados, rescates, préstamos internacionales y reservas de la Corona.

Rín menor: pieza de cobre o bronce para mercados locales, alimentos, transporte, pequeños servicios y pagos diarios.

El nombre rín se mantiene, pero el metal y el tamaño se indican en los documentos para evitar confusión.

##### Valor material

El valor de un rín depende de cuatro elementos:

1. peso;

2. pureza;

3. autoridad emisora;

4. posibilidad de conversión.

Una pieza ligera o de baja ley no conserva automáticamente su valor nominal. Puede ser pesada, descontada, reacuñada o aceptada solo por la autoridad que la emitió.

La Corona publica tablas de conversión entre monedas reales, monedas de Casa, piezas portuarias y monedas extranjeras.

##### Valor económico por periodo

##### 1000–990 a. C.

Todavía no existe el rín como moneda. Su antecedente es una unidad de peso utilizada para comparar plata, grano, ganado y trabajo.

##### 990–800 a. C.

El rín funciona como unidad contable del Concilio. Puede pagarse con:

- metal;

- grano;

- ganado;

- herramientas;

- madera;

- jornadas de trabajo;

- servicio naval.

##### 800–550 a. C.

El rín aparece en piezas locales de plata y bronce. Su valor varía según la Casa y el puerto, pero los registros de Forostar permiten establecer equivalencias.

##### Desde 550 a. C.

La Corona Telcontar reconoce el rín como unidad real de cuenta. La moneda real posee mayor aceptación en:

- arsenales;

- ejército;

- armada;

- puertos;

- tesorerías;

- contratos interregionales.

##### a. C.–200 d. C.

El rín se convierte en moneda comercial interregional. Se acepta junto con monedas mediterráneas y romanas, aunque conserva una valoración propia en los territorios valinari.

##### 200–800 d. C.

Las crisis producen descuentos regionales y reaparición de pagos en especie. El rín continúa siendo referencia fiscal, pero no siempre circula físicamente.

##### 800–1200 d. C.

El rín se utiliza en letras de cambio, depósitos y préstamos portuarios. Su valor empieza a depender tanto de la solvencia de la tesorería como del metal de la pieza.

##### 1200–1500 d. C.

El rín alcanza su forma monetaria madura: moneda de plata para operaciones normales, oro para comercio mayorista y cobre para mercados locales, con equivalencias reguladas por la Corona.

##### Valor práctico

El valor de un rín no se define solo por una cantidad abstracta de plata. Los registros comparan su poder de compra en bienes esenciales:

- cereal;

- pan;

- sal;

- hierro;

- madera;

- animales;

- transporte;

- alojamiento;

- jornada de artesano;

- servicio naval;

- reparación de embarcaciones.

Una misma cantidad nominal puede comprar menos grano durante una hambruna o más bienes en una región portuaria abastecida. Por eso los contratos de larga duración indican si el pago se fija en rines, metal, grano o una combinación.

##### Valor de los salarios

La remuneración se organiza por oficio y riesgo:

- trabajadores rurales: pagos mixtos en alimento, tierra, bienes y moneda menor;

- artesanos: moneda de plata, alojamiento y materiales;

- marineros: plata, raciones, participación en cargamento y compensación por riesgo;

- soldados: plata, grano, equipo y tierras o pensiones según servicio;

- ingenieros y escribas: plata, vivienda, privilegios de archivo y salario regular;

- capitanes y maestros de arsenal: múltiples rines, participación en contratos y derechos de Casa.

Los salarios militares pueden pagarse parcialmente en moneda y parcialmente en raciones o equipo, especialmente en campañas remotas.

##### Equivalencias monetarias

El sistema no mantiene una equivalencia única durante veinticinco siglos. Las relaciones cambian por:

- disponibilidad de plata;

- descubrimiento de minas;

- guerras;

- bloqueo de rutas;

- inflación;

- devaluación;

- reformas de la Corona;

- comercio con Roma y otras potencias.

Por ello, la formulación canónica no debe afirmar que un rín de 1000 a. C. tenga exactamente el mismo valor que uno de 1500 d. C. Lo que permanece es el nombre de la unidad de cuenta y el principio de conversión por peso, ley y tabla oficial.

##### Monedas de Casa y de puerto

Las Casas pueden emitir piezas locales si:

- indican su autoridad;

- respetan los pesos mínimos;

- aceptan inspección;

- no imitan sellos reales;

- registran sus emisiones;

- mantienen reservas para canjearlas.

Los puertos pueden acuñar moneda menor para facilitar mercados y salarios, pero estas piezas tienen circulación limitada. Una moneda de puerto puede ser aceptada con descuento fuera de su zona.

##### Moneda extranjera

Las monedas romanas, griegas, africanas, nórdicas y orientales se aceptan mediante pesaje y contraste. Pueden convertirse a rines, fundirse o circular como divisas extranjeras.

La aceptación de moneda extranjera depende de:

- estabilidad política del emisor;

- pureza;

- facilidad de cambio;

- confianza de comerciantes;

- seguridad de la ruta;

- demanda del metal.

La circulación de moneda extranjera no concede derechos políticos ni territoriales.

##### Valor de reserva

La Corona mantiene reservas en:

- monedas de oro y plata;

- lingotes;

- grano;

- sal;

- hierro;

- madera naval;

- animales;

- herramientas;

- documentos de crédito.

Esta política evita que una crisis de moneda metálica paralice la administración. Las reservas se distribuyen según las necesidades de liquidez y seguridad. La Doctrina de las Siete Copias se aplica a sus registros esenciales, no exige siete tesoros de igual tamaño.

##### Falsificación y confianza

La falsificación se considera un ataque contra el pacto económico. Las autoridades controlan:

- peso;

- diámetro;

- ley metálica;

- sello;

- bordes;

- marca de emisión;

- desgaste anormal.

Las monedas se retiran cuando pierden demasiado metal. Los falsificadores pueden ser sancionados con confiscación, trabajos forzados, prisión o pérdida de derechos, según la época y la gravedad.

##### Crisis monetarias

Las principales crisis se producen cuando:

- la Corona reduce la ley para financiar una guerra;

- una Casa emite más moneda de la que puede respaldar;

- se interrumpe el comercio de plata;

- los bancos portuarios pierden reservas;

- las rutas quedan bloqueadas;

- el grano se encarece;

- una moneda extranjera desplaza a la moneda local.

Las soluciones habituales son:

- reacuñación;

- conversión a lingotes;

- control temporal de precios estratégicos;

- pagos en grano;

- auditoría de tesorerías;

- garantía de la Corona;

- suspensión limitada de conversiones;

- apertura de reservas regionales.

##### Fórmula canónica

La definición oficial queda establecida así:

El rín valinari es una unidad monetaria de cuenta y una familia de monedas metálicas respaldada por peso, pureza, registro y autoridad. Su valor histórico no es fijo: varía con el metal, la oferta, las rutas, la producción y la confianza institucional.

La moneda valinari puede ser fuerte sin ser invariable. Su estabilidad procede de la combinación de reservas, fiscalidad, archivos, bancos portuarios, comercio oceánico y capacidad de la Corona para hacer cumplir los contratos.

### Evolución monetaria, 1000 a. C.–1500 d. C.

#### moneda y sistema monetario valinari, 1000 a. C.–1500 d. C.

##### Principio general

La moneda valinari no aparece desde el inicio como un sistema único y completamente centralizado. Evoluciona desde pagos en especie, pesos metálicos y unidades de cuenta hacia monedas acuñadas, tesoros de Casa, moneda real, letras de cambio y bancos portuarios.

Durante todo el periodo coexisten tres formas de riqueza:

- bienes y alimentos;

- metal pesado medido por peso y pureza;

- moneda acuñada o registrada.

La moneda facilita los intercambios, pero no sustituye al grano, ganado, madera, sal, hierro, trabajo, servicio naval ni derechos portuarios.

##### 1000–990 a. C.: pagos en especie y metal pesado

Antes del Concilio de Forostar, las Casas utilizan principalmente:

- grano;

- ganado;

- sal;

- pieles;

- ámbar;

- hierro;

- cobre;

- plata sin acuñar;

- herramientas;

- jornadas de trabajo;

- servicio militar y naval.

El metal se pesa con balanzas de piedra y bronce. Las transacciones importantes se certifican mediante testigos, sellos, tablillas, marcas de Casa y registros de santuario.

La unidad económica básica no es una moneda, sino una obligación: cantidad de grano, peso de metal, número de animales, días de trabajo o servicios debidos.

##### 990–800 a. C.: unidad de cuenta del Concilio

Después del Concilio de Forostar, las Casas acuerdan utilizar unidades de cuenta comunes para registrar:

- compensaciones;

- tributos;

- contratos navales;

- reservas de grano;

- reparaciones de guerra;

- salarios de artesanos;

- derechos de puerto.

Estas unidades no son todavía monedas físicas uniformes. Una cuenta puede pagarse en plata, hierro, grano, ganado o trabajo valorado según tablas regionales.

El Consejo establece pesos de referencia y patrones conservados en santuarios y tesorerías. Las Casas pueden certificar pesos y marcar piezas metálicas locales, pero deben declarar su peso y metal.

##### 800–500 a. C.: primeras acuñaciones regionales

El crecimiento de puertos y rutas comerciales favorece monedas pequeñas de:

- plata;

- bronce;

- cobre;

- electrum en cantidades limitadas.

Las primeras piezas llevan signos de Casa, puerto, santuario o autoridad emisora. No todas poseen el mismo valor fuera de su región. Por ello se comercia con tablas de equivalencia y se pesan las monedas cuando existen dudas.

La moneda se utiliza principalmente en:

- mercados urbanos;

- puertos;

- pago de marineros;

- talleres;

- compra de alimentos;

- servicios de transporte;

- adquisición de armas y herramientas.

##### a. C.: reforma monetaria de la Corona Telcontar

El pacto de 550 a. C. impulsa una reforma de pesos y registros. La Corona no elimina las monedas de las Casas, pero crea una unidad real de referencia para:

- impuestos;

- pagos militares;

- derechos de puerto;

- salarios de funcionarios;

- contratos entre territorios;

- indemnizaciones entre Casas.

La moneda real lleva símbolos de la Corona, pero su aceptación depende de que el peso y la pureza sean verificables. El Consejo conserva autoridad para revisar emisiones y sancionar devaluaciones fraudulentas.

La reforma no crea un banco central moderno. Crea una autoridad de pesos, sellos, tesoros y registros.

##### 500–300 a. C.: moneda real y moneda de Casa

Durante la consolidación monárquica coexisten:

- moneda real;

- moneda de Casa;

- moneda portuaria;

- moneda extranjera;

- plata por peso;

- pagos en especie.

La moneda real domina los contratos militares y administrativos. Las monedas de Casa circulan en mercados locales. Los puertos aplican descuentos o primas según la pureza, procedencia y estabilidad de cada emisión.

La Corona crea oficinas de contraste que verifican:

- peso;

- metal;

- desgaste;

- falsificaciones;

- recortes de bordes;

- alteraciones de ley.

##### 300–50 a. C.: expansión comercial

La expansión hacia el Báltico, el Mediterráneo y el Atlántico aumenta la necesidad de monedas intercambiables. Se crean piezas de mayor valor para:

- compra de cargamentos;

- pago de tripulaciones;

- reparación de barcos;

- compra de metales;

- financiación de expediciones;

- contratación de mercenarios o auxiliares extranjeros.

Los grandes comerciantes comienzan a utilizar depósitos de plata y recibos de tesorería. Estos recibos pueden transferirse entre puertos reconocidos, aunque todavía no funcionan como billetes de circulación general.

##### a. C.–200 d. C.: sistema monetario portuario

La relación con Roma y otras potencias mediterráneas introduce monedas extranjeras en los mercados valinari. Las autoridades no las prohíben, pero las clasifican por:

- peso;

- pureza;

- autoridad emisora;

- estabilidad;

- facilidad de fundición;

- aceptación internacional.

Los puertos mantienen cámaras de pesaje y cambio. Las monedas romanas, valinari, griegas, norteafricanas y orientales pueden utilizarse en comercio, pero los impuestos internos se registran en la unidad de cuenta de la Corona.

La moneda romana se acepta especialmente en transacciones mediterráneas, mientras la moneda valinari predomina en rutas atlánticas y septentrionales.

##### 200–500 d. C.: crisis, reservas y centralización

Las epidemias, interrupciones de rutas y conflictos reducen la circulación de moneda en algunas regiones. Aumentan los pagos en:

- grano;

- sal;

- madera;

- hierro;

- tejidos;

- trabajo;

- protección militar.

La Corona y las Casas crean tesoros de emergencia. Las reservas se dividen entre:

- metal amonedado;

- lingotes;

- grano;

- herramientas;

- madera naval;

- carbón vegetal;

- animales;

- documentos de deuda.

La crisis demuestra que una economía dependiente exclusivamente de la moneda es vulnerable. El sistema valinari conserva deliberadamente una base mixta.

##### 500–800 d. C.: moneda territorial y tesoros regionales

La expansión territorial genera monedas locales en provincias y puertos. Estas piezas pueden tener uso limitado y estar vinculadas a:

- mercados regionales;

- salarios de guarnición;

- peajes;

- almacenes;

- obras públicas;

- pagos de transporte.

La Corona exige que las monedas territoriales indiquen:

- autoridad emisora;

- peso aproximado;

- metal utilizado;

- fecha o símbolo de emisión;

- oficina de contraste.

Las provincias no pueden financiar guerras privadas mediante emisiones ilimitadas. La acuñación extraordinaria requiere autorización real o del Consejo.

##### 800–1000 d. C.: letras y crédito mercantil

El crecimiento de los puertos introduce instrumentos escritos:

- recibos de depósito;

- órdenes de pago;

- letras de transporte;

- contratos de cambio;

- préstamos marítimos;

- seguros de carga;

- obligaciones de Casa;

- cartas de crédito.

Estos instrumentos reducen la necesidad de transportar grandes cantidades de plata. Un comerciante puede depositar metal en un puerto y recibir una orden reconocida en otro.

La confianza depende de:

- reputación de la Casa;

- solvencia del puerto;

- registro en archivos;

- testigos;

- garantías de carga;

- arbitraje del Consejo;

- presencia de agentes reales.

##### 1000–1200 d. C.: banca portuaria y cámaras de compensación

Las ciudades portuarias crean instituciones más estables:

- casas de cambio;

- tesorerías mercantiles;

- bancos de depósito;

- cámaras de compensación;

- oficinas de seguros;

- registros de deuda;

- tribunales comerciales.

Los bancos no emiten todavía moneda fiduciaria ilimitada. Su función principal es custodiar metales, transferir créditos y financiar cargamentos, astilleros y caravanas.

La Corona supervisa las cámaras que trabajan con impuestos, defensa o contratos públicos.

##### 1200–1350 d. C.: moneda comercial interregional

La expansión de las rutas atlánticas, mediterráneas y asiáticas requiere una moneda más reconocible fuera de Valinor. Se establecen piezas de plata y oro de mayor estabilidad, con:

- peso regular;

- ley metálica declarada;

- símbolos reconocibles;

- bordes marcados;

- inspección periódica;

- retiro de emisiones desgastadas.

Las monedas de oro se destinan a grandes operaciones, tratados, compras de barcos, rescates, diplomacia y pagos internacionales. Las de plata sostienen el comercio ordinario y los salarios urbanos. Las de cobre facilitan mercados locales.

##### 1350–1500 d. C.: sistema monetario maduro

Hacia 1500 d. C., Valinor posee un sistema mixto y policéntrico compuesto por:

- moneda real de referencia;

- monedas territoriales reguladas;

- monedas de Casa limitadas;

- oro para comercio mayorista;

- plata para salarios y comercio interregional;

- cobre para mercados locales;

- letras de cambio;

- depósitos bancarios;

- seguros marítimos;

- deuda pública y portuaria;

- pagos en especie en zonas rurales.

La Corona controla los pesos, la ley metálica, la fiscalidad y la moneda de sus oficinas, pero no administra directamente cada banco. Las ciudades y Casas mantienen autonomía financiera dentro de límites establecidos.

##### Monedas y denominaciones

El sistema utiliza denominaciones basadas en peso, no solo en valor nominal:

- unidad pequeña de cobre para mercados diarios;

- pieza de bronce para pagos urbanos;

- unidad de plata para salarios, impuestos y comercio regional;

- múltiplos de plata para contratos portuarios;

- pieza de oro para grandes transacciones;

- lingote o peso certificado para operaciones extraordinarias.

Las denominaciones pueden cambiar entre siglos, pero los registros deben indicar equivalencia en peso y metal para evitar confusión histórica.

##### Fiscalidad monetaria

Los impuestos se cobran de forma mixta:

- moneda en ciudades;

- grano en zonas agrícolas;

- ganado en regiones pastoriles;

- madera y resina en zonas forestales;

- metal en regiones mineras;

- servicio naval en puertos;

- trabajo especializado en arsenales.

La Corona evita exigir moneda donde la economía local no tiene circulación suficiente. Esto reduce la presión sobre campesinos y evita que las Casas controlen toda la moneda disponible.

##### Inflación, devaluación y crisis

Las autoridades reconocen varios riesgos:

- reducir la cantidad de plata;

- mezclar cobre en exceso;

- recortar monedas;

- emitir piezas de emergencia;

- financiar guerras mediante acuñación;

- suspender conversiones;

- quebrar bancos de puerto.

Las respuestas incluyen:

- retiro de monedas defectuosas;

- reacuñación;

- pesaje obligatorio;

- límites de emisión;

- auditorías;

- conversión temporal a lingotes;

- pagos en grano;

- control de precios de bienes estratégicos.

##### Relación con Roma y otros sistemas

La moneda romana se acepta como divisa extranjera en el Mediterráneo. Las casas de cambio valinari registran equivalencias sin adoptar automáticamente el sistema romano. El comercio con Roma favorece el uso de plata y oro, pero Valinor mantiene su propia unidad fiscal y sus propios registros.

La circulación de monedas extranjeras no implica subordinación política. Las monedas son instrumentos comerciales, mientras los tratados determinan derechos, impuestos y soberanía.

##### Límites históricos

Antes de 1500 d. C. no deben atribuirse a Valinor:

- banco central moderno con política monetaria científica;

- papel moneda de circulación ilimitada;

- moneda digital;

- banca de reserva fraccionaria plenamente moderna;

- mercados financieros electrónicos;

- tipos de interés calculados de forma uniforme en todo el territorio;

- control macroeconómico contemporáneo.

El sistema monetario valinari es avanzado para su época, pero depende de metal, confianza, registros, rutas y autoridades locales.

##### Resultado histórico

Entre 1000 a. C. y 1500 d. C., Valinor pasa de una economía de obligaciones y metales pesados a una economía monetaria y crediticia compleja. La moneda real unifica impuestos y contratos, pero no elimina la autonomía de Casas, provincias y puertos.

La fortaleza del sistema reside en combinar:

- moneda metálica;

- pagos en especie;

- tesoros regionales;

- bancos portuarios;

- letras de cambio;

- seguros;

- registros públicos;

- reservas estratégicas.

La fórmula canónica queda establecida así:

La moneda valinari no reemplazó la economía material: la hizo medible, transferible y financiable sin separarla del grano, los metales, los puertos, el trabajo y la defensa.

### Evolución financiera comparada

La anticipación de aproximadamente un siglo es una divergencia del escenario para equivalentes funcionales. No constituye una comparación estadística observada con Venecia, Países Bajos, Reino Unido o Estados Unidos. Las cajas interterritoriales desde 1512 pertenecen a una monarquía compuesta; su denominación posterior como federales no traslada la organización constitucional de 1958 al siglo XVI.

#### Evolución financiera comparada y anticipación institucional

Valinor combina cuatro tradiciones históricas: la banca mercantil y el crédito marítimo de Venecia; la Bolsa, los seguros y las sociedades de inversión de Holanda; la deuda pública, la banca central y el Estado fiscal-militar de Inglaterra; y la banca federal, la escala industrial, la investigación aplicada y el mercado continental de Estados Unidos.

La anticipación canónica es aproximadamente de un siglo respecto de los equivalentes funcionales de esas potencias. No significa que Valinor posea bancos modernos, bolsas contemporáneas o empresas industriales desde la Antigüedad. Significa que desarrolla antes mecanismos comparables de registro, crédito, inversión, seguro, deuda, supervisión y financiación pública.

##### Secuencia institucional

- 1000–500 a. C.: graneros, depósitos de metales, préstamos entre Casas, fondos de reparación naval, contribuciones de convoyes, registros de deuda y arbitraje en santuarios.

- 500–50 a. C.: crédito portuario, anticipos sobre cosechas y cargamentos, inversión colectiva de Casas, fondos de expedición, garantías y depósitos protegidos.

- 50 a. C.–500 d. C.: seguros rudimentarios, financiación de factorías y puertos, cuentas entre ciudades, letras de obligación y fondos de reconstrucción.

- 500–900: tesorerías regionales, registros fiscales, equivalencias monetarias, fondos de emergencia y financiación de academias y astilleros.

- 1000–1200: sociedades mercantiles, participaciones en expediciones, mercados portuarios de deuda, inversión colectiva y contabilidad profesional.

- 1200–1400: cámaras de compensación, bolsas portuarias, bancos mercantiles, crédito internacional, compañías de navegación y seguros especializados.

- 1400–1512: bonos para obras, deuda naval, financiación de puertos, impuestos coordinados y obligaciones territoriales.

- 1512–1600: Tesorería interterritorial, presupuesto común, aduanas coordinadas, deuda federal, fondos de educación e investigación y supervisión de compañías.

- 1600–1705: autoridad monetaria funcional, reservas, cámara de compensación, emisión regulada, control de liquidez y mecanismos de prestamista de última instancia.

- 1705–1900: banca de desarrollo, crédito industrial, deuda pública normalizada, financiación de ferrocarriles, minería, siderurgia, energía, astilleros, canales y telecomunicaciones.

- 1900–1958: bancos privados profundos, fondos de investigación, seguros globales, universidades técnicas, mercados de capital e infraestructura multinodal.

- 1958–2026: Tesorería Federal, Autoridad Monetaria, banca pública y privada, fondos territoriales, cooperativas, seguros, OceanNet y coordinación financiera federal.

##### Comparación institucional

Venecia representa la banca mercantil urbana; Holanda, el comercio global y la inversión colectiva; Inglaterra, la deuda pública y la financiación naval; y Estados Unidos, la banca federal, la industria de escala y la innovación tecnológica. Valinor combina esas funciones dentro de una red oceánica de Casas, puertos, provincias, bancos, universidades, astilleros y organismos federales.

La diferencia valinari no consiste en inventar cada mecanismo de forma aislada, sino en integrarlo antes y conectarlo con educación, industria, tecnología, comercio y Armada. La formación de contables, actuarios, juristas, economistas, ingenieros, científicos y oficiales navales permite que el crédito financie no solo mercancías, sino también investigación, infraestructura y capacidad productiva.

##### Estado y finanzas

El Estado evoluciona desde una monarquía pactista basada en reservas y contribuciones de Casas hacia una administración fiscal, después hacia un Estado financiero compuesto y finalmente hacia una federación con moneda, tesorería, banca de desarrollo y supervisión comunes. La Corona conserva funciones patrimoniales y estratégicas, pero no controla directamente toda la banca ni sustituye a los gobiernos territoriales.

La crisis de Armenelos de 1736–1750 consolida reservas, auditorías, identificación de garantías, liquidación ordenada, protección limitada de depósitos y separación entre crédito productivo y especulación. Las pérdidas recaen primero en accionistas y administradores responsables; el apoyo público mantiene pagos esenciales, no beneficios privados ilimitados.

La formulación canónica queda establecida así: Valinor combina la banca mercantil de Venecia, la inversión y el comercio global de Holanda, la deuda pública y el Estado fiscal-militar de Inglaterra y la escala industrial, federal, educativa y tecnológica de Estados Unidos, desarrollando sus equivalentes funcionales aproximadamente un siglo antes y coordinándolos dentro de una civilización marítima federal.

### Banca valinari, 550–1875 d. C.

La banca evoluciona desde tesorerías y depósitos hacia bancos mercantiles, cámaras de compensación, banca pública y crédito industrial. La Corona Telcontar ya gobierna desde 560 a. C.; el periodo 550–700 d. C. es de reorganización de tesorerías y no la fundación de la dinastía.

#### 550–900: depósitos y corresponsales

Las tesorerías custodian metales y los almacenes acreditan bienes. Un depósito en custodia mantiene la titularidad de su dueño; un préstamo transfiere recursos y crea una deuda. El recibo local y la orden de un corresponsal no son todavía billetes universales. Los pagos entre puertos dependen de agentes, sellos, mensajes, rutas y compensaciones posteriores.

#### 900–1200: crédito mercantil

Se amplían letras, anticipos de carga, préstamos marítimos y participación en expediciones. Los Consejos Atlánticos permanentes de 1135 coordinan obligaciones sin reemplazar la Corona. Las garantías se valoran por nave, carga, deudor, puerto de pago, plazo y contingencias del viaje. El reparto de riesgos no equivale a un seguro moderno ilimitado.

#### 1200–1512: bancos y compensación

Las casas de cambio y bancos de depósito financian mercancías y obras. Compensan deudas entre clientes y liquidan saldos en metal. Las obligaciones fiscales, letras privadas y documentos de almacén mantienen diferente riesgo. Las ciudades y las Casas aportan capital, reputación y jurisdicciones de reclamación; una garantía de Casa no equivale a garantía pública.

#### 1512–1705: hacienda común y banca pública

La Secretaría Común y las cajas interterritoriales vinculan presupuestos, aduanas y deuda. Las autoridades monetarias precursoras desarrollan desde el siglo XVII reservas y apoyo de emergencia; su consolidación constitucional posterior no se presenta como primera aparición. El Banco de Desarrollo de la Corona se forma durante 1650–1700 para inversiones de largo plazo. Patrimonio del monarca, hacienda y depósitos de clientes se registran por separado.

#### 1705–1750: regulación y crisis de Armenelos

La Carta de 1705 fortalece presupuesto y responsabilidad. La crisis de 1736–1750 revela dobles garantías, créditos largos financiados con depósitos retirables y pérdidas ocultas. La respuesta distingue falta temporal de liquidez e insolvencia. Los propietarios soportan pérdidas; el apoyo público sostiene pagos esenciales, exige garantías y permite liquidar entidades inviables.

#### 1750–1875: banca industrial y naval

Los bancos de desarrollo financian minas, maquinaria, siderurgia, ferrocarriles, puertos, canal, astilleros y formación. El crédito a largo plazo se combina con capital propio y bonos. Las garantías públicas se presupuestan; no convierten toda inversión privada en deuda del Estado. COFOVAL coordina proyectos y la banca evalúa y administra financiación sin desplazar los controles políticos.

#### Reservas, activos y fondos de clientes

Oro, plata y saldos cobrables en metal forman reservas monetarias. Bonos, hipotecas y préstamos son activos con diferente liquidez. Grano, carbón, hierro y madera son reservas materiales estratégicas o garantías; no permiten convertir inmediatamente billetes a metal. Los depósitos custodiados, las cuentas operativas, las fundaciones y los recursos fiscales conservan expedientes separados.

#### Instituciones y límites en 1875

El Banco Real Valinari coordina emisión convertible, reservas, compensación y deuda conforme a su estatuto. Los bancos navales, industriales, de Casa y territoriales mantienen personalidad y balances propios. Las compañías de seguros y bolsas tienen supervisión diferenciada. La autorización de emisión, el privilegio de acuñar y el otorgamiento de crédito son competencias distintas. La red telegráfica transmite instrucciones y confirmaciones con demoras y verificación humana.

No se fija una garantía universal de depósitos para todo el periodo: las protecciones anteriores a los sistemas modernos son limitadas, territoriales y extraordinarias. Las crisis no desaparecen por disponer de archivos, capital o apoyo de la Corona.

### Contratos marítimos y continuidad de pagos

#### Expedición y financiación

El contrato distingue propietario del casco, armador, capitán, piloto, tripulación, dueño de la carga, prestamista y asegurador. Una Casa puede reunir varios papeles, pero debe registrar qué patrimonio responde por cada obligación. Esa distinción se vuelve más importante cuando las Casas adquieren personalidad mercantil y captan capital ajeno desde el siglo XV.

La cuenta de viaje incluye flete, provisiones, reparaciones, salarios, derechos de puerto, pérdidas y pago del crédito. El beneficio se calcula después de esos costes. Una bodega llena de mercancías valiosas puede producir pérdidas si el retraso obliga a comprar agua, reparar un casco o vender en un mercado saturado. La contabilidad histórica se desarrolla gradualmente y no utiliza desde la Antigüedad todos los instrumentos bancarios posteriores.

#### Riesgos y reparto de pérdidas

Los préstamos de expedición financian viajes concretos; los seguros y la diversificación entre rutas reducen la exposición de cada financiador. El contrato precisa carga cubierta, trayecto, exclusiones y pruebas de pérdida. La declaración de averías se contrasta con inventarios, testimonios y registros portuarios, porque tanto el siniestro ficticio como la ocultación de daños perjudican al conjunto de la red.

La coordinación portuaria facilita arbitraje y ejecución de obligaciones. Un asegurador paga según cobertura pactada; un fondo de socorro auxilia familias y tripulantes según su propio estatuto. Ambas funciones pueden coexistir y requieren cuentas separadas. La deuda comercial tampoco concede a un acreedor soberanía sobre la comunidad donde se produjo el impago.

#### Crisis financiera y respuesta pública

La Crisis de Armenelos de 1736–1750 se profundiza como combinación de garantías repetidas, sociedades vinculadas, depósitos exigibles y activos de recuperación lenta. La interrupción del crédito afecta talleres, salarios, proveedores y alimentos antes de que se resuelvan todos los pleitos patrimoniales.

La intervención distingue falta temporal de liquidez e insolvencia. La primera puede requerir crédito con garantías y plazo; la segunda exige reconocer pérdidas, reorganizar o liquidar. El apoyo a pagos esenciales y empleo no equivale a reponer íntegramente el patrimonio de propietarios. La supervisión coteja registros entre entidades para impedir que un mismo activo respalde obligaciones incompatibles sin conocimiento de los acreedores.

#### Relación con el fomento

Los bancos de desarrollo y COFOVAL financian proyectos cuyo retorno supera el plazo de una campaña comercial. Astilleros, canales, escuelas y redes energéticas requieren capital paciente y mantenimiento. Los compromisos públicos se registran como deuda, aportes o garantías según su naturaleza, evitando que una garantía parezca ingreso disponible. Las cuotas presupuestarias y los totales de ECON-03 mantienen sus valores vigentes; este desarrollo explica mecanismos y responsabilidades.

Desarrollo: 08_Economia/Contratos marítimos y continuidad de pagos.

## Educación y custodia del conocimiento

### Acumulación cultural y conocimiento

##### Educación, conocimiento y divergencia tecnológica

La ventaja valinoriana procede de educación sostenida, preservación y traducción, becas, formación técnica, intercambio comercial y continuidad institucional. Desde la integración de esta doctrina, la educación se considera el principal multiplicador de la economía, la banca, la tecnología y el poder marítimo. Su objetivo canónico no es afirmar que cada invención aparezca antes, sino que Valinor posea la mayor capacidad conjunta del mundo para convertir conocimiento en productividad, crédito, innovación, logística y defensa.

El margen orientativo de 20–80 años de ventaja se conserva para sectores y etapas concretos, pero deja de funcionar como límite de la posición mundial de Valinor. La comparación debe distinguir invención, madurez, adopción comercial, calidad de producción, escala industrial y difusión social. La primacía conjunta puede coexistir con tecnologías extranjeras superiores en un nicho, con regiones atrasadas y con crisis de financiación o de abastecimiento.

El circuito estructural es: educación → especialistas → investigación → producción → comercio y crédito → ingresos públicos y privados → nueva educación e investigación. La educación primaria eleva alfabetización, cálculo, medición, razonamiento, salud, cooperación y comprensión institucional; la secundaria y la formación técnica convierten esa base en operadores, artesanos, contables, pilotos, técnicos y mandos; la educación superior conecta investigación, ingeniería, medicina, economía, derecho, humanidades y administración.

La economía recibe especialistas en agricultura, materiales, procesos, transporte, energía, banca, seguros y mantenimiento. La Armada recibe hidrógrafos, meteorólogos, navegantes, médicos, constructores navales, especialistas en propulsión, comunicaciones, logística y reparación. La banca recibe contables, actuarios, juristas y analistas capaces de valorar proyectos, separar crédito productivo de especulación y sostener seguros marítimos. La tecnología se transfiere mediante la secuencia principio → ensayo → prototipo → fabricación de calidad → formación → mantenimiento, reduciendo la distancia entre el descubrimiento y su uso fiable.

La primacía depende también de instituciones: bancos de desarrollo, crédito industrial de largo plazo, seguros marítimos, fondos públicos de investigación, astilleros, laboratorios, talleres, observatorios y sistemas de supervisión. La crisis financiera de Armenelos de 1736–1750 se conserva como antecedente de que el conocimiento financiero debe acompañar al técnico: la educación no evita el riesgo, pero permite medirlo, auditarlo y limitar su propagación.

La trayectoria se divide en fases: organización de competencias entre 1000 y 500 a. C.; escuelas funcionales y custodia pública entre 500 a. C. y 650 d. C.; reforma de maestros y academias entre 650 y 1200; integración de universidades, comercio y crédito entre 1200 y 1705; conversión de esa base en primacía marítima, industrial y financiera entre 1705 y 1900; y liderazgo científico, productivo, bancario y naval desde 1900 hasta 2026. La inversión educativa conserva el 6 % del PIB federal, separado de los presupuestos de defensa, investigación aplicada, infraestructura y capital industrial para evitar doble contabilización.

La continuidad del circuito intelectual no implica que las mismas instituciones sobrevivieran intactas. Hubo guerras, incendios, censura, secretos, errores y retrocesos. Durante la fragmentación de 300–800 d. C. se perdieron o deterioraron copias regionales, comentarios y materiales pedagógicos, pero los archivos principales, santuarios mayores y Casas de la Memoria conservaron el núcleo del conocimiento mediante las Siete Copias. La estatización del saber significó que la Corona asumió progresivamente su custodia, autenticación, restauración y distribución; no que absorbiera de inmediato todas las escuelas.

La secuencia institucional vigente es: memoria familiar → santuario → Casa de la Memoria → escuela funcional → academia portuaria → universidad → sistema federal de conocimiento → OceanNet. La educación pública, gratuita y obligatoria se implantó gradualmente: escuelas comunitarias y de Casas en la Antigüedad; expansión urbana y portuaria medieval; escolarización pública moderna; garantía federal desde 1956; y acceso coordinado mediante OceanNet desde 1969. En 2026 la educación pública elemental, secundaria y superior es accesible sin arancel general, con regímenes diferenciados para formación técnica, investigación y posgrado.

Los hitos educativos y tecnológicos adoptados son: Reforma Educativa Fundacional del siglo VII y codificación hacia 702; Academias del Mar ampliadas hacia 700; reforma naval de 880–970; Consejos Atlánticos permanentes desde 1135; Secretaría Común y redes documentales después de 1512; Primera Industrialización desde aproximadamente 1740; trabajos del canal desde 1845 y apertura en 1872; Segunda Industrialización desde aproximadamente 1880; reorganización federal de 1958; Programa de Ciencias del Mar de 1963; Instituto de Sistemas Marítimos de Númenor de 1965; Escuela Federal de Documentación de Tol Eressëa de 1966; y Carta de Sistemas Inteligentes de 2024.

Las capacidades se distribuyen sin monopolios absolutos: Númenor en astilleros; Venezuela y Panamá en ingeniería y metalurgia; Systreyjar en logística; Valinor y Sírënandë en agricultura y gestión ambiental; y Malaca en redes formativas y productivas. El comercio, la educación y la investigación también pudieron servir a conquista, coerción y control. Los conocimientos indígenas, africanos, asiáticos y oceánicos conservan su autoría histórica aunque hayan sido traducidos o archivados por instituciones valinarias. La relación entre conocimiento, educación, innovación y recursos es una retroalimentación posible, no automática.

Desde el inicio del comercio, toda relación exterior incluye intercambio cultural. Las embajadas y factorías crean Casas de Traducción y Archivo dedicadas a:

- lenguas y escrituras;

- astronomía;

- medicina;

- matemáticas;

- navegación;

- derecho;

- filosofía;

- religión;

- agricultura;

- metalurgia;

- cartografía.

Los contactos canónicos incluyen Fenicia, Mileto, Nínive, Cos, Atenas, Alejandría, Pérgamo, Beirut, Cartago, Antioquía, Constantinopla, Gundeshapur, Al-Azhar, Bayt al-Hikma, Al-Qarawiyyin, Bolonia, Toledo, París, Cambridge, Padua, Salamanca, Lovaina, Coimbra, Harvard y la Royal Society.

La regla institucional es el Principio de las Siete Copias: toda obra importante debe conservarse en al menos siete archivos distintos.

### Educación y acumulación del conocimiento

##### Principio de las Siete Copias

Todo conocimiento estratégico debe conservarse en varias copias, instituciones y territorios. La doctrina protege leyes, genealogías, calendarios, mapas, navegación, medicina, metalurgia, agricultura, astronomía, administración, traducciones, comercio e ingeniería.

Las copias se distribuyen entre archivos de la Corona, Casas de la Memoria, santuarios, bibliotecas portuarias, escuelas, Casas nobles, depósitos diplomáticos y archivos exteriores. La existencia de varias copias no garantiza que todas sobrevivan, pero impide que la pérdida de un centro destruya necesariamente el conocimiento.

##### Instituciones educativas

La educación evoluciona desde la transmisión familiar y religiosa hacia escuelas de escribas, escuelas portuarias, talleres de oficio, academias de Casas, observatorios, hospitales docentes, academias militares y universidades. La enseñanza religiosa, técnica, jurídica y científica se diferencia progresivamente sin romper sus vínculos históricos.

Las Casas desarrollan especializaciones: Noldor conserva archivos y artesanía; Eressëa Menel, astronomía; Teleri y Alqualondë, navegación; Harnost, comercio; Eäralindë, exploración; las Casas agrícolas, semillas y calendarios; las metalúrgicas, forja e ingeniería; y las Casas Menores, cartografía, traducción y comercio.

##### Fragmentación y concentración, 300–800 d. C.

Las epidemias, guerras, crisis de abastecimiento y rivalidades interrumpen rutas y destruyen o deterioran copias regionales, bibliotecas secundarias, comentarios locales y materiales pedagógicos. No se pierde el núcleo del conocimiento: los archivos principales de la Corona, los grandes santuarios y las Casas de la Memoria conservan leyes, mapas, técnicas, genealogías, calendarios, medicina, metalurgia, agricultura, astronomía, administración y traducciones.

La fragmentación reduce el acceso, la circulación de maestros y la alfabetización regional, pero no borra la continuidad intelectual. El saber se concentra en centros protegidos y la Corona comienza a asumir su custodia, clasificación, autenticación, restauración, copia, certificación y distribución.

Este proceso se denomina estatización del saber. No significa que el Estado controle inmediatamente toda la educación: las Casas, santuarios y comunidades mantienen escuelas locales. Significa que el conocimiento estratégico deja de depender únicamente de familias, templos o linajes y pasa a estar protegido por instituciones públicas de la Corona.

##### Desarrollo cronológico

- 1000–990 a. C.: memoria familiar, santuarios, genealogías, calendarios, técnicas de oficio y transmisión oral.

- 990–850 a. C.: Forostar protege archivos, juramentos, registros de tierras y formación de escribas.

- 850–500 a. C.: las Casas desarrollan escuelas funcionales de navegación, astronomía, agricultura, metalurgia, medicina, derecho y comercio.

- 500 a. C.–300 d. C.: la Corona pactada amplía escuelas portuarias, observatorios, archivos y formación administrativa.

- 300–500 d. C.: los archivos principales reciben documentos de regiones aisladas y conservan el núcleo del conocimiento.

- 500–650 d. C.: se organizan inventarios de pérdidas, traslado documental y restauración de archivos.

- 650–800 d. C.: la Corona certifica calendarios, mapas, genealogías, tratados y copias escolares.

- 800–1000: la recuperación institucional extiende alfabetización y educación, manteniendo un sistema documental centralizado.

- 1005: convenio de astronomía, medicina y filosofía con Dar al-Hikma en El Cairo.

- 1200–1500: contactos con Al-Qarawiyyin, Toledo, Bolonia, París, Cambridge, Padua, Salamanca, Lovaina y Coimbra.

- 1500–1800: imprenta, academias, bibliotecas nacionales, censos y educación técnica.

- 1800–1958: educación industrial, ingeniería, medicina, electricidad, ferrocarriles, meteorología y telecomunicaciones.

- 1958–2026: redes precursoras y OceanNet conectan escuelas, universidades, hospitales, archivos y centros de investigación.

La secuencia canónica es: memoria familiar → santuario → Casa de la Memoria → escuela funcional → academia portuaria → universidad → sistema federal de conocimiento → OceanNet.

### Educación y primacía sistémica

#### sistema educativo como base de la primacía valinari

La educación queda integrada con la economía, la banca, la tecnología y la Armada como un único sistema histórico de acumulación de capacidades. La secuencia canónica es educación → especialistas → investigación → producción → comercio y crédito → ingresos → nueva educación e investigación.

La educación primaria proporciona alfabetización, cálculo, medición, razonamiento, salud, cooperación y comprensión institucional. La secundaria y la formación técnica preparan operadores, artesanos, contables, pilotos, técnicos y mandos. La educación superior vincula universidades, academias, hospitales, observatorios, laboratorios, bancos, astilleros y administración pública.

La economía obtiene productividad y mantenimiento; la banca, contabilidad, seguros, evaluación de riesgos y crédito de largo plazo; la tecnología, una transferencia ordenada desde el principio hasta la fabricación y el mantenimiento; y la Armada, hidrógrafos, meteorólogos, navegantes, médicos, constructores navales, especialistas en propulsión, comunicaciones y logística. La primacía resultante es la mayor capacidad conjunta del mundo para transformar conocimiento en riqueza, financiación, tecnología y poder marítimo, sin implicar adelanto uniforme en cada invención ni ausencia de desigualdades o crisis.

El margen orientativo de 20–80 años se mantiene para sectores y etapas concretos, pero ya no limita la posición mundial conjunta de Valinor. La trayectoria pasa por competencias organizadas entre 1000 y 500 a. C.; escuelas funcionales y custodia pública entre 500 a. C. y 650 d. C.; academias y reforma de maestros entre 650 y 1200; universidades, comercio y crédito entre 1200 y 1705; primacía marítima, industrial y financiera entre 1705 y 1900; y liderazgo científico, productivo, bancario y naval entre 1900 y 2026.

La inversión educativa conserva el 6 % del PIB federal, con 75 % federal, 24 % territorial y 1 % de la Corona mediante Becas Reales de Educación. La investigación aplicada, defensa, infraestructura, bancos de desarrollo, astilleros e industria mantienen partidas propias y no se suman de nuevo al gasto educativo.

### Ley de Custodia Compartida y acumulación del conocimiento, 700 a. C.–700 d. C.

La acumulación del conocimiento no es lineal ni universal. Existen pérdidas, traducciones incompletas, errores de interpretación, conflictos entre tradiciones, archivos destruidos, rutas cerradas, regiones aisladas y desigualdad material de acceso.

Sin embargo, la legislación valinari establece que las bibliotecas, santuarios, academias y archivos deben compartir el contenido técnico útil para la comunidad. La norma impide que una Casa convierta de forma permanente en propiedad exclusiva los conocimientos necesarios para la producción, la navegación, la salud, la agricultura, la construcción o la defensa común.

##### Principio de publicidad técnica

Todo conocimiento técnico que pueda mejorar la producción, la salud, la navegación, la agricultura, la construcción, la educación o la administración debe ser registrado, copiado y puesto a disposición de las instituciones reconocidas.

La obligación comprende:

- manuales agrícolas;

- técnicas metalúrgicas;

- construcción naval;

- navegación;

- medicina;

- hidráulica;

- arquitectura;

- calendarios;

- matemáticas;

- conservación de alimentos;

- ingeniería;

- administración;

- traducción;

- fabricación de herramientas.

##### Excepciones reguladas

Pueden mantenerse bajo custodia restringida los planes militares activos, la ubicación de arsenales, los códigos diplomáticos, las defensas, las rutas secretas en guerra, los datos personales, los rituales internos y los procedimientos peligrosos.

Toda restricción debe justificarse, registrarse, tener responsables, revisarse periódicamente y conservar una copia sellada. Cuando desaparece el riesgo, el conocimiento debe hacerse accesible.

##### Obligaciones de las bibliotecas y Casas

Las bibliotecas reconocidas deben registrar sus fondos, conservar copias, compartir manuales, permitir consultas, enviar duplicados a archivos regionales, traducir documentos esenciales e informar de pérdidas.

Las Casas pueden proteger genealogías, correspondencia privada, archivos patrimoniales y rituales internos, pero deben entregar al sistema común las técnicas agrícolas, navales, médicas, administrativas y de construcción.

La doctrina de las Siete Copias se aplica a los textos esenciales para reducir la posibilidad de pérdida completa.

##### Instituciones de difusión

La difusión se realiza mediante academias, escuelas portuarias, santuarios, Casas de la Memoria, talleres, archivos provinciales, maestros itinerantes, manuales, traducciones y demostraciones públicas.

La ley garantiza disponibilidad institucional, no alfabetización inmediata ni capacidad técnica uniforme. Una comunidad puede tener derecho a consultar un manual y carecer todavía de materiales, maestros o herramientas para aplicarlo.

##### Monopolios técnicos

Se prohíben los monopolios permanentes sobre alimentos, herramientas agrícolas, medicamentos básicos, construcción, reparación naval, sistemas de agua y prevención de epidemias.

Pueden concederse privilegios temporales para financiar una innovación, pero deben incluir duración limitada, registro público, formación de aprendices, copia del procedimiento y revisión por la Corona o el Consejo.

##### Efectos durante la Fragmentación

Entre 200 y 500 d. C., la ley no impide la destrucción de copias, la pérdida de traductores, la interrupción de talleres o el aislamiento regional. Su efecto consiste en conservar el núcleo técnico en los archivos principales y permitir la reconstrucción posterior mediante inventarios, testimonios, copias y memoria comunitaria.

La pérdida deja de ser principalmente un problema de propiedad y pasa a ser un problema de conservación, transmisión y capacidad práctica.

##### Evolución histórica

- 700–500 a. C.: obligación religiosa y pactista de compartir calendarios, agricultura, medicina y navegación básica.

- 500–300 a. C.: el Consejo exige copias de técnicas militares, agrícolas, metalúrgicas y portuarias.

- 300–50 a. C.: se crean inventarios, archivos de consulta y redes de traducción.

- 50 a. C.–200 d. C.: la expansión romana y mediterránea aumenta la circulación de manuales, contratos, medicina e ingeniería.

- 200–500 d. C.: los archivos principales preservan el núcleo técnico durante la Fragmentación.

- 500–700 d. C.: academias, bibliotecas públicas, escuelas de puerto y archivos centrales formalizan la difusión.

La regla canónica queda establecida así:

Las bibliotecas pueden restringir información militar, privada o ritual, pero no pueden apropiarse permanentemente del conocimiento técnico necesario para la vida, la producción, la navegación, la salud o la defensa común.

### Aprendizaje expedicionario y procedencia del conocimiento

#### Circuito de aprendizaje

La educación prepara navegantes, artesanos e intérpretes; las expediciones reúnen observaciones y testimonios; los archivos conservan resultados; las academias contrastan experiencias; escuelas y talleres distribuyen procedimientos que pueden volver a probarse. La ventaja técnica depende de completar ese circuito y de disponer de energía, herramientas, maestros, financiación y tiempo para aplicarlo.

En las primeras etapas predominan demostraciones y memoria oral. La reforma educativa del siglo VII y la codificación aproximada de 702 estabilizan enseñanza y formación de maestros. Las Academias del Mar amplían la comparación de diarios y prácticas. Las expediciones formativas llevan aprendices y especialistas cuando la misión y los recursos lo permiten; una travesía comercial pequeña no requiere la dotación de una misión científica posterior.

#### Testimonios y atribución

El Registro de Testimonio Técnico Oral se incorpora como función documental de la administración madura, con fecha de formalización pendiente. Registra quién transmite un procedimiento, dónde lo aprendió, con qué materiales funciona y qué condiciones limita su reproducción. Una demostración local puede revelar conocimientos que un texto traducido omite. La procedencia se conserva aunque la técnica se adapte en otro territorio.

Los saberes africanos, americanos y asiáticos tienen autores y comunidades propias. El comercio facilita aprendizaje; también existen apropiación, traducciones interesadas y acceso impuesto durante la expansión. El expediente técnico conserva esas circunstancias cuando pueden documentarse. La validación académica de una técnica no constituye por sí sola un título de propiedad sobre el conocimiento de quienes la enseñaron.

#### Fracasos y siete copias

Los archivos conservan diarios de naufragios, ensayos fallidos, errores de cálculo, cosechas mal adaptadas y reparaciones ineficaces. Las versiones corregidas remiten a las anteriores para que un taller pueda saber por qué cambió una instrucción. La ley de custodia compartida obliga a remitir contenido técnico a las bibliotecas autorizadas.

La norma de preservación continúa siendo siete copias completas en siete sedes independientes. Las referencias v050 a tres custodias o cinco localizaciones quedan sustituidas en esta materia. Durante la Fragmentación se deterioran copias regionales, rutas de acceso y capacidad de enseñar; los archivos principales conservan el corpus depositado. La reconstrucción restituye circulación, personal y talleres capaces de utilizarlo.

#### Acceso, becas y capacidad

Las ayudas de acceso y permanencia atienden alimentación, alojamiento, transporte y materiales. Las de excelencia e investigación se evalúan por sus fines específicos. El máximo de hasta dos plazas adicionales becadas por plaza privada se conserva como programa condicionado a docentes, talleres, laboratorios y financiación acreditada; no multiplica automáticamente la matrícula total ni crea gasto sin cobertura.

La financiación educativa mantiene el reparto ya aprobado: 75 % federal, 24 % territorial y 1 % mediante Becas Reales de Educación sobre el presupuesto público del sistema. Las instituciones de la Corona no obtienen control curricular por su aporte. Alfabetización, matrícula y titulación se miden por separado para que una obligación legal de enseñar no aparezca como cobertura completa desde su promulgación.

Desarrollo: 13_Sociedad/Aprendizaje expedicionario y procedencia del conocimiento.

## Energía, industria y tecnología

### Industrialización, tecnología, armada y diplomacia austral

La modernización valinoriana entre 1850 y 2026 se divide en cuatro procesos relacionados pero distintos: industrialización productiva, desarrollo científico-tecnológico, evolución de la armada y diplomacia de enclaves y alianzas. Esta separación evita confundir capacidad industrial con soberanía territorial o cooperación internacional.

##### Industrialización y complejo estratégico

- 1850–1880: expansión de máquinas de vapor ferroviarias y navales, arsenales, talleres metalúrgicos y producción de locomotoras.

- 1880–1910: motores de combustión, generadores, maquinaria industrial y primeros motores aeronáuticos.

- 1910–1940: motores diésel para blindados, submarinos, buques y transporte pesado.

- 1940–1960: turbinas de gas para aviación y generación eléctrica.

- 1958–1968: transistores, circuitos integrados y electrónica asociada a OceanNet.

- 1969–1980: microprocesadores federales, radares y sistemas de control.

- 1980–2000: motores modulares, combustibles sintéticos, circuitos resistentes y propulsión híbrida.

- 1995–2010: fabricación avanzada de procesadores para satélites, radares y aeronaves.

- 2010–2026: inteligencia artificial, procesadores neuromórficos, turbinas avanzadas y propulsión naval integrada.

- 2026: la cadena estratégica queda integrada desde la minería y la refinación hasta circuitos, procesadores, motores, turbinas y sistemas militares.

Estas actividades se contabilizan dentro de las categorías ECON-03 de minería y energía, manufactura, transporte, información e I+D. No crean una categoría adicional ni modifican los objetivos de PIB vigentes.

##### Ciencia y tecnología

OceanNet se desarrolla mediante redes precursoras entre 1954–1958 y alcanza funcionamiento operativo inicial en 1959 como red de comunicaciones, observación y coordinación científica. La etapa 1969–1980 consolida el procesamiento digital y los radares; 1980–2000 añade propulsión híbrida, combustibles sintéticos y electrónica resistente; 1995–2010 incorpora fabricación avanzada para satélites, radares y aeronaves; y 2010–2026 desarrolla IA, procesamiento neuromórfico y sistemas autónomos.

Entre 1990 y 2026 se formalizan además los programas orbitales, las comunicaciones satelitales, la observación oceánica y meteorológica, la navegación autónoma y los sistemas de alerta austral. La tecnología hipersónica se considera capacidad militar avanzada de 2026, no una capacidad civil generalizada.

##### Armada y sistemas de defensa

- 1850–1900: arsenales de vapor, buques blindados, torpederos y patrulleros.

- 1900–1945: destructores iniciales, submarinos convencionales, cruceros y aviación naval.

- 1945–1965: portaaviones, submarinos de largo alcance, buques logísticos y radares navales.

- 1965–1985: clases Gil-galad, Círdan inicial y Ulmo; misiles, sonar y OceanNet temprano.

- 1985–2005: clases Círdan II–III, Pelargir, Andúnië y primeros drones navales; producción modular y radares AESA.

- 2005–2026: Círdan IV, Eärendil, Telperion, Palantír, Menel, Esgaroth y Abyssal; misiles hipersónicos y vigilancia distribuida.

- 2026: la Armada opera portaaviones, escoltas, submarinos, buques logísticos, drones y unidades de rescate.

- 2022–2033: la clase Voronwë sustituye gradualmente a Círdan IV conforme al calendario anticipado ya adoptado.

La expresión técnica canónica será radar AESA tridimensional con procesamiento 4D. Palantír-4D es el sistema operativo desplegado en 2015–2026; Palantír Aeglos permanece en fase de investigación, pruebas y modernización progresiva hasta 2045.

##### Diplomacia austral y Gwaith Aear

- 1848: Tratado de Valparaíso entre Chile y la Unión Valinoriana.

- 1876: Pacto del Pacífico Austral para cooperación naval, seguros, formación de oficiales y logística.

- 1879–1886: Guerra del Pacífico ampliada, registrada como retcon histórico consolidado.

- 1886: Tratado de Nueva Tirion; Chile obtiene las cesiones territoriales establecidas por el canon y se consolida como potencia marítima del Pacífico sur.

- 1890: Andúnië Austral se funda como ciudad científica arrendada bajo soberanía chilena.

- 1938: creación del Instituto Austral de Oceanografía.

- 1945: integración con los programas antárticos valinorianos.

- 1958: conexión de Andúnië Austral con OceanNet.

- 1970–2010: radares meteorológicos, sísmicos y oceanográficos; ampliación del puerto, laboratorios, aeropuerto y sistemas de alerta.

- 2026: Andúnië Austral se consolida como nodo científico, antártico y logístico asociado a Gwaith Aear.

Los tratados con Chile no convierten a Chile ni a Andúnië Austral en provincias valinorianas. Representan cooperación con un aliado extranjero dentro de Gwaith Aear.

### Complejo Industrial Estratégico — motores, turbinas y microelectrónica

Estado: [CANON VIGENTE]. La sección describe capacidades industriales y su desarrollo tecnológico.

La industria militar valinoriana incluye una cadena autónoma de motores, turbinas, procesadores y circuitos. Estas ramas son estratégicas porque permiten fabricar aeronaves, buques, vehículos blindados, satélites, radares, drones y sistemas de mando sin depender de proveedores externos.

##### Motores y propulsión

- 1850–1880: máquinas de vapor ferroviarias y navales.

- 1880–1910: motores de combustión para camiones, aeronaves y generadores.

- 1910–1940: motores diésel para blindados, submarinos y buques.

- 1940–1960: turbinas de gas para aviación y generación eléctrica.

- 1960–1980: motores navales de alta eficiencia y turbinas aeronáuticas.

- 1980–2000: motores modulares, combustibles sintéticos y propulsión híbrida.

- 2000–2026: motores eléctricos militares, turbinas avanzadas y propulsión naval integrada.

##### Turbinas

La Federación produce turbinas navales, aeronáuticas, energéticas y microturbinas para drones, generadores portátiles y bases aisladas. La producción militar y civil comparte materiales, bancos de pruebas y cadenas de mantenimiento.

##### Procesadores y circuitos

- 1930–1945: cálculo electromecánico y analógico.

- 1946–1958: válvulas, relés y computadores centrales.

- 1958–1968: transistores y primeros circuitos integrados.

- 1959–1980: funcionamiento operativo inicial, microprocesadores federales para OceanNet.

- 1980–1995: procesadores resistentes a radiación y temperaturas extremas.

- 1995–2010: fabricación avanzada para satélites, radares y aeronaves.

- 2010–2026: procesadores de inteligencia artificial, computación cuántica experimental y sistemas neuromórficos.

##### Centros industriales

- Valinor: diseño de procesadores, arquitectura informática, inteligencia artificial y criptografía.

- Arnor: fabricación de chips, radares, motores y electrónica industrial.

- Malaca: producción masiva, encapsulado, robótica y electrónica naval.

- Calenardhon Austral: turbinas, generadores, motores navales y electrónica de potencia.

- Sírënandë y Provincia del Orinoco: cobre, aluminio, níquel, tierras raras y energía hidroeléctrica.

- Hawái: sistemas aeroespaciales, sensores oceánicos y satélites.

- Colombia Costera: puertos, manufactura, agroindustria, servicios empresariales y banca comercial regional.

- Panamá Federal: canal, puertos, financiación comercial, seguros marítimos, construcción naval y servicios digitales.

La cadena estratégica queda definida como:

minería → refinación → obleas → circuitos → procesadores → motores → turbinas → vehículos → sistemas militares.

Esta integración constituye una de las principales ventajas tecnológicas de Gwaith Valinor frente a los Estados externos.

#### Decisión 1 autonomía selectiva y balance de suministro 2026

La Decisión 1 adopta autonomía estratégica selectiva: Valinor diseña, fabrica, integra, repara y recicla componentes maduros y estratégicos; importa de forma diversificada equipos y chips de frontera. COFOVAL se funda en 1839. Su apropiación anual evoluciona como proporción del PIB contemporáneo: 0,10 % (1839–1869), 0,15 % (1870–1913), 0,25 % (1914–1945), 0,40 % (1946–1980), 0,50 % (1981–2000), 0,55 % (2001–2025) y 0,60 % en 2026.

Sobre el PIB PPA federal central de 65,50 billones, la apropiación de COFOVAL en 2026 es 393.000 millones PPA. El techo de proyectos movilizados es 917.000 millones e incluye la apropiación; hasta 524.000 millones dependen de préstamos y cofinanciación efectivamente contratados, no de una obligación automática del Tesoro. Los 78.600 millones del rubro de industria/electrónica se reparten en cofinanciación fabril (39.300), I+D aplicada (15.720), proveedores y reparación (9.432), infraestructura de energía/agua/ambiente (7.860), y formación, estándares y certificación (6.288 millones PPA).

El caso financiero de planificación concilia inversión sectorial de 131.000 millones PPA: 39.300 de COFOVAL, 19.650 de infraestructura pública/territorial, 52.400 de capital privado y 19.650 de préstamos. I+D suma 52.400 millones: 15.720 de COFOVAL, 13.100 de universidades y ciencia pública, 18.340 privados y 5.240 territoriales. Estos flujos se identifican por proyecto y fuente para impedir doble conteo; el gasto educativo del 6 % del PIB permanece separado.

La escala industrial se fija como meta de planificación: demanda de 6–9 millones de obleas equivalentes de 300 mm y 52–73 mil millones de componentes empaquetados al año; capacidad nominal de 7,0–8,8 millones de obleas y producción efectiva objetivo de 5,7–7,7 millones. Se planifican 4–6 polos, 10–12 líneas maduras/especializadas, 2–3 avanzadas, 6–10 centros de encapsulado y prueba, 2–3 centros de investigación, 12–20 TWh/año y 50–90 millones de m³/año de agua bruta. La fuerza laboral objetivo es 53–80 mil empleos directos y 110–180 mil indirectos. Emplazamientos, recursos y producción efectiva requieren auditoría y autorización territorial.

El PIB federal no cambia: 65,50 billones PPA. El valor añadido electrónico y los servicios de telecomunicaciones ya forman parte de ECON-03; COFOVAL, la inversión privada, préstamos y presupuestos territoriales se distinguen por fuente y nunca se suman dos veces.

Balance físico central de semiconductores en 2026. Millones de obleas equivalentes de 300 mm por año; producción local + importaciones = demanda interna + exportaciones + aumento de inventario.

| Familia | Demanda | Producción local | Importación | Exportación | Inventario neto | Balance |
| --- | --- | --- | --- | --- | --- | --- |
| Lógica madura, MCU y control | 2,40 | 2,65 | 0,15 | 0,35 | 0,05 | 2,80 = 2,80 |
| Analógico, discretos y potencia | 1,85 | 1,95 | 0,10 | 0,15 | 0,05 | 2,05 = 2,05 |
| Memoria y almacenamiento | 1,50 | 1,00 | 0,55 | 0,05 | 0,00 | 1,55 = 1,55 |
| RF, comunicaciones, imagen y sensores | 1,05 | 0,90 | 0,20 | 0,05 | 0,00 | 1,10 = 1,10 |
| Procesadores y aceleradores avanzados | 0,70 | 0,40 | 0,35 | 0,05 | 0,00 | 0,75 = 0,75 |
| TOTAL | 7,50 | 6,90 | 1,35 | 0,65 | 0,10 | 8,25 = 8,25 |

El caso central cierra en 7,50 millones de obleas demandadas, 6,90 producidas localmente, 1,35 importadas, 0,65 exportadas y 0,10 añadidas a inventario. La disponibilidad local neta es 6,15 millones, alrededor del 82 % de la demanda física; la cobertura total por valor se mantiene en 60–75 % porque los procesadores avanzados importados valen más por oblea. En componentes empaquetados, 48 mil millones locales + 14 importados = 62 demandados + 2 exportados. Son metas, no producción auditada.

#### Decisión 2 infraestructura troncal de telecomunicaciones

Valinor adopta una arquitectura equilibrada: fibra óptica terrestre y submarina como troncal de capacidad; radio, microondas y redes móviles para acceso, movilidad y rutas alternativas; satélites para navegación, islas remotas y respaldo. OceanNet es la capa lógica de servicios e intercambio que usa esos medios, no un sinónimo de cable ni una operadora única.

Los corredores forman anillos y mallas con diversidad física. Cada capital federal/provincial, puerto estratégico, hospital de referencia, centro de datos y nodo energético crítico debe tener dos rutas físicamente diversas cuando la geografía lo permita. Se mantienen planes de reparación de cables, repuestos, energía de respaldo y operación local degradada. Los dominios civiles, industriales críticos y militares se separan mediante controles y pasarelas; compartir cable no autoriza compartir bases de datos ni mando.

La norma tecnológica permite hasta siete años de adelanto en aplicación amplia solo después de que la etapa mundial pertinente ya sea demostrable. Los hitos se separan en investigación, demostración, prototipo, servicio limitado, despliegue federal y adopción general. Las metas de cobertura, tráfico, gasto y disponibilidad de 2026 quedan pendientes de mapa territorial y auditoría; no se presentan como resultados medidos.

La Decisión 2 no eleva el PIB ni el presupuesto canónico. COFOVAL cofinancia brechas de servicio universal y rutas estratégicas dentro de las partidas existentes; gobiernos territoriales, operadores, tarifas y capital privado cubren los demás costos. El regulador de comunicaciones mantiene independencia de OceanNet y de los operadores; su denominación y fecha legal quedan sujetas a armonización institucional.

##### Hitos de transporte, operación y regla de adelanto

| Fecha | Hito valinari | Límite/comparación |
| --- | --- | --- |
| 1850 | Red Telegráfica del Gran Mar entre capitales y puertos. | Telegrafía ya demostrable; uso comercial, naval y administrativo. |
| 1870–1900 | Cables submarinos y telefonía; Red de los Heraldos del Mar. | Red analógica; expansión progresiva. |
| 1954–1959 | Precursores OceanNet; desde 1959 servicio digital institucional limitado. | Sin cobertura civil general ni fibra comercial. |
| 1962–1965 | Pruebas valinari de estaciones satelitales tras demostraciones internacionales. | Telstar 1962; Early Bird comercial geoestacionario 1965. |
| 1970–1978 | Investigación/pilotos de fibra de baja pérdida, radioenlaces y telefonía móvil. | La demostración mundial de baja pérdida antecede el piloto valinari. |
| 1981 | Primer corredor óptico submarino transoceánico valinari en servicio limitado. | Siete años antes del TAT-8 mundial de 1988. |
| 1983 | Protocolo federal común entre redes sectoriales. | OceanNet no equivale retroactivamente a Internet pública. |
| 1984–2026 | Expansión de fibra, redes móviles, satélites y rutas redundantes; acceso civil gradual. | Sin cobertura universal atribuida sin medir hogares, capacidad y disponibilidad. |

El corredor óptico submarino de 1981 antecede siete años al TAT-8 transatlántico mundial. El adelanto parte de la demostración global de fibra de baja pérdida en 1970; no anticipa la prueba mundial ni elimina restricciones de fabricación, personal o reparación. Los demás adelantos se valoran frente a la difusión amplia, y no se fuerza un margen de siete años si contradice la demostración o la disponibilidad de componentes.

#### Normalización de la integración

La Unión Valinoriana aprueba una estrategia federal de catorce decisiones para la Tercera Revolución Industrial. Las Decisiones 1–2 —autonomía selectiva de semiconductores y arquitectura troncal de telecomunicaciones— conservan sus desarrollos técnicos específicos en las secciones precedentes. Las Decisiones 3–14 establecen el marco de continuidad, computación, automatización, seguridad, identidad, datos, investigación, calidad, energía, acceso, competencia y gobernanza.

#### Decisión 3 — Continuidad operativa y resiliencia

Los servicios se priorizan por función vital, crítica, estratégica o diferible. La continuidad combina reservas rotatorias, proveedores alternativos, reparación, sustitución, operación local degradada y coordinación civil. El escenario de doce meses es una prueba de estrés; los objetivos de servicio siguen siendo metas hasta validarse mediante ejercicios por sector y territorio. Se prueban fallos de proveedor, comunicaciones, energía, puertos, datos y sistemas industriales.

#### Decisión 4 — Computación y arquitectura digital

La arquitectura federal se organiza por capas interoperables: dispositivos, conectividad, cómputo, datos, servicios comunes, aplicaciones y gobernanza. Los centros federales, territoriales, universitarios, sectoriales y comerciales conservan funciones y permisos separados. Los servicios esenciales pueden operar localmente, recuperar datos y migrar de proveedor. Valinor fabrica o integra donde aporta continuidad y conocimiento; mantiene importación selectiva de equipos de frontera.

#### Decisión 5 — Automatización industrial

La automatización combina instrumentación, control local, supervisión, planificación y análisis. Las funciones de seguridad no dependen de OceanNet y pasan a estados seguros ante fallos. Los pilotos miden calidad, productividad, energía, incidentes y empleo. La expansión requiere técnicos, documentación, repuestos, mantenimiento y participación laboral. El éxito incluye seguridad y calidad del trabajo, además del volumen producido.

#### Decisión 6 — Ciberseguridad y privacidad

La protección se basa en inventario de activos, privilegio mínimo, segmentación, gestión de claves, actualización probada, monitoreo proporcional y recuperación verificada. Redes civiles, industriales y militares mantienen dominios separados. Los datos se tratan por finalidad y con retención limitada. Accesos excepcionales requieren base legal, alcance, plazo, registro y supervisión; la atribución de incidentes distingue hechos confirmados de hipótesis.

#### Decisión 7 — Identidad digital y servicios públicos

Las credenciales permiten probar identidad o atributos concretos sin crear un expediente universal. Su uso es voluntario y existen alternativas equivalentes para servicios esenciales. La firma se gradúa según riesgo; la biometría es excepcional y dispone de alternativa. El registro civil conserva autoridad sobre identidad legal, mientras proveedores suministran herramientas. Denegaciones automatizadas admiten explicación, revisión humana, apelación y reparación.

#### Decisión 8 — Datos e interoperabilidad

El gobierno de datos es federado: custodios sectoriales conservan sus conjuntos bajo estándares comunes, y un catálogo describe los datos sin conceder acceso automático. Los intercambios registran finalidad, fundamento, campos, destinatario y plazo. Calidad, incertidumbre, procedencia, correcciones, retención y eliminación quedan documentadas. La Doctrina de las Siete Copias se conserva para los fondos a los que aplica, con independencia y pruebas reales de restauración.

#### Decisión 9 — Investigación e innovación

La cartera equilibra ciencia básica, exploratoria, aplicada, demostración, escalamiento y difusión. La financiación se libera por etapas y revisión independiente; resultados negativos útiles se documentan. Universidades, institutos, laboratorios, territorios, empresas y COFOVAL participan según sus mandatos. Propiedad intelectual, publicación, datos, mantenimiento y continuidad se pactan al iniciar cada proyecto. Los presupuestos científicos y capacidades de laboratorios y personal requieren inventario antes de fijar metas.

#### Decisión 10 — Estándares, metrología y calidad

Patrones trazables, normas versionadas, laboratorios competentes, acreditación independiente y certificación proporcional al riesgo hacen comparables los productos. El fabricante no certifica por sí solo equipos críticos. Se conserva trazabilidad de lotes, versiones, pruebas, reparaciones y retiros. Las compras incluyen criterios de aceptación, soporte y costo de ciclo de vida; la capacidad nacional de ensayo se verifica con inventarios y auditorías.

#### Decisión 11 — Energía y huella material

Las instalaciones digitales declaran consumo anual y máximo, agua, respaldo, materiales, residuos y cargas flexibles. La planificación prioriza vida, agua, salud y control seguro de redes; cargas aplazables participan en respuesta a demanda. Se revisan impactos acumulados, sequía, refrigeración, reparación y recuperación material efectiva. La expansión digital no desplaza servicios esenciales ni transfiere costos ambientales a hogares y territorios.

#### Decisión 12 — Acceso y cohesión territorial

El acceso efectivo comprende conexión estable y asequible, equipos, energía, habilidades, accesibilidad, soporte y canales alternativos. Obligaciones y subsidios se vinculan a calidad y reparación medidas, no solo a infraestructura instalada. Educación y formación adulta desarrollan alfabetización, seguridad, evaluación crítica y capacidades técnicas. Los efectos laborales y las brechas territoriales se evalúan antes y después del despliegue.

#### Decisión 13 — Competencia y compras públicas

La política evalúa concentración junto con costos de cambio, control de datos e interfaces, exclusividad, precios, calidad y entrada de competidores. La concentración aislada no demuestra abuso. Las medidas pueden incluir portabilidad, interoperabilidad, corrección contractual, separación contable o sanciones proporcionales. Las compras públicas son competitivas y transparentes, incluyen salida y migración, y someten urgencias a revisión.

#### Decisión 14 — Gobernanza y corrección

Cada programa identifica dirección política, autorización presupuestaria, ejecutor, regulador, custodio, auditor y vía de apelación. Antes de crear organismos se armonizan funciones con instituciones canónicas vigentes y se documentan vacíos. El ciclo incluye diagnóstico, diseño, autorización, piloto, evaluación independiente, escalamiento, operación y revisión. Según evidencia, el programa continúa, se corrige, pausa o cierra.

#### Estatus presupuestario y de capacidad

La aprobación de las catorce decisiones adopta principios y arquitectura estratégica; no convierte metas en resultados medidos, no crea automáticamente nuevas instituciones y no eleva por sí sola el PIB ni los presupuestos. Cada programa requiere línea base, responsable, presupuesto de ciclo de vida, fuente conciliada con COFOVAL y ECON-03, auditoría, prueba y fecha de revisión. Las cifras se etiquetan como dato, observación, estimación, meta o pendiente.

#### Ventaja tecnológica selectiva de diez años

Valinor persigue hasta diez años de adelanto en despliegue amplio en áreas prioritarias, medido por tecnología y rival concreto. Se distinguen investigación, demostración, prototipo, servicio limitado, adopción amplia, producción, mantenimiento y acceso social. Una instalación piloto, una patente o una fecha temprana no bastan para declarar ventaja nacional. Las comparaciones se revisan con evidencia y pueden acotarse o retirarse. Este objetivo general no sustituye la regla específica de siete años para el adelanto de aplicación en telecomunicaciones, que se mantiene en su ámbito hasta una revisión expresa.

### Desarrollo histórico y evaluación de la Tercera Revolución Industrial 1950–2026

La Tercera Revolución Industrial valinari es la transformación acumulativa que une electrónica, computación, telecomunicaciones, automatización y redes digitales con la producción, la administración, la ciencia y la vida cotidiana. No es una sola invención ni un despliegue uniforme. Las capacidades aparecen primero en laboratorios, defensa, universidades o grandes operadores y solo después, de forma desigual, llegan a empresas, hogares y servicios públicos.

Cada afirmación histórica se clasifica como hito fijado en canon, decisión aprobada, objetivo, estimación o pendiente de datos. La cronología distingue investigación, demostración, prototipo, servicio limitado, adopción amplia, fabricación y mantenimiento. Una patente, prueba o instalación piloto no demuestra por sí sola una ventaja nacional.

#### Cronología integrada

- 1950–1953 — Bases de cálculo y electrónica: se fortalecen laboratorios, electrónica, criptografía, cálculo científico y control especializado. La prioridad es formar equipos y desarrollar instrumentación; todavía no existe una red digital federal de uso general.

- 1954–1958 — Programa precursor de OceanNet: se conectan de forma experimental centros de cálculo, radio, microondas y líneas dedicadas. Se diseñan protocolos, terminales y procedimientos de operación. Este intervalo es de preparación y prueba, no de funcionamiento pleno de OceanNet.

- 1958 — Programa OceanNet: queda constituido el programa federal científico, naval y de comunicaciones.

- 1959–1968 — Operación institucional limitada: OceanNet inicia servicio digital restringido para investigación, coordinación naval, observación y administración. El acceso depende de centros especializados y personal operador.

- 1961–1962 — Pruebas de conmutación y satélite: se ensayan nuevas formas de conexión y enlaces satelitales sin convertirlos todavía en servicios universales.

- 1968–1969 — Estatuto y consolidación federal: el estatuto federal de 1968 y la consolidación institucional de 1969 organizan la expansión de OceanNet. El año 1969 no es el comienzo del servicio, sino una fase institucional posterior.

- 1970–1979 — Expansión científica e industrial: universidades, puertos, observatorios, centros industriales y administraciones se integran gradualmente. La red conserva funciones especializadas y sus costos limitan el acceso.

- 1980–1989 — Interoperabilidad y fibra: avanzan redes digitales, protocolos comunes y corredores ópticos. La ficha de telecomunicaciones conserva los hitos específicos, incluida la regla de adelanto de siete años, su demostración de referencia y sus límites de fabricación y reparación.

- 1990–2000 — Apertura civil y comercial: se amplían banca, comercio, educación, medios y servicios públicos en línea. La conexión crece por etapas y con diferencias territoriales.

- 2001–2010 — Banda ancha y centros de datos: se extienden fibra, movilidad, servicios digitales y almacenamiento distribuido; crecen las necesidades de energía, refrigeración, especialistas y seguridad.

- 2011–2020 — Plataformas, nube y automatización sectorial: sensores, análisis de datos y servicios móviles mejoran coordinación y productividad, al tiempo que aumentan la dependencia de proveedores y la importancia de privacidad, competencia y continuidad.

- 2021–2026 — Infraestructura digital estratégica: se integran electrónica, centros de datos, ciberseguridad, inteligencia artificial aplicada, redes de energía y automatización. En 2026 se aprueba una estrategia de catorce decisiones y un objetivo selectivo de hasta diez años de ventaja en despliegue amplio por tecnología y rival. Es una meta comparativa, no una constatación uniforme.

#### Consecuencias económicas

La digitalización reduce costos de coordinación y transacción cuando existen redes confiables, procesos adecuados y personal formado. Sus efectos se observan en logística, banca, energía, manufactura, transporte, agricultura, salud, educación y administración. También crea sectores de software, telecomunicaciones, diseño electrónico, centros de datos, ciberseguridad, integración y mantenimiento.

La evaluación separa inversión inicial, operación y reposición; valor añadido digital directo; mejoras de productividad en sectores usuarios; y costos de energía, agua, seguridad y formación. El impacto indirecto no se suma de nuevo al valor directo. La tecnología puede elevar productividad, pero el crecimiento total no se atribuye automáticamente a ella ni se usa para modificar el PIB canónico sin una revisión macroeconómica explícita.

El empleo cambia junto con la producción. Se registran ocupaciones creadas, tareas automatizadas, puestos transformados o desplazados, salarios, seguridad laboral, formación y tiempo de recolocación. Los proyectos apoyados con fondos públicos deben explicar sus efectos laborales y prever capacitación o transición.

#### Transformación social y acceso

El acceso efectivo exige conectividad estable y asequible, electricidad, dispositivos, habilidades, accesibilidad, soporte y alternativas ante fallos. La cobertura nominal no equivale a uso efectivo. Las mediciones distinguen capitales, ciudades, áreas rurales, islas y regiones remotas, y consideran ingreso, edad, discapacidad y ocupación.

La educación combina alfabetización digital general, evaluación crítica de información, seguridad, formación técnica y aprendizaje adulto. La automatización no debe volver inaccesibles servicios esenciales: se conservan vías presenciales o asistidas para salud, educación, prestaciones y justicia.

La política de datos establece finalidad, minimización, plazos de conservación, trazabilidad, acceso y rectificación. Las decisiones automatizadas de alto impacto requieren responsable identificable, explicación adecuada, revisión humana y vía de apelación. Se evalúa quién obtiene beneficios y quién asume costos, con consulta y reparación para personas y comunidades afectadas.

#### Internet civil y separación funcional

OceanNet nace de redes científicas, administrativas y navales, pero su expansión civil constituye una etapa diferenciada. Se distinguen la infraestructura troncal; los servicios civiles para hogares, escuelas, hospitales, banca, comercio, medios y administración; y las redes militares o de seguridad.

Las redes de defensa mantienen dominios, credenciales y continuidad propios. Los servicios civiles esenciales no dependen del mando operativo militar. Los operadores definen procedimientos de degradación segura, respaldo, restauración y comunicación pública cuando se interrumpe una ruta o proveedor. Las redes amplían el acceso, pero no sustituyen a profesionales, instituciones ni canales alternativos.

#### Gobernanza institucional

La política separa dirección, autorización presupuestaria, ejecución, operación, regulación y auditoría. Gobierno federal y legislatura fijan prioridades y derechos; COFOVAL financia fomento dentro de su mandato; universidades e institutos investigan y forman; operadores prestan servicios; gobiernos territoriales identifican necesidades y vigilan la cobertura; reguladores independientes protegen competencia, privacidad y acceso; auditoría pública revisa gasto y resultados.

Cada programa identifica responsable ejecutivo, supervisor, financiador, operador, custodio de datos, auditor y vía de reclamación. Primero se cotejan las competencias de instituciones canónicas existentes. Solo se crea una institución nueva si se documenta un vacío que no pueda resolverse mediante coordinación. Los nombres legales pendientes no se presentan como organismos ya constituidos.

El ciclo de política comprende diagnóstico, diseño, autorización, piloto, evaluación independiente, escalamiento condicionado, operación y revisión. La evidencia puede justificar continuar, corregir, pausar o cerrar un programa. Las decisiones aprobadas no crean por sí solas partidas presupuestarias ni capacidades medidas.

#### Medición y comparación

Cada indicador declara definición, unidad, población cubierta, fuente, método, año base, frecuencia, responsable, incertidumbre y limitaciones. Se distinguen cuatro estados: observado, estimado, objetivo y pendiente.

El tablero de evaluación incluye:

- cobertura disponible y adopción activa de hogares, empresas e instituciones;

- asequibilidad, velocidad efectiva, disponibilidad, interrupciones y reparación;

- productividad y costos de transacción por sector;

- empleo creado, transformado y desplazado, salarios y reconversión;

- energía, agua, materiales, residuos y continuidad de centros y redes;

- capacidad local de diseño, fabricación, integración, reparación y reciclaje;

- acceso por territorio y grupo social, privacidad, reclamaciones y apelaciones;

- etapa alcanzada por tecnología y comparación con rivales pertinentes.

La ventaja tecnológica se mide por tecnología concreta y etapa equivalente: investigación, demostración, prototipo, servicio limitado, adopción amplia, fabricación y mantenimiento. El objetivo general de diez años en áreas prioritarias no reemplaza la norma específica de siete años para telecomunicaciones. La comparación internacional debe usar definiciones equivalentes y no confundir prototipo temprano con adopción amplia.

#### Presupuesto, evidencia y conciliación

Los presupuestos se desglosan por programa, fase, territorio y ciclo de vida: inversión, operación, mantenimiento, energía, agua, personal, seguridad, auditoría y retiro. Se diferencian autorizaciones, desembolsos y ejecución, y se identifican aportes federales, territoriales, COFOVAL, universidades y operadores sin duplicar cofinanciación.

La serie financiera se concilia con ECON-03 y partidas canónicas. No se modifica el PIB para acomodar metas sectoriales. Si los datos históricos son incompletos, se usan rangos con supuestos declarados y se marca su incertidumbre. Responsables legales concretos, presupuestos efectivos, capacidades de laboratorios, series de productividad, cobertura anual, desplazamiento laboral y comparaciones internacionales detalladas quedan sujetos a inventario y auditoría.

#### Fallos, daños y aprendizaje institucional

La historia incluye interrupciones, proyectos que no escalan, proveedores concentrados, filtraciones, fraude, decisiones automatizadas erróneas, desigualdad de acceso, equipos obsoletos, costos energéticos y desplazamiento laboral. Para cada incidente significativo se registra alcance, causas, duración, respuesta, población afectada y reforma posterior.

Las correcciones pueden incluir redundancia, estándares abiertos, portabilidad, reparación, diversificación de proveedores, formación, regulación de datos, protección laboral o suspensión de sistemas. La revisión debe ser independiente del ejecutor y comprobar si la medida corrigió el problema.

#### Transición posterior a 2026

La infraestructura digital habilita inteligencia artificial, robótica, redes eléctricas inteligentes, almacenamiento y computación avanzada, pero no garantiza su adopción ni sus beneficios. Cada capacidad requiere evaluación separada de seguridad, datos, energía, materiales, formación, responsabilidad y efectos sobre empleo. Los sistemas físicos automatizados conservan controles seguros y supervisión humana; los servicios esenciales disponen de operación alternativa.

#### Clasificación canónica de la información

- Fijado en canon: OceanNet inicia operación institucional limitada en 1959; obtiene estatuto federal en 1968 y consolidación institucional en 1969; se mantienen los hitos técnicos ya fijados en la cronología.

- Decisión aprobada: estrategia digital de catorce decisiones; objetivo selectivo de ventaja de diez años; gobernanza, derechos, resiliencia y evaluación.

- Objetivo o estimación: coberturas, capacidades, productividad e impactos que aún no cuentan con observación auditada.

- Pendiente: series territoriales, datos laborales, presupuestos ejecutados, nombres legales de reguladores y comparaciones cuantitativas completas.

### Antecedentes y nacimiento de OceanNet

OceanNet deriva de una evolución tecnológica continua y no aparece súbitamente como red digital. Sus antecedentes son las redes telegráficas, los cables submarinos, la telefonía, la radio, el radar, la criptografía, la meteorología y los centros de cálculo de la Unión.

- 1850: Red Telegráfica del Gran Mar entre Nueva Tirion, Ciudad Federal, Sirion, Erellond Sur, Calasir, Panamá Federal, Cartagena Federal, Armenelos, Ponta Delgada y Funchal. Se utiliza para órdenes navales, precios, carga, meteorología y censos.

- 1870–1900: cables submarinos, telefonía y centrales portuarias. La infraestructura recibe el nombre de Red de los Heraldos del Mar.

- 1895–1930: Servicio Radiomarítimo Federal, con radio costera, radiofaros, meteorología, navegación y coordinación de convoyes.

- 1930–1945: radar costero, control aéreo, criptografía, centros de cálculo y meteorología avanzada.

- 1946–1953: computadores centrales, bases censales, enlaces de alta frecuencia y redes de control naval; etapa Pre-OceanNet.

- 1954–1958: creación del Programa OceanNet, pruebas de arquitectura y consolidación de redes precursoras como proyecto federal naval, científico y espacial.

- 1959: OceanNet inicia un servicio digital institucional limitado sobre líneas dedicadas, radio y cable convencional; la red distribuida se consolida desde 1969.

- 1969: consolidación institucional de OceanNet como red digital federal distribuida; no es su primer año de servicio.

- 1960–1980: expansión institucional, industrial, bancaria, sanitaria, naviera y administrativa; se incorporan radio digital, satélites, centros interconectados, redundancia y rutas alternativas.

- 1968: Estatuto federal; Polinesia y Micronesia quedan integradas oficialmente a la infraestructura política y tecnológica.

- 1983: protocolo federal común para redes navales, científicas, industriales y civiles.

- 1990–2000: apertura al comercio, educación, hogares, banca, transporte e investigación privada.

- 2000–2026: infraestructura digital general con centros distribuidos y redundancia intercontinental e insular.

OceanNet administra logística, censos, finanzas, energía, transporte, investigación, educación, defensa civil y emergencias. La ficha técnica completa se conserva en 11_Ciencia y Tecnologia/OceanNet.

##### Normalización de nodos históricos

- Ciudad Federal corresponde a Nueva Tirion y es una denominación funcional empleada en documentos secretos antiguos.

- Cartagena Federal corresponde a Brithombar (Cartagena), ciudad principal y puerto de Colombia Costera.

- Armenelos es la capital histórica y naval de Númenor (Terranova), conforme a la normalización posterior de capitales; no es la capital federal.

- Ponta Delgada y Funchal son puertos atlánticos asociados y nodos históricos de comunicación. Su adscripción territorial definitiva —Systreyjar o puerto extranjero asociado de Gwaith Aear— queda pendiente.

### Metalurgia valinari, 1000–500 a. C.

La metalurgia es una base material del poder valinari. No existe una industria centralizada: la producción se organiza mediante minas, hornos, talleres familiares, santuarios y centros vinculados a las Casas Mayores.

### Recursos y producción

El cobre, estaño e hierro proceden de extracción superficial, pozos, cursos fluviales, intercambio con Noruega, Dinamarca y el Báltico, recuperación y reciclaje. Noruega aporta mineral, piedra, madera y carbón vegetal; Escania concentra transformación, almacenamiento y distribución; Dinamarca facilita el tránsito hacia el mar del Norte.

Los talleres emplean hornos pequeños y medianos, carbón vegetal, fuelles, crisoles, moldes de arcilla, yunques, martillos, tenazas y baños de enfriamiento. El hierro se obtiene progresivamente mediante reducción y forja, con calidad irregular según mineral, temperatura y experiencia.

### Bronce, hierro, armas y barcos

El bronce conserva importancia para armas ceremoniales, adornos, herramientas finas y objetos rituales. El hierro se expande gradualmente en hoces, azadas, hachas, cuchillos, rejas, clavos, remaches y piezas sometidas a desgaste; ambos materiales coexisten.

Las Casas producen lanzas, espadas, hachas, cuchillos, puntas de flecha y jabalina, escudos reforzados, cascos y herrajes. La lanza es el arma común; la espada exige más metal y trabajo. Las hachas sirven para construcción y combate.

La construcción naval sigue siendo de madera. La metalurgia aporta clavos, remaches, grapas, abrazaderas, bisagras, herrajes de timón, anillas, ganchos, refuerzos de mástil, piezas de ancla y herramientas de reparación. Los puertos con herrerías navales adquieren ventaja estratégica.

### Casas, santuarios y poder

Las Casas controlan mineral, carbón, talleres, armas, contratos y protección de artesanos. Los santuarios registran pesos, inventarios, derechos mineros y reservas. Entre 1000 y 990 a. C. minas, talleres y rutas de carbón provocan conflictos; Forostar establece arbitraje, compensaciones y protección de herrerías.

Entre 950 y 700 a. C. se recuperan rutas y se especializan talleres; entre 700 y 550 a. C. las expediciones y crisis impulsan depósitos, reciclaje y protección de reservas. Desde 550 a. C. la Corona coordina minas, talleres, puertos y arsenales en situaciones de defensa, sin abolir derechos locales.

La metalurgia es avanzada para su contexto regional, pero no industrializada. Sostiene agricultura, navegación, construcción, defensa, comercio y administración.

### Motores y Propulsión

#### Desarrollo de la propulsión naval valinari

##### Navegación a vela y propulsión humana, 1000–500 a. C.

Las embarcaciones combinan vela, remos y maniobra manual. La vela permite reservar fuerza humana para carga, desembarco y combate, pero no elimina el trabajo de aparejo, gobierno, reparación ni espera. La propulsión depende de madera, textiles, cabos, remos, viento y conocimiento de corrientes.

##### Vela oceánica y mejora de cascos, 500 a. C.–500 d. C.

La construcción incorpora mejores quillas, distribución de pesos, timones, velamen, lastre y compartimentación. Las mejoras aumentan estabilidad y autonomía, pero siguen limitadas por agua, alimentos, madera, clima y capacidad de reparación. No se importan retrospectivamente barcos medievales completos.

##### Vapor y carbón, 1800–1900

La industrialización introduce máquinas alternativas, calderas, hélices, ejes y cascos metálicos. Los primeros buques combinan vapor y vela para reducir consumo. La autonomía depende de depósitos, carboneras, estaciones de reabastecimiento y mantenimiento de calderas. La transición se inicia en transportes y remolcadores antes de generalizarse en cruceros, acorazados y auxiliares.

##### Diésel, turbinas y electricidad, 1900–1945

Los motores diésel mejoran eficiencia y simplifican ciertas operaciones; las turbinas de vapor y gas permiten mayor velocidad en destructores y cruceros. Los generadores eléctricos alimentan comunicaciones, radares iniciales, bombas, talleres y sistemas de control. La propulsión continúa siendo mecánica, con ejes y hélices, aunque aumenta la separación entre generación y consumo.

##### Propulsión de guerra antisubmarina, 1945–1965

La necesidad de reducir ruido impulsa montajes elásticos, hélices de menor cavitación, aislamiento de maquinaria, control de vibraciones y motores más silenciosos. Los buques Círdan iniciales incorporan turbinas de gas, motores auxiliares y generación eléctrica para sensores, helicópteros y sistemas de mando.

##### Propulsión eléctrica integrada, 1965–2000

La generación eléctrica comienza a alimentar motores de propulsión y sistemas de misión mediante una red común. Esto facilita redistribuir energía entre radar, sonar, comunicaciones, armas, talleres y hotelería. La propulsión eléctrica integrada no vuelve silencioso a cualquier buque: exige diseño de casco, aislamiento, control de vibraciones y mantenimiento especializado.

##### Propulsión nuclear y oceánica

Los portaaviones Telcontar y los submarinos estratégicos emplean reactores nucleares para obtener autonomía prolongada. La energía nuclear no elimina la necesidad de alimentos, mantenimiento, repuestos, puertos y rotación de tripulaciones. La industria nuclear permanece separada de la propulsión convencional y se somete a control federal estricto.

##### Círdan IV y Voronwë

Círdan IV utiliza turbinas de gas, generadores diésel y propulsión eléctrica integrada. Voronwë conserva esa arquitectura, pero mejora generación, almacenamiento, distribución eléctrica, aislamiento acústico, automatización, mantenimiento predictivo y reserva energética para sensores y drones.

##### Estado tecnológico en 2026

La Armada combina:

- propulsión nuclear en portaaviones y submarinos estratégicos;

- turbinas de gas en destructores y fragatas de alta velocidad;

- diésel-eléctrica en submarinos convencionales, patrulleros y buques auxiliares;

- propulsión eléctrica integrada en Círdan IV, Voronwë y nuevas plataformas;

- sistemas híbridos en buques de vigilancia, investigación y apoyo litoral;

- baterías y almacenamiento avanzado para reducir firma acústica y consumo durante periodos limitados.

La superioridad valinari proviene de combinar motores, astilleros, combustible, electrónica, educación, mantenimiento, bases y logística. Ningún sistema de propulsión por sí solo garantiza superioridad naval.

### Energía

#### Producción energética valinari, 1600–2026

La transición energética se desarrolla junto con educación, industria, banca, transporte, astilleros y Armada. No existe una sustitución inmediata: durante siglos coexisten madera, carbón, fuerza hidráulica, viento, petróleo, gas, energía nuclear, geotermia, biomasa, solar y eólica.

##### 1600–1700: energía orgánica e hidráulica

La economía depende de madera, carbón vegetal, tracción animal, viento, corrientes de agua y fuerza humana. Molinos hidráulicos y eólicos mueven grano, sierras, martillos y bombas. Los bosques son esenciales para calefacción, construcción naval, hornos y metalurgia, por lo que se regulan tala, reforestación y transporte. La banca financia molinos, canales, presas pequeñas y talleres; las academias forman constructores y administradores de agua.

##### 1700–1800: carbón y vapor inicial

La minería de carbón y la mejora de calderas permiten máquinas estacionarias en minas, molinos, arsenales y talleres. El vapor reduce la dependencia del viento, pero exige carbón, hierro, agua, mantenimiento y personal especializado. Sus primeros usos se concentran en bombeo, elevación, forja, aserraderos, minería y transporte portuario, antes de extenderse a buques de guerra.

##### 1800–1850: industrialización energética

La producción de carbón aumenta para abastecer ferrocarriles, máquinas, hornos, puertos y vapores. Se desarrollan minas profundas, ferrocarriles carboneros, depósitos de combustible y talleres de calderas. La energía hidráulica se expande en regiones húmedas y montañosas. La Armada crea estaciones de carbón y depósitos distribuidos para sostener rutas oceánicas.

##### 1850–1900: electricidad y petróleo inicial

La electricidad comienza en iluminación, telégrafo, fábricas, tranvías, arsenales y comunicaciones. Las primeras centrales usan carbón, vapor e hidráulica. El petróleo aparece en iluminación, lubricación y combustibles especializados. La producción energética se convierte en una cuestión financiera: centrales, líneas, depósitos, minas y puertos requieren deuda, seguros, concesiones y supervisión.

##### 1900–1945: electrificación y combustibles líquidos

Hidroelectricidad, carbón, petróleo y gas se expanden simultáneamente. Se electrifican ciudades, ferrocarriles, fábricas, estaciones de radio, astilleros, hospitales y centros de cálculo. El petróleo gana importancia en destructores, submarinos, aviación, blindados y transporte pesado. Se construyen refinerías, oleoductos, depósitos protegidos y buques tanque.

##### 1945–1965: energía nuclear y sistema federal

La investigación nuclear se desarrolla junto con física, metalurgia, química, medicina e ingeniería. Valinor construye reactores de investigación y posteriormente reactores de generación eléctrica y propulsión naval bajo control federal. La energía nuclear se reserva para funciones de alta densidad energética y no sustituye inmediatamente al carbón, petróleo o hidroelectricidad.

La reforma federal de 1958 coordina redes eléctricas, seguridad de reactores, reservas de combustible e interconexión territorial. Groenlandia aporta investigación ártica y recursos; Islandia, geotermia e hidroelectricidad; Arnor, Valinor, Númenor y Calenardhon Austral concentran industria, refinación y manufactura energética.

##### 1965–1985: diversificación y seguridad energética

La volatilidad del petróleo impulsa hidroelectricidad, energía nuclear, gas natural, reservas estratégicas, eficiencia industrial, electrificación ferroviaria e investigación solar y eólica. La Armada desarrolla propulsión nuclear para submarinos y portaaviones, mientras fragatas, patrulleros y auxiliares utilizan turbinas, diésel y sistemas eléctricos.

##### 1985–2000: gas, automatización y renovables

El gas natural se utiliza en generación eléctrica, calefacción, industria química y turbinas. La informática permite controlar redes y anticipar demanda. La energía eólica y solar pasan de proyectos experimentales a instalaciones comerciales; la hidroelectricidad continúa siendo importante, con conflictos por ríos, ecosistemas y desplazamientos.

##### 2000–2026: red energética integrada

La matriz energética combina hidroelectricidad, energía nuclear, gas natural, petróleo refinado, carbón en descenso, energía eólica, solar, geotermia, biomasa, almacenamiento eléctrico e hidrógeno en proyectos específicos. La red federal incorpora sensores, control digital, centros de datos, baterías, interconexiones submarinas y generación distribuida. OceanNet coordina información energética, pero no sustituye autoridades civiles.

La producción se organiza en generación centralizada, generación territorial y respaldo local. Las grandes centrales se complementan con plantas regionales, microredes, baterías, generadores y reservas de combustible.

##### Relación con la Armada

La Armada necesita energía para propulsión, radares, bases, submarinos, aeronaves, desalinizadores, hospitales, talleres y comunicaciones. Mantiene depósitos de combustible, centrales de respaldo, buques logísticos y acuerdos con territorios productores. La propulsión nuclear ofrece autonomía, pero no elimina alimentos, repuestos, mantenimiento ni personal. Los sistemas eléctricos integrados requieren generadores, baterías, software y técnicos.

##### Resultado canónico

En 2026 Valinor no depende de una única fuente energética. Su ventaja procede de una matriz diversificada, redes interconectadas, reservas estratégicas, educación técnica, bancos de desarrollo, industria pesada, investigación nuclear y capacidad de mantenimiento. La seguridad energética es una condición conjunta de economía, banca, Armada, tecnología y autonomía política.

### Industrialización valinari

#### Industrialización valinari anticipada y transformación integral

La industrialización valinari se anticipa de forma diferencial, no universal. La educación técnica, la hidráulica, la banca productiva, los astilleros, la metalurgia, el carbón y el vapor pueden adelantarse entre 50 y 100 años; la electricidad, la química, los motores y las telecomunicaciones entre 30 y 70 años; la electrónica, la energía nuclear y la inteligencia artificial conservan una anticipación más limitada y gradual.

Esta ventaja se explica por alfabetización técnica, archivos y Siete Copias, Academias del Mar, crédito de largo plazo, banca de desarrollo, red portuaria, demanda naval, acceso diversificado a agua, carbón y metales y coordinación entre Corona, Casas, ciudades y territorios.

##### Secuencia industrial

- 1600–1700: molinos especializados, metalurgia, manufactura textil, astilleros parcialmente mecanizados, imprentas, arsenales, canales, seguros y educación técnica. La energía sigue siendo principalmente orgánica, hidráulica, eólica y animal.

- 1700–1800: bombas de vapor, máquinas estacionarias, tornos, martillos mecánicos, aserraderos, hornos mejorados y minería de carbón. La mecanización se concentra donde el ahorro de trabajo justifica el coste.

- 1800–1850: ferrocarriles, siderurgia, astilleros mecanizados, fábricas de maquinaria, centrales hidráulicas, depósitos de carbón y logística industrial.

- 1850–1900: electricidad, telégrafo, tranvías, química industrial, petróleo inicial, iluminación urbana, hospitales, laboratorios y expansión de la educación técnica.

- 1900–1945: acero, motores de combustión, radio, aviación, submarinos, ferrocarriles, producción química, medicina industrial y construcción naval en serie.

- 1945–1965: energía nuclear, electrónica, aviación a reacción, informática inicial, física aplicada, metalurgia avanzada y Estado científico.

- 1965–1985: circuitos integrados, control numérico, automatización, satélites, radares digitales, telecomunicaciones y propulsión eléctrica.

- 1985–2000: microprocesadores, fibra óptica, biotecnología, materiales compuestos, renovables, logística computarizada y finanzas electrónicas.

- 2000–2026: inteligencia artificial, robótica, fabricación avanzada, baterías, redes inteligentes, drones, procesadores, propulsión naval integrada y OceanNet.

##### Transformación social y cultural

La industrialización eleva el prestigio de ingenieros y técnicos, amplía escuelas y universidades, crea prensa y archivos públicos, profesionaliza la administración y genera nuevas identidades obreras y profesionales. También produce migración urbana, accidentes, contaminación, conflictos laborales, sindicatos, mutualidades, seguros sociales y tensiones entre tradición de Casas y movilidad social.

Las Casas no desaparecen, pero dejan de ser las únicas instituciones capaces de organizar conocimiento, crédito y producción. El Estado, las universidades, las empresas, los sindicatos y las ciudades adquieren mayor peso.

##### Resultado canónico

Valinor alcanza antes que otras potencias una combinación de educación técnica, crédito industrial, energía diversificada, astilleros, ferrocarriles, industria pesada, ciencia aplicada y administración pública. Esta anticipación explica una primacía industrial y naval temprana, pero conserva desigualdad, contaminación, crisis financieras, dependencia de materias primas y conflictos por sostenibilidad.

#### Desarrollo ampliado de la industrialización valinari

La industrialización se entiende como un ecosistema y no como una sucesión de inventos. Cada avance depende de educación, capital, energía, materias primas, transporte, mano de obra, administración y mercados. La ventaja valinari consiste en coordinar estos elementos antes y con mayor continuidad que otras potencias, no en eliminar sus costes.

##### Preindustrialización, 1600–1700

Los molinos hidráulicos y eólicos accionan martillos, sierras, bombas, molinos de grano y maquinaria textil. Los arsenales y astilleros adoptan medidas estandarizadas, registros de piezas, especialización de oficios y mantenimiento planificado. Las imprentas, archivos y Academias del Mar difunden manuales de navegación, contabilidad, metalurgia, agricultura, construcción y administración.

La producción sigue siendo principalmente manual y local. La anticipación se encuentra en la organización: talleres conectados por crédito, transporte marítimo, educación técnica y contratos de suministro. Las Casas continúan controlando tierras y talleres, pero ciudades, bancos y arsenales adquieren autonomía creciente.

##### Mecanización, 1700–1800

El carbón mineral y las primeras máquinas de vapor se aplican a minas, bombas, fundiciones, arsenales, grúas y transporte portuario. La mecanización se concentra en actividades donde el ahorro de trabajo y la regularidad justifican el alto coste de combustible y reparación.

La banca financia minas, canales, máquinas y talleres; las academias forman mecánicos, medidores, dibujantes, ingenieros prácticos y administradores. Las primeras máquinas no son eficientes ni universales, por lo que la economía conserva energía hidráulica, viento, animales y carbón vegetal.

##### Ferrocarril, siderurgia y astilleros, 1800–1850

Los ferrocarriles conectan minas, siderurgias, puertos, arsenales, centros agrícolas y ciudades. La siderurgia produce raíles, calderas, ejes, herramientas, piezas de artillería y cascos metálicos. Los astilleros fabrican vapores, remolcadores, buques carboneros, fragatas, transportes y maquinaria naval.

La Armada se convierte en cliente industrial, pero la innovación naval se derrama hacia la economía civil: motores, bombas, comunicaciones, metalurgia, navegación, transporte y medicina. El Estado financia corredores de energía y logística, mientras la banca de desarrollo cubre inversiones de maduración larga.

##### Electricidad y química, 1850–1900

La electricidad se introduce en iluminación, telégrafo, tranvías, fábricas, hospitales, laboratorios, estaciones ferroviarias y arsenales. Las primeras redes son urbanas y regionales antes de interconectarse federalmente.

La química industrial produce fertilizantes, tintes, medicamentos, conservantes, lubricantes, materiales de tratamiento metálico y explosivos regulados. El petróleo comienza en iluminación, lubricación y motores pequeños antes de extenderse a submarinos, vehículos, aviación y destructores.

La urbanización genera barrios obreros, migración rural, accidentes, enfermedades laborales, contaminación y conflictos por jornadas. Mutualidades, sindicatos, inspecciones, seguros y educación pública responden de manera gradual y desigual.

##### Industria pesada y producción en serie, 1900–1945

Valinor integra acero, petróleo, motores de combustión, turbinas, radio, aviación, submarinos, ferrocarriles, química y construcción naval en serie. Se generalizan piezas intercambiables, catálogos, medidas comunes, control de calidad, manuales técnicos y cadenas de suministro.

La industria militar acelera la estandarización, pero también impulsa transporte civil, medicina, meteorología, electrificación y comunicaciones. La educación superior forma ingenieros eléctricos, químicos, mecánicos, geólogos, administradores y especialistas en producción.

##### Estado científico, 1945–1965

La investigación nuclear, la electrónica, la aviación a reacción, el radar, la computación inicial y los materiales especiales se desarrollan mediante universidades, laboratorios públicos, industria y programas navales. La Corona conserva becas y funciones patrimoniales, pero no controla la educación ni la ciencia pública.

La reforma federal de 1958 coordina grandes infraestructuras, investigación, seguridad energética, financiación industrial y formación técnica. Groenlandia, Islandia, Arnor, Valinor, Númenor y Calenardhon Austral adquieren funciones energéticas e industriales diferenciadas.

##### Automatización y OceanNet, 1965–1985

La industria incorpora circuitos integrados, control numérico, satélites, radares digitales, telecomunicaciones, automatización y primeros robots. OceanNet conecta universidades, bancos, astilleros, hospitales, centros de cálculo, puertos y administraciones.

La red reduce errores de coordinación y acelera mantenimiento, pero no sustituye fábricas, energía, trabajadores ni repuestos. La industria naval aprovecha la electrónica para mejorar propulsión, sensores, control de vibraciones y logística.

##### Alta tecnología y globalización regulada, 1985–2000

Se expanden microprocesadores, fibra óptica, biotecnología, materiales compuestos, software, fabricación modular, finanzas electrónicas y energías renovables. Valinor mantiene reservas estratégicas, bancos de desarrollo y producción propia de componentes críticos para reducir la dependencia exterior.

La globalización se regula mediante acuerdos de suministro, seguros, normas técnicas, control de exportaciones estratégicas y diversificación de proveedores. No desaparecen las crisis de deuda, las interrupciones logísticas ni las desigualdades regionales.

##### Economía industrial del conocimiento, 2000–2026

La fabricación avanzada integra inteligencia artificial, robótica, baterías, biotecnología, energía nuclear, redes inteligentes, drones, procesadores, propulsión eléctrica y OceanNet. La industria opera mediante simulación, sensores, mantenimiento predictivo, diseño digital, trazabilidad y control automatizado.

Los sectores industriales se distribuyen territorialmente: Arnor concentra electrónica, acero, motores y ferrocarriles; Valinor, diseño, universidades, banca e investigación; Númenor, grandes astilleros y turbinas; Calenardhon Austral, maquinaria, energía y metalurgia; Sírënandë, minería y refinación; Islandia, geotermia y reparación; Groenlandia, investigación polar y minerales; Panamá, logística y almacenamiento; y Malaca, manufactura y distribución asiática.

##### Transformación cultural y social

La industrialización eleva el prestigio de ingenieros, científicos y técnicos; amplía alfabetización y educación superior; profesionaliza la administración; crea prensa y archivos públicos; y genera identidades obreras y profesionales. Las mujeres acceden progresivamente a escuelas técnicas, universidades, laboratorios, administración, medicina e industria.

Las Casas conservan influencia en banca, diplomacia, defensa, patrimonio y educación, pero dejan de ser las únicas instituciones capaces de organizar conocimiento, crédito y producción. El Estado, las ciudades, las empresas, los sindicatos y las universidades adquieren mayor peso.

##### Anticipación tecnológica coherente

La anticipación valinari se fija de forma diferencial: 80–100 años en hidráulica, astilleros, educación técnica y contabilidad industrial; 50–80 años en carbón, vapor, minería y ferrocarriles; 30–60 años en electricidad, química y motores; y 20–40 años en electrónica, informática y energía nuclear. En 2000–2026 la ventaja principal es la integración de sistemas, no la invención previa de toda tecnología.

El resultado es una primacía industrial y naval temprana, pero acompañada de desigualdad, contaminación, explotación laboral, crisis financieras, dependencia de minerales, conflictos territoriales y tensiones entre crecimiento y sostenibilidad.

### Metalurgia y siderurgia

El desarrollo se periodiza: minería y forja preindustrial, mecanización de los siglos XVII y XVIII, siderurgia industrial del XIX y metalurgia contemporánea. Las composiciones especiales de manganeso, níquel y cromo se consideran ensayos selectivos en 1875; su disponibilidad industrial uniforme pertenece a etapas posteriores. Los controles del siglo XIX son mecánicos, químicos y empíricos.

#### profundización de la metalurgia valinari

La metalurgia valinari se desarrolla como un sistema integrado de minería, combustibles, hornos, transporte, educación, banca, arsenales y control de calidad. Su ventaja histórica no procede de una única técnica extraordinaria, sino de la continuidad documental y de la capacidad de aplicar el mismo conocimiento a agricultura, ferrocarriles, maquinaria, artillería, astilleros y construcción civil.

##### Cadena de materias primas

La cadena metalúrgica comienza con prospección, extracción y clasificación. Los geólogos y maestros mineros registran la ley del mineral, la humedad, la presencia de azufre y fósforo, la facilidad de reducción y la distancia hasta los hornos.

Los minerales se transportan en cuatro etapas:

1. extracción en mina;

2. trituración y lavado;

3. concentración y clasificación;

4. transporte a hornos, fundiciones y laminadores.

El mineral de hierro se complementa con carbón, caliza, arcillas refractarias, cobre, níquel, manganeso y estaño. La disponibilidad de agua es esencial para lavado, refrigeración, martillos hidráulicos y transporte.

##### Tipos de hornos

La industria utiliza distintos hornos según el producto buscado.

Hornos bajos: producen hierro esponjoso y hierro forjado para herramientas, clavos, cadenas y piezas pequeñas.

Hornos de reverbero: permiten calentar y refinar metales sin contacto directo con el combustible. Se emplean para hierro, cobre y tratamientos de piezas.

Altos hornos: producen hierro fundido a gran escala. Utilizan coque o carbón mineral preparado, caliza como fundente y aire impulsado por fuelles mecánicos.

Hornos de pudelado: reducen el carbono y las impurezas del hierro fundido para obtener hierro forjado y materiales maleables.

Convertidores Bessemer: producen acero rápidamente para raíles, perfiles, placas y piezas de gran volumen.

Hornos Siemens-Martin: se reservan para aceros de composición más controlada, especialmente blindajes, cañones, ejes, calderas y piezas navales.

##### Combustibles y energía

La metalurgia utiliza distintas fuentes de energía según la escala:

- carbón vegetal en hornos antiguos y talleres rurales;

- carbón mineral en altos hornos;

- coque en producción industrial;

- energía hidráulica en martillos, fuelles y laminadores;

- vapor en bombeo, transporte y grandes fábricas;

- electricidad limitada en iluminación, medición y algunos procesos experimentales desde finales del siglo XIX.

En 1875 no se presupone electrificación completa de la metalurgia. Las operaciones principales dependen todavía del carbón, el vapor y la fuerza hidráulica.

##### Producción de hierro y acero

El hierro fundido se clasifica por contenido de carbono y uso previsto. El hierro dulce se destina a remaches, cadenas y estructuras; el hierro pudelado a planchas, calderas y puentes; el acero estructural a perfiles, cascos y raíles; y los aceros especiales a cañones, ejes, hélices y blindajes.

La producción de acero se controla mediante:

- selección del mineral;

- proporción de fundentes;

- duración de la colada;

- temperatura del horno;

- eliminación de escorias;

- análisis químico;

- laminación;

- recocido;

- templado;

- revenido.

##### Aleaciones y materiales especiales

La industria conoce aleaciones simples y aceros mejorados, sin proyectar formulaciones propias del siglo XX.

Acero al manganeso: mejora la resistencia al desgaste y se emplea en piezas sometidas a golpes.

Acero al níquel: mejora tenacidad y resistencia en planchas, ejes y blindajes.

Acero al cromo: aparece en usos selectivos y experimentales, principalmente para herramientas y superficies resistentes.

Bronce y latón: se utilizan en válvulas, instrumentos, casquillos, tuberías, hélices menores y piezas navales.

Plomo y estaño: se destinan a soldaduras, revestimientos, munición y protección contra corrosión.

El uso de aleaciones es limitado por el coste, la disponibilidad de minerales y la dificultad de controlar composiciones uniformes.

##### Tratamientos térmicos

Los talleres metalúrgicos aplican:

- recocido para reducir tensiones;

- templado para aumentar dureza;

- revenido para recuperar tenacidad;

- cementación superficial para herramientas;

- normalizado para uniformar piezas;

- enfriamiento controlado en agua, aceite o aire.

Estos procedimientos se documentan en manuales y se enseñan en academias técnicas. La industria diferencia entre dureza superficial y resistencia interna para evitar que una pieza sea dura, pero frágil.

##### Metalurgia naval

La construcción naval necesita materiales diferenciados:

- planchas de casco;

- perfiles estructurales;

- remaches;

- ejes;

- hélices;

- calderas;

- tuberías;

- blindaje;

- soportes de artillería;

- cadenas y anclas.

Las planchas se laminan en espesores normalizados. Los cascos se refuerzan con cuadernas, mamparos y perfiles interiores. Las zonas de máquinas, pañoles y línea de flotación reciben acero o hierro de mayor calidad.

El diseño valinari favorece la intercambiabilidad: una pieza fabricada en Númenor puede sustituir a otra producida en Arnor o Calenardhon Austral si respeta las medidas y tolerancias oficiales.

##### Blindajes

En 1875 se emplean tres soluciones principales:

1. hierro laminado para protección estructural;

2. blindaje compuesto de hierro y acero para torres y cinturones;

3. acero temprano de mayor calidad para piezas críticas.

El blindaje se prueba mediante placas de ensayo. Se registran penetración, deformación, desprendimiento, fragmentación y daños en la estructura posterior. La finalidad no es hacer invulnerable al buque, sino proteger máquinas, pañoles y puestos de mando.

##### Metalurgia de artillería

Los cañones navales se fabrican con tubos forjados o fundidos de acero mejorado, ánimas rayadas y cierres de retrocarga. Los talleres deben controlar:

- concentricidad del tubo;

- uniformidad del rayado;

- resistencia de la recámara;

- cierre;

- presión de la carga;

- estabilidad del proyectil;

- desgaste después de los disparos.

Los calibres normalizados son 37, 47, 57, 76, 100, 120, 127, 140, 152, 203, 229, 254 y 305 mm. La normalización reduce el número de líneas de munición y facilita el abastecimiento.

##### Herramientas y maquinaria

La metalurgia avanzada exige máquinas herramienta:

- tornos;

- fresadoras;

- taladros verticales;

- cepilladoras;

- martillos pilón;

- laminadores;

- prensas;

- grúas;

- bombas;

- máquinas de medición.

La precisión se obtiene mediante plantillas, calibres, reglas, micrómetros y patrones de referencia. En 1875 la precisión industrial es alta para la época, pero no equivale a fabricación automatizada moderna.

##### Control de calidad y responsabilidad

Cada pieza estratégica recibe un registro de fabricación. El expediente incluye:

- procedencia del mineral;

- horno y turno de producción;

- composición estimada;

- tratamiento térmico;

- dimensiones;

- pruebas realizadas;

- operarios responsables;

- destino de la pieza;

- reparaciones posteriores.

Los defectos se clasifican como estructurales, superficiales, de composición, de montaje o de uso. Las piezas críticas pueden rechazarse aunque su coste sea alto. Esta cultura reduce accidentes de calderas, fracturas de ejes y fallos de artillería.

##### Distribución regional

Arnor: mineral de hierro, carbón, acero ferroviario, maquinaria pesada, calderas y artillería.

Valinor: investigación, ingeniería, análisis químico, instrumentos, banca industrial y diseño.

Númenor: planchas navales, ejes, hélices, calderas, motores y grandes astilleros.

Calenardhon Austral: maquinaria, estructuras, herramientas, acero agrícola y material ferroviario.

Sírënandë: hierro, cobre, manganeso, níquel y refinado mineral.

Islandia: energía geotérmica, ensayos de materiales, reparación y producción metalúrgica especializada.

Groenlandia: prospección, investigación polar, minerales estratégicos y producción limitada por condiciones climáticas.

##### Educación y transmisión técnica

Las academias forman ingenieros de minas, fundidores, laminadores, inspectores, mecánicos, artilleros, constructores navales y administradores de producción. Los estudiantes pasan por minas, hornos, arsenales, ferrocarriles y astilleros.

La Ley de Custodia Compartida y la Doctrina de las Siete Copias obligan a conservar y compartir los procedimientos técnicos generales. Las fórmulas militares activas, claves de seguridad y diseños en evaluación pueden restringirse temporalmente, pero ninguna Casa puede convertir la metalurgia básica en monopolio hereditario permanente.

##### Límites históricos

La siderurgia valinari de 1875 no posee:

- aceros inoxidables industriales generalizados;

- hornos eléctricos de producción masiva;

- metalurgia de polvos moderna;

- titanio industrial;

- superaleaciones contemporáneas;

- control computarizado;

- análisis espectrométrico automatizado;

- fabricación aditiva;

- soldadura moderna generalizada.

Su ventaja consiste en producir acero industrial de buena calidad, medirlo mejor, documentarlo y asignarlo estratégicamente a los sectores más importantes.

##### Resultado estratégico

La siderurgia permite que Valinor mantenga una Armada de 1875 con acorazados, cruceros, corbetas, cañoneras, torpederos, transportes y auxiliares técnicamente fiables. Gran Bretaña conserva mayor producción total y capacidad de reemplazo, pero Valinor logra una relación especialmente eficaz entre acero producido, buques disponibles, mantenimiento, artillería y logística.

La fórmula canónica queda establecida así:

Gran Bretaña produce más acero; Valinor integra mejor la siderurgia con la educación, la banca, los arsenales, los astilleros, la Armada y la logística.

### Metalurgia y siderurgia del siglo VIII

En 700–799 predomina la reducción directa con carbón vegetal, la forja y el acero de composición irregular. La mecanización hidráulica en ferrerías selectas es una divergencia técnica localizada del escenario, condicionada por caudal, carpintería, transmisión y maestros. Los hornos de cuba mayor siguen siendo hornos de reducción directa; una colada carburada ocasional no demuestra una cadena industrial de fundición y afino. Escania y Noruega se citan como zonas de origen y comercio, sin incorporarlas automáticamente al territorio soberano del siglo VIII.

#### metalurgia y siderurgia valinari en el siglo VIII d. C.

##### Situación general

Durante el siglo VIII d. C., Valinor todavía no posee siderurgia industrial. Su producción se basa en talleres regionales, ferrerías asociadas a ríos, hornos bajos y redes de herreros vinculadas a Casas, puertos, monasterios y arsenales. La ventaja valinari consiste en la continuidad de los registros, la especialización de los talleres y la distribución de herramientas, no en una producción masiva comparable a la de los siglos XVIII–XIX.

La metalurgia se encuentra en una fase intermedia: conserva técnicas antiguas de reducción directa, desarrolla hornos más eficientes y comienza a organizar centros de producción relativamente grandes. El hierro sigue siendo más valioso que abundante y cada pieza se repara, reutiliza o transforma cuando es posible.

##### Reducción directa

El procedimiento principal utiliza hornos bajos o de cuba pequeña. El mineral se mezcla con carbón vegetal y se calienta con aire impulsado por fuelles. El resultado no es un metal completamente líquido, sino una masa porosa de hierro y escoria llamada lupa.

La lupa se extrae, se recalienta y se golpea repetidamente para expulsar escoria. Después se convierte en barras o lingotes de hierro forjado. Las ferrerías más organizadas trabajan por lotes y registran:

- procedencia del mineral;

- cantidad de carbón;

- duración de la carga;

- calidad de la lupa;

- número de martillados;

- destino del hierro producido.

##### Hornos de mayor volumen

En algunos centros se emplean hornos de cuba más altos que permiten temperaturas superiores y una producción mayor. No son todavía altos hornos industriales plenamente desarrollados, pero representan una evolución hacia operaciones continuas y mayores cargas de mineral.

Estos hornos pueden producir masas de hierro fundido parcialmente carburado, difíciles de trabajar directamente. Por ello necesitan una segunda etapa de refinado en forja. Su uso se limita a regiones con abundante carbón vegetal, agua y mano de obra especializada.

##### Energía hidráulica

Los talleres junto a ríos utilizan ruedas hidráulicas para:

- accionar fuelles;

- mover martillos;

- elevar mineral;

- bombear agua;

- triturar escoria;

- accionar sierras y tornos sencillos.

La energía hidráulica no elimina el trabajo manual: permite aumentar la regularidad del aire y la fuerza de golpeo. Los talleres que controlan una corriente estable producen más hierro y pueden mantener piezas de mayor tamaño.

##### Carbón vegetal y gestión forestal

El carbón vegetal es el combustible principal. Su producción exige bosques administrados y turnos de tala. Las Casas metalúrgicas deben equilibrar:

- demanda de hornos;

- construcción naval;

- agricultura;

- calefacción;

- reparación de viviendas;

- regeneración forestal.

La administración valinari establece zonas de corte, bosques reservados, hornos de carbón regulados y rutas de transporte. La escasez de madera limita la expansión de la metalurgia en algunas islas y obliga a importar barras de hierro.

##### Calidad del mineral

Los mineros clasifican el mineral por color, peso, dureza, facilidad de trituración y comportamiento en el horno. Los maestros distinguen minerales más apropiados para:

- herramientas;

- armas;

- clavos;

- cadenas;

- anclas;

- ejes;

- piezas navales.

No existe todavía un análisis químico moderno. La experiencia se acumula en tablas prácticas, muestras comparativas y registros de cada mina.

##### Hierro forjado

El hierro forjado es el material más importante del siglo VIII. Se utiliza en:

- arados;

- azadas;

- hoces;

- hachas;

- cuchillos;

- clavos;

- remaches;

- bisagras;

- cerraduras;

- cadenas;

- anclas;

- herramientas de carpintería naval.

La calidad depende de la eliminación de escoria y del número de plegados y soldaduras. Las piezas sometidas a golpes reciben más trabajo de forja que las destinadas a estructuras simples.

##### Acero al carbono limitado

El acero se obtiene principalmente por carburación superficial del hierro forjado. Las piezas se calientan en contacto con carbón durante periodos controlados y luego se templan.

Se utiliza en:

- filos de espadas;

- cuchillos;

- cinceles;

- brocas primitivas;

- herramientas de precisión;

- puntas de armas.

El acero no es uniforme. Una misma pieza puede contener zonas de hierro dulce y zonas más carburadas. Los mejores talleres realizan soldadura de paquetes, combinando un núcleo resistente con un filo endurecido.

##### Tratamientos térmicos

Los herreros conocen empíricamente:

- recocido;

- temple en agua;

- temple en aceite o grasa;

- revenido mediante recalentamiento moderado;

- enfriamiento lento en ceniza;

- calentamiento diferencial.

El resultado se evalúa por color, sonido, elasticidad, dureza del filo y comportamiento en pruebas. No existe todavía una escala científica universal de dureza.

##### Metalurgia naval

La construcción naval del siglo VIII utiliza hierro en cantidades limitadas y estratégicas. Los principales productos son:

- clavos largos;

- remaches;

- abrazaderas;

- grapas;

- herrajes de timón;

- anclas;

- cadenas cortas;

- refuerzos de quilla;

- soportes de mástil;

- herramientas de astillero.

Los cascos siguen siendo principalmente de madera. Las piezas metálicas no sustituyen la estructura naval, sino que prolongan su vida y permiten construir embarcaciones mayores y más resistentes.

##### Armas y defensa

Los talleres producen:

- espadas de hierro con filos carburados;

- hachas;

- lanzas;

- puntas de flecha;

- cuchillos;

- escudos reforzados;

- herrajes de máquinas de asedio;

- cerraduras y mecanismos defensivos.

La calidad militar depende más de la regularidad de los lotes y del mantenimiento que de la existencia de un acero excepcional. Las Casas con mejores ferrerías pueden equipar tropas más uniformemente.

##### Organización de los talleres

Los centros metalúrgicos se dividen en:

- minas;

- lavaderos;

- hornos;

- forjas;

- talleres de herramientas;

- arsenales;

- almacenes de carbón;

- depósitos de barras;

- talleres navales;

- oficinas de registro.

Los maestros herreros conservan conocimientos de oficio, pero los archivos de las Casas y santuarios registran procedimientos generales, precios, pesos, calidades y obligaciones de suministro.

##### Distribución territorial

Escania y Noruega: hierro, herramientas, armas, forjas hidráulicas y herrajes navales.

Arnor: producción de herramientas agrícolas, armas, clavos y barras para construcción.

Valinor: talleres de precisión, archivos técnicos, instrumentos y coordinación de estándares.

Númenor: herrajes navales, anclas, cadenas, remaches y herramientas de astillero.

Systreyjar y Nosselië Toliva: producción limitada de reparación, importación de barras y transformación de hierro en piezas navales.

Calenardhon Austral: herramientas agrícolas, cuchillos, herrajes, arados y producción regional vinculada a ríos.

Sírënandë: metalurgia menor, cobre, herramientas, minería y forjas de apoyo a la navegación fluvial.

##### Trabajo, impuestos y obligaciones

Las ferrerías pueden estar sujetas a:

- impuestos en hierro o herramientas;

- servicio obligatorio para arsenales;

- suministro de clavos y herrajes;

- mantenimiento de caminos mineros;

- protección de bosques;

- reparación de armas de la guarnición.

La Corona no controla todos los talleres, pero reserva capacidad estratégica para defensa, navegación y agricultura. En tiempos de guerra, las Casas deben entregar cuotas de hierro, carbón vegetal, armas o mano de obra especializada.

##### Límites tecnológicos del siglo VIII

No deben atribuirse a este periodo:

- acero industrial uniforme;

- altos hornos plenamente modernos;

- coque;

- Bessemer;

- Siemens-Martin;

- producción masiva de planchas navales;

- artillería de acero de gran calibre;

- análisis químico instrumental;

- cadenas de montaje;

- electricidad industrial.

El siglo VIII posee una metalurgia avanzada para una economía medieval, pero no industrial. La producción es regional, estacional y dependiente de bosques, agua, carbón vegetal, transporte y maestros especializados.

##### Importancia histórica

La metalurgia del siglo VIII prepara la industrialización posterior porque conserva cinco capacidades fundamentales:

1. registros técnicos acumulativos;

2. especialización regional;

3. uso de energía hidráulica;

4. relación entre talleres, puertos y arsenales;

5. formación de maestros y transmisión de procedimientos.

La siderurgia industrial de los siglos posteriores no aparece de forma súbita: se apoya en esta red temprana de minas, ferrerías, archivos, bosques administrados, transporte y educación técnica.

### Continuidad civil de OceanNet

#### Herencia documental y base técnica

OceanNet recoge prácticas de archivo distribuido, procedencia y corrección de versiones. Su infraestructura exige una convergencia específica de telecomunicaciones, electrónica, computación, protocolos y financiación del siglo XX. La tradición de bibliotecas explica decisiones institucionales, mientras que cables, radio, centros de cálculo y equipos explican la capacidad material.

Se conservan las fechas de V16: precursores y pruebas de 1954–1958, funcionamiento operativo desde 1959, expansión institucional durante los años siguientes, consolidación de 1969 y protocolo común de 1983. Los hitos v050 de primer enlace en 1967, proyecto inicial en 1970 o nombre inaugural en 1973 quedan sustituidos cuando pretendan fechar el nacimiento de la red.

#### Servicios y autonomía territorial

Los servicios se incorporan por etapas según equipos, ancho de banda, formación y acuerdos. Un puerto puede intercambiar inventarios y avisos sin disponer todavía de transmisión multimedia, modelos contemporáneos o automatización completa. Los archivos digitales complementan soportes anteriores durante la transición.

La arquitectura distribuye funciones entre servicios y territorios. Un nodo debe mantener procedimientos locales ante desconexiones y reconciliar después las operaciones. La disponibilidad de comunicaciones no exige una base única con todos los datos de la Federación. Los bancos, hospitales, puertos y universidades conservan responsabilidades y acceso según finalidad.

#### Fallos y mejora institucional

Congestión, errores de registros, interrupciones y conflictos de acceso impulsan revisiones. Los registros deben permitir determinar qué versión recibió una autoridad, quién autorizó una modificación y qué operaciones quedaron pendientes. La reserva técnica y la protección de datos se articulan mediante competencias verificables y revisión, sin convertir el secreto en una excepción permanente a toda responsabilidad.

Los posibles episodios con años y leyes propios de v050 se conservan en el registro de propuestas cuando no estén ya adoptados en V16. Sus problemas funcionales —centralización, continuidad, acceso y brecha territorial— sí se integran como historia de desarrollo de la red.

#### Sistemas inteligentes

En el periodo contemporáneo, los sistemas inteligentes apoyan logística, energía, investigación y servicios públicos dentro del nivel tecnológico vigente. Las decisiones con efectos sobre personas requieren responsables, registro, revisión y posibilidad de reclamación. El apellido, el fenotipo o la pertenencia a una Casa no sustituyen una evaluación de capacidad, conducta o derecho.

La administración de nodos coordina contingencias; los órganos civiles conservan competencia sobre usos y datos. La Armada accede a lo necesario para misiones autorizadas y mantiene sistemas de defensa diferenciados. La continuidad digital se evalúa junto a energía, reparación, formación y redes físicas: un centro de datos sin suministro o personal no puede sostener una actividad por la sola existencia de protocolos.

Desarrollo: 11_Ciencia y Tecnologia/Continuidad civil de OceanNet.

## Defensa y fuerzas armadas

### Bases navales y desarrollo aeronaval

La Armada Valinoreana es una fuerza oceánica distribuida. Su poder depende de la coordinación entre arsenales, puertos, bases aéreas, submarinos, cables, radares, meteorología, logística y OceanNet.

El Consejo Federal de Defensa Oceánica fija la política naval y nuclear. El Almirantazgo Federal, con sede en Nueva Tirion, dirige el Estado Mayor Naval, la construcción naval, la aviación naval, la fuerza submarina, la infantería de Marina, la inteligencia marítima y el servicio hidrográfico. Desde 1956, el Comando Estratégico Marítimo coordina flotas, bases árticas, comunicaciones y disuasión; desde 1969 se integra progresivamente con OceanNet.

##### Red de bases en 2026

Las bases principales son Nueva Tirion, Alqualondë Nova, Ciudad Federal, Islandia, Groenlandia, Nosselië Toliva, Calenport, Panamá Federal, Honolondë, Malaca, Alqualondë, Harlond y Círdan. Harnen funciona como base de apoyo mediante tratados de defensa, pero no es una base federal constitucional plena; Rhunost es una provincia autónoma interna de Harnen.

##### Evolución militar

Entre 1900 y 1914 predominan el vapor, el carbón, los cruceros, torpederos, cañoneras, primeros submarinos y estaciones telegráficas. Entre 1914 y 1930 se crean flotillas submarinas, bases de hidroaviones, escuelas de convoy y centros meteorológicos. Entre 1930 y 1945 se incorporan radar, aviación de patrulla, criptografía, defensa antiaérea y buques de desembarco. Entre 1945 y 1956 aparecen el Comando Estratégico Marítimo, la aviación naval de reacción, los portaaviones modernos, los submarinos oceánicos, las bases árticas y la investigación nuclear. Entre 1956 y 1969 las bases se conectan mediante centros de cálculo, radar integrado, enlaces digitales y satélites; OceanNet se convierte en la red de mando y logística a partir de 1969.

##### Composición naval vigente

En 2026 la Armada mantiene un inventario canónico de referencia de 615 plataformas: 595 buques tripulados y 20 vehículos navales no tripulados. Su desglose por función aparece a continuación.

| Categoría | Composición | Total |
| --- | --- | --- |
| Portaaviones | 4 nucleares, 3 convencionales y 4 ligeros STOVL | 11 |
| Submarinos | 10 estratégicos, 18 de ataque nuclear, 18 convencionales/AIP y 8 especiales, inteligencia o rescate | 54 |
| Combatientes de superficie | 24 destructores, 64 fragatas, 72 corbetas oceánicas y 30 escoltas especializados | 190 |
| Anfibios y desembarco | 14 buques de asalto y 20 LPD/LSD | 34 |
| Patrulla, vigilancia y servicio | 80 OPV, 70 patrulleros rápidos, 30 MCM, 20 hidrográficos y 20 vehículos no tripulados | 220 |
| Logística y apoyo | 20 petroleros, 18 reabastecedores, 12 transportes, 10 hospitales, 12 reparadores, 10 oceanográficos, 8 de salvamento y 16 de mando/apoyo | 106 |

La disponibilidad no equivale al inventario. AM1 estima 449 plataformas disponibles en un ciclo ordinario (7 portaaviones, 38 submarinos, 130 combatientes de superficie, 34 anfibios, 170 unidades de patrulla/servicio y 70 auxiliares); es una hipótesis de planificación, no una estadística observada. El resto se distribuye entre mantenimiento, entrenamiento, modernización y reserva.

La composición permite mantener grupos de portaaviones, fuerzas submarinas, convoyes, patrulla oceánica, operaciones anfibias limitadas, vigilancia polar y apoyo científico sin suponer que las 615 plataformas estén reunidas o disponibles simultáneamente. La Armada prioriza rutas, cables, puertos, islas, centros industriales y territorios árticos.

La aviación naval comprende cazas embarcados, aviones de ataque, patrulla marítima, guerra antisubmarina, alerta temprana, reconocimiento electrónico, transporte, rescate y helicópteros anfibios. Islandia concentra guerra antisubmarina y meteorología; Groenlandia concentra alerta temprana, vigilancia espacial, patrulla polar y protección de cables.

##### Sonar antisubmarino Palantír-2087V CIP

La Armada emplea el Palantír-2087V CIP, sistema ficticio valinari inspirado en la referencia pública británica Sonar 2087. Este último es la designación real; Palantír-2087V CIP es la designación canónica valinari. No se adopta S2187 como nombre del sistema británico ni del valinari. Es un sonar remolcado de baja frecuencia y profundidad variable para guerra antisubmarina de largo alcance.

El sistema se integra con sonar de casco, sonoboyas, helicópteros Ulmo ASW, aviones Eärendil MP, vehículos submarinos no tripulados, meteorología oceánica y OceanNet. La ventaja valinari procede de la combinación de sensores, archivos acústicos, bases árticas, submarinos y procesamiento distribuido, no de que ningún otro Estado posea sistemas equivalentes.

La actualización CIP se desarrolla mediante inserciones progresivas de software, procesamiento acústico, clasificación asistida, mantenimiento predictivo y compatibilidad con nuevas plataformas. El sistema puede verse afectado por capas térmicas, ruido portuario, fondo marino, tormentas, señuelos y tráfico marítimo.

##### Defensa y economía naval

La red naval sostiene industrias de acero, motores, turbinas, electrónica, radares, astilleros, aeronáutica, combustibles, seguros marítimos y logística. Islandia aporta energía geotérmica, pesca, aluminio, reparación naval y meteorología. Groenlandia aporta minerales estratégicos, hidroelectricidad, investigación polar, comunicaciones y defensa.

La doctrina prioriza la defensa de rutas, islas, puertos, cables, convoyes y centros industriales. Valinor puede realizar desembarcos limitados y operaciones de evacuación, pero no basa su seguridad en la conquista continental permanente.

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados. Este archivo integra la actualización acumulativa vigente y conserva los documentos Markdown del proyecto como anexos trazables. La escala demográfica vigente es: Valinor 16 millones; Valinor a Tyl 26 millones; Aranath Valinor 481 millones; Gwaith Valinor 523,5 millones; Beleg Valinor 724,5–879,5 millones (rango rector A092; componentes exteriores aún por conciliar); Gwaith Aear 1.115,5–1.515,5 millones. PIB PPA de planificación: Reino 55–62 billones (centro 58,5); Federación 60,85–70,20 billones (centro operativo 65,50). La conciliación territorial ECON-03 mantiene el punto central del Reino en 58,50 y actualiza la Federación a 65,50 billones. Las entidades son acumulativas; la cifra federal anterior de 245.050.000 queda fuera del canon operativo.

### Canon naval — equivalencia tecnológica de la Círdan IV

Estado: [CANON VIGENTE] — incorporación del 30 de octubre de 2026.

La Círdan IV se establece como una fragata oceánica de alta gama tecnológicamente equivalente o ligeramente superior a la Type 26 británica de referencia contemporánea. No es una nave invisible ni representa una generación futura completa.

##### Características canónicas

- casco optimizado para reducir la firma acústica;

- propulsión eléctrica integrada, motores diésel y turbina de gas;

- soportes antivibración y aislamiento de maquinaria;

- hélices de baja cavitación;

- sonar de casco y sonar remolcado;

- helicóptero naval;

- drones aéreos, de superficie y submarinos;

- procesamiento acústico federal y enlaces OceanNet;

- autonomía oceánica y capacidad de escolta de portaaviones;

- tripulación aproximada de 145–175 personas.

La Círdan IV puede igualar o superar moderadamente a la Type 26 en integración de sensores, automatización, drones, logística y procesamiento de datos. Su silencio depende de velocidad, mar, mantenimiento, temperatura del agua y régimen de propulsión; no elimina la posibilidad de detección enemiga.

##### Equivalencia de generaciones

| Sistema | Equivalencia tecnológica |
| --- | --- |
| Círdan I | Fragata oceánica de transición |
| Círdan II | Fragata digitalizada de alta capacidad |
| Círdan III | Fragata avanzada previa a la Type 26 |
| Círdan IV | Type 26 avanzada contemporánea |
| Voronwë | Generación posterior a la Type 26 |

La clase Voronwë inicia construcción en 2022 y sus primeras unidades entran en servicio desde 2026; releva por lotes a Círdan IV hasta 2033, con mayor automatización, sensores distribuidos, margen eléctrico, drones y mantenimiento predictivo.

### Clases principales de la Armada Valinoreana

Estado: [CANON VIGENTE] — incorporación del 30 de octubre de 2026.

La Armada organiza sus buques en clases estandarizadas, con nombres del universo de Tolkien y producción distribuida entre el Reino, la Federación y Gran Valinor.

| Clase | Tipo | Función principal |
| --- | --- | --- |
| Eärendil | Submarino nuclear de ataque | Guerra antisubmarina, inteligencia y escolta |
| Telperion | Portaaviones nuclear | Proyección aérea oceánica, mando y disuasión |
| Anárion | Portaaviones convencional de flota | Cobertura aérea oceánica |
| Gil-galad | Destructor | Defensa aérea, escolta y mando de grupo |
| Círdan | Fragata multipropósito | Guerra antisubmarina y escolta oceánica |
| Eglarest | Corbeta de generaciones anteriores | Patrulla litoral e historial de clase |
| Forlond | Familia histórica de avisos y patrulleros | Seguridad marítima, comunicaciones y protección de rutas |
| Ulmo | Submarino estratégico de generaciones anteriores | Disuasión y patrulla estratégica histórica |
| Gondolin | Submarino de ataque de generaciones anteriores | Inteligencia, escolta y guerra antisubmarina histórica |
| Númenor | Submarino convencional de generaciones anteriores | Defensa litoral y vigilancia de estrechos |
| Pelargir | Buque de asalto anfibio | Desembarco, evacuación y ayuda humanitaria |
| Rómenna | Transporte militar | Tropas, vehículos, combustible y suministros |
| Andúnië | Buque logístico | Reabastecimiento y reparación en alta mar |
| Estë | Buque hospital | Atención médica y respuesta a desastres |
| Nimrodel | Cazaminas | Limpieza de puertos y rutas marítimas |
| Vingilot | Rescate y remolque | Salvamento, remolque y control de daños |
| Palantír | Inteligencia | Vigilancia electrónica y oceanografía |
| Menel | Sistema aéreo no tripulado | Reconocimiento y vigilancia marítima |
| Esgaroth | Sistema no tripulado de superficie | Protección de puertos y cables |
| Abyssal | Sistema no tripulado submarino | Cartografía y apoyo antisubmarino |

##### Distribución industrial

- Valinor: portaaviones, submarinos estratégicos, sistemas de mando y diseño.

- Arnor: destructores, fragatas, motores, sensores y electrónica.

- Calenardhon Austral: grandes buques, turbinas, transportes y astilleros pesados.

- Sírënandë: patrulleros, drones fluviales y materiales estratégicos.

- Malaca: corbetas, drones, electrónica y producción en serie.

- Hawái: satélites, sensores y aviación naval.

- Harnen: patrulleros, fragatas, mantenimiento y logística energética.

- Eryndor: financiación, seguros y servicios navales.

La doctrina de producción queda resumida así: Valinor diseña; Arnor integra; Calenardhon construye; Malaca produce en serie; Harnen mantiene; Hawái vigila; la Federación coordina.

### Radar, sonar y arquitectura integrada de sensores

La vigilancia valinari combina sensores activos, receptores pasivos, análisis ambiental, plataformas distribuidas y personal operador. El radar detecta principalmente blancos aéreos y de superficie mediante ondas electromagnéticas; no detecta submarinos sumergidos. El sonar trabaja con propagación acústica bajo el agua. Las cámaras electroópticas e infrarrojas y los sistemas de apoyo electrónico aportan observaciones complementarias, sujetas a línea de visión, meteorología, propagación, interferencias y calidad de las bibliotecas.

La cadena de información distingue detección, validación, correlación, clasificación/identificación y decisión. Cada informe conserva hora, procedencia, condición del sensor y grado de incertidumbre. «Detectado» no equivale a «identificado»; la correlación entre varias fuentes tampoco prueba automáticamente intención hostil. Los umbrales de confianza dependen de misión y servicio, sin un porcentaje universal fijado por el canon.

El Palantír-4D opera dentro del intervalo canónico 2015–2026. «4D» designa procesamiento de distancia, azimut, elevación y velocidad radial, no una imagen perfecta ni una dimensión literal adicional. Sus alcances publicados son valores de planificación y dependen de la altura, tamaño y firma del blanco, horizonte, clutter, propagación e interferencia.

Palantír Aeglos es un programa de sensores distribuidos: combina radar AESA multibanda con receptores pasivos, sensores infrarrojos y datos autorizados de otras plataformas. Sus prototipos de 2018–2022, ensayos de 2022–2025 y modernizaciones a partir de 2025 no significan despliegue completo en 2026; las metas hasta 2045 son futuras. La fusión puede sufrir latencia, datos engañosos, fallos de calibración o errores de clasificación. La recomendación automatizada no sustituye la decisión humana.

Palantír-2087V CIP es la designación ficticia valinari de una solución antisubmarina con sonar remolcado de baja frecuencia y profundidad variable. Sonar 2087 es la referencia británica; no se adopta S2187 como nombre de este sistema ni se atribuye a la Type 26 británica. La adaptación valinari se apoya en sonar de casco, sonoboyas, helicópteros Ulmo ASW, aeronaves Eärendil MP, sensores submarinos, archivos acústicos y meteorología. No se presupone que todos los cascos tengan idéntica variante. La expansión de CIP y la matriz de equipo por buque quedan pendientes de aprobación canónica.

OceanNet inicia su funcionamiento operativo en 1959; 1969 corresponde a su consolidación institucional y a la ampliación sostenida de la red. El protocolo federal común se adopta en 1983. La red transporta informes y órdenes autorizadas, pero no es un sensor ni una autoridad. Los nodos navales conservan operación local limitada durante interrupciones; al recuperar enlace, sincronizan registros con hora y procedencia. La segmentación protege redes civiles y militares, mientras las órdenes con efectos sobre personas y el empleo de fuerza siguen sujetas a responsables humanos y reglas legales.

Las funciones territoriales se limitan a los emplazamientos ya canónicos: Groenlandia apoya vigilancia ártica y enlaces; Islandia, meteorología y guerra antisubmarina del Atlántico Norte; Nosselië Toliva, rutas y cables del Atlántico oriental; Panamá, continuidad interoceánica; Hawái, vigilancia del Pacífico; Malaca, rutas del Índico. Harnen presta apoyo por tratado y continúa siendo protectorado. Esta sección no crea bases, unidades ni inventarios nuevos.

La configuración exacta por casco y lote, cantidades, umbrales operativos y expansión oficial de CIP permanecen abiertos por falta de decisiones de plataforma; no se completan con cifras inventadas. Desarrollo detallado: Radar y sensores.

### Sistemas de radar naval — Palantír-4D y Palantír Aeglos

Estado: [CANON VIGENTE] — incorporación del 30 de octubre de 2026.

##### Palantír-4D

El Palantír-4D es el radar AESA naval y territorial estándar de Gwaith Valinor. Mide distancia, azimut, elevación y velocidad radial mediante efecto Doppler. Su arquitectura AESA utiliza módulos transmisores-receptores independientes y permite formar varios haces, cambiar de frecuencia rápidamente y seguir múltiples objetivos.

| Parámetro | Palantír-4D naval |
| --- | --- |
| Arquitectura | AESA digital de cuatro paneles |
| Cobertura | 360° |
| Bandas | S y C según variante |
| Seguimiento | Centenares de trazas |
| Alcance aéreo de referencia | 300–450 km contra blancos grandes |
| Alcance de superficie | 50–100 km aproximadamente |
| Guerra electrónica | Integrada |
| Fusión de datos | OceanNet, satélites, drones y aeronaves |
| Operación | Rotatoria, sectorial o fija |

Se instala en destructores Gil-galad, fragatas Círdan IV, portaaviones Eärendil, portaeronaves Telperion, bases costeras y aeronaves de alerta temprana. Sus limitaciones dependen del horizonte radar, curvatura terrestre, meteorología, interferencias, firma del blanco, saturación y calidad de identificación.

##### Palantír Aeglos

El Palantír Aeglos es el sistema naval avanzado posterior al Palantír-4D. No es simplemente un radar de mayor potencia: combina AESA distribuido, varias bandas, receptores pasivos, sensores infrarrojos, redes multistáticas, inteligencia artificial y OceanNet.

| Característica | Palantír-4D | Palantír Aeglos |
| --- | --- | --- |
| Arquitectura | AESA | AESA distribuido y multibanda |
| Seguimiento | Centenares de trazas | Miles de trazas combinadas |
| Alcance aéreo de referencia | 300–450 km | 450–650 km según blanco |
| Guerra electrónica | Integrada | Adaptativa y cooperativa |
| Clasificación | Automática básica | Fusión avanzada de firmas y comportamiento |
| Operación | Activa | Activa, pasiva y multistática |

El Aeglos añade análisis de aceleración y maniobra, firma electrónica, firma infrarroja, reconocimiento de señuelos y correlación con sensores externos. Los alcances son valores de planificación, no garantías universales.

##### Despliegue

- Palantír-4D Naval: Círdan IV, Gil-galad, Eärendil y Telperion.

- Palantír-4D Costero: Canarias, Panamá, Harnen, Eryndor, Hawái, Malaca y Sírënandë.

- Palantír-4D Aerotransportado: aviones de alerta temprana, patrulla marítima y drones de gran autonomía.

- Palantír Aeglos: destructores modernizados, portaaviones Eärendil, bases estratégicas y fragatas Voronwë.

La red Aeglos permite que una plataforma detecte, otra siga y una tercera clasifique un objetivo. No vuelve invisible a la flota ni elimina la posibilidad de error, interferencia o penetración de la red.

##### Cronología técnica

- 1958–1970: radares tridimensionales iniciales.

- 1970–1985: escaneo electrónico y procesamiento digital.

- 1985–2000: primeros radares AESA navales.

- 2000–2015: integración con OceanNet y defensa aérea cooperativa.

- 2015–2026: Palantír-4D, módulos de nitruro de galio, seguimiento de drones y fusión multisensor.

- 2018–2022: investigación y prototipos Aeglos.

- 2022–2025: pruebas costeras y aéreas.

- 2025–2029: instalación en destructores Gil-galad modernizados.

- 2029–2040: incorporación progresiva en las primeras fragatas Voronwë.

- 2040–2045: despliegue completo en portaaviones, bases y aeronaves de alerta temprana.

### Organización militar valinari, 1000–500 a. C.

Durante este periodo, la fuerza valinari pasa de defensas de clan y séquitos familiares a un sistema pactado entre Casas, puertos y comunidades agrícolas. No existe todavía un ejército permanente centralizado.

### Fuerzas de las Casas y milicia

Cada Casa mantiene familiares nobles, campesinos movilizados, artesanos, marineros, cazadores, guardias de santuario y aliados matrimoniales. Las Casas Mayores aportan contingentes; las Casas Menores aportan barcos, exploradores, guías, cartógrafos y convoyes. Las milicias locales vigilan caminos, cosechas, fuentes, graneros y puertos, y se reúnen según la estación y la amenaza.

La infantería usa lanzas, hachas, espadas, jabalinas, arcos, escudos, cascos y protección de cuero o metal. La lanza es el arma común; la espada y la armadura completa son más costosas. La caballería es limitada y se emplea en exploración, mensajería, reconocimiento, persecución y transporte, no como fuerza de choque dominante.

### Guerra naval y fortificaciones

La guerra naval utiliza embarcaciones comerciales y de exploración adaptadas para transportar tropas, proteger convoyes, bloquear puertos, vigilar estrechos y realizar incursiones. El combate se basa en abordajes, jabalinas, flechas, ganchos, captura de timones y ataques contra velas.

Los puertos mantienen astilleros, talleres, almacenes, depósitos de alimentos, torres de vigilancia, embarcaderos militares y señales de fuego o humo. Helsingborg protege el Øresund; Malmö, Trelleborg, Falsterbo, Ystad y Simrishamn apoyan el Báltico; el Oslofjord, Rogaland, Hordaland y Trøndelag aportan madera, marineros y refugios.

Las fortificaciones combinan empalizadas, fosos, terraplenes, torres, muros de piedra, puertas reforzadas y plataformas de vigilancia. Protegen puertos, graneros, santuarios, fuentes, pasos, centros metalúrgicos y desembocaduras.

### Logística y economía de guerra

La capacidad militar depende de graneros, ganado, sal, pescado seco, madera, carbón, hierro, talleres y rutas seguras. Antes de una campaña se calculan alimentos, agua, forraje, repuestos, herreros, carpinteros y capacidad de transporte. Una expedición puede fracasar por falta de suministros aunque venza en combate.

Los santuarios registran inventarios y custodian reservas. Los puertos reparan naves y redistribuyen alimentos. Las Casas agrícolas sostienen tropas; las metalúrgicas producen armas y herrajes; las navales aportan barcos; las exploradoras informan sobre costas, corrientes, pasos y comunidades.

### Inteligencia, señales y mando

La información se transmite mediante mensajeros, fogatas, humo, cuernos, banderas, marcas de camino, tablillas y registros de puerto. Los exploradores observan movimientos de barcos, cambios de viento, rutas de ganado, estado de caminos y alianzas locales.

Antes de 990 a. C. el mando es fragmentario. Después de Forostar aparecen convocatorias comunes, señales de alarma, obligaciones de auxilio, arbitraje de campañas y coordinación de convoyes. El Concilio no elimina las fuerzas de las Casas: establece cuándo deben actuar en defensa común.

### Guerra regulada

Después de 990 a. C. continúan las guerras privadas, pero se prohíben progresivamente el saqueo de graneros, el ataque a santuarios, la destrucción de fuentes, la ejecución de prisioneros, la quema de cosechas, el bloqueo deliberado de alimentos y el ataque a puertos neutrales.

Las soluciones son compensaciones, devolución de tierras, arbitraje, rehenes nobles, matrimonios de reconciliación, devolución de prisioneros, juramentos renovados y aislamiento diplomático. La guerra se convierte gradualmente en actividad regulada por pactos.

### Desarrollo cronológico

- 1000–990 a. C.: guerras privadas, ataques a graneros, disputas por fuentes, destrucción de talleres y rivalidad por puertos.

- 990–950 a. C.: Forostar limita conflictos entre Casas y protege prisioneros, santuarios, graneros y puertos neutrales.

- 950–850 a. C.: recuperación de fortificaciones, rutas, astilleros y convoyes.

- 850–750 a. C.: expansión naval en el Báltico y el mar del Norte; las Casas Menores actúan como capitanías y protectoras de rutas.

- 750–700 a. C.: las expediciones atlánticas exigen depósitos, señales y marineros especializados.

- 700–600 a. C.: conflictos por minas, talleres, graneros y puertos; crecen las alianzas funcionales.

- 600–550 a. C.: el retorno de Telcontar aporta redes septentrionales, flotas y liderazgo militar.

- 550–500 a. C.: la Corona coordina la defensa general, mientras las Casas conservan sus fuerzas y fueros.

La fuerza valinari sigue siendo descentralizada, marítima y dependiente de agricultura, metalurgia, pactos y alianzas. La ventaja principal no es un ejército permanente enorme, sino la combinación de puertos, barcos, graneros, talleres, exploradores y milicias.

### Profundización militar valinari, 1000–500 a. C.

##### Cadena de mando y movilización

Antes de 990 a. C. cada Casa dirige sus fuerzas. Después de Forostar se establece una coordinación gradual: la Corona o autoridad de coalición convoca la defensa común; el Concilio aprueba contribuciones; los capitanes dirigen contingentes; los comandantes de puerto organizan naves y almacenes; los jefes de milicia movilizan aldeas; los guardianes de santuario protegen archivos y refugios; exploradores y mensajeros transmiten información.

La movilización utiliza fuegos, humo, cuernos, banderas, embarcaciones rápidas y mensajeros a caballo. La convocatoria especifica causa, duración, lugar de reunión, tropas, barcos y alimentos. La movilización general es excepcional porque afecta siembra, pesca y producción artesanal.

##### Campañas terrestres y asedios

Las campañas tienen objetivos limitados: recuperar una fortaleza o puerto, proteger una fuente, detener un saqueo, liberar prisioneros o restablecer un pacto. Las marchas siguen ríos, costas, caminos agrícolas, pasos y líneas de graneros. Los contingentes incluyen cocineros, herreros, carpinteros, cuidadores de animales y guardianes de suministros.

Los campamentos disponen de empalizada, depósitos, zona de armas, refugio de mandos, área médica, espacio para animales, lugar de culto y zona de prisioneros. Los asedios emplean bloqueo de caminos, corte de agua, rampas, escalas, torres, incendios controlados y negociación. La destrucción de una ciudad, santuario o granero es una medida extrema y puede provocar condena general.

##### Defensa portuaria y guerra naval

Los puertos combinan torres, barreras, patrullas, almacenes, señales de fuego, vigías y tropas de desembarco. Las naves comerciales y exploradoras se adaptan para transportar tropas, escoltar convoyes, bloquear entradas y combatir mediante abordajes, jabalinas, flechas, ganchos, captura de timones y ataques contra velas.

La información sobre mareas, corrientes, bancos de arena, refugios y vientos tiene valor militar equivalente al armamento. Helsingborg protege el Øresund; Malmö, Trelleborg, Falsterbo, Ystad y Simrishamn apoyan el Báltico; el Oslofjord, Rogaland, Hordaland y Trøndelag aportan madera, marineros y refugios.

##### Logística, inteligencia y sanidad

La capacidad militar depende de graneros, ganado, sal, pescado seco, madera, carbón, hierro, talleres y rutas seguras. Antes de una campaña se calculan alimentos, agua, forraje, repuestos, herreros, carpinteros y transporte. Una expedición puede fracasar por falta de suministros aunque venza en combate.

La información circula por mensajeros, fogatas, humo, cuernos, banderas, marcas de camino y registros de puerto. Los exploradores observan barcos, vientos, caminos, ganado y alianzas.

Los santuarios y Casas de sanación emplean vendajes de lino, miel, aceites, hierbas, férulas, agua hervida, suturas y reposo. Los heridos de cualquier Casa pueden recibir atención en santuarios neutrales. Atacar médicos, refugios o guardianes constituye una violación grave del pacto.

##### Prisioneros y financiación

Los prisioneros nobles garantizan acuerdos y pueden ser intercambiados o rescatados. Se exige alimentación, custodia, atención a heridas, prohibición de tortura y registro de identidad. La esclavización permanente pierde legitimidad dentro del orden pactista.

Las campañas se financian mediante contribuciones de Casas, impuestos portuarios, reservas de grano, ganado, metal, madera, trabajo temporal, préstamos de santuarios y derechos de navegación. Las Casas que aportan barcos reciben privilegios de atraque, comercio, tierras o precedencia, según el pacto.

##### Funciones militares de las Casas

Las Casas agrícolas aportan alimentos y milicias; las metalúrgicas, armas y reparación; las marítimas, barcos y marineros; las exploradoras, reconocimiento y cartografía; las de estudio, calendarios y registros; las comerciales, financiación y convoyes; las guerreras, oficiales y tropas de élite; y las vinculadas a santuarios, refugio, sanidad y custodia documental.

##### Telcontar y la Guardia de la Corona

El retorno de Telcontar entre 600 y 550 a. C. integra fuerzas navales y terrestres y convierte la defensa común en fundamento de la Corona. El pacto de 550 a. C. permite convocar campañas, organizar convoyes, requisar suministros en emergencias, proteger puertos y arbitrar rendiciones sin eliminar los fueros militares locales.

La primera Guardia de la Corona es pequeña y está formada por veteranos, guerreros de Casas aliadas, escoltas reales, marineros y guardianes de archivos. Protege a la familia real, embajadas, mensajeros, capital y archivos dinásticos. No puede convertirse en fuerza privada contra el Concilio.

La cultura militar valinari valora disciplina, resistencia, navegación, memoria, protección civil, devolución de prisioneros y capacidad de retirarse a tiempo. Una victoria que destruye los graneros propios se considera un fracaso.

### Casas participantes en las campañas militares, 1000–500 a. C.

La participación de las Casas se define por función y territorio. Las Casas Mayores proporcionan mando, recursos y contingentes; las Casas Menores actúan como capitanías, exploradoras, comerciantes, cartógrafas y protectoras de convoyes. Las Casas Vasallas participan bajo la autoridad de su Casa tutelar y no reciben mando independiente salvo delegación expresa.

##### Guerra de los Graneros del Este, 1000–994 a. C.

Casas Mayores: Esgal, Calenor, Calenhad, Annúminas y Minas Anor.

Casas Menores: Tumladen, Lindor, Maethor y Nimrodel.

Funciones: defensa de graneros, transporte fluvial, registro de reservas y movilización agrícola.

##### Conflicto del Øresund, 997–990 a. C.

Casas Mayores: Círdan, Pelargir, Harlond, Teleri y Alqualondë.

Casas Menores: Falastur, Eärond, Aerandir y Círdanir.

Funciones: patrulla del estrecho, escolta mercante, control de atraques y negociación con Dinamarca.

##### Campaña de Forostar, 990–985 a. C.

Casas Mayores: Annúminas, Fornost, Noldor, Minas Anor y Vanyar.

Casas Menores: Erestor, Meneldir, Gwindor y Aglaran.

Funciones: imposición de arbitrajes, custodia de archivos, protección de santuarios y coordinación de contingentes.

##### Guerra de las Rutas Noruegas, 965–950 a. C.

Casas Mayores: Mithlond, Harlond, Alqualondë, Eressëa Menel y Teleri.

Casas Menores: Aerandir, Falathar, Voronwë y Thoron.

Funciones: navegación de fiordos, intercambio de madera y hierro, reconocimiento costero y pactos con comunidades noruegas.

##### Campaña de Åhus y las Marismas, 930–920 a. C.

Casas Mayores: Esgal, Calenhad, Eldalondë y Calenor.

Casas Menores: Tumladen, Nimrodel, Duilin y Belegor.

Funciones: diques, canales, salinas, agricultura, defensa fluvial y protección de obras hidráulicas.

##### Guerra de las Tres Costas, 900–885 a. C.

Casas Mayores: Pelargir, Mithlond, Teleri, Alqualondë y Taur-en-Mor.

Casas Menores: Ostor, Círdanir, Falastur, Eärond y Baranor.

Funciones: convoyes, bloqueo, diplomacia portuaria y protección del comercio entre Báltico, Kattegat y mar del Norte.

##### Campaña de las Islas del Ámbar, 860–845 a. C.

Casas Mayores: Eressëa Menel, Alqualondë, Eryn Lasgalen, Taur-en-Mor y Vanyar.

Casas Menores: Aerandir, Falathar, Voronwë, Elentir y Celepharn.

Funciones: cartografía, exploración insular, traducción, factorías temporales y protección de convoyes.

##### Guerra de los Puertos Neutrales, 780–765 a. C.

Casas Mayores: Harnost, Harlond, Mithlond, Vanyar y Pelargir.

Casas Menores: Baranor, Celepharn, Hallas, Aglaran y Lindor.

Funciones: defensa de mercados, neutralidad portuaria, crédito comercial, mediación y sanciones económicas.

##### Campaña de las Rutas Atlánticas, 720–700 a. C.

Casas Mayores: Eressëa Menel, Alqualondë, Teleri, Eldalondë y Círdan.

Casas Menores: Aerandir, Falathar, Voronwë, Thoron y Elentir.

Funciones: exploración, astronomía, señales costeras, depósitos de agua, rescate y retorno seguro.

##### Crisis de las Minas y los Arsenales, 690–675 a. C.

Casas Mayores: Noldor, Barad Calen, Calenor, Minas Anor y Esgal.

Casas Menores: Angren, Gwindor, Erestor, Maethor y Ostor.

Funciones: hierro, carbón, talleres, armas, herrajes navales, protección de artesanos y arbitraje de reservas.

##### Guerra de los Graneros del Norte, 640–625 a. C.

Casas Mayores: Annúminas, Calenhad, Rhunost, Esgal y Eldalondë.

Casas Menores: Tumladen, Nimrodel, Lindor, Meneldir y Belegor.

Funciones: transporte de cereal, pesca seca, protección de graneros, convoyes y rutas entre Escania y Noruega.

##### Guerra de la Sucesión Occidental, 590–560 a. C.

Casa Real en formación: Telcontar.

Casas Mayores: Annúminas, Fornost, Círdan, Harlond, Harnost, Pelargir y Eressëa Menel.

Casas Menores: Falastur, Círdanir, Elentir, Ostor, Meneldir y Aerandir.

Funciones: control de Helsingborg, archivos genealógicos, arsenales, graneros, rutas del Øresund, mediación y apoyo a la sucesión.

Las Casas Vasallas participan como contingentes dependientes de estas Casas Mayores. Su aportación se concentra en guardias de puerto, infantería local, escolta de convoyes, administración de graneros, talleres y defensa de santuarios. Ninguna Casa Vasalla altera por sí sola el equilibrio constitucional de las 24 Casas Mayores.

### Cultura naval y continuidad de rutas

#### cultura naval y continuidad de rutas

La Armada valinari se define como una institución de continuidad estratégica. Su función histórica es mantener rutas, comunidades, puertos, comunicaciones, comercio, investigación, crédito, suministros e infraestructuras críticas. La máxima doctrinal «Sin rutas no hay comercio; sin comercio no hay conocimiento; sin conocimiento no hay prosperidad» se conserva como formulación estratégica, no como una ley absoluta: también existen conocimiento terrestre, producción local y aprendizaje fuera del comercio.

La historia naval combina exploración, comercio, auxilio, protección, coerción, bloqueo, conquista, transporte militar, colonización y apoyo a factorías y asentamientos. La especial importancia de la red valinari no implica una superioridad moral automática ni una ausencia histórica de violencia. La posterior profesionalización y constitucionalización somete las operaciones a presupuesto, autoridad responsable, derecho aplicable y control jurisdiccional; la tradición naval no concede a la Corona ni a la Armada poderes ilimitados.

##### Formación y misiones

Las Academias del Mar forman especialistas en navegación, matemáticas, astronomía, cartografía, meteorología, lenguas, derecho, administración, medicina, mantenimiento y logística. No se exige que cada oficial domine todas las disciplinas: la capacidad se distribuye entre equipos, cuerpos profesionales y formación continua.

Las misiones navales canónicas comprenden protección de comunidades, escolta de convoyes, continuidad de comunicaciones, auxilio y rescate, levantamientos hidrográficos, vigilancia de rutas, apoyo a astilleros y estaciones, transporte logístico y operaciones militares autorizadas. Proteger el comercio no equivale a garantizar beneficios privados, cobrar deudas o subordinar los bancos a la Armada.

##### Puertos y escalas

La red distingue puerto principal, puerto militar, estación de abastecimiento, astillero, factoría, depósito documental, estación meteorológica, nodo de comunicaciones, refugio temporal, base logística y puerto asociado. No todo puerto es una base naval completa y no toda escala crea soberanía sobre la población o el territorio que la recibe.

La redundancia de puertos, reservas, talleres, cartas y comunicaciones reduce la dependencia de un único paso, pero no elimina tormentas, averías, sabotaje, bloqueo, errores de información o vulnerabilidades económicas. La utilidad comercial de un lugar no demuestra consentimiento general ni jurisdicción ilimitada.

##### Finanzas y protección naval

Letras de crédito, seguros marítimos, bancos, compensación comercial y protección de transportes sensibles forman parte de la infraestructura económica de la red. Una letra de crédito representa un derecho y una obligación; no es una carga física equivalente transportada dentro del buque.

La Armada puede proteger metales, documentos, archivos, convoyes y comunicaciones cuando existe mandato legal y necesidad estratégica. Bancos, aseguradoras, mercados y oficinas conservan competencias civiles propias. La protección naval no autoriza vigilancia indiscriminada, control automático de la banca ni uso de la fuerza para resolver obligaciones privadas.

##### OceanNet y separación de competencias

OceanNet mantiene continuidad documental y coordinación logística, pero distingue servicios civiles, infraestructura operacional y sistemas militares. El acceso se organiza por función, privacidad, autorización y responsabilidad. La Armada no controla automáticamente OceanNet, las bibliotecas, los archivos civiles ni el capital financiero por necesitar comunicaciones fiables.

##### Límites territoriales y contables

La integración mantiene la geografía vigente: Númenor corresponde a Terranova y Tol Eressëa es una entidad diferenciada. No se trasladan a Tol Eressëa los recursos, población o geografía de Terranova. Barad Nimras/Gibraltar continúa como base arrendada desde 1815; Ceuta y Melilla no se convierten por esta integración en distritos federales. Las cifras navales deben distinguir inventario, unidades activas, reserva, mantenimiento, formación, transporte y auxiliares antes de compararse entre periodos.

La cultura naval explica la coordinación de la red, pero no certifica por sí sola supremacía mundial, control absoluto de todas las rutas ni una flota idéntica en cada siglo. Cada capacidad debe comprobarse mediante educación, astilleros, suministros, finanzas, personal, mantenimiento y disponibilidad operativa.

### Serie Círdan y transición a Voronwë

La serie de fragatas contemporáneas comienza en 1955. El acorazado Círdan I de 1875 es una reutilización histórica del nombre, no la primera fragata de la serie moderna.

#### Adelanto de la serie Círdan y transición a Voronwë

La serie Círdan se introduce diez años antes de la planificación anterior. El adelanto se justifica por la continuidad educativa, la industria naval, la electrónica, la investigación antisubmarina y la financiación federal, no por la aparición súbita de tecnología futura.

- Círdan inicial, 1955–1965: fragata oceánica antisubmarina con turbinas de gas, sonar de casco, helicóptero naval y primeros enlaces digitales.

- Círdan II, 1965–1975: sonar remolcado, defensa aérea de corto alcance, mejores comunicaciones y mayor autonomía.

- Círdan III, 1975–1985: propulsión más silenciosa, misiles antibuque, guerra electrónica y enlaces con la red OceanNet precursora.

- Círdan IV, 1995–2005: propulsión eléctrica integrada, radar AESA inicial, sonar remolcado, helicóptero, drones tempranos y arquitectura digital modular.

- 2005–2015: modernización de Círdan IV con mejoras de sensores, comunicaciones, mantenimiento y guerra antisubmarina.

- 2018–2022: diseño, prototipo y pruebas de la clase Voronwë.

- 2022–2033: sustitución progresiva de Círdan IV; los buques más recientes permanecen en servicio secundario, entrenamiento o reserva.

Voronwë conserva la misión oceánica, antisubmarina y de escolta de Círdan IV. Mejora firma acústica, generación eléctrica, automatización, drones, guerra electrónica, mantenimiento predictivo y compatibilidad con el Palantír-2087V CIP. La transición no retira toda la serie Círdan simultáneamente y mantiene una fuerza mixta durante la década de 2020.

### Armada antigua, 500 a. C.–500 d. C.

#### Poder militar valinari, 500 a. C.–500 d. C.

##### Modelo estratégico

El poder militar valinari se basa en una talasocracia defensiva. La armada es el instrumento principal de proyección y defensa exterior, pero opera junto con fortalezas portuarias, milicias de Casas, convoyes logísticos, guarniciones y fuerzas terrestres.

La doctrina central es impedir que una potencia continental alcance los puertos, las islas o los graneros costeros. El enemigo debe ser detectado, desgastado y, cuando sea posible, destruido en el mar antes de consolidar un desembarco.

##### Evolución entre 500 a. C. y 500 d. C.

Entre 500 y 300 a. C., cada Casa aporta barcos, marineros, remeros, pilotos, astilleros y tropas. La Corona y el Consejo de las Casas coordinan las campañas mayores, pero todavía no existe una armada completamente centralizada.

Entre 300 y 50 a. C. aparecen arsenales permanentes, registros de tripulaciones, depósitos de madera y brea, torres de observación, señales de fuego, patrullas estacionales y escuadras regionales.

Entre 50 a. C. y 200 d. C. la armada oceánica se profesionaliza. Se organizan escuadras atlánticas, mediterráneas e insulares, además de flotillas de convoy, unidades de desembarco y buques de exploración.

Entre 200 y 500 d. C. la prioridad pasa a ser la defensa de rutas, el control de estrechos, la protección de grano y la guerra contra piratas y expediciones de desembarco.

##### Tipos de buque

La armada combina buques oceánicos de vela, galeras rápidas, patrulleros, cargueros protegidos, transportes de tropas y barcos auxiliares. Los buques oceánicos tienen mayor autonomía, estabilidad, capacidad de agua y resistencia al oleaje que los trirremes mediterráneos, pero son menos ágiles en espacios estrechos.

Los trirremes y galeras romanas conservan ventajas en aceleración, maniobra, embestida y combate costero. Por eso la doctrina valinari no reemplaza las galeras: utiliza buques oceánicos para resistencia, transporte y combate prolongado, y galeras para exploración, persecución y abordaje.

##### Defensa contra invasiones

La defensa se organiza en cuatro fases: detección mediante torres, vigías y barcos exploradores; aislamiento de la flota enemiga mediante ataques a transportes y suministros; destrucción de escoltas y buques de desembarco; y negación del desembarco mediante guarniciones, obstáculos, fuego costero y contraataques.

Una escuadra atlántica puede incluir, según la campaña, buques oceánicos pesados y medianos, galeras rápidas, patrulleros, transportes protegidos y unidades de apoyo. La ventaja valinari procede de la integración entre navegación, meteorología, bases, inteligencia y logística, no solamente del tamaño de los cascos.

##### Comparación con Roma

Roma mantiene ventaja en el Mediterráneo, las galeras de combate, el transporte de legiones y las grandes operaciones anfibias. Valinor mantiene ventaja en navegación oceánica, mar abierto septentrional, guerra de convoyes, defensa de islas atlánticas e inteligencia marítima.

### Ejército antiguo, 500 a. C.–500 d. C.

#### Ejército valinari, 500 a. C.–500 d. C.

##### Organización general

El ejército terrestre se desarrolla como complemento de la armada. No es inicialmente un ejército permanente de tipo romano, sino una estructura compuesta por:

- séquitos armados de las Casas;

- milicias territoriales;

- guarniciones de puertos y fortalezas;

- tropas profesionales de la Corona;

- ingenieros y constructores;

- exploradores y mensajeros;

- unidades de convoy y abastecimiento;

- fuerzas auxiliares reclutadas entre comunidades portuarias y aliadas.

La obligación militar se relaciona con la tierra, la ciudadanía, los pactos de las Casas y el servicio naval. Las familias nobles aportan oficiales y contingentes, mientras las comunidades urbanas aportan artesanos, defensores, marineros y personal logístico.

##### 500–300 a. C.: milicia pactista

El ejército está formado principalmente por infantería de lanza, escudo, espada y hacha. Las unidades se reúnen por Casa o por territorio y actúan bajo mandos temporales.

Sus funciones principales son:

- defender santuarios y graneros;

- proteger puertos;

- controlar pasos y ríos;

- acompañar convoyes terrestres;

- reforzar desembarcos propios;

- impedir incursiones y saqueos.

La lealtad primaria es local. El Consejo de las Casas establece compensaciones, límites de campaña, devolución de prisioneros y prohibiciones contra el saqueo de mercados y santuarios.

##### 300–50 a. C.: profesionalización parcial

El crecimiento de los puertos y la rivalidad mediterránea impulsa tropas más estables. Aparecen compañías permanentes de:

- infantería pesada;

- infantería ligera;

- arqueros y honderos;

- exploradores;

- zapadores;

- escoltas de convoy;

- guardias de arsenales;

- tropas de guarnición.

La Corona empieza a pagar unidades permanentes con ingresos portuarios, impuestos sobre mercancías, reservas de grano y contribuciones de las Casas.

##### a. C.–200 d. C.: ejército territorial y anfibio

El ejército se adapta a la expansión atlántica. La unidad típica combina una guarnición costera, una fuerza de reacción y un destacamento naval.

Las tropas se emplean para:

- proteger astilleros;

- custodiar depósitos;

- asegurar desembarcos;

- ocupar posiciones elevadas;

- defender colonias y estaciones;

- escoltar expediciones científicas y comerciales;

- combatir piratería terrestre;

- sostener enclaves mediterráneos.

La fuerza anfibia se vuelve especialmente importante. Las tropas entrenan para desembarcar, levantar empalizadas, tomar muelles y asegurar agua y alimentos antes de avanzar.

##### 200–500 d. C.: ejército de guarnición y respuesta rápida

La crisis del siglo III y la inestabilidad de las rutas impulsan una estructura más defensiva. La Corona mantiene tropas de reacción rápida cerca de los principales puertos, mientras las Casas conservan milicias y fuerzas territoriales.

El ejército se divide funcionalmente en:

- guarniciones permanentes;

- infantería de campaña;

- tropas de frontera;

- guardias de arsenales y graneros;

- unidades anfibias;

- ingenieros;

- exploradores;

- convoyes y tren logístico.

La prioridad ya no es conquistar grandes territorios interiores, sino conservar rutas, puertos, islas, depósitos y corredores de navegación.

##### Armas y equipo

La infantería utiliza lanzas, escudos, espadas, hachas, cuchillos, arcos y hondas. Las tropas de élite emplean armaduras de escamas, placas parciales, cascos reforzados y escudos de madera recubierta.

Los ingenieros construyen empalizadas, torres, muelles defensivos, rampas, almacenes, caminos militares y máquinas de asedio sencillas. El ejército valinari no depende de una tecnología única: su eficacia procede de la calidad del hierro, la disciplina de los arsenales y la coordinación con la armada.

##### Caballería y transporte

La caballería es limitada frente a la romana y se emplea en:

- reconocimiento;

- mensajería;

- persecución;

- protección de rutas interiores;

- respuesta ante incursiones.

No constituye el núcleo del ejército. El terreno fragmentado, las islas, los bosques, las costas y las rutas marítimas favorecen a la infantería y a las fuerzas anfibias.

##### Relación entre Casas, Corona y ejército

Las Casas conservan autonomía para reclutar y equipar fuerzas propias, pero no pueden declarar guerras ilimitadas después de la regulación pactista. La Corona coordina la defensa exterior, la movilización común, los arsenales reales, las guarniciones estratégicas y las campañas que afectan a varias provincias.

El Consejo de las Casas supervisa las contribuciones, arbitra disputas y limita el uso privado de la fuerza. La centralización crece especialmente desde la consolidación de la Casa Telcontar, pero las milicias de las Casas permanecen como parte esencial del sistema.

##### Balance militar

Frente a Roma, Valinor es inferior en población movilizable, profundidad territorial, caminos y guerra terrestre prolongada. Es superior en defensa de costas atlánticas, guerra anfibia, navegación oceánica, logística insular y coordinación entre puertos.

El modelo militar valinari no busca imitar a las legiones. Su finalidad es hacer costosa o inviable una invasión mediante la combinación de armada, fortalezas, milicias, guarniciones y control de suministros.

##### Solución dogmática

El dogma religioso incorpora la siguiente fórmula:

Ninguna persona puede ser poseída plenamente, porque toda vida pertenece al orden de la creación y toda memoria debe poder continuar. La custodia de una persona sometida obliga a devolverle libertad, nombre, familia y comunidad cuando cese la causa legítima de cautiverio.

La fórmula permite resolver la contradicción sin borrar la historia. Durante siglos, las Casas siguen explotando trabajo esclavizado, pero ya no pueden presentarlo sin disputa como una institución moralmente neutral. La religión, los santuarios y los archivos se convierten en instrumentos de limitación, rescate y posterior abolición.

### Red histórica de bases antiguas

Cada instalación se fecha por su etapa efectiva: reconocimiento, refugio, factoría, guarnición y arsenal. Los nombres actuales permiten localizar sitios, sin atribuirles retrospectivamente su capacidad o soberanía de 2026. Forostar es sede histórica de pactos; Nueva Tirion y Armenelos tienen funciones territoriales y navales diferentes.

#### Bases militares y distribución territorial, 500 a. C.–500 d. C.

La red militar valinari no es una ocupación uniforme, sino una cadena de puntos de apoyo situados junto a rutas, puertos, estrechos, fuentes de agua, graneros, astilleros y pasos terrestres. Se organiza en arsenales navales, fortalezas portuarias, estaciones de convoy, torres de vigilancia, guarniciones interiores, depósitos y campamentos temporales.

##### Núcleo ancestral septentrional

Entre 500 y 300 a. C., el núcleo militar se concentra en Escania, las costas noruegas, los corredores daneses de tránsito, el Báltico occidental y el mar del Norte. Las instalaciones protegen ensenadas, desembocaduras, astilleros, rutas de hierro y madera, depósitos de grano y lugares de reunión de las milicias de las Casas.

Escania mantiene valor genealógico y logístico aunque deja de ser el único centro político. Las bases de esta zona son principalmente fortalezas locales, almacenes, torres de señales y puertos de movilización.

##### Mar del Norte y Atlántico oriental

Desde 300 a. C., las estaciones se extienden hacia estuarios, cabos, islas y desembocaduras. No todas son colonias permanentes: algunas son puestos de agua, reparación, observación y almacenamiento. Sus unidades habituales son patrulleros, guardias de puerto, infantería ligera, exploradores, ingenieros y equipos de señales.

Nosselië Toliva se convierte gradualmente en una escala atlántica fortificada con puerto, depósitos de agua, talleres navales, torre de observación, guarnición, destacamento de marinería y almacenes agrícolas. Su función principal es proteger convoyes y controlar la navegación, no proyectar grandes ejércitos hacia África.

##### Systreyjar, Tol Eressëa y Groenlandia

Systreyjar funciona como escala entre el norte europeo y el Atlántico. Sus instalaciones incluyen fondeaderos, depósitos, torres de señal, talleres y pequeñas guarniciones.

Tol Eressëa se descubre antes que Groenlandia y se utiliza inicialmente como referencia y estación oceánica. Groenlandia se incorpora después como puesto septentrional. Las primeras instalaciones son refugios fortificados, depósitos estacionales, talleres ligeros, observatorios costeros y pequeños destacamentos. No deben confundirse con provincias plenamente administradas.

##### Númenor y Valinor

Númenor se convierte en una base oceánica de primera importancia después de su incorporación. Controla rutas entre Europa y América, convoyes atlánticos, accesos a Valinor y movimientos de exploración. Cuenta con arsenal, rampas de reparación, fortaleza costera, guarnición, tropas anfibias, almacenes de agua y grano y observatorios.

Valinor se incorpora más tarde que Tol Eressëa y Groenlandia. Sus primeras instalaciones son puestos de exploración y asentamientos costeros. Con el tiempo se desarrollan puertos fortificados, arsenales, graneros, guarniciones costeras, fortalezas de altura, centros de mando y rutas interiores protegidas.

##### Bases mediterráneas

La presencia mediterránea es selectiva y combina comercio, diplomacia y defensa. Malta funciona como estación de escala y observación; Chipre protege las rutas entre Mediterráneo oriental, Egipto y Levante; Sicilia mantiene apoyo portuario mediante acuerdos locales; y Alejandría alberga delegaciones, guardias portuarias, ingenieros y especialistas navales.

Estas bases no constituyen una ocupación continua del Mediterráneo. Son puntos de reparación, protección de comerciantes, almacenamiento, observación y apoyo a convoyes.

##### Mar Rojo, Adén y Socotra

Desde el siglo I a. C. y durante los primeros siglos d. C., las rutas hacia el mar Rojo adquieren importancia. Las estaciones se sitúan en entradas del mar Rojo, puertos de reabastecimiento, Adén, Socotra y rutas hacia el golfo de Omán.

Algunas son estaciones diplomáticas con guardia; otras poseen almacenes, muelles y guarniciones mayores. Su misión es proteger convoyes, vigilar estrechos y asegurar agua y reparaciones.

##### Estructura de una base media

Una base de importancia media puede incluir comandante, guarnición de 100–400 soldados, destacamento naval, almacén de grano, cisterna, herrería, depósito de madera, enfermería, torre de señales, archivo de movimientos y zona de reparación. Las bases mayores pueden superar los mil efectivos durante una crisis, pero no mantienen ese tamaño de forma permanente.

##### Comunicaciones y mando

Las bases se conectan mediante señales de fuego, banderas, mensajeros, embarcaciones rápidas, campanas, tablillas y convoyes. La cadena de mando pasa del comandante local a la autoridad portuaria o provincial, la Casa responsable, el mando regional, la Corona y, en movilizaciones generales, el Consejo de las Casas.

##### Cinco cinturones estratégicos

1. Cinturón ancestral: Escania, Noruega, Dinamarca de tránsito, Báltico y mar del Norte.

2. Cinturón atlántico oriental: islas, escalas y Nosselië Toliva.

3. Cinturón oceánico: Tol Eressëa, Groenlandia, Númenor y Valinor.

4. Cinturón mediterráneo: Malta, Chipre, Sicilia, Egipto y el Levante.

5. Cinturón meridional: mar Rojo, Adén, Socotra y rutas hacia Omán.

La red no forma una frontera continua. Es una cadena de estaciones conectadas por rutas marítimas, tratados, depósitos y señales. Sus principales limitaciones son el clima, las distancias, la falta de agua, el aislamiento insular, las enfermedades, la dependencia de convoyes y la autonomía de las Casas regionales.

#### Capital y centros defensivos, 500 a. C.–500 d. C.

##### Forostar (Helsingborg) como capital inicial

Durante el periodo 500–300 a. C., la capital política, jurídica y militar es Forostar (Helsingborg), situada en el núcleo escaniano. Su ubicación permite controlar los accesos entre Escania, Dinamarca, Noruega, el Kattegat, el mar del Norte y el Báltico.

Forostar concentra:

- la residencia de la Corona;

- el Consejo de las Casas;

- el archivo de pactos y genealogías;

- el arsenal principal;

- el puerto militar;

- los graneros estratégicos;

- la guardia real;

- el santuario de los juramentos;

- los astilleros;

- la movilización de las milicias.

La capital no es únicamente un centro administrativo: es el núcleo del sistema defensivo escaniano. Noruega funciona como segundo núcleo naval y de recursos, mientras Dinamarca actúa como corredor de tránsito, migración y comercio.

##### Expansión regional, 300–50 a. C.

Durante la expansión hacia el Báltico, el mar del Norte y el Mediterráneo, Forostar continúa siendo la capital política y militar. La Corona no se traslada porque las nuevas bases todavía son estaciones subordinadas y no centros de gobierno.

La administración se organiza mediante mandos regionales dependientes de Forostar. Los puertos mediterráneos, las bases del Báltico y las estaciones del mar del Norte reciben instrucciones, recursos y oficiales desde la capital escaniana.

##### Antecedente sustituido de consolidación atlántica

ANTECEDENTE A092-R01 y R01. La enumeración siguiente conserva el antiguo reparto funcional, que no es vigente para 50 a. C.–200 d. C. Las funciones insulares solo pueden desarrollarse después de los descubrimientos y asentamientos fijados por la cronología principal:

- Forostar (Helsingborg): capital política, sede de la Corona y del Consejo de las Casas.

- Númenor: capital oceánica y principal base naval occidental.

- Systreyjar: estación de enlace septentrional.

- Nosselië Toliva: escala atlántica oriental.

- Tol Eressëa: estación avanzada de exploración y comunicación.

- Valinor: territorio en proceso de incorporación, todavía sin ser la capital.

Númenor no sustituye jurídicamente a Forostar, pero concentra astilleros, escuelas navales, depósitos, cartografía y mando de las rutas oceánicas.

##### Transición posterior

V16.3-R01. Forostar conserva la capitalidad formal. Las funciones oceánicas de Númenor y el desarrollo político de Nueva Tirion se sitúan después de sus respectivos asentamientos permanentes, en 920–980 y 750–850 d. C. La proyección de esas funciones sobre 200–500 queda sustituida.

La evolución posterior puede distinguir entre capital histórica, capital real, capital naval y capital federal. No se establece un traslado automático de la Corona hasta que Valinor posea población, instituciones, archivos, graneros y defensas suficientes para sostener un gobierno central.

La secuencia canónica queda fijada así:

- 500–50 a. C.: Forostar es capital política y principal centro defensivo.

- 50 a. C.–200 d. C.: Forostar conserva la capitalidad; no se atribuye a Númenor una capital naval permanente anterior a su asentamiento de 920–980. V16.3-R01.

- 200–350 d. C.: Forostar conserva la capitalidad formal; la dirección atlántica desde un Númenor permanentemente asentado no corresponde a esta etapa. V16.3-R01.

- 750–850 d. C.: primeros asentamientos permanentes de Valinor y desarrollo inicial de Nueva Tirion; sustituye su consolidación política en 350–500. V16.3-R01.

### Defensa territorial antigua

#### Defensa territorial en profundidad, 500 a. C.–500 d. C.

La defensa valinari se organiza en capas sucesivas. El objetivo no es hacer inexpugnable cada costa, sino impedir que una incursión naval se transforme en una conquista duradera. Cada capa combina vigilancia, fortificación, movilidad, reservas y coordinación entre la Corona, las Casas y las ciudades.

##### Primera línea: vigilancia y alerta

La primera línea está formada por torres de vigía, patrullas costeras, estaciones de señales y pequeñas estaciones navales. Sus funciones son detectar velas, incendios, movimientos de tropas y cambios meteorológicos, y transmitir la alerta hacia los puertos y fortalezas.

Los principales puntos de observación son:

- Amon Sûl del Estrecho (Helsingborg): control de los accesos entre Escania y el Kattegat.

- Calenhad del Norte (Malmö): vigilancia del litoral de Escania oriental.

- Forostar de los Vientos (Halmstad): enlace entre las rutas del Kattegat y el mar del Norte.

- Ras Morthal (Bergen): vigilancia de las entradas a los fiordos occidentales.

- Eithel Norðr (Trondheim): control de las rutas septentrionales.

- Círdanost Systreyjar (Shetland): estación de señales entre Noruega, las islas y el Atlántico.

Las señales combinan fuego, humo, banderas, cuernos, tambores, corredores y embarcaciones de enlace. Una señal de amenaza no ordena automáticamente una movilización general: activa una cadena graduada de reconocimiento, aviso portuario y convocatoria de reservas.

##### Segunda línea: puertos fortificados

Los puertos fortificados son centros navales, comerciales y militares. No son únicamente murallas junto al agua: incluyen arsenales, depósitos, muelles protegidos, talleres, guarniciones, tribunales portuarios y graneros.

Los principales son:

- Forostar (Helsingborg): capital constitucional, arsenal del estrecho y centro de coordinación de la defensa de Escania.

- Pelargir del Norte (Oslo): principal puerto militar del litoral noruego meridional.

- Rómenna Norðr (Bergen): base de navegación oceánica y refugio de convoyes.

- Alcarinor (Trondheim): puerto de reserva y punto de concentración septentrional.

- Círdanost Systreyjar (Lerwick): control de pasos hacia el Atlántico norte.

- Lond Calad (Las Palmas de Gran Canaria): puerto fortificado y centro de abastecimiento de Nosselië Toliva.

- Rómenlond (Santa Cruz de Tenerife): base militar oriental del archipiélago.

- Avallónë (isla de Tol Eressëa): estación oceánica, arsenal insular y punto de reunión de convoyes.

La defensa portuaria incluye cadenas y barreras de entrada, torres de tiro, rampas para varar embarcaciones, almacenes separados por sectores, pozos de agua, talleres de reparación y rutas terrestres hacia el interior. Las máquinas de proyectiles son de torsión y contrapeso; la terminología de artillería posterior no se proyecta sobre este periodo.

##### Tercera línea: fortalezas interiores

Las fortalezas interiores protegen los accesos a las capitales, los graneros, los pasos y los talleres. También sirven como depósitos de reserva y puntos de reunión cuando un puerto queda bloqueado.

Las principales son:

- Amon Sûl (Ottawa): fortaleza de paso y depósito interior de Arnor en la etapa posterior de expansión; no pertenece al sistema de 500 a. C.–500 d. C.

- Tirith Calen (Uppsala): defensa interior de las rutas de Escania y enlace con los núcleos del Báltico.

- Barad Norðr (Lillehammer): control de los corredores interiores noruegos.

- Emyn Forostar (Örebro): protección de caminos, talleres y depósitos entre el litoral y el interior escandinavo.

- Tyrn Gorthad del Norte (Jönköping): defensa de los corredores lacustres y terrestres del sur de Suecia.

- Calenost Toliva (La Laguna): reserva interior de Nosselië Toliva y protección de sus depósitos agrícolas.

La mención de Amon Sûl (Ottawa) queda clasificada como desarrollo territorial posterior y no como una fortaleza existente durante la primera fase de este periodo. Su inclusión en el inventario evita confundir el sistema defensivo antiguo con la red provincial de Arnor desarrollada muchos siglos después.

##### Cuarta línea: milicias, reservas y defensa urbana

La cuarta línea se activa cuando el enemigo supera la costa o amenaza una ciudad. Incluye milicias de Casa, reservas urbanas, evacuación organizada, defensa de puentes y caminos, protección de graneros y guerra de desgaste.

Para el periodo 500 a. C.–500 d. C., la capacidad movilizable se estima así:

- Guarnición permanente de la Corona: 4.000–6.000 efectivos, repartidos entre capital, arsenales, puertos y fortalezas.

- Guarniciones de las Casas Mayores: 8.000–12.000 efectivos, con funciones de defensa territorial y custodia de rutas.

- Milicias locales de ciudades y distritos: 20.000–30.000 efectivos convocables en una crisis regional.

- Reservas de las Casas Menores y Vasallas: 8.000–14.000 efectivos, principalmente infantería ligera, exploradores, marineros y zapadores.

- Levas extraordinarias: hasta 35.000–50.000 personas en una movilización general prolongada, sin considerar esta cifra como ejército permanente.

La cifra operativa habitual para una guerra regional es, por tanto, de 40.000–60.000 efectivos movilizados, mientras que una amenaza excepcional puede elevar la movilización a 70.000–90.000 con costes severos para la agricultura, el transporte y la navegación. Las cifras son agregadas para el conjunto del sistema valinari conocido y no implican que todas las unidades se concentren en un solo frente.

Las reservas materiales incluyen grano, legumbres, sal, agua, madera naval, hierro, bronce, cuero, cuerda, brea, velas, animales de tiro y herramientas. Cada puerto principal mantiene depósitos para varios meses, y las fortalezas interiores conservan reservas suficientes para sostener una guarnición y recibir población evacuada durante una crisis limitada.

##### Coordinación entre las líneas

La Corona establece la prioridad estratégica y coordina la armada. Las Casas mantienen las guarniciones y milicias asignadas. Las ciudades administran murallas, almacenes, pozos y refugios. Los santuarios conservan registros de población, reservas y obligaciones de servicio.

La secuencia defensiva normal es:

1. detección en la primera línea;

2. clasificación de la amenaza;

3. salida de patrullas y concentración de naves;

4. cierre o control del puerto amenazado;

5. convocatoria de guarniciones y milicias;

6. protección de graneros, talleres, puentes y archivos;

7. contraataque naval o terrestre cuando existan condiciones favorables;

8. recuperación del litoral y restitución de las rutas.

La pérdida de una playa, una estación o un muelle no equivale a la pérdida del territorio. La defensa en profundidad permite replegar población y suministros, negar recursos al invasor y conservar la capacidad de contraatacar.

##### Límites y coherencia histórica

Este sistema no supone una red moderna de fortificaciones continuas ni un ejército profesional permanente comparable al de los grandes imperios posteriores. Se trata de una defensa regional, escalonada y marítima, adecuada para una monarquía compuesta que controla estrechos, puertos, islas y corredores comerciales.

La doctrina queda resumida así: el enemigo puede alcanzar una costa, pero no debe poder convertir el desembarco en una conquista estable.

### Equilibrio militar y naval hacia 1410

Hacia 1410, la ventaja valinari se concentra en navegación oceánica, administración marítima, financiación, arsenales y logística sostenida en las rutas que abastece. La Corona mantiene un núcleo profesional de marineros, artilleros, ingenieros, guardias y personal de arsenal; las Casas aportan contingentes y milicias. Las armas de fuego y la artillería se normalizan en unidades, buques y servicios seleccionados, sin generalizarse a toda la población ni a todos los ejércitos. La movilización puede ser más rápida en corredores con depósitos y comunicaciones, pero sigue limitada por clima, distancia, transporte, capacidad de casco y disponibilidad de tripulaciones.

La comparación es regional y funcional: «Europa» no constituye un solo sistema militar, y la China Ming ya cuenta con fuerzas especializadas y armas de pólvora. Valinor no posee superioridad universal en cada tecnología; su ventaja procede de conectar navegación, financiación, arsenales, formación, reparación y abastecimiento. No se proyectan radar, sonar, electricidad, motores ni armamento industrial sobre el siglo XV.

### Armada Real de 1875

La Armada Real mantiene 332 unidades: 178 de combate y apoyo armado y 154 auxiliares. Dentro del grupo de 178, unas 105 están activas, 35 en mantenimiento o reserva y 38 en instrucción, patrulla local o transporte armado. Esa partición no clasifica la disponibilidad de los 154 auxiliares. La asignación territorial expresa adscripción administrativa, no concentración simultánea en el mar.

Los rangos aprobados describen series, variantes y modernizaciones. La velocidad máxima de pruebas difiere de la velocidad sostenida con carga; los espesores son máximos locales, sin cubrir todo el casco. Las mejoras compound, el blindaje compuesto y el rendimiento de los torpederos representan la divergencia tecnológica valinari adoptada. El arqueo comercial no sustituye al desplazamiento naval en toneladas métricas. Las bandas de calado, potencia indicada, ejes y autonomía adoptadas en 111v completan esos campos como parámetros de diseño; se leen por clase y lote, no como una prueba de prestaciones idénticas en todas las unidades.

La máquina de triple expansión entra en servicio naval valinari en 1873 para nuevas construcciones seleccionadas, sin conversión automática de cascos existentes. El acorazado Círdan I de 1875 y la serie Círdan de fragatas iniciada en 1955 son programas distintos que reutilizan un nombre histórico.

#### Bandas técnicas complementarias adoptadas para la flota de 1875

Los intervalos siguientes completan las fichas de clase. La potencia es indicada (ihp); la autonomía se estima a velocidad económica. El tonelaje y las características originales permanecen vigentes.

| Clase | Calado | Ejes | Potencia | Autonomía de referencia |
| --- | --- | --- | --- | --- |
| Círdan I | 6,8–8,0 m | 2 | 6.000–9.000 ihp | 2.500–3.800 mn a 10 nudos |
| Eärendil pesado | 6,5–7,6 m | 2 | 5.000–8.000 ihp | 2.400–3.600 mn a 10 nudos |
| Gil-galad inicial | 6,0–7,2 m | 2 | 4.500–7.000 ihp | 2.200–3.300 mn a 10 nudos |
| Aulë | 5,8–7,2 m | 2 | 2.500–4.500 ihp | 1.600–2.700 mn a 8 nudos |
| Minas Tirith | 4,5–5,8 m | 1–2 | 1.800–3.500 ihp | 1.500–2.500 mn a 8 nudos |
| Eärendil crucero | 5,5–6,8 m | 2 | 8.000–12.000 ihp | 4.000–5.800 mn a 10 nudos |
| Rómenna crucero | 4,5–5,8 m | 2 | 5.000–9.000 ihp | 3.500–5.000 mn a 10 nudos |
| Pelargir | 4,0–5,2 m | 2 | 3.000–5.500 ihp | 3.200–4.800 mn a 9–10 nudos |
| Alqualondë | 3,5–4,8 m | 2 | 2.500–4.500 ihp | 2.800–4.200 mn a 9–10 nudos |
| Systreyjar | 3,0–4,2 m | 2 | 2.000–3.800 ihp | 2.300–3.600 mn a 9 nudos |
| Harlond oceánica | 3,5–4,5 m | 2 | 1.800–3.200 ihp | 1.800–3.000 mn a 10 nudos |
| Harlond fluvial | 1,6–2,5 m | 1–2 | 700–1.400 ihp | 500–1.200 mn a 8 nudos |
| Calasir | 2,0–3,2 m | 1–2 | 1.200–2.500 ihp | 800–1.800 mn a 8 nudos |
| Calenhad | 1,3–2,0 m | 2 | 1.200–2.500 ihp | 300–700 mn a 10 nudos |
| Forlond torpedero | 1,5–2,3 m | 2 | 2.000–4.000 ihp | 400–900 mn a 10 nudos |
| Avisos y transportes armados | 3,0–7,5 m | 1–2 | 2.000–12.000 ihp | 1.500–4.500 mn a 10 nudos |

#### Clases principales

##### Círdan I

- Tipo: acorazado oceánico.

- Unidades: 6.

- Desplazamiento: 7.000–8.500 t.

- Eslora: 105–120 m.

- Manga: 17–19 m.

- Velocidad máxima: 14–16 nudos.

- Dotación: 480–620 personas.

- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.

- Armamento: 4 × 254–305 mm; 6–10 × 120–152 mm; piezas de 37–76 mm.

- Protección: cinturón 250–350 mm; torres/barbetas 200–300 mm; cubierta 50–75 mm.

##### Eärendil pesado

- Tipo: acorazado de escuadra.

- Unidades: 4.

- Desplazamiento: 6.500–7.500 t.

- Eslora: 100–112 m.

- Manga: 16–18 m.

- Velocidad máxima: 13–15 nudos.

- Dotación: 420–550 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 4 × 229–254 mm; 6–8 × 120–140 mm; piezas de 37–76 mm.

- Protección: cinturón 220–300 mm; torres 180–250 mm; cubierta 45–70 mm.

##### Gil-galad inicial

- Tipo: acorazado de defensa oceánica.

- Unidades: 6.

- Desplazamiento: 5.500–6.800 t.

- Eslora: 92–105 m.

- Manga: 15–17 m.

- Velocidad máxima: 12–15 nudos.

- Dotación: 360–480 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 2–4 × 203–254 mm; 6 × 100–127 mm; piezas de 37–57 mm.

- Protección: cinturón 180–250 mm; torres 160–220 mm; cubierta 40–60 mm.

##### Aulë

- Tipo: monitor pesado.

- Unidades: 8.

- Desplazamiento: 3.500–4.500 t.

- Eslora: 75–90 m.

- Manga: 14–17 m.

- Velocidad máxima: 9–12 nudos.

- Dotación: 180–280 personas.

- Propulsión: vapor de carbón; máquinas alternativas.

- Armamento: 2 × 254–305 mm; 4–6 × 76–120 mm.

- Protección: torres 200–300 mm; cubierta 40–60 mm; protección lateral localizada.

##### Minas Tirith

- Tipo: monitor litoral.

- Unidades: 4.

- Desplazamiento: 2.500–3.500 t.

- Eslora: 65–80 m.

- Manga: 13–15 m.

- Velocidad máxima: 9–11 nudos.

- Dotación: 150–220 personas.

- Propulsión: vapor de carbón; máquinas alternativas.

- Armamento: 2 × 203–254 mm; 4–6 × 76–100 mm.

- Protección: torres 160–250 mm; cubierta 35–50 mm.

##### Eärendil

- Tipo: crucero protegido.

- Unidades: 8.

- Desplazamiento: 4.500–6.000 t.

- Eslora: 95–115 m.

- Manga: 13–16 m.

- Velocidad máxima: 17–19 nudos.

- Dotación: 300–420 personas.

- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.

- Armamento: 8–12 × 120–152 mm; piezas de 37–76 mm; 2–4 tubos de 356–381 mm.

- Protección: cubierta y escudos 40–60 mm.

##### Rómenna crucero

- Tipo: crucero de estación.

- Unidades: 10.

- Desplazamiento: 2.500–4.000 t.

- Eslora: 80–100 m.

- Manga: 11–14 m.

- Velocidad máxima: 15–18 nudos.

- Dotación: 180–300 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 6–10 × 120–140 mm; piezas de 37–57 mm.

- Protección: cubierta 25–45 mm; escudos 30–50 mm.

##### Pelargir

- Tipo: corbeta oceánica.

- Unidades: 12.

- Desplazamiento: 1.800–2.500 t.

- Eslora: 70–85 m.

- Manga: 10–12 m.

- Velocidad máxima: 13–16 nudos.

- Dotación: 160–240 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 8–12 × 100–152 mm.

- Protección: cubierta reforzada; escudos 20–40 mm.

##### Alqualondë

- Tipo: corbeta de enlace.

- Unidades: 8.

- Desplazamiento: 1.200–1.800 t.

- Eslora: 60–75 m.

- Manga: 9–11 m.

- Velocidad máxima: 13–16 nudos.

- Dotación: 120–190 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 6–10 × 100–127 mm.

- Protección: escudos 20–35 mm; protección localizada de máquinas.

##### Systreyjar

- Tipo: corbeta ligera.

- Unidades: 8.

- Desplazamiento: 900–1.400 t.

- Eslora: 50–65 m.

- Manga: 8–10 m.

- Velocidad máxima: 14–17 nudos.

- Dotación: 90–150 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 4–8 × 76–120 mm.

- Protección: escudos 15–30 mm; cubierta reforzada.

##### Rómenna aviso

- Tipo: aviso oceánico.

- Unidades: 12.

- Desplazamiento: 700–1.200 t.

- Eslora: 45–60 m.

- Manga: 7–9 m.

- Velocidad máxima: 16–20 nudos.

- Dotación: 60–110 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 2–6 × 76–120 mm.

- Protección: escudos 10–20 mm.

##### Forlond aviso

- Tipo: aviso costero.

- Unidades: 12.

- Desplazamiento: 400–800 t.

- Eslora: 35–50 m.

- Manga: 6–8 m.

- Velocidad máxima: 15–19 nudos.

- Dotación: 40–80 personas.

- Propulsión: vapor de carbón; máquinas alternativas.

- Armamento: 2–4 × 57–100 mm.

- Protección: protección ligera localizada.

##### Harlond oceánica

- Tipo: cañonera oceánica.

- Unidades: 14.

- Desplazamiento: 700–1.000 t.

- Eslora: 45–60 m.

- Manga: 8–10 m.

- Velocidad máxima: 13–16 nudos.

- Dotación: 70–120 personas.

- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.

- Armamento: 2–4 × 120–152 mm; secundarias de 37–57 mm.

- Protección: cubierta 25–40 mm; escudos 40–60 mm.

##### Harlond fluvial

- Tipo: cañonera fluvial.

- Unidades: 16.

- Desplazamiento: 300–600 t.

- Eslora: 30–45 m.

- Manga: 6–8 m.

- Velocidad máxima: 9–13 nudos.

- Dotación: 40–80 personas.

- Propulsión: vapor de carbón; máquinas alternativas; hélices protegidas o rueda según variante.

- Armamento: 1–2 × 76–120 mm; secundarias de 37–57 mm.

- Protección: escudos 20–40 mm; protección localizada de calderas.

##### Calasir

- Tipo: cañonera litoral.

- Unidades: 12.

- Desplazamiento: 250–450 t.

- Eslora: 28–40 m.

- Manga: 5–7 m.

- Velocidad máxima: 14–18 nudos.

- Dotación: 30–65 personas.

- Propulsión: vapor de carbón; máquinas alternativas.

- Armamento: 2–4 × 57–100 mm; piezas ligeras de 37–47 mm.

- Protección: cubierta 15–25 mm; escudos ligeros.

##### Forlond torpedero

- Tipo: torpedero rápido.

- Unidades: 12.

- Desplazamiento: 120–250 t.

- Eslora: 30–40 m.

- Manga: 4–6 m.

- Velocidad máxima: 20–24 nudos.

- Dotación: 25–45 personas.

- Propulsión: vapor de carbón; máquinas alternativas de alta presión; prioridad de potencia y bajo peso.

- Armamento: 2 tubos de 356–381 mm; 1–2 × 37–57 mm.

- Protección: sin blindaje significativo.

##### Calenhad

- Tipo: torpedero ligero.

- Unidades: 12.

- Desplazamiento: 80–150 t.

- Eslora: 24–32 m.

- Manga: 3–5 m.

- Velocidad máxima: 18–22 nudos.

- Dotación: 15–30 personas.

- Propulsión: vapor de carbón; máquinas alternativas de alta presión; prioridad de potencia y bajo peso.

- Armamento: 1–2 tubos de 356 mm; 1 × 37–47 mm.

- Protección: sin blindaje significativo.

##### Transportes armados

- Tipo: transporte y desembarco.

- Unidades: 14.

- Desplazamiento: 1.000–3.500 t.

- Eslora: 55–100 m.

- Manga: 9–14 m.

- Velocidad máxima: 10–14 nudos.

- Dotación: 70–180 personas.

- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.

- Armamento: 2–8 × 76–120 mm.

- Protección: protección estructural.

#### Auxiliares

- Carboneros y combustible: 32.

- Transportes militares auxiliares: 18.

- Munición y almacén: 12.

- Remolcadores y reparación: 20.

- Hospitales: 8.

- Hidrográficos y oceanográficos: 16.

- Escuela e instrucción: 12.

- Patrulleros y guardacostas: 36.

Los auxiliares desplazan aproximadamente 150–8.000 t, con 25–220 tripulantes y velocidades de 8–15 nudos según función. La reserva hospitalaria puede comprender unidades adaptadas; no se presume que las ocho sean hospitales especializados de construcción reciente.

### Distribución territorial de la Armada en 1875

La matriz siguiente sustituye el reparto preliminar del acumulativo, cuyos teatros sumaban 332 pero no conciliaban el número de cañoneras, avisos y torpederos. Las categorías se asignan una sola vez.

| Mando | Blindados | Cruceros | Corbetas | Avisos | Cañoneras | Torpederos | Transportes armados | Auxiliares | Total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Atlántico central y núcleo del Reino | 12 | 5 | 6 | 4 | 2 | 4 | 2 | 35 | 70 |
| Atlántico occidental y norteamericano | 2 | 3 | 4 | 3 | 3 | 2 | 1 | 17 | 35 |
| América meridional, Caribe y Panamá | 4 | 2 | 4 | 3 | 10 | 3 | 4 | 15 | 45 |
| Mediterráneo | 3 | 3 | 3 | 3 | 4 | 4 | 1 | 14 | 35 |
| África occidental | 1 | 1 | 2 | 2 | 6 | 1 | 2 | 10 | 25 |
| Índico y Malaca | 1 | 2 | 3 | 2 | 4 | 2 | 1 | 15 | 30 |
| Pacífico | 0 | 1 | 3 | 2 | 3 | 1 | 1 | 14 | 25 |
| Defensa fluvial y portuaria | 3 | 0 | 1 | 3 | 8 | 5 | 1 | 14 | 35 |
| Reserva y formación central | 2 | 1 | 2 | 2 | 2 | 2 | 1 | 20 | 32 |

El núcleo del Reino se apoya en Nueva Tirion, Avallónë, los puertos de Systreyjar y Lond Calad. Armenelos (Númenor, Terranova) y Arnor pertenecen al Atlántico occidental. Islandia y las estaciones groenlandesas se atienden desde mandos septentrionales según el régimen del siglo XIX; su integración federal contemporánea no se anticipa. Forostar (Helsingborg) conserva sus funciones históricas y vínculos, sin convertirse automáticamente en territorio metropolitano soberano de 1875.

El Mediterráneo se apoya en Barad Nimras (Gibraltar), arrendado desde 1815, y facilidades pactadas en Malta, Chipre y Alejandría. África occidental utiliza Cabo Verde y Esgal Nénar. El Índico enlaza Adén, Socotra, Harnen y Malaca según tratados; Rhunost es interno de Harnen. El Pacífico se sostiene desde Hawái, Fiyi y estaciones insulares, sin trasladar Númenor ni Systreyjar a ese océano. Cada mando separa despliegue, reparación y disponibilidad.

### Cañoneras valinari de 1875

Las cañoneras valinari se especializan en defensa litoral, vigilancia de ríos, protección de puertos, apoyo a estaciones y presencia armada en territorios asociados. No sustituyen a los acorazados ni a los cruceros: su valor reside en operar donde los buques mayores no pueden maniobrar, mantener una presencia permanente y coordinarse con baterías terrestres, torpederos, avisos y depósitos de carbón.

##### Cañoneras oceánicas Harlond

- Unidades: 14.

- Desplazamiento: 700–1.000 toneladas.

- Dimensiones: 45–60 m de eslora; 8–10 m de manga.

- Propulsión: máquinas compound de vapor alimentadas por carbón, dos ejes y aparejo auxiliar reducido.

- Velocidad: 13–16 nudos.

- Autonomía: 3.500–5.000 millas náuticas a velocidad económica.

- Armamento principal: dos a cuatro piezas de 120–152 mm de retrocarga.

- Armamento secundario: dos a cuatro piezas de 37–57 mm contra torpederos y embarcaciones ligeras.

- Protección: cubierta blindada de 25–40 mm, escudos de artillería de 40–60 mm y compartimentación estanca básica.

- Dotación: 70–120 tripulantes.

Su mejora principal consiste en transformarlas en pequeñas unidades de estación capaces de cruzar océanos, no solo en cañoneras coloniales de corto alcance. Pueden escoltar convoyes menores, proteger cables y depósitos, perseguir piratas y apoyar desembarcos limitados.

##### Cañoneras fluviales Harlond

- Unidades: 16.

- Desplazamiento: 300–600 toneladas.

- Dimensiones: 30–45 m de eslora; 6–8 m de manga.

- Propulsión: vapor de carbón, dos hélices protegidas o rueda parcialmente protegida según el río.

- Velocidad: 9–13 nudos en aguas tranquilas.

- Calado: reducido, aproximadamente 1,5–2,5 m.

- Armamento principal: una o dos piezas de 76–120 mm.

- Armamento secundario: dos a cuatro piezas de 37–57 mm.

- Protección: escudos blindados y cubierta reforzada; blindaje limitado para no perder calado.

- Dotación: 40–80 tripulantes.

Las mejoras se concentran en calado, fiabilidad de las máquinas, protección de hélices, depósitos intercambiables de carbón y capacidad para transportar ingenieros, marines, médicos y equipos de señalización. No se convierten en pequeños acorazados: su función es controlar pasos, apoyar puestos fluviales y mantener comunicaciones.

##### Cañoneras litorales Calasir

- Unidades: 12.

- Desplazamiento: 250–450 toneladas.

- Dimensiones: 28–40 m de eslora; 5–7 m de manga.

- Propulsión: vapor de carbón, una o dos hélices, con maniobra reforzada.

- Velocidad: 14–18 nudos.

- Autonomía: 1.500–2.500 millas náuticas.

- Armamento principal: dos a cuatro piezas de 57–100 mm.

- Armamento adicional: ametralladoras navales tempranas o piezas de 37–47 mm, cuando estén disponibles.

- Protección: escudos de artillería, cubierta de 15–25 mm y compartimentación básica.

- Dotación: 30–65 tripulantes.

Son unidades de reacción rápida. Operan junto a torpederos y baterías costeras, protegen entradas de puertos, inspeccionan tráfico, colocan o vigilan campos de minas y responden a incursiones. Su prioridad es velocidad y maniobrabilidad, no resistencia a artillería pesada.

##### Mejoras tecnológicas comunes

Las cañoneras valinari incorporan de forma progresiva:

- máquinas compound de mayor presión;

- calderas más eficientes y compartimentadas;

- hélices optimizadas para cada calado;

- cascos de acero temprano en las unidades nuevas;

- blindaje compuesto de hierro y acero en las zonas críticas;

- depósitos de carbón protegidos y modulares;

- piezas de retrocarga de 57–152 mm;

- munición explosiva y perforante diferenciada;

- telémetros ópticos sencillos;

- tablas balísticas comunes;

- telégrafo y señales ópticas codificadas;

- bombas de achique accionadas por vapor;

- talleres portátiles y repuestos normalizados;

- botes auxiliares para desembarco y rescate.

##### Organización operativa

Las cañoneras no operan aisladas. Su sistema de empleo se divide en cuatro capas:

1. Observación: estaciones, vigías, avisos y señales costeras detectan movimientos.

2. Interdicción: cañoneras litorales y torpederos bloquean canales, radas y entradas.

3. Apoyo: cañoneras oceánicas y cruceros protegen convoyes, depósitos y desembarcos.

4. Sostenimiento: carboneros, talleres, hospitales y arsenales mantienen la presencia.

Esta doctrina permite que una cañonera de menor tonelaje combata dentro de una red defensiva. Su eficacia no procede de superar a un crucero británico en combate abierto, sino de obligarlo a operar lentamente, bajo observación y dentro del alcance combinado de baterías, torpederos, minas y refuerzos.

##### Límites canónicos

Las cañoneras valinari no poseen radar, sonar, misiles, aviación embarcada ni sistemas electrónicos de control de tiro. La mejora de 1875 debe entenderse como una ventaja de ingeniería, estandarización, entrenamiento y logística. Frente a una cañonera británica individual, las unidades valinari pueden ser más rápidas, autónomas y mejor integradas; frente a la Royal Navy completa, el Reino Unido conserva superioridad en cantidad, reservas, bases y reemplazo industrial.

### Comparación naval de 1875

Comparación cualitativa del escenario. Los inventarios británicos anteriormente citados no constituyen un censo homogéneo por fecha y estado operativo. Las ventajas se presentan como hipótesis estratégicas valinari; cifras históricas o nombres de buques requieren contraste independiente.

La comparación naval de 1875 queda fijada por categorías equivalentes, no por una correspondencia exacta de nombres. La Royal Navy dispone de más unidades, tonelaje, bases, reservas y capacidad de reemplazo; la Armada Valinari obtiene sus mejores resultados mediante integración tecnológica, navegación oceánica, defensa territorial y logística policéntrica.

##### Buques pesados

- Círdan I frente a acorazados británicos de primera línea: los Círdan desplazan 7.000–8.500 toneladas, montan cuatro piezas de 254–305 mm y alcanzan 14–16 nudos. Son comparables individualmente a acorazados británicos contemporáneos, pero Gran Bretaña posee más unidades y mayor capacidad de sustitución.

- Eärendil pesado frente a acorazados de escuadra británicos: sus 6.500–7.500 toneladas y cuatro piezas de 229–254 mm los sitúan en una categoría equivalente, con ventaja británica en número y experiencia de concentración de flota.

- Gil-galad inicial frente a buques británicos de segunda línea: cumple funciones de defensa oceánica y apoyo regional. Valinor obtiene ventaja cuando opera cerca de sus arsenales; el Reino Unido conserva mayor volumen.

- Aulë y Minas Tirith frente a monitores británicos: son equivalentes en defensa costera. Las unidades valinari se benefician de mejor integración con torpederos, baterías y redes de señales.

##### Cruceros, corbetas y avisos

- Eärendil crucero frente a cruceros protegidos británicos: los ocho buques valinari combinan 4.500–6.000 toneladas, piezas de 120–152 mm, velocidad de 17–19 nudos y tubos lanzatorpedos. Gran Bretaña tiene más cruceros y mayor autonomía imperial; Valinor conserva una ventaja relativa en coordinación y velocidad de sus mejores unidades.

- Rómenna frente a cruceros coloniales británicos: son comparables en misión, pero los británicos son más numerosos y disponen de una red de estaciones mayor.

- Pelargir, Alqualondë y Systreyjar frente a corbetas, balandras y cañoneras oceánicas británicas: las Pelargir son equivalentes a corbetas oceánicas grandes; Alqualondë y Systreyjar se aproximan a corbetas ligeras y cañoneras de estación. Valinor destaca en autonomía relativa; Gran Bretaña en cantidad.

- Avisos Rómenna y Forlond frente a dispatch vessels británicos: cumplen funciones equivalentes de mensajería, reconocimiento y enlace. La Royal Navy mantiene una red más amplia y profesionalizada.

##### Cañoneras y torpederos

- Harlond oceánica frente a cañoneras coloniales británicas: las unidades valinari son más aptas para cruzar entre estaciones y montar piezas de 120–152 mm. Las británicas son más numerosas y poseen mayor experiencia imperial.

- Harlond fluvial frente a cañoneras fluviales británicas: existe equivalencia técnica. Gran Bretaña tiene ventaja en experiencia de operaciones fluviales en Asia y África; Valinor compensa con mejor integración territorial y disponibilidad de talleres propios.

- Calasir frente a cañoneras litorales británicas: las Calasir priorizan velocidad, maniobra y respuesta rápida; el Reino Unido dispone de más unidades, pero Valinor puede emplearlas con baterías y torpederos dentro de una defensa de puerto.

- Forlond y Calenhad frente a torpederos británicos: los buques valinari incorporan tubos de 356–381 mm y alcanzan aproximadamente 18–24 nudos. Gran Bretaña posee mayor cantidad y experimentación, mientras Valinor adopta antes una doctrina coordinada de minas, torpederos y baterías.

##### Transportes y auxiliares

Los transportes, carboneros, talleres, hospitales, buques hidrográficos y escuelas británicos superan ampliamente a los valinari en tonelaje y número. La ventaja británica es decisiva en guerras prolongadas y operaciones simultáneas en varios continentes. Valinor compensa parcialmente mediante arsenales distribuidos, depósitos escalonados, talleres flotantes y mejor conocimiento de sus rutas.

##### Balance por función

- Acorazados: ventaja británica en cantidad; equivalencia aproximada en las mejores unidades.

- Cruceros: ventaja británica en número y autonomía; Valinor conserva una buena relación velocidad-armamento.

- Corbetas: equilibrio técnico general.

- Cañoneras: ventaja británica en volumen; ventaja valinari en integración con la defensa territorial.

- Torpederos: ventaja británica en cantidad; doctrina valinari más integrada en costas propias.

- Logística: superioridad clara británica.

- Defensa de puertos y estrechos valinari: ventaja local de Valinor.

- Guerra oceánica prolongada: superioridad británica.

El resultado canónico es que la Royal Navy sigue siendo la primera armada mundial en 1875. La Armada Valinari es una potencia oceánica de primer orden, capaz de disputar zonas concretas y encarecer seriamente una campaña británica, pero no de superar al conjunto del sistema naval imperial del Reino Unido.

### Desarrollo naval 1882–1945

La secuencia siguiente queda adoptada como referencia tecnológica y de diseño. Los intervalos describen clases o grupos plausibles; no determinan por sí solos número de cascos, unidades construidas, inventario anual ni disponibilidad. Los nombres y cantidades no fijados expresamente permanecen abiertos. La instalación de turbinas y sensores es gradual por casco y lote.

### Comparación naval Valinor–Royal Navy en 1907

En 1907, la Royal Navy conserva la superioridad global demostrada por su amplitud de flota, experiencia institucional, concentración de unidades listas y red mundial de bases. El debate parlamentario británico de mayo de ese año comparaba 51 acorazados, 28 cruceros acorazados, 76 cruceros no acorazados y 143 destructores; esas cifras agrupan generaciones y estados de disponibilidad distintos. El plan del Nore contemplaba una fuerza concentrada de seis acorazados, seis cruceros acorazados y 48 destructores con alta disponibilidad.

La ventaja tecnológica valinari es más concreta: turbina experimental en 1882, torpedero operativo en 1887 y primer buque capital de turbina en 1894. No supone que todos los buques de 1907 fueran de turbina ni que Valinor aventajara a Gran Bretaña en blindaje, dirección de tiro, tonelaje o disponibilidad. La aviación embarcada y el radar no se proyectan sobre esta fecha.

Como modelo canónico de planificación —no como inventario exacto casco por casco— se adopta para la Armada Valinari una banda de 18–24 acorazados modernos; 20–28 pre-dreadnoughts y acorazados de transición; 20–28 cruceros acorazados; 35–50 cruceros protegidos o ligeros; 70–100 destructores y torpederos oceánicos; 8–16 submarinos costeros; y 50–80 cañoneras, avisos y auxiliares. La suma de 221–326 cascos mezcla buques de combate y apoyo y no es directamente comparable con los agregados británicos. Una parte estaría en reserva, instrucción, mantenimiento o defensa regional.

Los perfiles de referencia valinari sitúan los acorazados modernos en 20–23 nudos y con batería inicial de 4 × 305–343 mm más 10–14 × 120–152 mm; los cruceros acorazados en 22–25 nudos con 4–6 × 203–254 mm y 8–12 × 120–152 mm; y los destructores nuevos en 27–33 nudos con 2–4 × 76–102 mm y 2–5 tubos lanzatorpedos. La variedad de generaciones impide atribuir una configuración única a todas las unidades.

El resultado comparativo es una potencia naval valinari de primer orden, con ventaja de propulsión en ciertas clases y capacidad de disputar teatros atlánticos. La Royal Navy mantiene la ventaja global por escala, despliegue, reservas y logística mundial. La disponibilidad exacta valinari queda pendiente de un inventario por casco, entrada en servicio, dotación, estado y estación.

Desarrollo técnico, cantidades por clase y fuentes: Comparación naval Valinor–Royal Navy en 1907.

### Norma de adelanto de doce años

La triple expansión no es una caldera. Es una máquina alternativa que aprovecha el vapor sucesivamente en cilindros de alta, media y baja presión. La caldera produce el vapor y puede alimentar tanto esta máquina como una turbina. La turbina de vapor convierte el flujo en rotación continua y constituye una tecnología distinta. La turbina de gas de los Círdan modernos pertenece a otra época y otro ciclo termodinámico.

- Triple expansión: primer uso naval operativo valinari adoptado para 1873, doce años antes de la adopción amplia en nuevos buques de la Royal Navy, situada hacia 1885. No se afirma que Valinor invente el principio ni que no existieran ensayos marítimos extranjeros anteriores; la ventaja consiste en investigación propia, adopción en unidades seleccionadas, producción y sostenimiento.

- Turbina de vapor: banco de pruebas y nave experimental valinari en 1882, doce años antes de la Turbinia británica de 1894; primer torpedero o aviso operativo valinari en 1887, antes de los ensayos británicos de destructores con turbina de 1899; primer buque capital valinari de turbina en 1894, doce años antes del HMS Dreadnought de 1906. Esta secuencia constituye una divergencia tecnológica fuerte y requiere un programa naval y metalúrgico sostenido.

- Límite: el adelanto no convierte todos los cascos de 1875 a turbina. La transición se hace por nuevas construcciones y lotes; los barcos antiguos conservan máquinas compound o de triple expansión hasta el retiro.

### Catálogo canónico de clases y grupos navales, 1882–1945

Las fichas de este catálogo son parámetros de diseño adoptados, no datos ya adoptados por el canon ni un inventario. Las cifras se expresan como rangos porque representan varias unidades y lotes. El desplazamiento es métrico; el armamento, en milímetros; la potencia de máquinas de vapor, en caballos al eje (shp). La velocidad es máxima de prueba. La autonomía indica millas náuticas (mn) a la velocidad económica especificada; no equivale al radio de combate. En submarinos se diferencia superficie y navegación sumergida. Los espesores de blindaje se especifican por zona, no como protección uniforme.

Los barcos canónicos de 1875 quedan en la sección precedente y conservan sus características vigentes. Las sucesiones 1882–1945 reutilizan líneas funcionales Calenhad/Forlond, Rómenna, Pelargir/Alqualondë y Harlond cuando corresponde. Los nombres de las nuevas clases aún no están fijados.

#### 1. Nave experimental de turbina de vapor (1882)

- Función: banco de pruebas marítimo para turbina, condensador, ejes y hélices; no es unidad de combate.

- Desplazamiento: 150–350 t. Dimensiones: eslora 35–55 m; manga 5–8 m. Calado: 1,5–2,5 m.

- Propulsión: turbina de vapor de carbón con condensador; transmisión experimental de alta velocidad. Potencia: 1.500–3.500 shp. Ejes: 2–3, con hélices múltiples si todavía no hay una reductora fiable.

- Velocidad: 24–30 nudos en pruebas cortas. Alcance: 300–800 mn a 10 nudos.

- Blindaje: ninguno; compartimentación de seguridad y protección ligera de maquinaria.

- Armamento: ninguno o 1–2 piezas de 37–47 mm para ensayos de estabilidad.

- Dotación: 20–45, incluidos ingenieros de pruebas.

- Criterio: no se cuenta como clase naval ni como prueba de que una turbina de 1882 sea ya fiable para flota oceánica.

#### 2. Torpedero de turbina, evolución Calenhad/Forlond (1887–1895)

- Función: ataque rápido desde puertos y estaciones protegidas; nueva construcción, sin reconvertir los torpederos de 1875.

- Desplazamiento: 250–600 t. Dimensiones: 45–65 m de eslora; manga 5–8 m. Calado: 1,8–3,0 m.

- Propulsión: turbina de vapor y calderas ligeras de carbón; primeras unidades con varias hélices/ejes y posteriores con reducción más compacta. Potencia: 4.000–8.000 shp. Ejes: 2–3 según lote.

- Velocidad: 25–30 nudos en prueba; velocidad sostenida menor para no agotar carbón ni maquinaria. Alcance: 700–1.500 mn a 10 nudos.

- Blindaje: sin cinturón; escudos locales y subdivisión estanca.

- Armamento: 2–4 tubos lanzatorpedos de 356–450 mm; 2–4 piezas de 47–76 mm.

- Dotación: 40–90.

- Límite: turbinas de alta potencia son apropiadas para una salida rápida, pero el alcance y la disponibilidad mecánica las hacen dependientes de una base cercana.

#### 3. Buque capital de turbina, primera generación (1894–1905)

- Función: combate de línea y demostración de que la turbina puede impulsar un buque capital. El nombre definitivo de clase y el número de unidades quedan sin asignar; este perfil fija el intervalo técnico de referencia, no el inventario.

- Desplazamiento: 14.000–18.000 t. Dimensiones: eslora 125–150 m; manga 22–26 m. Calado: 8–9,5 m.

- Propulsión: turbinas de vapor, calderas de carbón, condensadores y auxiliares; transmisión ajustada a cuatro hélices. Potencia: 22.000–35.000 shp. Ejes: 4.

- Velocidad: 20–23 nudos en prueba; 17–20 nudos sostenidos según estado de mar y calderas. Alcance: 4.000–6.000 mn a 10 nudos.

- Blindaje adoptado: cinturón 250–320 mm; torres/barbetas 250–305 mm; cubierta 50–90 mm; protección antitorpedo interna limitada.

- Armamento: 4 × 305–343 mm; 10–14 × 120–152 mm; 12–20 piezas de 47–76 mm; 2–4 tubos lanzatorpedos, si se conserva la doctrina de la época.

- Dotación: 750–1.050.

- Aplicación de los doce años: 1894 se compara con la entrada en servicio del Dreadnought en 1906 para la adopción de turbina en un gran acorazado. No significa que todas las armadas del mundo esperaran hasta 1906 para probar turbinas.

#### 4. Crucero de estación y exploración, nueva generación Rómenna (1895–1905)

- Función: reconocimiento oceánico, protección de comercio y mando de flotillas.

- Desplazamiento: 5.000–8.000 t. Dimensiones: eslora 115–140 m; manga 15–19 m. Calado: 5,5–7 m.

- Propulsión: turbinas de vapor en los lotes nuevos; carbón y calderas acuotubulares cuando el diseño y la experiencia del astillero lo permitan. Unidades anteriores mantienen máquinas alternativas. Potencia: 15.000–28.000 shp. Ejes: 2–4.

- Velocidad: 22–27 nudos de prueba; 18–22 sostenidos. Alcance: 4.000–6.000 mn a 10 nudos.

- Blindaje: cubierta 40–80 mm y/o cinturón localizado 50–120 mm, según variante.

- Armamento: 6–10 × 120–203 mm; 8–16 piezas ligeras de 37–76 mm; 2–4 tubos de torpedo; telémetros ópticos y radiotelegrafía.

- Dotación: 400–700.

#### 5. Acorazado de escuadra (1905–1918)

- Función: línea de batalla oceánica; sustituye gradualmente a los acorazados de transición, no de inmediato.

- Desplazamiento: 18.000–30.000 t. Dimensiones: eslora 160–195 m; manga 25–30 m. Calado: 8,5–10,5 m.

- Propulsión: turbinas de vapor; calderas de carbón en los primeros lotes y carbón/petróleo o petróleo en los posteriores. Reductoras si están maduras. Potencia: 30.000–70.000 shp. Ejes: 4.

- Velocidad: 20–25 nudos de prueba; 17–21 sostenidos. Alcance: 5.000–8.000 mn a 10 nudos.

- Blindaje: cinturón principal 250–350 mm; torres 250–330 mm; cubierta 50–100 mm; mamparos y protección submarina limitados según generación.

- Armamento: batería principal de 8–12 × 305–381 mm; batería secundaria de 10–20 × 100–152 mm; piezas antitorpederas de 37–76 mm; torpedos solo en algunos lotes.

- Sensores: telémetros, dirección óptica de tiro, reflectores y radiotelegrafía. No se instala radar antes de la época en que aparece en la cronología canónica.

- Dotación: 950–1.500.

#### 6. Crucero blindado y crucero ligero (1900–1918)

Crucero blindado de escuadra

- Desplazamiento: 8.000–15.000 t. Dimensiones: 140–180 m de eslora; 18–23 m de manga. Calado: 6,5–8,5 m.

- Propulsión: turbinas de vapor y calderas de carbón/petróleo por lote. Potencia: 25.000–55.000 shp. Ejes: 4.

- Velocidad: 22–28 nudos. Alcance: 5.000–8.000 mn a 12 nudos.

- Blindaje: cinturón 100–200 mm; cubierta 40–80 mm; torres 100–200 mm.

- Armamento: 4–8 × 203–254 mm; 8–14 × 120–152 mm; piezas ligeras; torpedos en algunos lotes.

- Dotación: 600–1.000.

Crucero ligero de exploración

- Desplazamiento: 4.000–8.000 t. Dimensiones: 120–155 m; manga 14–18 m. Calado: 5–7 m.

- Propulsión: turbinas de vapor; potencia 15.000–35.000 shp; ejes 2–4.

- Velocidad: 23–29 nudos. Alcance: 4.000–7.000 mn a 10–12 nudos.

- Blindaje: cubierta 25–60 mm; escudos y protección local 25–75 mm.

- Armamento: 8–12 × 102–152 mm; 4–8 tubos de torpedo; armas ligeras contra torpederos.

- Dotación: 350–650.

#### 7. Destructor de flota y torpedero oceánico (1900–1918)

- Función: escolta de escuadra, exploración cercana, torpedo y defensa contra torpederos enemigos.

- Desplazamiento: 700–1.800 t. Dimensiones: eslora 65–105 m; manga 6–10 m. Calado: 2,5–4 m.

- Propulsión: turbinas de vapor en destructores de alta velocidad; máquinas alternativas o diésel en unidades económicas y de patrulla. Potencia: 20.000–45.000 shp en unidades de turbina. Ejes: normalmente 2.

- Velocidad: 27–36 nudos en prueba; 20–28 sostenidos. Alcance: 1.500–3.500 mn a 12 nudos.

- Blindaje: ninguno como cinturón; protección contra fragmentos en puestos y pañoles seleccionados.

- Armamento: 2–5 × 76–102 mm; 2–6 tubos de torpedo de 450–533 mm; ametralladoras y, según fecha, cargas de profundidad.

- Dotación: 80–170.

#### 8. Submarino oceánico convencional (1900–1918)

- Desplazamiento: 500–1.500 t en superficie. Dimensiones: eslora 50–85 m; manga 5–8 m. Calado: 3,5–5,5 m.

- Propulsión: diésel en superficie y motor eléctrico/baterías sumergido. Potencia: diésel 1.500–5.000 shp; eléctrica 500–1.500 shp. Ejes: 2.

- Velocidad: 14–20 nudos en superficie; 7–10 sumergido. Alcance: 4.000–8.000 mn a 10 nudos en superficie; autonomía sumergida de horas a pocos días según velocidad y batería.

- Blindaje: casco resistente, no blindaje contra artillería; subdivisión y control de inundación.

- Armamento: 4–8 tubos de torpedo de 450–533 mm; cañón de cubierta de 76–102 mm en unidades tardías.

- Dotación: 35–70.

#### 9. Nodriza de hidroaviones y primer portaaviones (1912–1918)

- Función: observación naval, exploración y prueba de aviación embarcada; puede ser conversión de transporte o buque nuevo.

- Desplazamiento: 6.000–15.000 t. Dimensiones: 130–190 m; manga 18–25 m. Calado: 5,5–8 m.

- Propulsión: máquinas alternativas o turbinas de vapor según casco; carbón o petróleo por lote. Potencia: 15.000–40.000 shp. Ejes: 2–4.

- Velocidad: 18–25 nudos. Alcance: 4.000–7.000 mn a 10 nudos.

- Blindaje: 25–75 mm local; protección de pañoles y máquinas antes que cubierta de vuelo pesada.

- Armamento: 4–8 × 100–152 mm y piezas antiaéreas iniciales de 37–76 mm.

- Aeronaves: 6–24 hidroaviones o aviones ligeros; grúas, hangares, talleres y combustible limitados.

- Dotación: 400–850 más personal aéreo.

#### 10. Acorazado rápido entre guerras (1919–1938)

- Desplazamiento: 25.000–40.000 t. Dimensiones: eslora 210–245 m; manga 28–34 m. Calado: 9–11 m.

- Propulsión: turbinas de vapor con calderas de petróleo; transmisión a cuatro ejes. Potencia: 70.000–130.000 shp. Ejes: 4.

- Velocidad: 25–30 nudos de prueba. Alcance: 7.000–11.000 mn a 15 nudos.

- Blindaje: cinturón 280–380 mm; torres 300–400 mm; cubierta 100–160 mm; protección antitorpedo mejorada.

- Armamento: 8–12 × 356–406 mm; 8–16 × 127–152 mm; batería antiaérea de 20–102 mm por lote; dirección óptica y radio, radar solo en modernizaciones tardías conforme a la cronología.

- Dotación: 1.300–2.000.

#### 11. Portaaviones de flota entre guerras (1919–1938)

- Desplazamiento: 15.000–30.000 t. Dimensiones: eslora 190–240 m; manga 25–33 m. Calado: 7–9 m.

- Propulsión: turbinas de vapor y calderas de petróleo; potencia 45.000–100.000 shp; ejes 4.

- Velocidad: 25–32 nudos. Alcance: 7.000–11.000 mn a 15 nudos.

- Blindaje: cinturón 25–100 mm; cubierta de vuelo 25–75 mm o sin blindaje integral en diseños que priorizan aeronaves y autonomía.

- Armamento: 8–12 × 100–127 mm y piezas antiaéreas de 20–40 mm conforme a la fecha.

- Ala aérea: 35–75 aeronaves entre cazas, exploradores, bombarderos y torpederos; configuración dependiente de hangares y ascensores.

- Dotación: 900–1.600 navales, más 400–900 de aviación y servicios embarcados.

#### 12. Cruceros de los años veinte y treinta

- Desplazamiento: crucero ligero 6.000–10.000 t; pesado 9.000–15.000 t. Dimensiones: eslora 150–200 m; manga 17–23 m. Calado: 6–8,5 m.

- Propulsión: turbinas de vapor, calderas de petróleo, cuatro ejes. Potencia: 50.000–110.000 shp.

- Velocidad: 30–35 nudos. Alcance: 6.000–10.000 mn a 15 nudos.

- Blindaje: ligero 50–120 mm de cinturón; pesado 100–200 mm; cubiertas 40–100 mm.

- Armamento: ligero 8–12 × 152 mm; pesado 6–9 × 203 mm; secundario/antiaéreo de 76–127 mm; torpedos y 1–3 hidroaviones de exploración en unidades aptas.

- Dotación: 600–1.100.

#### 13. Destructor de escuadra entre guerras (1919–1938)

- Desplazamiento: 1.500–3.000 t. Dimensiones: eslora 100–125 m; manga 10–13 m. Calado: 3,5–5 m.

- Propulsión: turbinas de vapor y calderas de petróleo; potencia 35.000–70.000 shp; ejes 2.

- Velocidad: 32–38 nudos. Alcance: 3.000–6.000 mn a 15 nudos.

- Blindaje: sin cinturón; placas locales de 10–25 mm en puestos de mando o pañoles tardíos.

- Armamento: 4–8 × 100–127 mm; 4–10 tubos de torpedo de 533 mm; armas antiaéreas ligeras; sonar, hidrofonos y cargas de profundidad en unidades antisubmarinas.

- Dotación: 130–250.

#### 14. Submarino oceánico diésel-eléctrico entre guerras (1919–1938)

- Desplazamiento: 800–2.500 t en superficie. Dimensiones: 65–100 m; manga 6–9 m. Calado: 4–6 m.

- Propulsión: dos diésel y motores eléctricos/baterías; potencia diésel 3.000–8.000 shp y eléctrica 1.000–2.500 shp; ejes 2.

- Velocidad: 16–22 nudos en superficie; 8–10 sumergido. Alcance: 8.000–14.000 mn a 10 nudos en superficie; en inmersión, alcance mucho menor y dependiente del régimen eléctrico.

- Blindaje: casco resistente, sin blindaje naval convencional.

- Armamento: 6–10 tubos de 533 mm; 1 cañón de cubierta en algunas unidades; minas en variantes especializadas.

- Dotación: 45–80.

#### 15. Acorazado rápido de guerra (1939–1945)

- Desplazamiento: 35.000–55.000 t a plena carga. Dimensiones: eslora 230–270 m; manga 32–38 m. Calado: 9,5–11,5 m.

- Propulsión: turbinas de vapor con calderas de petróleo; potencia 120.000–180.000 shp; ejes 4.

- Velocidad: 27–32 nudos de prueba. Alcance: 10.000–15.000 mn a 15 nudos.

- Blindaje: cinturón 300–410 mm; torres 330–450 mm; cubierta 120–200 mm; protección antitorpedo en capas.

- Armamento: 8–12 × 356–406 mm; 8–20 × 127–152 mm de doble propósito; baterías antiaéreas de 20–40 mm; radar de búsqueda y dirección de tiro en unidades y lotes tardíos.

- Dotación: 1.800–2.700.

#### 16. Portaaviones de flota de guerra (1939–1945)

- Desplazamiento: 25.000–45.000 t a plena carga. Dimensiones: eslora 240–280 m; manga 32–40 m. Calado: 8–10 m.

- Propulsión: turbinas de vapor y calderas de petróleo; potencia 120.000–200.000 shp; ejes 4.

- Velocidad: 30–34 nudos de prueba. Alcance: 10.000–15.000 mn a 15 nudos.

- Blindaje: cinturón 100–200 mm; cubierta de vuelo 30–100 mm según diseño; protección adicional de hangares, pañoles y combustible aeronáutico.

- Armamento: 8–16 × 100–127 mm; baterías de 40 mm y 20 mm, con dirección de tiro; radar de alerta, control de caza y enlaces navales por lote.

- Ala aérea: 60–100 aeronaves en configuración teórica; normalmente menos disponibles simultáneamente durante operaciones prolongadas. Cazas, exploración, bombardeo y ataque torpedero.

- Dotación: 1.800–2.800 navales y 700–1.300 de aviación/servicios; total aproximado 2.500–4.100.

#### 17. Portaaviones de escolta (1941–1945)

- Función: convoyes, cobertura antisubmarina, transporte de aeronaves y apoyo de desembarcos; conversión de mercante o casco simplificado.

- Desplazamiento: 8.000–20.000 t. Dimensiones: eslora 130–190 m; manga 20–28 m. Calado: 6–8 m.

- Propulsión: máquina alternativa, turbina de vapor sencilla o diésel según casco; potencia 8.000–30.000 shp; ejes 1–2.

- Velocidad: 16–25 nudos. Alcance: 6.000–12.000 mn a 12 nudos.

- Blindaje: ninguno o protección local ligera de 10–50 mm.

- Armamento: 2–8 × 76–127 mm; 20–40 mm antiaéreos; armas antisubmarinas ligeras cuando opera como escolta.

- Ala aérea: 20–40 aeronaves, principalmente caza, patrulla y antisubmarina.

- Dotación: 500–1.200 navales y personal aéreo.

#### 18. Crucero de guerra (1939–1945)

- Desplazamiento: ligero 8.000–13.000 t; pesado 10.000–18.000 t. Dimensiones: eslora 170–220 m; manga 19–26 m. Calado: 6,5–9 m.

- Propulsión: turbinas de vapor con petróleo; potencia 70.000–130.000 shp; ejes 4.

- Velocidad: 30–35 nudos. Alcance: 6.000–10.000 mn a 15 nudos.

- Blindaje: cinturón 80–200 mm, cubiertas 40–120 mm y protección local de torres.

- Armamento: crucero ligero 8–12 × 152 mm; pesado 6–10 × 203 mm; ambos con 100–127 mm de doble propósito, armas antiaéreas ligeras, radares por lote y sonar en unidades de escolta.

- Dotación: 700–1.300.

#### 19. Destructor y escolta antisubmarina (1939–1945)

Destructor de flota

- Desplazamiento: 1.800–3.500 t. Dimensiones: 110–135 m de eslora; manga 11–14 m. Calado: 3,5–5 m.

- Propulsión: turbinas de vapor y petróleo; potencia 45.000–80.000 shp; ejes 2.

- Velocidad: 30–38 nudos. Alcance: 3.500–6.000 mn a 15 nudos.

- Blindaje: no significativo; protección local de pañoles y puestos.

- Armamento: 4–8 × 100–127 mm; 6–10 tubos de 533 mm; 20–40 mm antiaéreos; sonar, cargas de profundidad y morteros antisubmarinos según lote.

- Dotación: 180–330.

Escolta oceánica antisubmarina

- Desplazamiento: 800–2.000 t. Dimensiones: 85–120 m; manga 10–15 m. Calado: 3–5 m.

- Propulsión: diésel, turbina de vapor económica o combinación; potencia 8.000–25.000 shp; ejes 1–2.

- Velocidad: 18–27 nudos. Alcance: 4.000–8.000 mn a 12 nudos.

- Blindaje: ninguno o protección local ligera.

- Armamento: 2–4 × 76–127 mm; 20–40 mm antiaéreos; sonar; morteros antisubmarinos y cargas de profundidad; normalmente sin batería de torpedos pesada.

- Dotación: 90–200.

#### 20. Submarino oceánico de guerra (1939–1945)

- Desplazamiento: 1.200–2.500 t en superficie; sumergido, aproximadamente 1.700–3.200 t según casco. Dimensiones: eslora 75–100 m; manga 7–9 m. Calado: 4,5–6 m.

- Propulsión: dos diésel en superficie, motores eléctricos y baterías sumergido; potencia diésel 4.000–9.000 shp; eléctrica 1.500–3.000 shp; ejes 2.

- Velocidad: 17–22 nudos en superficie; 7–10 sumergido. Alcance: 8.000–14.000 mn a 10 nudos en superficie; patrulla sumergida limitada por baterías y velocidad.

- Blindaje: casco resistente, no blindaje contra proyectiles; compartimentación y control de inundación.

- Armamento: 6–10 tubos de 533 mm; 12–24 torpedos entre tubos y reserva según diseño; cañón de cubierta de 76–127 mm en ciertos lotes; minas en variantes.

- Dotación: 50–85.

#### 21. Auxiliares, petroleros, talleres y transportes de desembarco (1939–1945)

- Desplazamiento: 2.000–20.000 t por misión. Dimensiones: eslora 90–190 m; manga 14–28 m. Calado: 4–9 m cargados.

- Propulsión: diésel o vapor; turbinas solo en transportes rápidos. Potencia: 5.000–30.000 shp. Ejes: 1–2.

- Velocidad: 12–22 nudos. Alcance: 5.000–12.000 mn a 12 nudos.

- Blindaje: ninguno; compartimentación, protección contra incendios y daños por torpedo en buques de mayor valor.

- Armamento: 2–8 × 76–127 mm y armas antiaéreas ligeras; el armamento no convierte al transporte en buque de línea.

- Dotación: 100–400 navales, más personal técnico, sanitario, de carga o tropas transportadas.

- Papel en combate: sostener combustible, munición, víveres, reparación, evacuación médica, desembarco y recuperación de buques.

#### Reglas de lectura y límites

- Las cifras son rangos de diseño adoptados, no valores simultáneos máximos para cada casco. Blindajes son espesores locales; velocidad suele ser de prueba; autonomía depende de carga, combustible, estado del mar y régimen.

- Las cifras no fijan cantidades de buques ni dotaciones de toda la flota. No se inventan nombres de clase fuera de los ya establecidos ni un orden de batalla.

- Los buques de 1875 mantienen sus características originales; los añadidos de potencia, ejes, calado y alcance son rangos por lote. Los cascos existentes no se convierten automáticamente a triple expansión o turbina.

- El adelanto de doce años afecta solo a los hitos navales de vapor indicados; no adelanta radar, sonar, armas, aviación ni doctrina.

- La generación de potencia, astilleros, educación técnica, logística, mantenimiento y bases condicionan la disponibilidad; la tecnología no implica superioridad automática.

### Tripulaciones abastecimiento y disponibilidad histórica

#### El viaje como unidad logística

Un buque disponible necesita casco, aparejo o maquinaria, dotación entrenada, agua, alimentos, herramientas, repuestos y puerto de retorno. El inventario de cascos es una medida distinta de la fuerza que puede salir a una misión. Cada periodo utiliza las categorías técnicas de su época y calcula por separado construcción, mantenimiento, reserva y bajas.

La navegación temprana combina propulsión humana y vela conforme a la divergencia histórica ya adoptada. La carga útil disminuye cuando aumentan tripulantes, animales, forraje y reservas de agua. Una expedición de reconocimiento puede tolerar escalas inciertas; un convoy de familias necesita saber si encontrará recepción, terreno, alimento y herramientas al desembarcar. Llevar ganado requiere embarque preparado y no permite suponer rebaños completos en el primer viaje.

#### Tripulación y aprendizaje

Capitanes y pilotos coordinan navegación; carpinteros, herreros, responsables de provisiones e intérpretes cubren necesidades según la misión. La formación embarcada transmite maniobras, observación del tiempo, conservación de agua y reparación. La jornada de trabajo, descanso, alojamiento, dieta y disciplina afectan directamente a la capacidad de combatir o regresar.

Las listas de embarque y pago permiten reclamar salarios y localizar obligaciones familiares. El cuidado de heridos, las cajas de socorro y la memoria de desaparecidos se desarrollan con las instituciones de cada época. La capellanía puede asistir al tripulante sin sustituir al mando operativo ni imponer una sola confesión a toda dotación.

#### Escalas y reparación

Las estaciones necesitan existencias comprobadas y acuerdos de acceso. Un punto dibujado en una carta no asegura agua dulce, madera seca, herrero o almacén abastecido. Los informes de llegada deben comunicar consumos, daños y trabajos pendientes, para que la escala siguiente no se planifique sobre recursos ya agotados.

La industrialización añade dependencia de carbón, lubricantes, munición, calderas y talleres. La distribución de la Armada de 1875 conserva sus 332 unidades de inventario y su reparto vigente entre combate, apoyo y auxiliares. La comparación de teatros requiere tiempos de tránsito y reparación; ninguna unidad debe contarse simultáneamente como disponible en dos escuadras.

#### Continuidad hasta 2026

La aviación embarcada, la propulsión moderna y OceanNet aumentan la coordinación y también las exigencias de mantenimiento. Los destacamentos rotatorios se descuentan del inventario nacional al asignarlos, en vez de sumarlos como otra flota. La plantilla de 272 buques de v050 y su serie histórica no sustituyen la Armada contemporánea de V16. Las cifras de personal, aeronaves y drones requieren categorías excluyentes para evitar dobles cómputos.

Desarrollo: 12_Militar/Tripulaciones abastecimiento y disponibilidad histórica.

## Resoluciones canónicas acumulativas V16.2

Esta sección integra A087 y cierra las propuestas de la revisión V16.1. Las decisiones conservan la jerarquía territorial, las cifras y las fechas vigentes; lo incompatible o insuficientemente documentado queda expresamente fuera del canon.

### Siderurgia naval y blindaje: integración A087

La continuidad de los archivos desde la Antigüedad no implica capacidad industrial continua. La siderurgia evoluciona desde reducción directa y forja hacia ferrerías hidráulicas, arsenales normalizados, mecanización por carbón/coque/vapor y producción industrial de acero controlado. El salto del siglo XIX requiere minas, transporte, energía, laboratorios, trabajadores especializados, escuelas técnicas y compras coordinadas.

Entre 1844 y 1860 Valinor desarrolla, como divergencia deliberada, convertidores y hornos de composición controlada antes que sus equivalentes de referencia real. Esto permite separar acero estructural de lotes críticos; no vuelve homogénea toda la producción. Desde 1861 se ensayan placas y se registran fallas.

En 1875 los acorazados Círdan I incorporan acero de frente endurecido temprano en sectores seleccionados del cinturón y protecciones de torres/barbetas. El resto conserva hierro laminado o blindaje compuesto hierro-acero según la función. Los espesores ya aprobados son máximos locales, no cobertura uniforme. La producción inicial es limitada, con control empírico y riesgos de fragilidad, desprendimiento y variación entre placas.

Entre 1876 y 1882 los ensayos producen placas de gradiente endurecido más repetibles para nuevas construcciones y reconstrucciones justificadas. De 1883 a 1899 mejoran limpieza, tamaño, inspección y uniformidad. Entre 1890 y 1902 se desarrolla una generación cementada avanzada, cuya expansión de proveedores ocurre entre 1903 y 1908. Krupp/Vickers sirven como comparaciones funcionales, no como identidad de marca, proceso o química.

La cadena exige control de mineral y carga, afino, colada, forja/laminación, tratamiento superficial, respaldo tenaz y ensayo de aceptación por lote. Se registran grietas, deformación, desprendimiento y comportamiento balístico. No se fijan química, equivalencias universales, coste/tonelada, porcentaje de rechazo, tonelaje de placas ni número de buques modernizados sin modelo específico.

### Armada de 1500–1600

Durante el siglo XVI la Armada pasa gradualmente de escuadras de vela y galeras regionales a buques oceánicos de vela artillada, escoltas, transportes armados, avisos y auxiliares. La galera conserva utilidad en mares cerrados y operaciones costeras, pero no reemplaza al velero oceánico en convoyes transatlánticos. Artillería, pólvora, cureñas, fundición, jarcia y reparación limitan el ritmo de expansión.

La financiación combina Corona, derechos portuarios, fondos de arsenal, contratos de Casas y crédito público presupuestado. La disponibilidad se cuenta por unidades operativas, en reparación y reserva, sin asignar una nave a varios teatros simultáneamente. Se adopta la evolución cualitativa, no los totales v050 de 3.300 o 2.288 cañones ni una curva 1500–2026. Cantidades, tonelajes y dotaciones esperan un registro naval por clase.

### Instituciones y representación constitucional

La representación moderna queda fijada con Senado de 74 y Cámara Popular de 300: 37 circunscripciones territoriales senatoriales eligen dos miembros cada una; sus límites se revisan tras cada censo. El Senado dura seis años y renueva 37 escaños cada tres. La Cámara Popular se elige proporcionalmente cada cuatro años. Las unidades contables ECON-03 no son Estados constitucionales. Harnen sigue siendo protectorado y Rhunost una provincia autónoma interna de Harnen, sin escaños como Estados federados. Las leyes ordinarias requieren ambas cámaras; el presupuesto se inicia en la Cámara Popular. El bloqueo pasa a conciliación paritaria por 60 días y puede continuar el presupuesto previo hasta 90 días, bajo control parlamentario.

La Cámara Federal de Seguros se formaliza en 1705 sobre precedentes portuarios: supervisa solvencia, reservas, contratos públicos y fondos de catástrofe, sin monopolizar seguros privados. El Consejo Real de Academias Científicas se formaliza en 1848–1850 como asesor civil e industrial. En 1958 se establece el Consejo Federal de Ciencia y Tecnología, consultivo y coordinador. El Registro Federal de Testimonio Técnico Oral se crea en 1946 para preservar experiencia, incidentes y saber práctico bajo la doctrina de siete copias, respetando privacidad.

La crisis financiera de 1736–1750 y sus reformas son institucionales y colectivas. Maia Rómen y un supuesto informe de 1741 no quedan canonizados como autoría confirmada o causa única sin una fuente interna verificable.

### Población, emancipación y religión

Las series demográficas separan residentes, migración, nacimientos, muertes, desplazamientos y reclasificaciones. Cada cifra de 50 d. C. indica si comprende territorios administrados, estaciones, puertos asociados o protectorados; el contacto no añade población al censo. Los 8 millones de 800 d. C. son escenario central adoptado, no simulación validada. Tasas vitales y esperanza de vida son parámetros de modelo hasta validación; reclasificar personas no cambia el total.

La emancipación se fija por etapas: reformas limitantes en 450–500; cierre de nuevas licencias de trata en puertos de la Corona en 1768; prohibición de importar/exportar personas esclavizadas desde territorios directos en 1788; emancipación gradual y libertad de nacimiento desde 1806; fin del estatus esclavo en territorios directos en 1836; extensión pactada a protectorados y puertos asociados en 1856. La norma no implica cumplimiento uniforme ni reparación automática.

Se conservan las controversias de 430–864 y el Pacto de las Dos Reverencias de 864. No se fija lengua litúrgica universal, porcentaje confesional por territorio ni fecha exacta de cada texto sin fuentes. El Camino del Oeste es tradición religiosa y marítima, no título territorial ni mandato de conquista.

### Política exterior, Escandinavia y rutas orientales

Para tratados y crisis rige la precedencia del V16 activo: una fecha presente solo en v050 o en borradores no se integra por inferencia. Sicilia, Malta, Chipre, Egipto y el Levante conservan el modelo comercial, diplomático y de apoyo acordado; África, América, Caribe e islas con comunidades previas mantienen el relato canónico de conquista y esclavización donde ocurrieron.

La retirada de Escandinavia es gradual. Entre 800 y 1000 se transfieren funciones fiscales y navales a centros atlánticos; entre 1000 y 1150 disminuyen guarniciones y administración directa. El arreglo de 1200 termina la soberanía ordinaria sobre Escania y Noruega como núcleo metropolitano. Forostar (Helsingborg) conserva sede histórica, constitucional y archivística, sin implicar soberanía posterior. No se adoptan 150 ni 380 d. C. como abandono definitivo.

Entre los siglos IX y XII, las rutas bálticas y fluviales de la Rus permiten comercio, tránsito, traducción y contactos diplomáticos hacia el mar Negro; sus portajes y autoridades intermediarias hacen la conexión discontinua. No se crean provincias, enclaves ni protectorados valinari en la Rus o el mar Negro.

### Resolución técnica 111v

111v permanece integrada: OceanNet opera desde 1959 y consolida institución e interoperabilidad en 1969. Radar, sonar, óptica/infrarrojo y guerra electrónica son dominios complementarios; OceanNet comunica y correlaciona, no detecta ni decide. Palantír-2087V CIP es adaptación ficticia inspirada en Sonar 2087, no designación S2187. No existe matriz universal por casco ni cantidad total de sensores: la instalación se decide por misión, lote, presupuesto y modernización aprobada.

## Integración AM1 — Armada 1875 a 2026

Estado: canon V16 integrado. La Armada combina masa crítica sostenible de unidades seriadas con una punta de lanza de alta tecnología. Las capacidades de vanguardia no sustituyen tripulaciones, municiones, mantenimiento, bases y logística.

### Composiciones de referencia

| Año | Estatus | Composición | Total |
| --- | --- | --- | --- |
| 1945 | Reconstrucción, no inventario medido | 8 portaaviones; 18 cruceros; 54 destructores; 42 fragatas; 42 corbetas; 18 patrulleros; 38 submarinos; 28 anfibios; 20 MCM; 100 auxiliares | 368 |
| 1960 | Reconstrucción, no inventario medido | 9 portaaviones; 16 cruceros; 48 destructores; 52 fragatas; 50 corbetas; 20 lanchas misilísticas; 50 patrulleros; 46 submarinos; 32 anfibios; 20 MCM; 65 auxiliares | 408 |
| 1980 | Composición canónica de referencia | 7 portaaviones; 14 cruceros; 36 destructores; 56 fragatas/escoltas; 50 corbetas; 24 lanchas misilísticas; 60 patrulleros; 42 submarinos; 34 anfibios; 26 MCM; 78 auxiliares | 427 |
| 2026 | Inventario estructural; disponibilidad no medida | 11 portaaviones; 54 submarinos; 190 combatientes de superficie; 34 anfibios; 220 patrulla/vigilancia/servicio; 106 auxiliares | 615 plataformas |

Las reconstrucciones de 1945 y 1960 explican la transición histórica y no generan una serie anual por interpolación. En 1980, las corbetas, lanchas misilísticas, patrulleros y auxiliares son categorías distintas.

### Desglose funcional de 2026

| Familia | Cantidad | Contenido |
| --- | --- | --- |
| Portaaviones | 11 | 4 nucleares, 3 convencionales y 4 ligeros STOVL |
| Submarinos | 54 | 10 estratégicos, 18 de ataque nuclear, 18 convencionales/AIP y 8 especiales/inteligencia/rescate |
| Combatientes de superficie | 190 | 24 destructores, 64 fragatas, 72 corbetas y 30 escoltas especializados |
| Anfibios | 34 | 14 buques de asalto y 20 LPD/LSD |
| Patrulla y vigilancia | 220 | 80 OPV, 70 rápidos, 30 MCM, 20 hidrográficos y 20 no tripulados |
| Auxiliares | 106 | 20 petroleros, 18 reabastecedores, 12 transportes, 10 hospitales, 12 talleres, 10 oceanográficos, 8 salvamento y 16 mando/apoyo |

El inventario comprende 595 buques tripulados y 20 vehículos navales no tripulados. La estimación de 449 plataformas disponibles en un ciclo ordinario es una hipótesis de planificación, no una medición.

### Fichas técnicas 2026

#### Portaaviones nucleares Telperion

Cantidad: 4

Dimensiones, dotación, velocidad y alcance: 75.000–95.000 t; 300–335 m; 2.400–3.200 marinos + 1.500–2.000 ala aérea; 30+ kn; autonomía de combustible muy larga, limitada por víveres y mantenimiento

Propulsión, armas, sensores y construcción: Reactores nucleares; defensa puntual, señuelos/EW; radar AESA de vigilancia aérea y control de vuelo, enlaces tácticos, CMS aéreo distribuido. Construcción: Armenelos; integración de sensores en Nueva Tirion.

#### Portaaviones convencionales Anárion II / Elwing I / Aldarion I

Cantidad: 3

Dimensiones, dotación, velocidad y alcance: 45.000–65.000 t; 270–310 m; 2.000–2.900 + ala aérea; 27–30 kn; 8.000–12.000 mn

Propulsión, armas, sensores y construcción: Turbinas de vapor/gas según generación; defensa cercana; radares AESA/3D; CMS aéreo. Nueva Tirion/Armenelos.

#### Portaaviones ligeros STOVL Varda II–III

Cantidad: 4

Dimensiones, dotación, velocidad y alcance: 25.000–40.000 t; 220–260 m; 900–1.500 + ala aérea; 24–28 kn; 7.000–9.000 mn

Propulsión, armas, sensores y construcción: Diésel/turbina; defensa puntual; radar 3D/AESA compacto, control aéreo táctico; Calenport/Pelargir Austral.

#### Submarinos estratégicos Arnor II–IV

Cantidad: 10

Dimensiones, dotación, velocidad y alcance: 12.000–18.000 t sumergidos; 130–170 m; 130–160 personas; baja velocidad de patrulla silenciosa, autonomía de meses

Propulsión, armas, sensores y construcción: Nuclear; disuasión estratégica y torpedos defensivos; sonar de proa/flancos/remolcado, sensores de interceptación, navegación inercial; Armenelos.

#### Submarinos nucleares de ataque Eärendil II–IV

Cantidad: 18

Dimensiones, dotación, velocidad y alcance: 6.000–10.000 t; 100–130 m; 90–130 personas; alta velocidad máxima clasificada en canon técnico público, alcance de misión oceánico

Propulsión, armas, sensores y construcción: Nuclear; torpedos pesados, minas y misiles conforme al canon; sonar de gran apertura, CMS acústico, mástiles electroópticos; Armenelos/Nueva Tirion.

#### Submarinos convencionales AIP Tolfalas II–IV

Cantidad: 18

Dimensiones, dotación, velocidad y alcance: 2.000–4.000 t; 65–90 m; 40–65 personas; semanas sumergidos según perfil, 6.000–9.000 mn de tránsito

Propulsión, armas, sensores y construcción: Diésel-eléctrico/AIP; torpedos y minas; sonar pasivo, navegación inercial y comunicación esporádica; Númenor.

#### Submarinos especiales Aeglos y rescate Falathar

Cantidad: 8

Dimensiones, dotación, velocidad y alcance: 1.000–4.000 t; 45–95 m; 25–70 personas

Propulsión, armas, sensores y construcción: Diésel-eléctrico o nuclear según misión; rescate, investigación, buceo, inteligencia oceanográfica; sensores acústicos y de navegación; Númenor/Armenelos.

#### Destructores Gil-galad de defensa aérea

Cantidad: 24

Dimensiones, dotación, velocidad y alcance: 8.000–12.000 t; 155–190 m; 280–380 personas; 30–32 kn; 5.000–7.000 mn

Propulsión, armas, sensores y construcción: Turbina/diésel o propulsión eléctrica integrada por sublote; cañón medio, misiles de defensa de área y punto, antibuque y torpedos; radar AESA multifunción, CMS de grupo y EW. Armenelos/Pelargir Austral.

#### Fragatas Círdan/Voronwë multipropósito

Cantidad: 64

Dimensiones, dotación, velocidad y alcance: 4.500–7.000 t; 125–155 m; 150–220 personas; 26–30 kn; 5.000–7.000 mn

Propulsión, armas, sensores y construcción: CODLAG/CODOG o eléctrica según bloque; cañón medio, misiles de punto/área local, antibuque y torpedos; radar AESA compacto, sonar casco/remolcado, CMS común. Calenport/Pelargir Austral.

#### Corbetas oceánicas Calenport

Cantidad: 72

Dimensiones, dotación, velocidad y alcance: 1.800–3.000 t; 90–115 m; 70–115 personas; 25–29 kn; 3.500–5.000 mn

Propulsión, armas, sensores y construcción: Diésel; cañón 57–76 mm, misiles defensivos/antibuque según misión; radar 3D compacto, electroóptica, CMS escalable; astilleros regionales/insulares.

#### Escoltas especializados ASW/AAW

Cantidad: 30

Dimensiones, dotación, velocidad y alcance: 3.500–6.500 t; 110–145 m; 100–190 personas; 25–30 kn; 4.000–6.000 mn

Propulsión, armas, sensores y construcción: Diésel-eléctrica o turbina; equipo ASW o radar/armamento AAW; CMS de misión; Calenport/Nueva Tirion.

#### Buques de asalto/anfibios

Cantidad: 14

Dimensiones, dotación, velocidad y alcance: 15.000–40.000 t; 180–260 m; 300–900 tripulantes + fuerza embarcada

Propulsión, armas, sensores y construcción: Diésel/turbina; aeronaves, lanchas, vehículos; defensa puntual, radares de aproximación y CMS de grupo anfibio; Pelargir Austral/Armenelos.

#### LPD/LSD de desembarco

Cantidad: 20

Dimensiones, dotación, velocidad y alcance: 8.000–25.000 t; 130–210 m; 150–450 + tropas

Propulsión, armas, sensores y construcción: Diésel; dique inundable, grúas, radar de navegación y enlaces de fuerza; Pelargir Austral.

#### OPV Sírënandë

Cantidad: 80

Dimensiones, dotación, velocidad y alcance: 2.000–5.000 t; 90–125 m; 65–110 personas; 18–24 kn; 6.000–9.000 mn

Propulsión, armas, sensores y construcción: Diésel; cañón ligero, UAV embarcado donde proceda; radar de vigilancia/superficie, electroóptica, CMS de seguridad marítima; Sírënandë/Calenport.

#### Patrulleros rápidos

Cantidad: 70

Dimensiones, dotación, velocidad y alcance: 300–1.200 t; 45–80 m; 25–60 personas; 25–35 kn; 1.500–3.500 mn

Propulsión, armas, sensores y construcción: Diésel; cañón 20–57 mm, sensores compactos y enlaces costeros; astilleros locales.

#### Guerra de minas

Cantidad: 30

Dimensiones, dotación, velocidad y alcance: 500–2.500 t; 45–100 m; 35–100 personas; 12–20 kn; 2.000–5.000 mn

Propulsión, armas, sensores y construcción: Diésel-eléctrica; casco no magnético donde corresponda; sonar de alta resolución, vehículos no tripulados y CMS MCM; Calenport/Númenor.

#### Hidrografía

Cantidad: 20

Dimensiones, dotación, velocidad y alcance: 1.500–6.000 t; 60–120 m; 50–150 tripulantes/científicos; 12–20 kn

Propulsión, armas, sensores y construcción: Diésel; ecosondas multihaz, sonar de cartografía, posicionamiento preciso y OceanNet científico; Númenor/Calenport.

#### Vehículos no tripulados navales

Cantidad: 20

Dimensiones, dotación, velocidad y alcance: Unidades de superficie y submarinas de varias toneladas a tamaño de patrullero ligero; supervisión remota, no dotación embarcada permanente

Propulsión, armas, sensores y construcción: Diésel/batería; vigilancia, cartografía y contramedidas; sensores electroópticos/acústicos; uso supervisado y recuperación desde buques nodriza.

#### Petroleros de flota

Cantidad: 20

Dimensiones, dotación, velocidad y alcance: 25.000–50.000 t; 180–230 m; 100–180 personas; 18–22 kn; 10.000+ mn

Propulsión, armas, sensores y construcción: Diésel; transferencia en navegación, radar y comunicaciones logísticas; Pelargir Austral.

#### Reabastecedores multipropósito

Cantidad: 18

Dimensiones, dotación, velocidad y alcance: 20.000–40.000 t; 170–220 m; 180–300 personas; 18–24 kn; 8.000–10.000 mn

Propulsión, armas, sensores y construcción: Diésel; combustible/carga/municiones en operaciones controladas, defensa propia ligera, enlace logístico; Pelargir/Armenelos.

#### Transportes estratégicos

Cantidad: 12

Dimensiones, dotación, velocidad y alcance: 10.000–30.000 t; 120–200 m; 80–220 personas; 18–23 kn

Propulsión, armas, sensores y construcción: Diésel; carga, vehículos y apoyo expedicionario; radar de navegación y CMS logístico; Pelargir Austral/Númenor.

#### Hospitales

Cantidad: 10

Dimensiones, dotación, velocidad y alcance: 8.000–25.000 t; 140–220 m; 150–350 de tripulación y sanidad

Propulsión, armas, sensores y construcción: Diésel; sin armamento ofensivo; navegación, comunicaciones médicas y protección humanitaria; conversión/construcción en Pelargir Austral.

#### Reparación/taller

Cantidad: 12

Dimensiones, dotación, velocidad y alcance: 5.000–20.000 t; 120–190 m; 180–400 tripulación y técnicos

Propulsión, armas, sensores y construcción: Diésel; talleres, repuestos y grúas; redes de mantenimiento; Númenor/Pelargir.

#### Oceanográficos

Cantidad: 10

Dimensiones, dotación, velocidad y alcance: 2.000–8.000 t; 75–130 m; 70–180 personas

Propulsión, armas, sensores y construcción: Diésel-eléctrica silenciosa; sonar científico, sensores meteorológicos y de fondo; Calenport/Númenor.

#### Salvamento y rescate

Cantidad: 8

Dimensiones, dotación, velocidad y alcance: 2.000–8.000 t; 70–130 m; 60–160 personas

Propulsión, armas, sensores y construcción: Diésel; sonar de trabajo, vehículos de rescate, buceo y remolque; Númenor.

#### Mando, comunicaciones y apoyo especializado

Cantidad: 16

Dimensiones, dotación, velocidad y alcance: 2.000–12.000 t; 80–180 m; 80–300 personas

Propulsión, armas, sensores y construcción: Diésel; 8 buques de mando/comunicaciones, 4 de rescate polar y 4 de mantenimiento avanzado; Nueva Tirion/Pelargir/Númenor.

### Composición de 1980 por clases

#### Portaaviones Aulë II / Anárion I / Varda I

Cantidad: 7 (2 / 3 / 2)

Tipo y escala: Aulë II nuclear, 68–75 mil t; Anárion I convencional, 45–55 mil t; Varda I ligero/ASW, 22–28 mil t

Propulsión, prestaciones y dotación: 25–32 kn; dotación total con ala aérea, aproximadamente 1.500–5.300 según tipo

Armamento, sensores, astilleros y servicio: Defensa antiaérea y señuelos; radar de alerta y control aéreo; CMS de ala embarcada. Armenelos/Nueva Tirion para grandes; Pelargir Austral/Calenport para convencionales y ligeros. Construcción aprox. 1955–79; retiro por casco 1990–2015.

#### Cruceros Turgon / Eärendil / Noldor

Cantidad: 14 (4 / 6 / 4)

Tipo y escala: AAW, multimisión y mando; 8.000–14.000 t

Propulsión, prestaciones y dotación: 27–32 kn; 450–700 tripulantes; 5.000–8.000 mn

Armamento, sensores, astilleros y servicio: Cañón 127–152 mm, misiles antiaéreos y antibuque, torpedos; radar 2D/3D, sonar según variante y CMS digital en lotes tardíos. Armenelos/Pelargir; servicio 1960–2005.

#### Destructores Gil-galad / Beleg / Ossë

Cantidad: 36 (12 / 16 / 8)

Tipo y escala: Defensa aérea, antisubmarina y propósito general; 4.500–8.000 t

Propulsión, prestaciones y dotación: 29–32 kn; 260–420 personas; 4.000–6.000 mn

Armamento, sensores, astilleros y servicio: Cañón 127 mm, misiles de zona/local y antibuque, torpedos; radar 3D, sonar de casco/remolcado en ASW, EW y CMS integrado. Nueva Tirion/Armenelos/Pelargir Austral; construcción 1960–80, retiro 2005–2020.

#### Fragatas Círdan / Mithlond / Nimrodel

Cantidad: 56 (36 / 12 / 8)

Tipo y escala: Multipropósito y escolta oceánica/de convoy; 3.000–4.800 t

Propulsión, prestaciones y dotación: 25–29 kn; 190–260 personas; 4.000–5.500 mn

Armamento, sensores, astilleros y servicio: Cañón 76–127 mm, misiles de punto y antibuque, torpedos; radar 2D/3D por bloque, sonar de casco/remolcado y CMS analógico-digital. Calenport/Pelargir Austral. Programa Círdan moderno desde 1955; reemplazo generacional y refit según casco.

#### Corbetas Calenport / Eglarest

Cantidad: 50 (30 / 20)

Tipo y escala: Oceánicas y litorales; 900–2.200 t

Propulsión, prestaciones y dotación: 24–29 kn; 85–155 personas; 2.000–4.000 mn

Armamento, sensores, astilleros y servicio: Cañón 57–76 mm; misiles antibuque en parte de los cascos; radar de superficie, electroóptica, sonar ASW en algunas unidades y CMS compacto. Calenport/Pelargir/astilleros insulares; servicio 1965–2000.

#### Lanchas lanzamisiles Nosselië

Cantidad: 24

Tipo y escala: Ataque litoral rápido; 350–700 t

Propulsión, prestaciones y dotación: 35–43 kn; 40–65 tripulantes; 700–1.300 mn

Armamento, sensores, astilleros y servicio: Cañón ligero, misiles antibuque, radar de superficie y enlace táctico. Astilleros insulares; servicio 1970–1995.

#### Submarinos Arnor / Eärendil / Tolfalas / Ossë

Cantidad: 42 (6 / 12 / 18 / 6)

Tipo y escala: Estratégicos, ataque nuclear, convencionales y especiales; 1.000–16.000 t según misión

Propulsión, prestaciones y dotación: Dotación 25–160; autonomía prolongada en nucleares y de semanas en convencionales

Armamento, sensores, astilleros y servicio: Torpedos, minas y misiles según tipo; sonar pasivo/de proa, interceptación acústica y navegación inercial; recepción LF/comunicaciones discretas. Armenelos/Númenor; construcción 1955–80, retiro por casco hasta 2000–2030.

#### Anfibios Aranath / Pelargir / Forlond / Andúnië

Cantidad: 34 (6 / 8 / 12 / 8)

Tipo y escala: Asalto LPH, LPD, desembarco LST y apoyo logístico; 2.000–30.000 t

Propulsión, prestaciones y dotación: 15–25 kn; 80–800 tripulantes, más fuerza embarcada

Armamento, sensores, astilleros y servicio: Radar de navegación/vigilancia, comunicaciones de grupo, CMS defensivo y armas de punto. Pelargir Austral/Calenport/Armenelos; construcción 1955–80, servicio aproximado 1980–2010.

#### Contramedidas de minas Amon Sûl / Menel

Cantidad: 26 (18 / 8)

Tipo y escala: Cazaminas y mando/apoyo; 500–3.000 t

Propulsión, prestaciones y dotación: 12–20 kn; 35–120 personas

Armamento, sensores, astilleros y servicio: Sonar de búsqueda, vehículos de inspección, casco de baja firma, CMS de misión y comunicaciones seguras. Calenport/Númenor; servicio 1960–2005.

#### Patrulla Sírënandë / Malaca

Cantidad: 60 (30 / 30)

Tipo y escala: OPV oceánico y patrullero rápido; 500–3.500 t

Propulsión, prestaciones y dotación: 18–32 kn; 35–120 personas

Armamento, sensores, astilleros y servicio: Cañón 30–76 mm, radar de superficie, electroóptica y CMS de vigilancia marítima. Calenport, Sírënandë y astilleros insulares; servicio 1960–2010.

#### Auxiliares Aulë / Ecthelion / Harlond / Númenor / Estel / Eärendil / Palantír / Alcarondas

Cantidad: 78 (14 / 12 / 12 / 8 / 6 / 8 / 10 / 8)

Tipo y escala: Petroleros, reabastecedores, transportes, talleres, hospitales, salvamento, oceanografía y comunicaciones; 2.000–35.000 t

Propulsión, prestaciones y dotación: 15–24 kn; dotación de 70–400 según misión

Armamento, sensores, astilleros y servicio: Radar de navegación y comunicaciones HF/VHF/UHF; satélite en las unidades tardías; armamento ligero o ninguno. Pelargir Austral, Armenelos, Númenor y Calenport; ciclos de 20–35 años.

### Ciclo de vida y evolución industrial

Desde 1945 cada casco recibe una modernización integral principal de media vida; las reparaciones y actualizaciones menores se distinguen de ese refit. Las clases continúan mediante generaciones nuevas: no se supone un casco con 85 años de servicio. Los combatientes mayores suelen planificarse para 30–40 años; patrulleros y vehículos no tripulados, para ciclos menores.

La industria naval madura desde los arsenales de vapor y siderurgia de 1750–1880, pasa por turbinas, motores, submarinos y aviación entre 1880–1945, y desarrolla portaaviones, propulsión nuclear, sensores, radar, sonar y construcción seriada en la posguerra. Desde 1969 OceanNet articula gradualmente mando y logística; entre 1980 y 2026 se amplían propulsión eléctrica, AESA, guerra electrónica, drones, construcción modular y mantenimiento predictivo.

La regla comparativa presupuestaria aplica la proporción del PIB estadounidense dedicada al Department of the Navy con perímetro homogéneo. Para 2026, la referencia AM1 de alrededor de 0,9 % sobre 65,50 billones PPA equivale a unos 589,5 mil millones PPA; es una equivalencia de planificación, no presupuesto nominal ni gasto auditado. La serie histórica, incluido 1980, requiere armonizar conceptos presupuestarios.

La infantería de Marina se planifica en 150.000–190.000 efectivos activos y 80.000–120.000 reservistas; son rangos de diseño, no una nómina censada. Detalle técnico, ciclos y fichas por familia: 12_Militar/AM1 Armada 1875-2026.md.

## Destructores Gil-galad

La familia Gil-galad reúne generaciones de destructores de defensa aérea y escolta oceánica. Protege portaaviones, convoyes, buques anfibios y nodos de mando frente a amenazas aéreas, submarinas y de superficie. Cada generación es un diseño nuevo; el nombre no implica que un mismo casco sirva durante décadas sin relevo.

Se adopta una secuencia única: I, generación de guerra; II, posguerra a vapor; III, primera serie de turbinas de gas; IV, diseño digital de los años noventa; V, diseño de red y AESA inicial de los años 2000; VI, diseño de los años 2020. Esta norma corrige las tablas anteriores que reutilizaban números de generación.

### Generaciones, botadura y retiro

| Generación | Construcción / botadura | Primer servicio | Retiro previsto | Cambio principal |
| --- | --- | --- | --- | --- |
| I | 1938–1944 / 1940–1945 | 1940–1945 | 1958–1968 | Vapor, artillería, torpedos y ASW de convoy |
| II | 1952–1960 / 1953–1962 | 1955–1965 | 1978–1988 | Vapor modernizado, radar analógico y refits de misiles limitados |
| III | 1972–1980 / 1974–1982 | 1978–1985 | 2005–2015 | COGOG/CODOG, turbina de gas, misiles de serie y CMS temprano |
| IV | 1990–1998 / 1992–2000 | 1997–2005 | 2028–2038 | Radar 3D, enlaces de datos y VLS en lotes posteriores |
| V | 2005–2013 / 2008–2016 | 2012–2020 | 2040–2048 | AESA inicial, CMS integrado y defensa de área |
| VI | 2020–2030 / 2023–2033 | 2027–2035 | 2058–2068 | Energía ampliada, sensores distribuidos y automatización |

### Prestaciones y sistemas por generación

| Generación | Desplazamiento | Propulsión / rendimiento | Dotación | Armamento y sensores |
| --- | --- | --- | --- | --- |
| I | 2.500–3.500 t | Vapor; 30–35 kn; 3.000–4.500 mn | 250–330 | Cañones 102–127 mm, torpedos, cargas ASW, sonar y radar tardío |
| II | 3.500–5.000 t | Vapor; 32–35 kn; 3.500–5.000 mn | 280–360 | 114–127 mm, torpedos, cohetes/cargas ASW, radar 2D; SAM solo en algunos refits |
| III | 6.500–8.000 t | COGOG/CODOG, 2 ejes; 30–32 kn; 4.500–5.500 mn | 300–380 | 127 mm, Míriel SAM, Nénar en lotes, torpedos, radar 2D/3D y CMS temprano |
| IV | 7.000–9.000 t | Gas/diésel; 30–32 kn; 5.000–6.000 mn | 280–360 | 127 mm, 32–48 VLS según bloque, radar 3D, sonar y enlace de datos |
| V | 8.000–10.500 t | Gas con generación eléctrica integrada; 30–32 kn; 5.500–7.000 mn | 280–380 | 127 mm, 48–64 VLS, AESA y CMS integrado |
| VI | 9.000–12.000 t | Gas, arquitectura eléctrica ampliada; 30–32 kn; 6.000–7.000 mn | 250–340 | 64–96 VLS previstos por configuración, AESA multifunción y sensores cooperativos |

### Inventarios AM1 y transición

La reconstrucción de 1973 cuenta 12 Gil-galad II de posguerra a vapor. El diseño III de turbina de gas empieza a entrar en servicio desde 1978. La cifra familiar de 12 en 1980 es agregada durante el relevo II–III y no debe duplicarse por generación. En 2026 se cuentan 24 destructores de las generaciones IV y V; la generación VI no es operativa antes de 2027.

La generación II combina cañón de 114–127 mm, radar analógico y sonar de casco. La III incorpora turbinas de gas COGOG/CODOG, misil antiaéreo Míriel y, por lotes, misil antibuque Nénar; su control de combate es digital temprano y conserva canales de tiro limitados. Las generaciones posteriores evolucionan hacia radar 3D, lanzadores verticales, AESA, guerra electrónica y mando de grupo.

La regla de ciclo es una modernización integral de media vida por casco, además de reparaciones ordinarias. La modernización cambia sensores, CMS, comunicaciones y armas compatibles, pero no convierte un casco antiguo en otro diseño ni prolonga indefinidamente su vida estructural.

En la historia real, HMS Exmouth probó propulsión íntegra de turbinas de gas en 1967 y USS Spruance, primer destructor de turbina de gas de la Marina estadounidense, entró en servicio en 1975. La cronología valinari adelanta la decisión de serie mediante inversión industrial y técnica; no supone que desaparezcan el consumo elevado a máxima potencia, la corrosión salina o la necesidad de módulos de repuesto.

Ficha de Obsidian: [[12_Militar/03_Armada/Destructores Gil-galad — evolución de la familia|12_Militar/Destructores Gil-galad — evolución de la familia]].md

## Complementos recuperados del Canon Markdown

Estos contenidos estaban presentes en el Markdown activo y no tenían coincidencia textual completa en el Word. Se preservan con sección y estado de origen. A092 prevalece sobre cifras o fechas incompatibles; las matrices antiguas no sustituyen el cierre actual de 23 cuentas.

### Desarrollo sistemático de la religión

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

4. Maiar: seres humanos sacralizados por la memoria, como sacerdotisas, astrónomas, médicas, maestras y fundadoras.

### Teología valinari de Eru Ainur y Maiar

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Los Maiar son intermediarios de la tradición religiosa: profetisas, guardianas de santuarios, maestras, astrónomas-sacerdotisas, consejeras de Casas y fundadoras de hospitales, escuelas o archivos. No son seres sobrenaturales documentados; muchos relatos conservan la memoria transformada de personas humanas de gran prestigio.

### Composición naval vigente

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

En 2026 el inventario canónico de referencia comprende 615 plataformas navales: 595 buques tripulados y 20 vehículos navales no tripulados. Se distribuye en 11 portaaviones, 54 submarinos, 190 escoltas y combatientes de superficie, 34 anfibios, 220 plataformas de patrulla/vigilancia/servicio y 106 auxiliares. La estimación de 449 unidades disponibles en un ciclo ordinario es una hipótesis de planificación, no una tasa observada. El desglose funcional y técnico se encuentra en [[12_Militar/03_Armada/AM1 Armada 1875-2026|AM1 Armada 1875–2026]].

### Precedencia canónica

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

1. Decisiones expresas más recientes del autor.

2. Sección de retcon y escala vigente de actualizaciones_acumulativas_canon_v12.md.

3. Cronología maestra y enmiendas v12 compatibles.

4. Anexos históricos o documentos con cifras sustituidas, conservados para trazabilidad.

Los anexos no reactivan cifras o reglas sustituidas cuando contradicen la sección vigente.

### Índice de archivos integrados

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

[[10_Archivo/Documentos de trabajo integrados/actualizacion_canon_arnor_poblacion_economia_526ac_2026|actualizacion_canon_arnor_poblacion_economia_526ac_2026.md]]

[[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_ciudades_poblacion_industrial_v12|enmienda_canon_ciudades_poblacion_industrial_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_demografia_1850_2026_v12|enmienda_canon_demografia_1850_2026_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_distribucion_urbana_historica_v12|enmienda_canon_distribucion_urbana_historica_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_enclaves_medio_oriente_v12|enmienda_canon_enclaves_medio_oriente_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_industrializacion_1850_2026_v12|enmienda_canon_industrializacion_1850_2026_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_nosselie_toliva_canarias_v12|enmienda_canon_nosselie_toliva_canarias_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_oceannet_1850_2026_v12|enmienda_canon_oceannet_1850_2026_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_poligono_tol_eressea_y_numenor_v12|enmienda_canon_poligono_tol_eressea_y_numenor_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_primer_contacto_caribe_150_ac_v12|enmienda_canon_primer_contacto_caribe_150_ac_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_provincia_arnor_v12|enmienda_canon_provincia_arnor_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_provincia_calendardhon_austral_v12|enmienda_canon_provincia_calendardhon_austral_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_recalibracion_poblacion_v12|enmienda_canon_recalibracion_poblacion_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_secuencia_atlantica_tol_terranova_valinor_v12|enmienda_canon_secuencia_atlantica_tol_terranova_valinor_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_sirenande_poblacion_v12|enmienda_canon_sirenande_poblacion_v12.md]]

[[10_Archivo/Documentos de trabajo integrados/enmienda_canon_sirenande_v12|enmienda_canon_sirenande_v12.md]]

informe_comparacion_v11.md

[[10_Archivo/Documentos de trabajo integrados/regla_primordial_nomenclatura_urbana_v12|regla_primordial_nomenclatura_urbana_v12.md]]

### Actualizaciones acumulativas del canon valinoriano

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: documento consolidado de referencia

Este documento reúne las decisiones canónicas adoptadas en las enmiendas del proyecto. Los mapas generados anteriormente fueron eliminados y no forman parte del canon.

### 2. Territorios directos

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Islandia, territorio federal autónomo externo al Reino.

Groenlandia, territorio federal autónomo externo al Reino.

### 3. Arnor

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Población de Arnor en 2026: 145 millones. PIB provincial estimado: 18–22 billones de dólares PPA, con un valor central ECON-03 de 20 billones. Arnor concentra fabricación de chips, radares, motores y electrónica industrial, junto con finanzas, ingeniería, energía y servicios urbanos. La sección 36 fija 131,5 millones urbanos, 13,5 rurales/dispersos y las cuentas sectoriales propias; las distribuciones provinciales y urbanas allí prevalecen sobre estimaciones anteriores.

### 4. Calenardhon Austral

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Población 2026: 88 millones. PIB PPA fijado: 11,5 billones, equivalente a aproximadamente 130.682 dólares PPA por habitante. La primera estimación de VAB y la cuña fiscal uniforme de la sección 33.8 quedan sustituidas por la cuenta sectorial propia de la sección 36. El perfil refleja su base agroindustrial y alimentaria, metalurgia, astilleros, turbinas, generadores, motores navales, electrónica de potencia, ferrocarriles, energía y defensa austral.

### 5. Sírënandë

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Superficie de referencia: 462.323 km². Población 2026: 55 millones. PIB PPA fijado: 3,5 billones, equivalente a aproximadamente 63.636 dólares PPA por habitante. La sección 36 fija la cuenta sectorial, impuestos y subvenciones propios; la matriz uniforme de 33.8 queda como antecedente. El perfil presupone minería, energía hidroeléctrica, refinación y procesamiento local de cobre, aluminio, níquel y tierras raras, manufactura, puertos y logística. El límite corresponde a Guyana, Surinam y Guayana Francesa completos, sin una franja adicional.

### Armada y sistemas de defensa

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

2030–2037, planificado: la clase Voronwë sustituirá gradualmente a Círdan IV.

### Normalización de capitales y ciudades principales

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Las capitales propuestas para Malaca, Hawái, Fiyi, Polinesia, Micronesia, Kheled-zâram, Círdan, Harlond, Amon Rûdh, Alqualondë, Eglarest y Pelargir se conservan en el índice político de Obsidian como capitales administrativas provisionales hasta su confirmación individual.

### Clasificación territorial en 50 d. C.

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Categoría | Ejemplos | Situación política |
| --- | --- | --- |
| Patria ancestral | Escania, Helsingborg | Fuera del centro político, pero vinculada por memoria, propiedades y parentesco |
| Núcleo administrado | Systreyjar, Nosselië Toliva | Bajo autoridad valinaria directa y pactista |
| Dominio de Casa | Tierras agrícolas, talleres y puertos menores | Administrado por una Casa bajo obligaciones reales |
| Puerto asociado | Sicilia, Malta, Chipre, Alejandría | Autoridad local conservada; acuerdos comerciales y navales |
| Factoría | Estaciones mediterráneas y del mar Rojo | Presencia limitada, almacenes y agentes |
| Territorio no descubierto en 50 d. C. | Tol Eressëa | Descubrimiento 20–40 d. C. A092-R01 |
| Ruta reconocida | Groenlandia futura, costas americanas futuras | Sin soberanía ni administración permanente |
| Territorio no incorporado | Númenor, Arnor, América continental, Valinor | Fuera del dominio territorial valinario |

### Espacios aún no desarrollados en 50 d. C.

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Groenlandia: sin incorporación estable en 50 d. C.; reconocimiento independiente pendiente de conciliación A092-R01.

### Modelo demográfico valinari, 1000 a. C.–800 d. C.

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La población residente valinari o vinculada a su administración se fija como modelo de planificación en 180.000 habitantes en 1000 a. C., 430.000 en 500 a. C., 1.700.000 en 50 d. C., 4.600.000 en 500 d. C. y 7.200.000 en 800 d. C. Estas cifras no incluyen automáticamente a toda la población local de los territorios conocidos.

La inmigración exterior acumulada entre 1000 a. C. y 800 d. C. se estima en 2.072.000 llegadas brutas: 1.295.000 nórdicas y 777.000 no nórdicas. Las primeras proceden principalmente de Dinamarca, Escania, Noruega y, posteriormente, Finlandia; las segundas proceden de comunidades germánicas no fundacionales y de Europa oriental. La distribución orientativa es de 52 % mujeres y 48 % hombres para el conjunto de las corrientes. Las llegadas no equivalen al crecimiento neto: deben descontarse defunciones, naufragios, enfermedades, guerras, salidas y pérdidas de asentamientos.

La fecundidad media orientativa es de aproximadamente 3 hijos por mujer, con variaciones por época y territorio. No es una tasa rígida ni implica supervivencia completa hasta la edad adulta. La población crece mediante descendencia de migrantes, comunidades fundadoras, integración parcial de poblaciones locales, manumisión, absorción de aliados y urbanización. La distinción entre Valinari de linaje, descendientes mestizos, población local, población dependiente y personas esclavizadas se mantiene en las cuentas.

### Recalculo demográfico centenario y migración diferenciada

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La tabla siguiente sustituye las escalas demográficas anteriores para el periodo 1000 a. C.–800 d. C. La categoría población local superviviente desaparece aproximadamente cien años después del descubrimiento o incorporación de cada territorio, entendida como desaparición de la categoría censal y jurídica, no como desaparición física de todas las personas originarias. Los territorios incorporados después conservan su propia ventana de cien años.

| Fecha | Población total | Valinari de linaje | Mestizos y portuarios | Local superviviente | Esclavizados o dependientes | Migración nórdica acumulada | Migración no nórdica acumulada |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1000 a. C. | 180.000 | 135.000 | 9.000 | 27.000 | 9.000 | 0 | 0 |
| 900 a. C. | 225.000 | 162.000 | 18.000 | 33.750 | 11.250 | 25.000 | 15.000 |
| 800 a. C. | 280.000 | 196.000 | 28.000 | 42.000 | 14.000 | 50.000 | 30.000 |
| 700 a. C. | 350.000 | 238.000 | 42.000 | 52.500 | 17.500 | 75.000 | 45.000 |
| 600 a. C. | 410.000 | 266.500 | 61.500 | 61.500 | 20.500 | 105.000 | 63.000 |
| 500 a. C. | 466.750 | 289.385 | 93.350 | 56.010 | 28.005 | 155.000 | 93.000 |
| 400 a. C. | 650.000 | 390.000 | 156.000 | 65.000 | 39.000 | 220.000 | 132.000 |
| 300 a. C. | 900.000 | 522.000 | 243.000 | 72.000 | 63.000 | 285.000 | 171.000 |
| 200 a. C. | 1.200.000 | 720.000 | 336.000 | 60.000 | 84.000 | 350.000 | 210.000 |
| 100 a. C. | 1.500.000 | 930.000 | 420.000 | 45.000 | 105.000 | 415.000 | 249.000 |
| 0/1 d. C. | 1.750.000 | 1.137.500 | 472.500 | 17.500 | 122.500 | 480.000 | 288.000 |
| 100 d. C. | 2.050.000 | 1.394.000 | 553.500 | 0 | 102.500 | 500.000 | 300.000 |
| 200 d. C. | 2.450.000 | 1.592.500 | 735.000 | 0 | 122.500 | 605.000 | 363.000 |
| 300 d. C. | 2.950.000 | 1.829.000 | 973.500 | 0 | 147.500 | 710.000 | 426.000 |
| 400 d. C. | 3.550.000 | 2.130.000 | 1.242.500 | 0 | 177.500 | 815.000 | 489.000 |
| 500 d. C. | 4.876.000 | 2.828.080 | 1.804.120 | 0 | 243.800 | 920.000 | 552.000 |
| 600 d. C. | 5.750.000 | 3.277.500 | 2.185.000 | 0 | 287.500 | 1.045.000 | 627.000 |
| 700 d. C. | 6.650.000 | 3.724.000 | 2.593.500 | 0 | 332.500 | 1.170.000 | 702.000 |
| 800 d. C. | 7.588.500 | 4.173.675 | 3.035.400 | 0 | 379.425 | 1.295.000 | 777.000 |

La migración nórdica procede principalmente de Dinamarca, Escania y Noruega, con aportes posteriores limitados de Finlandia. La migración no nórdica equivale, como modelo acumulativo, al 60 % de la migración nórdica y procede de comunidades germánicas no fundacionales y de Europa oriental. No crea nuevas Casas Mayores ni se integra automáticamente en el linaje valinari: sus familias se incorporan sobre todo a comunidades mestizas, portuarias, artesanales, agrícolas y dependientes.

Las cifras migratorias son llegadas brutas acumuladas, no población viva adicional: incluyen pérdidas por enfermedad, naufragio, guerra, retorno, mortalidad y absorción demográfica. Por eso no deben sumarse mecánicamente a la población total.

### Integración acumulativa consolidada

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

El Canon V16 incorpora de forma coordinada las actualizaciones acumulativas sobre educación, logística naval, ganadería, recursos naturales, hogar, parentesco, cultura naval y finanzas. Estas materias forman un sistema histórico: la educación produce especialistas; la logística conecta territorios; la ganadería y los recursos sostienen la producción; los hogares organizan cuidado, herencia y pertenencia; la Armada protege rutas; y las finanzas convierten excedentes y conocimiento en infraestructura, industria y capacidad estatal.

La integración conserva límites materiales y sociales: la disponibilidad de un barco no demuestra por sí sola la viabilidad de una misión; la presencia geológica no equivale a extracción; la ganadería requiere agua, forraje, transporte y recepción; y las cifras de población, barcos, animales, minerales o producción requieren comprobación física, económica y administrativa.

La endogamia valinari es religiosa, política y social, con continuidad hereditaria de rasgos poblacionales sin genotipo único obligatorio. Las poblaciones locales, esclavizadas, liberadas, mestizas y portuarias mantienen historias jurídicas diferenciadas. La Armada combina protección, comercio, auxilio, coerción, conquista y transporte militar, bajo separación entre competencias civiles, financieras y militares. OceanNet mantiene servicios civiles y militares diferenciados.

Númenor corresponde a Terranova; Tol Eressëa es una entidad distinta; Barad Nimras/Gibraltar continúa como base arrendada desde 1815; y Ceuta y Melilla no se incorporan automáticamente como distritos federales.

La respuesta combina investigación de cuentas, inventarios de garantías, liquidación de entidades inviables y continuidad de pagos esenciales. Los propietarios y administradores responsables soportan pérdidas antes de recibir apoyo público. La supervisión posterior exige reservas, identificación de compromisos y cuentas contrastables, con aplicación territorial desigual. La crisis constituye un antecedente de regulación bancaria, no un banco central moderno plenamente desarrollado.

### Industria, canal y fiscalidad contemporánea

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Durante los siglos XVIII y XIX, el crédito y la deuda pública financian minas, máquinas, ferrocarriles, puertos y obras interoceánicas. El presupuesto debe registrar el coste de operación y mantenimiento, además de la construcción inicial. Los peajes del canal atienden servicio, deuda, reparación y obligaciones territoriales conforme a sus normas.

Las crisis de 1929 y 2008 incorporan nuevos instrumentos de supervisión, protección de depósitos y continuidad del crédito productivo. Son episodios diferentes de la crisis de Armenelos. Desde la reforma federal de 1958, los mecanismos presupuestarios coordinan competencias comunes y territoriales; OceanNet, operativa inicialmente desde 1959, facilita posteriormente pagos e información sin eliminar el riesgo financiero.

Este desarrollo institucional no modifica las cifras de ECON-03 ni crea un nuevo agregado de PIB. La financiación educativa vigente conserva el reparto aprobado: 75 % federal, 24 % territorial y 1 % de la Corona mediante Becas Reales de Educación y los programas patrimoniales asociados.

### Esclavitud dependencia y reforma

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La Crisis de la Custodia de los siglos III–V y la reforma de 450–500 d. C. limitan la esclavización, protegen a personas amparadas por tratados, regulan registros y manumisión y condenan la coerción sexual. La reforma no equivale a una abolición inmediata. La fecha general de abolición y sus calendarios territoriales siguen pendientes de fijación expresa.

### COFOVAL y el fomento económico federal

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La Corporación Federal Valinari de Fomento y Desarrollo (COFOVAL) se funda en 1839 para financiar infraestructura, producción, ciencia aplicada, capacidades laborales y desarrollo territorial. Antes de su creación existen fondos de puerto, crédito mercantil, obras de la Corona, cajas de Casa y consorcios municipales, pero no se denominan COFOVAL.

Su apropiación fiscal anual evoluciona como proporción del PIB contemporáneo: 0,10 % (1839–1869), 0,15 % (1870–1913), 0,25 % (1914–1945), 0,40 % (1946–1980), 0,50 % (1981–2000), 0,55 % (2001–2025) y 0,60 % en 2026. El sobre bruto de financiación movilizada, que incluye la apropiación y añade préstamos y cofinanciación efectivamente comprometidos, puede alcanzar respectivamente hasta 0,20 %, 0,35 %, 0,55 %, 0,85 %, 1,10 %, 1,25 % y 1,40 % del PIB. El sobre no se suma a la apropiación como gasto adicional.

Sobre el PIB federal PPA central de 65,50 billones en 2026, COFOVAL dispone de 393.000 millones PPA de apropiación anual. Su cartera de proyectos puede movilizar hasta 917.000 millones PPA, incluidos los 393.000 millones; el saldo de hasta 524.000 millones requiere financiación no fiscal contratada y no constituye obligación automática del Tesoro.

La distribución de la apropiación 2026 es: industria y electrónica 20 %; energía y recursos 18 %; transporte, puertos, agua e infraestructura 15 %; agricultura y seguridad alimentaria 10 %; ciencia y tecnología 10 %; capacitación productiva 8 %; salud y vivienda 8 %; desarrollo territorial 5 %; cultura y patrimonio 2 %; administración, auditoría y contingencia 4 %. Las proporciones suman 100 %. Educación pública permanece en su partida canónica separada de 6 % del PIB; las Becas Reales no financian plantas industriales.

Dentro del rubro de industria y electrónica, 78.600 millones PPA se destinan en 2026 a fomento de industria, electrónica y semiconductores. De ellos, el modelo presupuestario asigna 50 % a cofinanciación de inversión fabril; 20 % a I+D aplicada; 12 % a proveedores, reparación y sustitución; 10 % a infraestructura habilitante de energía, agua y ambiente; y 8 % a formación técnica, estándares y certificación. Esta asignación está incluida en el presupuesto de COFOVAL; no se añade nuevamente a la inversión sectorial.

La industria electrónica se desarrolla en el marco de la alternativa selectiva: capacidad nacional de diseño, componentes maduros, electrónica de potencia, sensores, encapsulado, prueba, reparación y reciclaje; importación diversificada de equipos y componentes de frontera. El PIB canónico de 65,50 billones no aumenta: el valor añadido electrónico y su ecosistema ya se contabilizan dentro de ECON-03 y no se suman por segunda vez. COFOVAL financia proyectos, pero no sustituye a reguladores, universidades, bancos ni gobiernos territoriales y no certifica por sí mismo proyectos que financia.

La envolvente de planificación industrial de 2026 estima 52–73 mil millones de componentes semiconductores empaquetados demandados anualmente y 6–9 millones de obleas equivalentes de 300 mm de demanda física. La capacidad nominal federal es 7,0–8,8 millones de obleas equivalentes; con una utilización de 82–88 %, la producción efectiva objetivo es 5,7–7,7 millones. Se fija como objetivo local de salida 5,2–7,2 millones de obleas y 40–55 mil millones de componentes empaquetados al año. La cobertura nacional se mide por familia y valor: 80–90 % para la demanda crítica y 60–75 % para el mercado total. Estas son metas canónicas de capacidad, no cifras auditadas de producción realizada.

### Balance físico de suministro: escenario central 2026

Estado del material recuperado: HIPÓTESIS. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

El balance central separa demanda, producción local, importaciones, exportaciones y variación de inventarios. Las cantidades de obleas se expresan en millones equivalentes de 300 mm por año. La identidad es producción local + importaciones = demanda interna + exportaciones + aumento neto de inventario.

| Familia | Demanda interna | Producción local | Importaciones | Exportaciones | Aumento de inventario | Balance |
| --- | --- | --- | --- | --- | --- | --- |
| Lógica madura, MCU y control | 2,40 | 2,65 | 0,15 | 0,35 | 0,05 | 2,80 = 2,80 |
| Analógico, discretos, potencia | 1,85 | 1,95 | 0,10 | 0,15 | 0,05 | 2,05 = 2,05 |
| Memoria y almacenamiento | 1,50 | 1,00 | 0,55 | 0,05 | 0,00 | 1,55 = 1,55 |
| RF, comunicaciones, imagen, sensores | 1,05 | 0,90 | 0,20 | 0,05 | 0,00 | 1,10 = 1,10 |
| Procesadores y aceleradores avanzados | 0,70 | 0,40 | 0,35 | 0,05 | 0,00 | 0,75 = 0,75 |
| TOTAL | 7,50 | 6,90 | 1,35 | 0,65 | 0,10 | 8,25 = 8,25 |

El caso suma 7,50 millones de obleas de demanda, 6,90 de producción local, 1,35 de importación, 0,65 de exportación y 0,10 de aumento de inventario. La disponibilidad local neta es 6,15 millones, cerca del 82 % de la demanda física; la cobertura por valor permanece en 60–75 % porque los procesadores avanzados importados tienen mayor valor unitario. En componentes empaquetados, el caso central es 48 mil millones locales + 14 importados = 62 de demanda + 2 exportados. Son metas de planificación coherentes, no datos auditados.

La carga de diseño para los polos distribuidos es 12–20 TWh anuales de electricidad firme y 50–90 millones de m³ de agua bruta, sujetos a estudios de cuenca, recirculación, licencias y disponibilidad local. La cadena se reparte entre 4–6 polos, 10–12 líneas maduras/especializadas, 2–3 líneas avanzadas de menor volumen, 6–10 centros de encapsulado y prueba y 2–3 centros de investigación de procesos y materiales. Ninguna región obtiene capacidad o consumo territorial por atribución automática: las fichas de polo deben verificar agua, energía, transporte, trabajadores, recursos, ambiente y contingencias.

### 12. Regla primordial de nomenclatura urbana

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Toda ciudad, puerto, asentamiento, provincia urbana o nodo administrativo nuevo debe usar el formato Nombre ficticio (nombre real). El nombre ficticio procederá preferentemente de Tolkien, especialmente del sindarin, y se escogerá por relación con la región, función, paisaje, linaje o tradición local. Los nombres de *Juego de Tronos* solo se usarán como segunda reserva cuando no exista un nombre tolkieniano pertinente.

Los nombres inventados fuera de Tolkien o *Juego de Tronos* deberán justificar su relación lingüística, geográfica o histórica con el territorio. No se incorporará una ciudad ficticia usando únicamente el nombre real. Las ciudades ya adoptadas conservan su identidad canónica hasta una revisión formal de la tabla de renombramiento.

### Fragmentación, recuperación y memoria institucional

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Entre 1000 a. C. y 1000 d. C., la inmigración exterior hacia las comunidades valinarias procede principalmente de Dinamarca, Escania y Noruega. Las llegadas se producen mediante partidas reiteradas y quedan limitadas por transporte, supervivencia, recepción, alimentos, agua, capacidad portuaria, conflictos y disponibilidad de asentamientos. Las cifras absolutas y la distribución entre procedencias y destinos permanecen abiertas; no existe una cuota migratoria obligatoria ni una deuda demográfica acumulada.

### 17.2. Escala acumulativa de las entidades

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Entidad | Componentes | Superficie aproximada | Población 2026 |
| --- | --- | --- | --- |
| Valinor | Isla y territorio histórico | 32.800 km² | 16 millones |
| Valinor a Tyl | Valinor, Tol Eressëa y Systreyjar | 53.200 km² | 26 millones |
| Aranath Valinor | Valinor a Tyl, Nosselië Toliva y América y Caribe directos | 5,4–5,5 millones km² | 481 millones |
| Gwaith constitucional / ECON-03 operativo | Reino más ocho externas federales; Harnen solo en el ámbito operativo | Superficie total no conciliada; septentrionales incluidos en su cuenta | 515,5 constitucionales; 523,5 operativos |
| Beleg Valinor | Federación más protectorados y enclaves | Perímetro extendido; superficie pendiente de conciliación | 724,5–879,5 millones; rango rector con residuo por asignar |

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados.. Datos del antecedente: Gwaith Aear; Gran Valinor más aliados extranjeros; Sin frontera única; 1.115,5–1.515,5 millones.

### 17.3. Composición política

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Gwaith Valinor constitucional comprende el Reino completo y ocho unidades federales externas: Malaca, Hawái, Fiyi, Polinesia, Micronesia, Eryndor, Islandia y Groenlandia. Cuenta 515,5 millones y 64,98 billones PPA. Harnen es protectorado de Beleg, con Rhunost dentro; al incluir su cuenta una sola vez se obtiene el agregado operativo ECON-03 de 523,5 millones y 65,50 billones. A092-R03.

### 17.4. Política cultural de la expansión oriental

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

> comercio + diplomacia + ciencia + traducción + educación + archivo + navegación

### 19. Ampliación demográfica y económica de Eryndor y Harnen

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [ANTECEDENTE SUSTITUIDO — NO VIGENTE; prevalece la sección 20].

La escala anterior de 10 millones de habitantes y 0,70 billones PPA se sustituye por una estructura federal más desarrollada. El aumento se explica por urbanización planificada, migración interna, inversión portuaria, industrialización energética y concentración de servicios financieros.

### 19.1. Indicadores vigentes

Estado del material recuperado: ANTECEDENTE. Ampliación de 22 millones sustituida por los valores proporcionales y A092.

| Estado | Población 2026 | PIB PPA | PIB nominal | Urbanización | Peso dentro de Gwaith Valinor |
| --- | --- | --- | --- | --- | --- |
| Eryndor (Baréin) | 4 millones | 0,32 billones | 0,24 billones | 95 % | 0,5 % |
| Harnen (Omán) | 18 millones | 1,08 billones | 0,78 billones | 82 % | 1,6 % |
| Total | 22 millones | 1,40 billones | 1,02 billones | 84 % | 2,1 % |

Rhunost (Musandam) queda incluido dentro de Harnen: aporta aproximadamente 0,8 millones de habitantes, 0,09 billones PPA y una urbanización del 88 %.

### 19.2. Curva histórica revisada

Estado del material recuperado: ANTECEDENTE. Ampliación de 22 millones sustituida por los valores proporcionales y A092.

| Año | Población conjunta | Urbanización | PIB PPA conjunto | Infraestructura dominante |
| --- | --- | --- | --- | --- |
| 1850 | 0,60 millones | 20 % | 0,015 billones | Puertos, pesca, oasis y comercio regional |
| 1900 | 1,10 millones | 30 % | 0,035 billones | Vapor, aduanas, telégrafo y navegación comercial |
| 1950 | 2,80 millones | 48 % | 0,11 billones | Petróleo, electricidad, carreteras y primeros aeropuertos |
| 2000 | 11,50 millones | 76 % | 0,62 billones | Petroquímica, autopistas, puertos y finanzas |
| 2026 | 22,00 millones | 84 % | 1,40 billones | Energía avanzada, astilleros, banca, tecnología y defensa |

### 19.3. Producción y empleo en 2026

Estado del material recuperado: ANTECEDENTE. Ampliación de 22 millones sustituida por los valores proporcionales y A092.

| Sector | Participación del PIB | Empleo directo e indirecto |
| --- | --- | --- |
| Energía, refinación y petroquímica | 24 % | 13 % |
| Finanzas, seguros y servicios empresariales | 22 % | 18 % |
| Puertos, logística y transporte | 18 % | 16 % |
| Industria, astilleros y mantenimiento naval | 15 % | 17 % |
| Tecnología, telecomunicaciones y OceanNet | 9 % | 11 % |
| Turismo, educación y salud | 7 % | 15 % |
| Minería, pesca y agricultura | 5 % | 10 % |

### 19.4. Recalculo de los niveles superiores

Estado del material recuperado: ANTECEDENTE. Ampliación de 22 millones sustituida por los valores proporcionales y A092.

La ampliación se incorpora dentro de la jerarquía acumulativa y no se suma dos veces:

Aranath Valinor: 481 millones; no cambia, porque Eryndor es externo al Reino y Harnen es protectorado.

Gwaith Valinor: queda fijado en 523,5 millones.

PIB PPA de Gwaith Valinor: pasa a un rango de 61–73 billones, con valor central aproximado de 67 billones.

Beleg Valinor: pasa a aproximadamente 720–870 millones y 82–108 billones PPA.

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados. - Gwaith Aear: pasa a aproximadamente 1.120–1.520 millones y 107–143 billones PPA, dependiendo de los aliados incluidos.

La ampliación convierte el Golfo de Omán y Baréin en uno de los principales polos industriales, financieros y navales de la Federación. Las cifras anteriores de 10 millones y 0,70 billones quedan reemplazadas y no deben utilizarse en cálculos posteriores.

### 20. Corrección de la ampliación federal — valores proporcionales

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [POBLACIÓN VIGENTE; AGREGADOS DE PIB HISTÓRICOS] — 30 de octubre de 2026.

Se revierte la ampliación excesiva de la sección anterior. Los totales de PIB PPA de esta sección registran el cálculo previo a ECON-03 y quedan sustituidos por los rangos de la sección 23; se conservan solo para trazabilidad. La población y el tratamiento contable indicados aquí siguen vigentes. Eryndor conserva su condición de unidad federal directa; Harnen conserva su condición de protectorado y participa en el agregado operativo por sus vínculos fiscales, monetarios, defensivos y comerciales.

### Valores vigentes de los nuevos estados

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Estado | Población 2026 | PIB PPA | Urbanización |
| --- | --- | --- | --- |
| Eryndor (Baréin) | 2,0 millones | 0,18 billones | 97,5 % |
| Harnen (Omán) | 8,0 millones | 0,52 billones | 82,5 % |
| Total incorporado | 10,0 millones | 0,70 billones | 85,5 % |

Rhunost (Musandam) queda incluido dentro de Harnen y no se suma nuevamente.

### Totales actualizados por adición proporcional

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Entidad | Valor anterior | Aporte Eryndor + Harnen | Valor vigente |
| --- | --- | --- | --- |
| Gwaith Valinor | 508 millones | +10 millones | 523,5 millones |
| PIB PPA de Gwaith Valinor | 60–72 billones | +0,70 billones | 60,7–72,7 billones |
| Beleg Valinor | 700–850 millones | +10 millones | 724,5–879,5 millones (rango rector A092; componentes exteriores aún por conciliar) |
| PIB PPA de Beleg Valinor | 80–105 billones | +0,70 billones | 80,7–105,7 billones |

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados.. Datos del antecedente: Gwaith Aear; 1.100–1.500 millones; +10 millones; 1.115,5–1.515,5 millones.

| PIB PPA de Gwaith Aear | 105–140 billones | +0,70 billones | 105,7–140,7 billones |
| --- | --- | --- | --- |

Aranath Valinor permanece en 481 millones, porque Eryndor es externo al Reino y Harnen es protectorado. Esta es la única actualización necesaria para reflejar su incorporación contable sin modificar la jerarquía política.

Las cifras demográficas de la sección 19 —22 millones— y sus PIB quedan sustituidas por esta corrección proporcional y por las referencias de la sección 23. El reparto territorial ECON-03, completado en la sección 36, fija las cuentas propias de Eryndor y Harnen y una urbanización combinada de 85,5 %.

### 21. Auditoría de coherencia y decisiones resueltas

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [CANON CERRADO — ACTUALIZADO] — decisiones registradas el 31 de octubre de 2026.

Todos los archivos del proyecto quedan integrados como anexos documentales del Canon Maestro Unificado. Los documentos con versiones anteriores no se eliminan, pero sus datos no prevalecen sobre las resoluciones siguientes.

### Resolución A — escala demográfica principal

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Versión vigente actualmente aplicada: Valinor 16 millones; Valinor a Tyl 26 millones; Aranath Valinor 481 millones; Gwaith Valinor 523,5 millones con Islandia y Groenlandia como territorios federales autónomos, Eryndor como unidad federal directa y Harnen como protectorado incluido en el agregado operativo.

Versión anterior presente en varios anexos: 245.050.000 habitantes federales.

Decisión vigente: mantener la escala acumulativa 16/26/481/523,5, con Islandia y Groenlandia como territorios federales autónomos.

### Resolución B — estatus de Nosselië Toliva

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Algunas enmiendas la sitúan dentro de Aranath Valinor.

Otras la describen como adición federal de Gwaith Valinor.

Decisión del autor: Nosselië Toliva pertenece a Aranath Valinor y, por medio del Reino, forma parte de Gwaith Valinor. No se suma como unidad federal externa ni como miembro federal directo.

### Resolución C — estatus de Eryndor y Harnen

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Los documentos antiguos los presentan como protectorados.

Eryndor es unidad federal directa y Harnen es protectorado de Beleg Valinor.

Decisión del autor: Harnen permanece como protectorado, con Rhunost como provincia autónoma dentro de Harnen.

### Resolución D — Systreyjar

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

En algunas tablas aparece como parte de Valinor a Tyl.

En otras aparece como adición de la Federación.

Decisión del autor: Systreyjar permanece dentro de Valinor a Tyl.

### Resolución F — relación constitucional y contable entre el Reino y la Federación

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Aranath Valinor es un reino constituyente de Gwaith Valinor, con gobierno y administración propios dentro del marco federal.

Todo territorio integrante de Aranath Valinor pertenece también a Gwaith Valinor por medio del Reino. Esto incluye expresamente Nosselië Toliva.

Las unidades territoriales del Reino no son miembros federales directos salvo decisión expresa. Eryndor se vincula directamente al gobierno federal; Harnen se vincula como protectorado de Beleg Valinor; Rhunost permanece dentro de Harnen.

La consolidación económica sigue una sola vía: PIB de Gwaith Valinor = PIB de Aranath Valinor + PIB de las unidades federales externas al Reino. El PIB del Reino se obtiene sumando sus territorios internos. Nosselië se cuenta en el Reino y, por esa vía, en la Federación; nunca se vuelve a sumar como adición externa.

La sección 23 fija los rangos agregados de referencia. El reparto ECON-03 y la conciliación territorial quedaron completados en las secciones 35 y 36, con suma territorial sin doble conteo.

### Resolución E — cronologías y convenios culturales

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Las fechas de contactos con Fenicia, Mileto, Nínive, Alejandría, Constantinopla, Bayt al-Hikma, Al-Qarawiyyin, universidades europeas, japonesas, rusas y norteamericanas pertenecen a épocas distintas. Por decisión del autor, se registran como fechas aproximadas con carácter histórico, no como fechas documentales exactas.

### Regla de precedencia consolidada

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Las resoluciones A–F fijan la precedencia vigente. Los documentos anteriores se conservan como anexos históricos y ninguna cifra o estatus sustituido se reincorpora por aparecer en un documento fuente.

### 22.4. Centros industriales

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

> minería → refinación → obleas → circuitos → procesadores → motores → turbinas → vehículos → sistemas militares.

### 23.3. Distribución sectorial federal revisada

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La antigua distribución porcentual macroeconómica queda sustituida por las matrices territoriales A–J de las secciones 35–36. No se fuerza un porcentaje federal único para actividades que atraviesan varios sectores: defensa, electrónica, astilleros y agroindustria se clasifican según la actividad productiva efectivamente realizada. Cada valor añadido se registra una sola vez.

### Equivalencia de generaciones

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La clase Voronwë inicia construcción en 2022 y sus primeras unidades entran en servicio desde 2026; releva por lotes a Círdan IV hasta 2033. Incorpora mayor automatización, sensores distribuidos, margen eléctrico, drones y mantenimiento predictivo.

### 26. Clases principales de la Armada Valinoreana

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Clase/familia | Tipo vigente | Función principal |
| --- | --- | --- |
| Telperion | Portaaviones nuclear | Proyección aérea oceánica, mando y disuasión |
| Anárion, Elwing, Aldarion | Portaaviones convencionales de flota | Cobertura aérea oceánica y operaciones de ala embarcada |
| Varda | Portaaviones ligero STOVL/ASW | Defensa insular, guerra antisubmarina y presencia regional |
| Arnor | Submarino estratégico | Disuasión y patrulla estratégica |
| Eärendil | Submarino nuclear de ataque | Guerra antisubmarina, inteligencia y escolta |
| Tolfalas | Submarino convencional/AIP | Vigilancia oceánica, defensa litoral y estrechos |
| Aeglos / Falathar | Submarino especial / rescate | Operaciones especiales, inteligencia oceanográfica y rescate |
| Gil-galad | Destructor | Defensa aérea, escolta y mando de grupo |
| Círdan / Voronwë | Fragata multipropósito | Guerra antisubmarina, escolta y vigilancia oceánica |
| Calenport | Corbeta oceánica | Escolta ligera, patrulla y defensa regional |
| Eglarest | Corbeta de generaciones anteriores | Patrulla litoral y defensa regional histórica |
| Pelargir / Aranath / Forlond / Andúnië | Buques anfibios y de desembarco | Proyección limitada, evacuación, apoyo y desembarco |
| Sírënandë / Nosselië | Patrulleros oceánicos y rápidos | Seguridad marítima, vigilancia y protección de rutas |
| Amon Sûl / Menel | Guerra de minas e inspección | Limpieza de rutas y contramedidas de minas |
| Aulë / Andúnië / Rómenna / Estë / Galdor / Palantír / Alcarondas | Auxiliares por misión | Reabastecimiento, transporte, hospital, reparación, rescate, ciencia y mando |
| Menel / Esgaroth / Abyssal | Sistemas no tripulados aéreos, de superficie y submarinos | Reconocimiento, cartografía, vigilancia y apoyo a contramedidas |

### Integración canónica AM1 — Armada 1875–2026

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La decisión AM1 adopta una flota de dos escalones: una masa crítica sostenible de fragatas multipropósito, corbetas oceánicas, submarinos convencionales, patrulleros, medios anfibios y auxiliares producidos en series mantenibles; y una punta de lanza tecnológica de portaaviones, submarinos nucleares, destructores de defensa aérea, sensores y mando avanzado. La punta de lanza no desplaza los fondos necesarios para dotaciones, municiones, mantenimiento, bases y logística.

### Composiciones de referencia

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Año | Estado de la cifra | Composición resumida | Total |
| --- | --- | --- | --- |
| 1945 | Reconstrucción AM1, no inventario medido | 8 portaaviones, 18 cruceros, 54 destructores, 42 fragatas, 42 corbetas, 18 patrulleros, 38 submarinos, 28 anfibios, 20 MCM y 100 auxiliares | 368 |
| 1960 | Reconstrucción AM1, no inventario medido | 9 portaaviones, 16 cruceros, 48 destructores, 52 fragatas, 50 corbetas, 20 lanchas misilísticas, 50 patrulleros, 46 submarinos, 32 anfibios, 20 MCM y 65 auxiliares | 408 |
| 1980 | Composición canónica de referencia | 7 portaaviones, 14 cruceros, 36 destructores, 56 fragatas/escoltas, 50 corbetas, 24 lanchas misilísticas, 60 patrulleros, 42 submarinos, 34 anfibios, 26 MCM y 78 auxiliares | 427 |
| 2026 | Inventario estructural canónico; no equivale a disponibilidad observada | 11 portaaviones, 54 submarinos, 190 combatientes de superficie, 34 anfibios, 220 unidades de patrulla/vigilancia/servicio y 106 auxiliares | 615 plataformas |

Las categorías de 1980 se cuentan por separado: corbetas, lanchas misilísticas, patrulleros y auxiliares no se solapan. En 2026 las 220 plataformas comprenden 80 OPV, 70 patrulleros rápidos, 30 unidades MCM, 20 hidrográficos y 20 vehículos navales no tripulados. Los 106 auxiliares comprenden 20 petroleros, 18 reabastecedores, 12 transportes, 10 hospitales, 12 reparadores, 10 oceanográficos, 8 de salvamento y 16 de mando/apoyo especializado. Los 34 anfibios comprenden 14 buques de asalto y 20 LPD/LSD. Así, el total se compone de 595 buques tripulados y 20 plataformas no tripuladas.

La estimación de 449 disponibles (7 portaaviones, 38 submarinos, 130 combatientes de superficie, 34 anfibios, 170 unidades de patrulla/servicio y 70 auxiliares) se conserva como hipótesis de planificación. No es una tasa de disponibilidad medida ni implica que las unidades estén concentradas en un teatro.

### Ciclo de vida y modernización

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Desde 1945 cada casco se diseña con margen de crecimiento y recibe una modernización integral principal de media vida. Reparaciones, sustitución de componentes y actualizaciones menores posteriores no se contabilizan como un segundo refit integral. La vida típica de los combatientes mayores es de 30–40 años; patrulleros, lanchas y vehículos no tripulados tienen ciclos más cortos. La continuidad de un nombre de clase representa generaciones sucesivas y no un único diseño o casco de 85 años.

La transición Círdan–Voronwë queda normalizada así: construcción de Círdan IV desde 1995 y servicio desde 2000; construcción de Voronwë desde 2022, primeras entradas en servicio desde 2026 y relevo por lotes hasta 2033. El agregado de 64 fragatas de 2026 incluye generaciones Círdan IV y Voronwë; el reparto exacto por casco no está fijado.

### Industria, tecnología y sostenimiento

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La industria naval evoluciona desde los arsenales de vapor y siderurgia de 1750–1880 hacia turbinas, motores, submarinos y aviación entre 1880–1945; después desarrolla portaaviones, propulsión nuclear, electrónica, radar y sonar, y desde 1969 integra logística y mando mediante OceanNet. Entre 1980 y 2026 amplía construcción modular, propulsión eléctrica, sensores AESA, guerra electrónica, vehículos no tripulados, mantenimiento predictivo y fabricación nacional selectiva de componentes críticos. Las tecnologías extranjeras se adoptan, adaptan o coproducen cuando hay una etapa demostrable y una base industrial compatible; no se atribuye fabricación local automática a toda tecnología utilizada.

La planificación presupuestaria adopta como regla comparativa la misma proporción del PIB estadounidense dedicada al Department of the Navy, contando Navy y Marine Corps de forma homogénea. Para 2026 la referencia de AM1 es aproximadamente 0,9 % del PIB, equivalente a unos 589,5 mil millones PPA sobre el PIB federal canónico de 65,50 billones PPA. Es una equivalencia de planificación: PPA no es presupuesto nominal y la serie histórica, especialmente 1980, requiere armonizar apropiaciones, gasto ejecutado y perímetro institucional antes de fijar montos canónicos comparables.

La infantería de Marina mantiene una fuerza expedicionaria para evacuación, respuesta rápida, defensa de puertos y apoyo a territorios; el rango de 150.000–190.000 activos y 80.000–120.000 reservistas se trata como objetivo de planificación, no como censo de personal verificado. Las fichas de clase y los perfiles técnicos completos se encuentran en [[12_Militar/03_Armada/AM1 Armada 1875-2026|AM1 Armada 1875–2026]], [[12_Militar/03_Armada/Clases navales 1980|Clases navales de referencia 1980]] y [[12_Militar/03_Armada/Clases navales 2026|Clases navales de referencia 2026]].

### 24. Integración total de actualizaciones acumulativas

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [CANON VIGENTE] — integración confirmada el 30 de octubre de 2026.

Quedan incorporadas al Canon Maestro todas las actualizaciones acumulativas y enmiendas del proyecto relativas a:

cronología atlántica y descubrimiento del Caribe, Tol Eressëa, Terranova y Valinor;

Valinor a Tyl, Aranath Valinor, Gwaith Valinor, Beleg Valinor y Gwaith Aear;

Arnor, Calenardhon Austral, Sírënandë, Venezuela Federal, Provincia del Orinoco, Colombia Costera y Panamá Federal;

Nosselië Toliva, Systreyjar, Númenor y los territorios insulares;

Eryndor como unidad federal directa; Harnen como protectorado y Rhunost como provincia autónoma interna;

población, urbanización, ciudades, provincias y economía;

industrialización desde 1850;

industria naval, aeronáutica, blindada, espacial y electrónica;

motores, turbinas, procesadores, circuitos y OceanNet;

exportaciones militares y tecnológicas;

política cultural, traducción, bibliotecas y acumulación del conocimiento;

regla primordial de nomenclatura urbana;

coordenadas textuales y polígonos ficticios aprobados.

ANTECEDENTE CUANTITATIVO para Gwaith Aear: el rango de aliados no está conciliado; rige A092-R04 y el registro de aliados. La escala vigente queda fijada en: Valinor 16 millones; Valinor a Tyl 26 millones; Aranath Valinor 481 millones; Gwaith Valinor 523,5 millones; Beleg Valinor 724,5–879,5 millones (rango rector A092; componentes exteriores aún por conciliar); Gwaith Aear 1.115,5–1.515,5 millones. El PIB PPA vigente de Gwaith Valinor es 60,85–70,20 billones, con valor central de 65,50 billones; el PIB nominal estimado se actualiza proporcionalmente a 45,6–52,9 billones, con centro de 49,2 billones.

Los documentos fuente permanecen como anexos de trazabilidad. Cuando contienen cifras o estatus anteriores, prevalecen las resoluciones más recientes de este canon y no se produce doble contabilización.

### 29.5. Consecuencias

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

> El dominio marítimo decide las guerras terrestres del Pacífico.

### 31.3. Primera estimación del VAB (sustituida por sección 36)

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Antecedente ECON-03 de trabajo, año 2026: se conserva el PIB PPA central de 7,200 billones, equivalente a 135.849 dólares por habitante. Con el supuesto provisional de impuestos netos sobre productos equivalente al 5 % del PIB, el VAB territorial estimado es 6,840 billones. Las participaciones de la matriz se aplican al VAB, no al PIB. La confianza es baja-media: se basa en el perfil productivo canónico y en la redistribución explícita de las categorías que antes estaban mezcladas; todavía no existen cuentas de producción e insumo por industria.

| Código ECON-03 | Sector | Participación del VAB | VAB estimado (billones PPA) |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 12 % | 0,8208 |
| B | Minería y energía | 14 % | 0,9576 |
| C | Manufactura y reparación | 20 % | 1,3680 |
| D | Construcción e infraestructura | 4 % | 0,2736 |
| E | Comercio, alojamiento y servicios personales | 7 % | 0,4788 |
| F | Transporte y logística | 9 % | 0,6156 |
| G | Finanzas, seguros y servicios empresariales | 14 % | 0,9576 |
| H | Información, telecomunicaciones, software e I+D | 9 % | 0,6156 |
| I | Servicios inmobiliarios | 3 % | 0,2052 |
| J | Administración y servicios sociales | 8 % | 0,5472 |
| Subtotal VAB |  | 100 % | 6,8400 |
| Impuestos netos sobre productos (ajuste provisional) |  |  | 0,3600 |
| PIB PPA territorial |  |  | 7,2000 |

La reclasificación distribuye el antiguo 24 % de manufactura entre C (20 %) y D (4 %); separa el bloque combinado de comercio, puertos y logística en E (7 %) y F (9 %); y redistribuye finanzas y servicios empresariales entre G (14 %) e inmobiliario (I, 3 %). Agroindustria procesada queda en C; la producción agrícola, pesquera y forestal primaria queda en A. El movimiento de carga no se cuenta como producción local.

El supuesto fiscal uniforme y esta matriz quedan sustituidos por la cuenta territorial de Colombia Costera de la sección 36. Se conservan aquí únicamente para trazabilidad de la primera ronda.

### 32.2. Primera estimación del VAB (sustituida por sección 36)

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Antecedente ECON-03 de trabajo, año 2026: se conserva el PIB PPA central de 2,500 billones, equivalente a 147.059 dólares por habitante. Con el supuesto provisional de impuestos netos sobre productos equivalente al 5 % del PIB, el VAB territorial estimado es 2,375 billones. Las participaciones de la matriz se aplican al VAB. La confianza es baja-media: las participaciones derivan del perfil económico fijado para Panamá, reclasificado para separar actividades mezcladas; no hay cuentas sectoriales de producción e insumos.

| Código ECON-03 | Sector | Participación del VAB | VAB estimado (billones PPA) |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 8 % | 0,19000 |
| B | Minería y energía | 6 % | 0,14250 |
| C | Manufactura y reparación | 18 % | 0,42750 |
| D | Construcción e infraestructura | 4 % | 0,09500 |
| E | Comercio, alojamiento y servicios personales | 7 % | 0,16625 |
| F | Transporte y logística | 18 % | 0,42750 |
| G | Finanzas, seguros y servicios empresariales | 21 % | 0,49875 |
| H | Información, telecomunicaciones, software e I+D | 12 % | 0,28500 |
| I | Servicios inmobiliarios | 3 % | 0,07125 |
| J | Administración y servicios sociales | 3 % | 0,07125 |
| Subtotal VAB |  | 100 % | 2,37500 |
| Impuestos netos sobre productos (ajuste provisional) |  |  | 0,12500 |
| PIB PPA territorial |  |  | 2,50000 |

El bloque original de canal, puertos, transporte y logística se separa entre E (4 %) y F (18 %); los servicios financieros y empresariales quedan en G (21 %) y los inmobiliarios en I (3 %). Manufactura, tecnología y agroindustria procesada se asignan a C y A, respectivamente. La construcción física del canal y los puertos va a D; la operación y los servicios de tránsito van a F. No se añade el valor bruto de la carga ni el valor de reposición de la infraestructura.

El supuesto fiscal uniforme y esta matriz quedan sustituidos por la cuenta territorial de Panamá Federal de la sección 36. Se conservan aquí únicamente para trazabilidad de la primera ronda.

El sistema bancario panameño se especializa en financiación de comercio, crédito portuario y naval, seguros marítimos, gestión de riesgos, arbitraje, pagos regionales y servicios digitales. Su PIB financiero mide servicios efectivamente producidos en Panamá, no el valor nominal de depósitos, préstamos, carga en tránsito ni operaciones contabilizadas en Valinor o Eryndor.

El PIB combinado de Colombia Costera y Panamá Federal es 9,7 billones PPA. Ambos son territorios del Reino: sus cifras están incluidas en el PIB del Reino, no se agregan otra vez al total federal. Estas dos jurisdicciones ocupan 9,7 de los 19,4 billones del bloque territorial americano-caribeño utilizado en el cierre provisional ECON-03.

Referencias cartográficas de equivalencia: IGAC, Atlas de Colombia, división político-administrativa, edición 2024; INEC de Panamá, división política-administrativa por provincia y comarca, corte 2022. Las cifras demográficas y económicas son propias del canon ficticio, no estimaciones de esas fuentes.

### 33. ECON-03: cálculo del valor añadido por sector y territorio

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [MARCO Y PRIMERAS MATRICES — cifras iniciales conservadas como antecedentes; las matrices vigentes y la conciliación actual constan en las secciones 35 y 36] — 31 de octubre de 2026.

### 33.4. Formato de entrega y confianza

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Cada territorio tendrá columnas A–J, subtotal VAB, ajuste de impuestos netos sobre productos, PIB PPA, población, PIB por habitante, método y confianza. La conciliación sumará primero territorios del Reino y luego Reino más unidades federales externas. Las matrices iniciales de Colombia Costera, Panamá Federal, Arnor, Calenardhon Austral y Sírënandë se conservan como primera pasada. Las secciones 35 y 36 fijan cuentas territoriales propias para las 21 unidades; las tablas de esta sección son antecedentes de la primera ronda.

### 33.5. Primera matriz ECON-03: Colombia Costera y Panamá Federal

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Las dos matrices de las secciones 31.3 y 32.2 son la primera estimación de VAB por territorio. Reasignan a categorías no solapadas los perfiles sectoriales anteriores y escalan el subtotal de VAB al 95 % del PIB objetivo. El 5 % restante se registra como impuestos netos sobre productos, supuesto común provisional. Como referencia histórica de la primera pasada, antes de la tasa diferenciada de la sección 34, la conciliación era:

| Cuenta 2026 (billones PPA) | Colombia Costera | Panamá Federal | Total conjunto |
| --- | --- | --- | --- |
| VAB estimado | 6,840 | 2,375 | 9,215 |
| Impuestos netos sobre productos (5 % PIB, supuesto) | 0,360 | 0,125 | 0,485 |
| PIB territorial de referencia | 7,200 | 2,500 | 9,700 |
| Población | 53 M | 17 M | 70 M |
| PIB PPA por habitante | 135.849 | 147.059 | 138.571 |

Los valores son una estimación de la primera pasada, no datos observados. Sus impuestos al 5 % quedaron reemplazados por tasas territoriales diferenciadas y cuentas de producción modeladas en la sección 34; los PIB territoriales centrales se mantienen como objetivos de referencia. Los dos territorios están dentro del Reino: los 9,7 billones se incluyen una sola vez en el PIB del Reino y, por ese conducto, en la Federación.

### 33.6. Primera matriz ECON-03 para Arnor

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La primera matriz, sustituida fiscalmente por la conciliación de la sección 34, usa como escenario central el PIB PPA de 20 billones dentro del rango vigente de 18–22 billones y la población canónica de 145 millones. El supuesto inicial del 5 % deja 19 billones de VAB; la sección 34 sustituye ese ajuste fiscal por la tasa diferenciada de Arnor. El PIB por habitante es 137.931 dólares PPA en el centro; el rango es 124.138–151.724 dólares. Arnor representa aproximadamente el 34,2 % del centro actual del PIB del Reino.

| Código ECON-03 | Sector | Participación del VAB | VAB estimado central (billones PPA) |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 4 % | 0,7600 |
| B | Minería y energía | 10 % | 1,9000 |
| C | Manufactura y reparación | 25 % | 4,7500 |
| D | Construcción e infraestructura | 7 % | 1,3300 |
| E | Comercio, alojamiento y servicios personales | 8 % | 1,5200 |
| F | Transporte y logística | 7 % | 1,3300 |
| G | Finanzas, seguros y servicios empresariales | 15 % | 2,8500 |
| H | Información, telecomunicaciones, software e I+D | 13 % | 2,4700 |
| I | Servicios inmobiliarios | 4 % | 0,7600 |
| J | Administración y servicios sociales | 7 % | 1,3300 |
| Subtotal VAB |  | 100 % | 19,0000 |
| Impuestos netos sobre productos (supuesto 5 % del PIB) |  |  | 1,0000 |
| PIB PPA de referencia |  |  | 20,0000 |

La participación alta de C y H representa la fabricación de chips, radares, motores y electrónica industrial establecida en el canon. B recoge minería y energía; G y J incluyen los servicios financieros, profesionales, administrativos y sociales necesarios para una provincia de 145 millones de habitantes. Los bienes militares se incluyen en C o H según el producto y no se suman de nuevo.

| Escenario | PIB PPA (billones) | VAB estimado (billones) | Impuestos netos estimados (billones) | PIB PPA por habitante |
| --- | --- | --- | --- | --- |
| Bajo | 18,0 | 17,1 | 0,9 | 124.138 |
| Centro de trabajo | 20,0 | 19,0 | 1,0 | 137.931 |
| Alto | 22,0 | 20,9 | 1,1 | 151.724 |

La matriz de esta sección es un antecedente de la primera ronda, no una observación estadística. Su ajuste fiscal y sus coeficientes técnicos quedaron sustituidos por las cuentas propias de la sección 36, que también fija la distribución entre las siete provincias, las ciudades y las zonas rurales.

### 33.7. Objetivos de PIB para Calenardhon Austral y Sírënandë

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Se fijan los siguientes objetivos de planificación para la ronda territorial 2026. Los rangos expresan incertidumbre alrededor del centro de trabajo y no constituyen matrices de VAB; estas se elaborarán con la clasificación de la sección 33.2 y el ajuste fiscal separado de la sección 33.1.

### 33.7. Objetivos de PIB para Calenardhon Austral y Sírënandë

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Territorio | Población 2026 | PIB PPA objetivo | Centro de trabajo | PIB PPA por habitante en el centro | Base de coherencia |
| --- | --- | --- | --- | --- | --- |
| Calenardhon Austral | 88 millones | 10,5–12,5 billones | 11,5 billones | 130.682 dólares | Agroindustria, metales, astilleros, turbinas, motores navales, generadores y electrónica de potencia |
| Sírënandë | 55 millones | 3,1–3,9 billones | 3,5 billones | 63.636 dólares | Minería, hidroelectricidad, refinación y procesamiento local, manufactura, puertos y logística |

### 33.7. Objetivos de PIB para Calenardhon Austral y Sírënandë

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Calenardhon Austral se sitúa cerca de la productividad media de Arnor, coherente con un polo urbano e industrial de alta densidad. Sírënandë conserva una productividad menor que los núcleos tecnológicos del Reino, pero elevada frente a economías extractivas simples porque procesa una parte sustancial de sus minerales y energía dentro del territorio. Ambas lecturas son hipótesis de planificación, no estadísticas observadas.

La suma parcial de Valinor a Tyl, Arnor, Calenardhon Austral, Sírënandë y Nosselië Toliva es 39,1 billones. Colombia Costera y Panamá Federal agregan 9,7, por lo que estas siete unidades suman 48,8. Para alcanzar el centro de 58,5 quedan 9,7 billones para Venezuela Federal, Provincia del Orinoco y los cinco territorios caribeños. La asignación cerrada de esos 9,7 billones se presenta en la sección 34.

Las matrices siguientes convierten los objetivos en estimaciones sectoriales iniciales. No cambian por sí solas los objetivos del Reino ni de la Federación; ambos siguen sujetos a conciliación territorial completa.

### 33.8. Matrices iniciales ECON-03: Calenardhon Austral y Sírënandë

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La primera matriz de Calenardhon y Sírënandë, conservada para trazabilidad, usa el supuesto uniforme del 5 %. La matriz vigente y diferenciada por territorio, incluida la estimación de producción e insumos, figura en la sección 34. Las participaciones siguen siendo una hipótesis de modelación, no datos observados.

### Calenardhon Austral

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Población: 88 millones. PIB PPA central: 11,5 billones. VAB: 10,925 billones. Ajuste de impuestos netos sobre productos: 0,575 billones. PIB por habitante: 130.682 dólares PPA.

| Código | Sector | Participación del VAB | VAB estimado (billones PPA) |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 10 % | 1,0925 |
| B | Minería y energía | 11 % | 1,20175 |
| C | Manufactura y reparación | 31 % | 3,38675 |
| D | Construcción e infraestructura | 6 % | 0,6555 |
| E | Comercio, alojamiento y servicios personales | 7 % | 0,76475 |
| F | Transporte y logística | 8 % | 0,8740 |
| G | Finanzas, seguros y servicios empresariales | 10 % | 1,0925 |
| H | Información, telecomunicaciones, software e I+D | 8 % | 0,8740 |
| I | Servicios inmobiliarios | 3 % | 0,32775 |
| J | Administración y servicios sociales | 6 % | 0,6555 |
| Subtotal VAB |  | 100 % | 10,9250 |
| Impuestos netos sobre productos (supuesto 5 % del PIB) |  |  | 0,5750 |
| PIB PPA de referencia |  |  | 11,5000 |

La cuota elevada de C recoge agroindustria, metalurgia, material ferroviario, astilleros, turbinas, motores navales, generadores y electrónica de potencia. B incluye energía y extracción; A conserva la producción primaria; H incluye I+D, software y telecomunicaciones. La fabricación militar se cuenta en C o H por actividad, no como una suma adicional.

### Sírënandë

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

Población: 55 millones. PIB PPA central: 3,5 billones. VAB: 3,325 billones. Ajuste de impuestos netos sobre productos: 0,175 billones. PIB por habitante: 63.636 dólares PPA.

| Código | Sector | Participación del VAB | VAB estimado (billones PPA) |
| --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 12 % | 0,3990 |
| B | Minería y energía | 28 % | 0,9310 |
| C | Manufactura y reparación | 20 % | 0,6650 |
| D | Construcción e infraestructura | 6 % | 0,1995 |
| E | Comercio, alojamiento y servicios personales | 6 % | 0,1995 |
| F | Transporte y logística | 8 % | 0,2660 |
| G | Finanzas, seguros y servicios empresariales | 6 % | 0,1995 |
| H | Información, telecomunicaciones, software e I+D | 6 % | 0,1995 |
| I | Servicios inmobiliarios | 2 % | 0,0665 |
| J | Administración y servicios sociales | 6 % | 0,1995 |
| Subtotal VAB |  | 100 % | 3,3250 |
| Impuestos netos sobre productos (supuesto 5 % del PIB) |  |  | 0,1750 |
| PIB PPA de referencia |  |  | 3,5000 |

B recoge extracción minera y generación hidroeléctrica. C representa refinación y procesamiento local de cobre, aluminio, níquel y tierras raras, además de manufactura. F comprende puertos y logística; el valor bruto de minerales exportados y de carga en tránsito no se suma al VAB. La participación de I es baja por el perfil territorial y debe revisarse cuando se fijen ciudades, urbanización y límites definitivos.

| Territorio | Población | PIB bajo–centro–alto (billones PPA) | VAB central | Impuestos netos centrales | PIB por habitante central |
| --- | --- | --- | --- | --- | --- |
| Calenardhon Austral | 88 M | 10,5–11,5–12,5 | 10,925 | 0,575 | 130.682 |
| Sírënandë | 55 M | 3,1–3,5–3,9 | 3,325 | 0,175 | 63.636 |
| Conjunto | 143 M | 13,6–15,0–16,4 | 14,250 | 0,750 | 104.895 |

En los extremos del rango, Calenardhon tendría un VAB de 9,975–11,875 billones y Sírënandë de 2,945–3,705 billones, manteniendo las tasas diferenciadas de la sección 34. El conjunto aporta 15,0 billones al centro territorial del Reino; esta cifra ya estaba incluida en la conciliación de 58,5 billones y no debe sumarse otra vez. Confianza: baja-media; las participaciones sectoriales, en especial el tamaño manufacturero de Sírënandë, requieren validación con población urbana, empleo, capacidad instalada y comercio interior.

### 34. ECON-03 integrado: territorios, población, PIB y cuentas modeladas

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Estado: [MATRICES DE REFERENCIA HISTÓRICAS — sustituidas para las 21 unidades por las secciones 35 y 36] — 31 de octubre de 2026.

### 34.1. Límites y población (sustituidos para Venezuela y Orinoco por la sección 35)

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Como antecedente sustituido parcialmente por la sección 35: Venezuela Federal comprende Distrito Capital y los estados Aragua, Barinas, Carabobo, Cojedes, Falcón, Lara, Mérida, Miranda, Nueva Esparta, Portuguesa, Sucre, Táchira, Trujillo, Yaracuy, Zulia y La Guaira. Se excluyen los siete estados asignados a Orinoco. Población propuesta: 50 millones. Provincia del Orinoco comprende, del lado venezolano, Amazonas, Bolívar, Delta Amacuro, Anzoátegui, Monagas, Guárico y Apure; del lado colombiano, Arauca, Casanare, Meta, Vichada, Guaviare, Guainía, Vaupés, Amazonas, Caquetá y Putumayo. Se fija una población de 15 millones: 10 millones en la parte venezolana y 5 millones en la colombiana. Los límites corresponden a unidades administrativas completas. Colombia Costera conserva sus departamentos fijados en 31.1 y excluye los diez departamentos colombianos asignados a Orinoco.

Los 87 millones restantes del Reino se distribuyen entre Venezuela, Orinoco y cinco jurisdicciones caribeñas. La asignación caribeña usa las islas y archipiélagos como límites de cuenta, sin sumar espacios marítimos como territorio adicional:

### 34.1. Límites y población (sustituidos para Venezuela y Orinoco por la sección 35)

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Unidad | Población propuesta |
| --- | --- |
| Trinidad | 8 M |
| Tobago | 1 M |
| Bahamas | 6 M |
| Bermudas | 2 M |
| Barbados | 5 M |
| Total Caribe | 22 M |

### 34.2. PIB objetivo por unidad y conciliación

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Se mantienen las anclas económicas previas. El residuo del Reino y el agregado externo se distribuyen para que los totales territoriales reproduzcan los centros de referencia. Las nuevas cifras son estimaciones de planificación, no observaciones estadísticas.

### 34.2. PIB objetivo por unidad y conciliación

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Unidad | Población (M) | PIB PPA (billones) | PIB por habitante (USD PPA) |
| --- | --- | --- | --- |
| Valinor a Tyl | 26,00 | 3,10 | 119.231 |
| Arnor | 145,00 | 20,00 | 137.931 |
| Calenardhon Austral | 88,00 | 11,50 | 130.682 |
| Sírënandë | 55,00 | 3,50 | 63.636 |
| Venezuela Federal | 50,00 | 4,50 | 90.000 |
| Provincia del Orinoco | 15,00 | 2,20 | 146.667 |
| Colombia Costera | 53,00 | 7,20 | 135.849 |
| Panamá Federal | 17,00 | 2,50 | 147.059 |
| Trinidad | 8,00 | 1,20 | 150.000 |
| Tobago | 1,00 | 0,10 | 100.000 |
| Bahamas | 6,00 | 0,80 | 133.333 |
| Bermudas | 2,00 | 0,40 | 200.000 |
| Barbados | 5,00 | 0,50 | 100.000 |
| Nosselië Toliva | 10,00 | 1,00 | 100.000 |
| Malaca | 16,00 | 2,97 | 185.625 |
| Hawái | 4,00 | 1,35 | 337.500 |
| Fiyi | 3,00 | 0,42 | 140.000 |
| Polinesia | 2,50 | 0,35 | 140.000 |
| Micronesia | 1,50 | 0,26 | 173.333 |
| Eryndor | 2,00 | 0,18 | 90.000 |
| Harnen | 8,00 | 0,52 | 65.000 |
| Reino | 481 | 58,50 | 121.622 |
| Unidades externas | 42,5 | 7,00 | 163.514 |
| Federación | 523,5 | 65,50 | 125.119 |

### 34.2. PIB objetivo por unidad y conciliación

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Del residuo de 9,7 billones del Reino: Venezuela 4,5; Orinoco 2,2; Trinidad 1,2; Tobago 0,1; Bahamas 0,8; Bermudas 0,4; Barbados 0,5. Los territorios ya anclados suman 48,8; el conjunto cierra en 58,5.

Desglose operativo externo de 7,00 billones: Malaca 2,97; Hawái 1,35; Fiyi 0,42; Polinesia 0,35; Micronesia 0,26; Eryndor 0,18; Harnen 0,52; Islandia 0,55; Groenlandia 0,40. Las primeras ocho unidades federales directas incluyen Islandia y Groenlandia; Harnen es protectorado y se incluye en el agregado operativo por su vinculación fiscal, monetaria, defensiva y comercial. El PIB federal operativo resulta 58,50 + 7,00 = 65,50 billones PPA, redondeado a aproximadamente 66, sin alterar el estatus constitucional de Harnen.

### 34.3. Cuentas modeladas de producción e insumos

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Cada matriz separa producción bruta, consumo intermedio y VAB. Coeficientes técnicos provisionales comunes representan el VAB como proporción de la producción: producción bruta = VAB / coeficiente; consumo intermedio = producción bruta − VAB. Son parámetros de planificación, no datos observados.

### 34.3. Cuentas modeladas de producción e insumos

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Código | Sector | VAB como % de la producción modelada |
| --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 65 % |
| B | Minería y energía | 60 % |
| C | Manufactura y reparación | 35 % |
| D | Construcción e infraestructura | 50 % |
| E | Comercio, alojamiento y servicios personales | 55 % |
| F | Transporte y logística | 50 % |
| G | Finanzas, seguros y servicios empresariales | 65 % |
| H | Información, telecomunicaciones, software e I+D | 55 % |
| I | Servicios inmobiliarios | 70 % |
| J | Administración y servicios sociales | 80 % |

### 34.3. Cuentas modeladas de producción e insumos

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Los impuestos netos sobre productos se diferencian por jurisdicción como porcentaje del PIB objetivo. Con ello se sustituye la cuña uniforme del 5 % para esta ronda, aunque las tasas siguen siendo estimaciones.

### 34.4. Matrices iniciales de las 21 unidades (sustituidas para siete territorios por la sección 35)

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La tabla presenta participaciones A–J del VAB. Los valores monetarios están en billones PPA. Producción bruta e insumos se calculan con los coeficientes de 34.3. Para obtener el valor sectorial en una columna A–J, multiplicar la participación por el VAB total de la fila.

| Territorio | Población M | PIB | Impuesto neto % | Impuestos netos | VAB | A % | B % | C % | D % | E % | F % | G % | H % | I % | J % | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Valinor a Tyl | 26,00 | 3,10 | 4,5% | 0,13950 | 2,96050 | 1% | 4% | 18% | 5% | 8% | 10% | 20% | 20% | 6% | 8% | 5,62150 | 2,66100 |
| Arnor | 145,00 | 20,00 | 4,6% | 0,92000 | 19,08000 | 4% | 10% | 25% | 7% | 8% | 7% | 15% | 13% | 4% | 7% | 37,77308 | 18,69308 |
| Calenardhon Austral | 88,00 | 11,50 | 4,3% | 0,49450 | 11,00550 | 10% | 11% | 31% | 6% | 7% | 8% | 10% | 8% | 3% | 6% | 22,53183 | 11,52633 |
| Sírënandë | 55,00 | 3,50 | 3,8% | 0,13300 | 3,36700 | 12% | 28% | 20% | 6% | 6% | 8% | 6% | 6% | 2% | 6% | 6,45377 | 3,08677 |
| Venezuela Federal | 50,00 | 4,50 | 4,8% | 0,21600 | 4,28400 | 8% | 15% | 24% | 7% | 9% | 8% | 11% | 8% | 3% | 7% | 8,42864 | 4,14464 |
| Provincia del Orinoco | 15,00 | 2,20 | 3,2% | 0,07040 | 2,12960 | 10% | 26% | 22% | 7% | 5% | 8% | 5% | 6% | 2% | 9% | 4,11810 | 1,98850 |
| Colombia Costera | 53,00 | 7,20 | 5,0% | 0,36000 | 6,84000 | 12% | 14% | 20% | 4% | 7% | 9% | 14% | 9% | 3% | 8% | 12,98593 | 6,14593 |
| Panamá Federal | 17,00 | 2,50 | 6,2% | 0,15500 | 2,34500 | 8% | 6% | 18% | 4% | 7% | 18% | 21% | 12% | 3% | 3% | 4,51706 | 2,17206 |
| Trinidad | 8,00 | 1,20 | 4,5% | 0,05400 | 1,14600 | 5% | 15% | 20% | 5% | 8% | 15% | 12% | 8% | 5% | 7% | 2,21499 | 1,06899 |
| Tobago | 1,00 | 0,10 | 5,5% | 0,00550 | 0,09450 | 12% | 8% | 12% | 6% | 18% | 12% | 8% | 8% | 8% | 8% | 0,17302 | 0,07852 |
| Bahamas | 6,00 | 0,80 | 6,5% | 0,05200 | 0,74800 | 3% | 2% | 8% | 6% | 20% | 20% | 15% | 10% | 6% | 10% | 1,35762 | 0,60962 |
| Bermudas | 2,00 | 0,40 | 5,0% | 0,02000 | 0,38000 | 1% | 0% | 5% | 4% | 12% | 10% | 38% | 12% | 8% | 10% | 0,64543 | 0,26543 |
| Barbados | 5,00 | 0,50 | 5,8% | 0,02900 | 0,47100 | 5% | 1% | 12% | 6% | 20% | 12% | 12% | 10% | 8% | 14% | 0,85524 | 0,38424 |
| Nosselië Toliva | 10,00 | 1,00 | 5,5% | 0,05500 | 0,94500 | 8% | 2% | 8% | 8% | 20% | 18% | 8% | 10% | 8% | 10% | 1,71309 | 0,76809 |
| Malaca | 16,00 | 2,97 | 4,0% | 0,11880 | 2,85120 | 2% | 4% | 38% | 8% | 6% | 12% | 8% | 14% | 3% | 5% | 6,20199 | 3,35079 |
| Hawái | 4,00 | 1,35 | 5,3% | 0,07155 | 1,27845 | 2% | 5% | 18% | 7% | 9% | 12% | 10% | 20% | 5% | 12% | 2,44304 | 1,16459 |
| Fiyi | 3,00 | 0,42 | 5,0% | 0,02100 | 0,39900 | 14% | 8% | 12% | 7% | 14% | 12% | 6% | 8% | 5% | 14% | 0,72231 | 0,32331 |
| Polinesia | 2,50 | 0,35 | 5,5% | 0,01925 | 0,33075 | 10% | 5% | 10% | 8% | 20% | 16% | 8% | 8% | 5% | 10% | 0,60577 | 0,27502 |
| Micronesia | 1,50 | 0,26 | 4,0% | 0,01040 | 0,24960 | 8% | 10% | 15% | 7% | 12% | 20% | 8% | 10% | 3% | 7% | 0,47717 | 0,22757 |
| Eryndor | 2,00 | 0,18 | 5,0% | 0,00900 | 0,17100 | 1% | 10% | 12% | 4% | 8% | 10% | 32% | 10% | 5% | 8% | 0,30710 | 0,13610 |
| Harnen | 8,00 | 0,52 | 3,5% | 0,01820 | 0,50180 | 5% | 25% | 15% | 7% | 5% | 16% | 8% | 7% | 3% | 9% | 0,94277 | 0,44097 |

La producción bruta menos el consumo intermedio equivale a VAB; VAB más impuestos netos equivale a PIB. La producción bruta interterritorial no se suma entre unidades para formar PIB: solo se agregan VAB e impuestos. Cada unidad entra una sola vez.

### 34.5. Conciliación inicial de cuentas (sustituida por las secciones 35 y 36)

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Ámbito | PIB | Impuestos netos | VAB | Producción bruta estimada | Consumo intermedio estimado | Población |
| --- | --- | --- | --- | --- | --- | --- |
| Reino | 58,50 | 2,70390 | 55,79610 | 95,47967 | 39,68355 | 481,00 M |
| Externas | 7,00 | 0,31820 | 6,68180 | 12,26838 | 5,18651 | 42,50 M |
| Federación | 65,50 | 3,02210 | 62,47790 | 107,20049 | 44,72259 | 523,50 M |

### 34.6. Estado de la primera ronda (actualizado por secciones 35 y 36)

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Antecedente de primera ronda: PIB por unidad para las 21 jurisdicciones y matrices modeladas con tasas y coeficientes generales. Las secciones 35 y 36 sustituyen ese modelo para las 21 unidades con cuentas territoriales propias aprobadas como canon.

Cierre actualizado: las cuentas territoriales pendientes quedan desarrolladas en la sección 36. La sección 35 rige para Venezuela Federal, Provincia del Orinoco y las cinco unidades caribeñas. Las matrices de 34.4 y los coeficientes comunes de 34.3 son antecedentes, no cuentas vigentes.

### 35.3. Cuentas propias de producción e insumos

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Jurisdicción | Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- | --- |
| Venezuela Federal | A | Agricultura, silvicultura y pesca | 0,50400 | 0,16128 | 0,34272 |
| Venezuela Federal | B | Minería y energía | 1,10793 | 0,46533 | 0,64260 |
| Venezuela Federal | C | Manufactura y reparación | 2,63631 | 1,60815 | 1,02816 |
| Venezuela Federal | D | Construcción e infraestructura | 0,56581 | 0,26593 | 0,29988 |
| Venezuela Federal | E | Comercio, alojamiento y servicios personales | 0,64260 | 0,25704 | 0,38556 |
| Venezuela Federal | F | Transporte y logística | 0,63467 | 0,29195 | 0,34272 |
| Venezuela Federal | G | Finanzas, seguros y servicios empresariales | 0,62832 | 0,15708 | 0,47124 |
| Venezuela Federal | H | Información, telecomunicaciones, software e I+D | 0,52726 | 0,18454 | 0,34272 |
| Venezuela Federal | I | Servicios inmobiliarios | 0,18360 | 0,05508 | 0,12852 |
| Venezuela Federal | J | Administración y servicios sociales | 0,37485 | 0,07497 | 0,29988 |
| Provincia del Orinoco | A | Agricultura, silvicultura y pesca | 0,34348 | 0,13052 | 0,21296 |
| Provincia del Orinoco | B | Minería y energía | 1,06480 | 0,51110 | 0,55370 |
| Provincia del Orinoco | C | Manufactura y reparación | 1,17128 | 0,70277 | 0,46851 |
| Provincia del Orinoco | D | Construcción e infraestructura | 0,27104 | 0,12197 | 0,14907 |
| Provincia del Orinoco | E | Comercio, alojamiento y servicios personales | 0,17174 | 0,06526 | 0,10648 |
| Provincia del Orinoco | F | Transporte y logística | 0,33405 | 0,16369 | 0,17037 |
| Provincia del Orinoco | G | Finanzas, seguros y servicios empresariales | 0,15211 | 0,04563 | 0,10648 |
| Provincia del Orinoco | H | Información, telecomunicaciones, software e I+D | 0,20609 | 0,07831 | 0,12778 |
| Provincia del Orinoco | I | Servicios inmobiliarios | 0,06173 | 0,01914 | 0,04259 |
| Provincia del Orinoco | J | Administración y servicios sociales | 0,24572 | 0,05406 | 0,19166 |
| Trinidad | A | Agricultura, silvicultura y pesca | 0,08426 | 0,02696 | 0,05730 |
| Trinidad | B | Minería y energía | 0,34380 | 0,17190 | 0,17190 |
| Trinidad | C | Manufactura y reparación | 0,54571 | 0,31651 | 0,22920 |
| Trinidad | D | Construcción e infraestructura | 0,11019 | 0,05289 | 0,05730 |
| Trinidad | E | Comercio, alojamiento y servicios personales | 0,15280 | 0,06112 | 0,09168 |
| Trinidad | F | Transporte y logística | 0,29638 | 0,12448 | 0,17190 |
| Trinidad | G | Finanzas, seguros y servicios empresariales | 0,19100 | 0,05348 | 0,13752 |
| Trinidad | H | Información, telecomunicaciones, software e I+D | 0,14105 | 0,04937 | 0,09168 |
| Trinidad | I | Servicios inmobiliarios | 0,08426 | 0,02696 | 0,05730 |
| Trinidad | J | Administración y servicios sociales | 0,10285 | 0,02263 | 0,08022 |
| Tobago | A | Agricultura, silvicultura y pesca | 0,01620 | 0,00486 | 0,01134 |
| Tobago | B | Minería y energía | 0,01303 | 0,00547 | 0,00756 |
| Tobago | C | Manufactura y reparación | 0,02700 | 0,01566 | 0,01134 |
| Tobago | D | Construcción e infraestructura | 0,01031 | 0,00464 | 0,00567 |
| Tobago | E | Comercio, alojamiento y servicios personales | 0,02835 | 0,01134 | 0,01701 |
| Tobago | F | Transporte y logística | 0,02062 | 0,00928 | 0,01134 |
| Tobago | G | Finanzas, seguros y servicios empresariales | 0,01080 | 0,00324 | 0,00756 |
| Tobago | H | Información, telecomunicaciones, software e I+D | 0,01145 | 0,00389 | 0,00756 |
| Tobago | I | Servicios inmobiliarios | 0,01112 | 0,00356 | 0,00756 |
| Tobago | J | Administración y servicios sociales | 0,00969 | 0,00213 | 0,00756 |
| Bahamas | A | Agricultura, silvicultura y pesca | 0,03300 | 0,01056 | 0,02244 |
| Bahamas | B | Minería y energía | 0,02720 | 0,01224 | 0,01496 |
| Bahamas | C | Manufactura y reparación | 0,14248 | 0,08264 | 0,05984 |
| Bahamas | D | Construcción e infraestructura | 0,08160 | 0,03672 | 0,04488 |
| Bahamas | E | Comercio, alojamiento y servicios personales | 0,24129 | 0,09169 | 0,14960 |
| Bahamas | F | Transporte y logística | 0,24933 | 0,09973 | 0,14960 |
| Bahamas | G | Finanzas, seguros y servicios empresariales | 0,15370 | 0,04150 | 0,11220 |
| Bahamas | H | Información, telecomunicaciones, software e I+D | 0,11164 | 0,03684 | 0,07480 |
| Bahamas | I | Servicios inmobiliarios | 0,06411 | 0,01923 | 0,04488 |
| Bahamas | J | Administración y servicios sociales | 0,09350 | 0,01870 | 0,07480 |
| Bermudas | A | Agricultura, silvicultura y pesca | 0,00543 | 0,00163 | 0,00380 |
| Bermudas | B | Minería y energía | 0,00000 | 0,00000 | 0,00000 |
| Bermudas | C | Manufactura y reparación | 0,04222 | 0,02322 | 0,01900 |
| Bermudas | D | Construcción e infraestructura | 0,02764 | 0,01244 | 0,01520 |
| Bermudas | E | Comercio, alojamiento y servicios personales | 0,07355 | 0,02795 | 0,04560 |
| Bermudas | F | Transporte y logística | 0,06230 | 0,02430 | 0,03800 |
| Bermudas | G | Finanzas, seguros y servicios empresariales | 0,19000 | 0,04560 | 0,14440 |
| Bermudas | H | Información, telecomunicaciones, software e I+D | 0,06514 | 0,01954 | 0,04560 |
| Bermudas | I | Servicios inmobiliarios | 0,04282 | 0,01242 | 0,03040 |
| Bermudas | J | Administración y servicios sociales | 0,04750 | 0,00950 | 0,03800 |
| Barbados | A | Agricultura, silvicultura y pesca | 0,03413 | 0,01058 | 0,02355 |
| Barbados | B | Minería y energía | 0,00812 | 0,00341 | 0,00471 |
| Barbados | C | Manufactura y reparación | 0,13144 | 0,07492 | 0,05652 |
| Barbados | D | Construcción e infraestructura | 0,05233 | 0,02407 | 0,02826 |
| Barbados | E | Comercio, alojamiento y servicios personales | 0,15443 | 0,06023 | 0,09420 |
| Barbados | F | Transporte y logística | 0,09745 | 0,04093 | 0,05652 |
| Barbados | G | Finanzas, seguros y servicios empresariales | 0,07850 | 0,02198 | 0,05652 |
| Barbados | H | Información, telecomunicaciones, software e I+D | 0,06926 | 0,02216 | 0,04710 |
| Barbados | I | Servicios inmobiliarios | 0,05383 | 0,01615 | 0,03768 |
| Barbados | J | Administración y servicios sociales | 0,08242 | 0,01648 | 0,06594 |

### 35.4. Conciliación del Reino y estado de aceptación

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Quedan aprobados como canon sus límites, poblaciones, distribución urbana/rural, objetivos de PIB y cuentas de producción e insumos indicados aquí. La actualización de estos siete territorios queda cerrada. La sección 36 completa las cuentas territoriales pendientes: siete unidades del Reino, seis unidades federales directas y el protectorado de Harnen. En las secciones 33 y 34, las matrices y coeficientes anteriores se conservan solo como antecedentes.

### 36.1. Límites operativos y población urbana/rural

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Unidad | Población | Urbana | Rural/dispersa | Urbanización |
| --- | --- | --- | --- | --- |
| Valinor a Tyl | 26,00 M | 23,00 M | 3,00 M | 88,5 % |
| Arnor | 145,00 M | 131,50 M | 13,50 M | 90,7 % |
| Calenardhon Austral | 88,00 M | 80,00 M | 8,00 M | 90,9 % |
| Sírënandë | 55,00 M | 48,00 M | 7,00 M | 87,3 % |
| Colombia Costera | 53,00 M | 47,30 M | 5,70 M | 89,2 % |
| Panamá Federal | 17,00 M | 15,80 M | 1,20 M | 92,9 % |
| Nosselië Toliva | 10,00 M | 9,00 M | 1,00 M | 90,0 % |
| Malaca | 16,00 M | 14,80 M | 1,20 M | 92,5 % |
| Hawái | 4,00 M | 3,80 M | 0,20 M | 95,0 % |
| Fiyi | 3,00 M | 2,25 M | 0,75 M | 75,0 % |
| Polinesia | 2,50 M | 1,80 M | 0,70 M | 72,0 % |
| Micronesia | 1,50 M | 1,00 M | 0,50 M | 66,7 % |
| Eryndor | 2,00 M | 1,95 M | 0,05 M | 97,5 % |
| Harnen | 8,00 M | 6,60 M | 1,40 M | 82,5 % |

### Valinor a Tyl

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04486 | 0,01525 | 0,02961 |
| B | Minería y energía | 0,18797 | 0,06955 | 0,11842 |
| C | Manufactura y reparación | 1,18420 | 0,65131 | 0,53289 |
| D | Construcción e infraestructura | 0,28466 | 0,13664 | 0,14803 |
| E | Comercio, alojamiento y servicios personales | 0,37006 | 0,13322 | 0,23684 |
| F | Transporte y logística | 0,48533 | 0,18928 | 0,29605 |
| G | Finanzas, seguros y servicios empresariales | 0,77908 | 0,18698 | 0,59210 |
| H | Información, telecomunicaciones, software e I+D | 0,80014 | 0,20804 | 0,59210 |
| I | Servicios inmobiliarios | 0,21662 | 0,03899 | 0,17763 |
| J | Administración y servicios sociales | 0,27864 | 0,04180 | 0,23684 |
| Total |  | 4,63156 | 1,67106 | 2,96051 |

### Calenardhon Austral

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 1,64261 | 0,54206 | 1,10055 |
| B | Minería y energía | 2,03178 | 0,71112 | 1,32066 |
| C | Manufactura y reparación | 8,19014 | 4,66838 | 3,52176 |
| D | Construcción e infraestructura | 1,48151 | 0,71112 | 0,77039 |
| E | Comercio, alojamiento y servicios personales | 1,24256 | 0,47217 | 0,77039 |
| F | Transporte y logística | 1,49227 | 0,61183 | 0,88044 |
| G | Finanzas, seguros y servicios empresariales | 1,25777 | 0,37733 | 0,88044 |
| H | Información, telecomunicaciones, software e I+D | 1,13292 | 0,36253 | 0,77039 |
| I | Servicios inmobiliarios | 0,41271 | 0,08254 | 0,33017 |
| J | Administración y servicios sociales | 0,78611 | 0,12578 | 0,66033 |
| Total |  | 19,67038 | 8,66486 | 11,00552 |

### Malaca

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,12960 | 0,04406 | 0,08554 |
| B | Minería y energía | 0,36790 | 0,13980 | 0,22810 |
| C | Manufactura y reparación | 2,57966 | 1,49620 | 1,08346 |
| D | Construcción e infraestructura | 0,39917 | 0,19958 | 0,19958 |
| E | Comercio, alojamiento y servicios personales | 0,32719 | 0,12760 | 0,19958 |
| F | Transporte y logística | 0,61097 | 0,26883 | 0,34214 |
| G | Finanzas, seguros y servicios empresariales | 0,31680 | 0,08870 | 0,22810 |
| H | Información, telecomunicaciones, software e I+D | 0,46869 | 0,12655 | 0,34214 |
| I | Servicios inmobiliarios | 0,10560 | 0,02006 | 0,08554 |
| J | Administración y servicios sociales | 0,06789 | 0,01086 | 0,05702 |
| Total |  | 5,37347 | 2,52224 | 2,85120 |

### Hawái

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,03934 | 0,01377 | 0,02557 |
| B | Minería y energía | 0,09988 | 0,03596 | 0,06392 |
| C | Manufactura y reparación | 0,58111 | 0,32542 | 0,25569 |
| D | Construcción e infraestructura | 0,16885 | 0,07936 | 0,08949 |
| E | Comercio, alojamiento y servicios personales | 0,15981 | 0,05753 | 0,10228 |
| F | Transporte y logística | 0,26002 | 0,10661 | 0,15341 |
| G | Finanzas, seguros y servicios empresariales | 0,19264 | 0,05201 | 0,14063 |
| H | Información, telecomunicaciones, software e I+D | 0,29886 | 0,06874 | 0,23012 |
| I | Servicios inmobiliarios | 0,07795 | 0,01403 | 0,06392 |
| J | Administración y servicios sociales | 0,18264 | 0,02922 | 0,15341 |
| Total |  | 2,06110 | 0,78265 | 1,27844 |

### Polinesia

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,08133 | 0,03172 | 0,04961 |
| B | Minería y energía | 0,03482 | 0,01497 | 0,01985 |
| C | Manufactura y reparación | 0,08704 | 0,05396 | 0,03308 |
| D | Construcción e infraestructura | 0,05630 | 0,02984 | 0,02646 |
| E | Comercio, alojamiento y servicios personales | 0,10302 | 0,04018 | 0,06284 |
| F | Transporte y logística | 0,09188 | 0,04226 | 0,04961 |
| G | Finanzas, seguros y servicios empresariales | 0,03405 | 0,01090 | 0,02315 |
| H | Información, telecomunicaciones, software e I+D | 0,03456 | 0,01140 | 0,02315 |
| I | Servicios inmobiliarios | 0,01696 | 0,00373 | 0,01323 |
| J | Administración y servicios sociales | 0,03721 | 0,00744 | 0,02977 |
| Total |  | 0,57717 | 0,24640 | 0,33075 |

### Micronesia

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04092 | 0,01596 | 0,02496 |
| B | Minería y energía | 0,03807 | 0,01561 | 0,02246 |
| C | Manufactura y reparación | 0,08960 | 0,05466 | 0,03494 |
| D | Construcción e infraestructura | 0,03640 | 0,01893 | 0,01747 |
| E | Comercio, alojamiento y servicios personales | 0,04160 | 0,01664 | 0,02496 |
| F | Transporte y logística | 0,09984 | 0,04493 | 0,05491 |
| G | Finanzas, seguros y servicios empresariales | 0,02569 | 0,00822 | 0,01747 |
| H | Información, telecomunicaciones, software e I+D | 0,03353 | 0,01106 | 0,02246 |
| I | Servicios inmobiliarios | 0,01280 | 0,00282 | 0,00998 |
| J | Administración y servicios sociales | 0,02465 | 0,00468 | 0,01997 |
| Total |  | 0,44310 | 0,19351 | 0,24958 |

### Eryndor

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,00132 | 0,00046 | 0,00086 |
| B | Minería y energía | 0,00276 | 0,00105 | 0,00171 |
| C | Manufactura y reparación | 0,02036 | 0,01181 | 0,00855 |
| D | Construcción e infraestructura | 0,01644 | 0,00789 | 0,00855 |
| E | Comercio, alojamiento y servicios personales | 0,02332 | 0,00793 | 0,01539 |
| F | Transporte y logística | 0,02948 | 0,01238 | 0,01710 |
| G | Finanzas, seguros y servicios empresariales | 0,09427 | 0,02074 | 0,07353 |
| H | Información, telecomunicaciones, software e I+D | 0,03279 | 0,00885 | 0,02394 |
| I | Servicios inmobiliarios | 0,01460 | 0,00263 | 0,01197 |
| J | Administración y servicios sociales | 0,01094 | 0,00153 | 0,00941 |
| Total |  | 0,24628 | 0,07527 | 0,17101 |

### Harnen

Estado del material recuperado: ANTECEDENTE. Fuente Markdown anterior. Prevalecen los cierres y ámbitos A092.

| Código | Sector | Producción | Consumo intermedio | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04632 | 0,01621 | 0,03011 |
| B | Minería y energía | 0,25090 | 0,09032 | 0,16058 |
| C | Manufactura y reparación | 0,22173 | 0,12638 | 0,09534 |
| D | Construcción e infraestructura | 0,06887 | 0,03375 | 0,03513 |
| E | Comercio, alojamiento y servicios personales | 0,04182 | 0,01673 | 0,02509 |
| F | Transporte y logística | 0,11445 | 0,04921 | 0,06523 |
| G | Finanzas, seguros y servicios empresariales | 0,04301 | 0,01290 | 0,03011 |
| H | Información, telecomunicaciones, software e I+D | 0,03690 | 0,01181 | 0,02509 |
| I | Servicios inmobiliarios | 0,01255 | 0,00251 | 0,01004 |
| J | Administración y servicios sociales | 0,03023 | 0,00514 | 0,02509 |
| Total |  | 0,86678 | 0,36496 | 0,50181 |

### 36.6. Coherencia territorial y conciliación final

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Unidad | Población | PIB PPA | PIB por habitante (USD PPA) |
| --- | --- | --- | --- |
| Valinor a Tyl | 26,00000 M | 3,10000 | 119.231 |
| Arnor | 145,00000 M | 20,00000 | 137.931 |
| Calenardhon Austral | 88,00000 M | 11,50000 | 130.682 |
| Sírënandë | 55,00000 M | 3,50000 | 63.636 |
| Colombia Costera | 53,00000 M | 7,20000 | 135.849 |
| Panamá Federal | 17,00000 M | 2,50000 | 147.059 |
| Nosselië Toliva | 10,00000 M | 1,00000 | 100.000 |
| Malaca | 16,00000 M | 2,97000 | 185.625 |
| Hawái | 4,00000 M | 1,35000 | 337.500 |
| Fiyi | 3,00000 M | 0,42000 | 140.000 |
| Polinesia | 2,50000 M | 0,35000 | 140.000 |
| Micronesia | 1,50000 M | 0,26000 | 173.333 |
| Eryndor | 2,00000 M | 0,18000 | 90.000 |
| Harnen | 8,00000 M | 0,52000 | 65.000 |

| Unidad | Impuestos netos | VAB | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- |
| Valinor a Tyl | 0,13950 | 2,96051 | 4,63156 | 1,67106 |
| Arnor | 0,92000 | 19,08000 | 30,83561 | 11,75561 |
| Calenardhon Austral | 0,49450 | 11,00552 | 19,67038 | 8,66486 |
| Sírënandë | 0,13300 | 3,36700 | 6,01240 | 2,64540 |
| Colombia Costera | 0,36000 | 6,84000 | 12,08992 | 5,24992 |
| Panamá Federal | 0,15500 | 2,34500 | 4,11435 | 1,76935 |
| Nosselië Toliva | 0,05500 | 0,94500 | 1,57080 | 0,62580 |
| Malaca | 0,11880 | 2,85120 | 5,37347 | 2,52224 |
| Hawái | 0,07155 | 1,27844 | 2,06110 | 0,78265 |
| Fiyi | 0,02100 | 0,39900 | 0,70048 | 0,30148 |
| Polinesia | 0,01925 | 0,33075 | 0,57717 | 0,24640 |
| Micronesia | 0,01040 | 0,24958 | 0,44310 | 0,19351 |
| Eryndor | 0,00900 | 0,17101 | 0,24628 | 0,07527 |
| Harnen | 0,01820 | 0,50181 | 0,86678 | 0,36496 |

| Ámbito | Población | PIB PPA | Impuestos netos | VAB | Producción bruta | Consumo intermedio |
| --- | --- | --- | --- | --- | --- | --- |
| Resto del Reino | 394 M | 48,80000 | 2,25700 | 46,54300 | 78,92502 | 32,38200 |
| Unidades externas | 37 M | 7,00000 | 0,26820 | 5,78180 | 10,26838 | 4,48651 |
| Reino | 481 M | 58,50000 | 2,70390 | 55,79610 | 95,47967 | 39,68355 |
| Federación | 523,5 M | 65,50000 | 3,02210 | 62,47790 | 107,20049 | 44,72259 |

### 7.4. Antecedentes y nacimiento de OceanNet

Estado del material recuperado: ANTECEDENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

1959: OceanNet alcanza servicio digital institucional limitado, sin cobertura civil universal.

OceanNet administra logística, censos, finanzas, energía, transporte, investigación, educación, defensa civil y emergencias. La ficha técnica completa se conserva en OceanNet.

### Infraestructura troncal de telecomunicaciones — Decisión 2

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Valinor adopta una arquitectura equilibrada: fibra terrestre y submarina como troncal de capacidad; radio, microondas y redes móviles para acceso, movilidad y rutas alternativas; satélites para navegación, comunidades remotas y respaldo. OceanNet es la capa lógica de intercambio y servicios que utiliza esos medios, no un sinónimo de cable ni una operadora única. Los corredores se diseñan con rutas físicamente diversas, reparación de cables y respaldo energético. La conectividad civil, industrial crítica y militar conserva dominios de seguridad separados.

La norma de adelanto tecnológico permite hasta siete años de ventaja en despliegue amplio una vez que la etapa mundial pertinente ya es técnicamente demostrable. La cronología distingue investigación, prototipo, servicio limitado y expansión; no adelanta una aplicación a antes de que existan sus componentes. En 2026, los requisitos de cobertura, tráfico, presupuesto y disponibilidad siguen siendo objetivos de diseño hasta que operadores y reguladores los midan. El desarrollo completo, los corredores, la cronología y los controles constan en A090_Infraestructura_troncal_telecomunicaciones.

### Estrategia federal de la Tercera Revolución Industrial — Decisiones 1–14

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La Unión Valinoriana adopta una estrategia coordinada para semiconductores y electrónica, telecomunicaciones, continuidad, computación, automatización, ciberseguridad, identidad y servicios digitales, gobierno de datos, investigación, metrología, energía y materiales, acceso territorial, competencia y evaluación institucional. Las Decisiones 1 y 2 conservan sus desarrollos técnicos específicos en A089 y A090; las Decisiones 3–14 establecen principios y arquitectura de política pública.

La ventaja tecnológica de diez años es un objetivo selectivo de despliegue amplio en sectores prioritarios, medido por tecnología y rival concreto. La evaluación distingue investigación, demostración, prototipo, servicio limitado, adopción amplia, producción, mantenimiento y acceso social. Un prototipo o instalación singular no demuestra por sí solo una ventaja nacional. Este objetivo comparativo no sustituye la regla específica de siete años ya fijada para el adelanto de aplicación en telecomunicaciones; esa regla sigue vigente en su ámbito hasta una revisión expresa.

La gobernanza separa dirección política, autorización presupuestaria, ejecución, regulación y auditoría. Antes de crear instituciones se armonizan las funciones con organismos canónicos vigentes; una institución nueva solo se propone ante un vacío documentado. COFOVAL financia programas de fomento dentro de su mandato y partidas aprobadas, sin regular ni certificar sus propios proyectos. Universidades, territorios, operadores, empresas y Casas participan según competencias y reglas comunes.

Los programas avanzan mediante inventario y línea base, diseño y conciliación presupuestaria, piloto, evaluación independiente, escalamiento condicionado y revisión operativa. Las metas y capacidades no medidas se mantienen como objetivos, estimaciones o asuntos pendientes. La aprobación estratégica no aumenta automáticamente el PIB ni los presupuestos; toda financiación se concilia con ECON-03 y las partidas vigentes, evitando doble conteo de cofinanciación, I+D, inversión y valor añadido.

La política protege continuidad de servicios, privacidad, accesibilidad, derechos laborales, competencia, reparación y sostenibilidad energética y material. Los ejercicios y auditorías pueden ordenar corrección, pausa o cierre. La matriz de implementación, los estatus y el desarrollo de cada decisión constan en A091_Estrategia_digital_y_decisiones_3_14.

### Desarrollo histórico y evaluación de la Tercera Revolución Industrial (1950–2026)

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La transformación digital valinari enlaza electrónica, computación, telecomunicaciones, automatización y redes con la producción, la ciencia, el Estado y la vida civil. Su despliegue es acumulativo y desigual: investigación, demostración, prototipo, servicio limitado, adopción amplia, fabricación y mantenimiento son etapas distintas. El desarrollo temático, los efectos económicos y sociales, la gobernanza, los indicadores y los asuntos abiertos se reúnen en [[11_Ciencia y Tecnologia/Tercera Revolución Industrial 1950-2026|11_Ciencia y Tecnologia/Tercera Revolución Industrial 1950-2026]].

La secuencia conserva los hitos establecidos: preparación y redes precursoras de OceanNet en 1954–1958; Programa OceanNet en 1958; operación institucional limitada desde 1959; estatuto federal en 1968; consolidación institucional en 1969; protocolo federal común en 1983; apertura civil y comercial durante 1990–2000; expansión de banda ancha, centros de datos, plataformas y automatización hasta 2026. La cronología no confunde pruebas precursoras con operación, ni consolidación institucional con el inicio del servicio.

La digitalización mejora coordinación, logística, pagos, producción, investigación y servicios cuando hay energía, infraestructura, personal y procesos adecuados. También genera costos de operación, dependencia de proveedores, presión sobre agua y electricidad, concentración, cambios laborales, riesgos de privacidad y brechas territoriales. Sus efectos deben medirse por sector y territorio, separando inversión, valor añadido directo, productividad indirecta y costos, sin doble conteo ni atribución automática del crecimiento del PIB.

La expansión civil de OceanNet se trata como fase propia de sus antecedentes científicos, administrativos y navales. Infraestructura troncal, servicios civiles y redes militares mantienen funciones y controles diferenciados. Los servicios esenciales disponen de continuidad, atención alternativa y revisión humana de decisiones de alto impacto.

La gobernanza separa orientación, autorización presupuestaria, ejecución, operación, regulación y auditoría. Se utilizan instituciones canónicas existentes; una entidad nueva requiere justificar un vacío de competencia. Cada programa cuenta con responsable, línea base, presupuesto de ciclo de vida, fuentes conciliadas con ECON-03, piloto, evaluación independiente, mecanismo de reclamación y revisión. Los indicadores distinguen datos observados, estimaciones, objetivos y asuntos pendientes.

La ventaja selectiva de hasta diez años se evalúa por tecnología, rival y etapa equivalente. No sustituye la regla específica de siete años para telecomunicaciones. La aprobación de la estrategia no declara capacidades no medidas, no crea partidas automáticas y no modifica el PIB canónico. Las series de productividad y cobertura, presupuestos ejecutados, efectos laborales, nombres legales pendientes y comparaciones internacionales requieren inventario, fuente y auditoría.

### Normalización de nodos históricos

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Armenelos conserva su nombre y es una ciudad histórica y administrativa de Valinor, no la capital federal.

### Secuencia histórica de desarrollo

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

1959: servicio digital institucional inicial y limitado de OceanNet en la red federal.

### Orden de lectura y precedencia editorial

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

El canon vigente se lee según la precedencia de las secciones de decisiones consolidadas, no según el orden histórico de incorporación de los bloques acumulativos. Las secciones que indiquen “antecedente”, “sustituida” o “conservada para trazabilidad” no modifican los valores vigentes. La estructura política, los estatus territoriales, la nobleza y las cifras ECON-03 de las secciones consolidadas prevalecen sobre formulaciones anteriores.

### Casas Mayores pendientes de imagen

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Casa | Cabello del hombre | Cabello de la mujer |  |
| --- | --- | --- | --- |
| [[09_Politica/Casas Mayores/Casa Harlond | Casa Harlond]] | pelirrojo | rubio muy claro |
| [[09_Politica/Casas Mayores/Casa Harnost | Casa Harnost]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Mayores/Casa Minas Anor | Casa Minas Anor]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Mithlond | Casa Mithlond]] | rubio oscuro | rubio dorado |
| [[09_Politica/Casas Mayores/Casa Pelargir | Casa Pelargir]] | rubio ceniza | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Rhunost | Casa Rhunost]] | pelirrojo | rubio ceniza |
| [[09_Politica/Casas Mayores/Casa Taur-en-Mor | Casa Taur-en-Mor]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Mayores/Casa Teleri | Casa Teleri]] | rubio platino | rubio oscuro |
| [[09_Politica/Casas Mayores/Casa Vanyar | Casa Vanyar]] | rubio muy claro | rubio platino |

### Casas Menores

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Casa | Cabello del hombre | Cabello de la mujer |  |
| --- | --- | --- | --- |
| [[09_Politica/Casas Menores/Casa Aerandir | Casa Aerandir]] | rubio claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Aglaran | Casa Aglaran]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Angren | Casa Angren]] | rubio dorado | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Baranor | Casa Baranor]] | rubio platino | rubio claro |
| [[09_Politica/Casas Menores/Casa Belegor | Casa Belegor]] | rubio dorado | pelirrojo |
| [[09_Politica/Casas Menores/Casa Celepharn | Casa Celepharn]] | rubio dorado | rubio platino |
| [[09_Politica/Casas Menores/Casa Círdanir | Casa Círdanir]] | rubio muy claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Duilin | Casa Duilin]] | pelirrojo | rubio dorado |
| [[09_Politica/Casas Menores/Casa Elentir | Casa Elentir]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Menores/Casa Erestor | Casa Erestor]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Menores/Casa Eärond | Casa Eärond]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Menores/Casa Falastur | Casa Falastur]] | rubio oscuro | rubio platino |
| [[09_Politica/Casas Menores/Casa Falathar | Casa Falathar]] | pelirrojo | rubio oscuro |
| [[09_Politica/Casas Menores/Casa Gwindor | Casa Gwindor]] | rubio claro | rubio dorado |
| [[09_Politica/Casas Menores/Casa Hallas | Casa Hallas]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Menores/Casa Lindor | Casa Lindor]] | rubio muy claro | rubio claro |
| [[09_Politica/Casas Menores/Casa Maethor | Casa Maethor]] | rubio ceniza | pelirrojo |
| [[09_Politica/Casas Menores/Casa Meneldir | Casa Meneldir]] | castaño claro | castaño claro |
| [[09_Politica/Casas Menores/Casa Nimrodel | Casa Nimrodel]] | rubio claro | rubio claro |
| [[09_Politica/Casas Menores/Casa Ostor | Casa Ostor]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Menores/Casa Tarond | Casa Tarond]] | rubio platino | rubio claro |
| [[09_Politica/Casas Menores/Casa Thoron | Casa Thoron]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Menores/Casa Tumladen | Casa Tumladen]] | rubio claro | rubio dorado |
| [[09_Politica/Casas Menores/Casa Voronwë | Casa Voronwë]] | rubio ceniza | rubio muy claro |

### Casas Vasallas

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Casa | Cabello del hombre | Cabello de la mujer |  |
| --- | --- | --- | --- |
| [[09_Politica/Casas Vasallas/Casa Aegnor | Casa Aegnor]] | rubio dorado | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Amdir | Casa Amdir]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Amrod | Casa Amrod]] | rubio ceniza | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Anardil | Casa Anardil]] | rubio dorado | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Araphor | Casa Araphor]] | rubio muy claro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Ardamir | Casa Ardamir]] | rubio oscuro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Barahir | Casa Barahir]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Belegund | Casa Belegund]] | rubio muy claro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Brandir | Casa Brandir]] | rubio dorado | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Calenard | Casa Calenard]] | pelirrojo | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Dírhael | Casa Dírhael]] | rubio platinado blanco | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Ecthelion | Casa Ecthelion]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Erchirion | Casa Erchirion]] | rubio dorado | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Erellont | Casa Erellont]] | rubio oscuro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Estelmo | Casa Estelmo]] | rubio claro | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Findegil | Casa Findegil]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Folcred | Casa Folcred]] | rubio claro | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Forlong | Casa Forlong]] | rubio ceniza | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Galdor | Casa Galdor]] | rubio oscuro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Hador | Casa Hador]] | rubio ceniza | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Hareth | Casa Hareth]] | rubio claro | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Harlind | Casa Harlind]] | pelirrojo | rubio oscuro |
| [[09_Politica/Casas Vasallas/Casa Imrahil | Casa Imrahil]] | rubio claro | rubio claro |
| [[09_Politica/Casas Vasallas/Casa Iorlas | Casa Iorlas]] | rubio muy claro | castaño claro |
| [[09_Politica/Casas Vasallas/Casa Malbeth | Casa Malbeth]] | rubio dorado | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Ohtar | Casa Ohtar]] | castaño oscuro | rubio platinado blanco |
| [[09_Politica/Casas Vasallas/Casa Oropher | Casa Oropher]] | rubio ceniza | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Rúmilion | Casa Rúmilion]] | rubio muy claro | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Saeros | Casa Saeros]] | rubio claro | rubio muy claro |
| [[09_Politica/Casas Vasallas/Casa Targon | Casa Targon]] | rubio claro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Tuor | Casa Tuor]] | rubio muy claro | pelirrojo |
| [[09_Politica/Casas Vasallas/Casa Vorondil | Casa Vorondil]] | rubio muy claro | rubio platinado blanco |
| [[09_Politica/Casas Vasallas/Casa Wídfara | Casa Wídfara]] | rubio dorado | rubio dorado |
| [[09_Politica/Casas Vasallas/Casa Yavannor | Casa Yavannor]] | rubio oscuro | rubio ceniza |
| [[09_Politica/Casas Vasallas/Casa Zirin | Casa Zirin]] | rubio oscuro | rubio dorado |

### Maiar

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Los Maiar son intermediarios y figuras ejemplares de la tradición. El término puede designar guardianas de santuarios, sacerdotisas, astrónomas, maestras, sanadoras, consejeras, navegantes y fundadoras de archivos, hospitales o escuelas. Muchos relatos de Maiar conservan la memoria transformada de personas humanas de gran prestigio.

### Armada Valinoreana en 1875

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

En 1875 Valinor ya es una potencia marítima mundial. Su presencia procede de rutas recorridas desde la Antigüedad, puertos asociados, protectorados, enclaves navales, estaciones de carbón, comunidades mercantiles y acuerdos de navegación. No administra todos esos puntos como provincias: distingue soberanía federal, protectorado, enclave, concesión y puerto asociado.

La Armada Real es inferior a la Royal Navy británica en tonelaje total y número de buques, pero no es una fuerza regional limitada. Puede mantener escuadras en el Atlántico norte, Caribe, África occidental, Mediterráneo, mar Rojo, Índico, Malaca, Pacífico y rutas árticas.

### Fuerza de combate

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

| Tipo | Unidades valinari en 1875 | Función |
| --- | --- | --- |
| Ironclads oceánicos | 16 | combate de escuadra y protección de rutas principales |
| Ironclads costeros y monitores | 12 | defensa de puertos, estrechos y enclaves |
| Cruceros protegidos o de casco compuesto | 18 | presencia mundial, exploración y guerra comercial |
| Corbetas de vapor y vela | 28 | estaciones navales, escolta y diplomacia |
| Sloops y avisos armados | 24 | mensajería, patrulla y enlace entre puertos |
| Cañoneras | 42 | ríos, protectorados, costas y defensa de enclaves |
| Torpederos | 24 | defensa portuaria y ataques nocturnos |
| Buques de desembarco y transportes armados | 14 | operaciones anfibias y refuerzo territorial |
| Total de combate y apoyo armado | 178 | incluye unidades de primera línea y ligeras |

De estos buques, aproximadamente 105 están activos, 35 se encuentran en mantenimiento o reserva y 38 cumplen tareas de instrucción, patrulla local o transporte armado.

### Clases principales

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Los Círdan I son seis ironclads oceánicos de 7.000–8.500 toneladas, con cuatro cañones rayados de 10–12 pulgadas, piezas secundarias de 6 pulgadas, blindaje de ciudadela y velocidad aproximada de 12–13 nudos.

Los Aulë son ocho ironclads costeros y monitores de 3.500–4.500 toneladas, armados con dos cañones de 10–12 pulgadas y piezas secundarias. Protegen Helsingborg, Nueva Tirion, Calenport, Panamá, Nosselië Toliva, Islandia y Groenlandia.

Los Eärendil son ocho cruceros protegidos de largo alcance, complementados por diez cruceros de segunda línea. Llevan cañones de 4,7–6 pulgadas, piezas rápidas y tubos lanzatorpedos experimentales.

Las corbetas Pelargir, los avisos Rómenna, las cañoneras Harlond y los torpederos Forlond forman la red de presencia mundial. No todos poseen el mismo nivel tecnológico: la flota combina vapor, vela auxiliar, hierro, acero temprano, artillería de avancarga, retrocarga y torpedos experimentales.

### Fuerza logística

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La presencia mundial requiere una logística mayor que la de una armada regional. Valinor mantiene aproximadamente:

| Tipo de unidad logística | Cantidad |
| --- | --- |
| Carboneros y buques de combustible | 32 |
| Transportes militares | 18 |
| Buques de munición y almacén | 12 |
| Remolcadores y buques de reparación | 20 |
| Buques hospital | 8 |
| Buques hidrográficos y oceanográficos | 16 |
| Buques escuela y de instrucción | 12 |
| Patrulleros y guardacostas | 36 |
| Total logístico y auxiliar | 154 |

La flota completa, sumando combate, patrulla, transporte y auxiliares, alcanza aproximadamente 332 buques, aunque solo una parte puede concentrarse en una misma crisis.

### Red mundial de apoyo

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Las principales zonas de apoyo son:

Atlántico norte: Valinor, Arnor, Númenor, Islandia, Groenlandia y Systreyjar.

Atlántico medio: Nosselië Toliva, Azores, Madeira y estaciones asociadas.

Caribe y Panamá: Panamá Federal, Bahamas, Bermudas, Trinidad, Tobago y puertos asociados.

África occidental: Eärendil, Tol Morwen, Esgal Nénar y estaciones de comercio.

Mediterráneo: Barad Nimras, Alqualondë, Eglarest y Pelargir como bases arrendadas o puertos asociados.

mar Rojo y golfo: Amon Rûdh, Harlond, Círdan, Harnen, Eryndor y Rhunost según su estatuto político.

Índico y Asia: Malaca, Eressëa Índica y rutas hacia los estados del Pacífico.

Pacífico: Hawái, Fiyi, Polinesia, Micronesia y Nanduhirion.

La red no implica que todos los puntos sean territorio federal. Su valor reside en carbón, agua, reparación, inteligencia, sanidad, almacenamiento y relevo de tripulaciones.

### Comparación con la Royal Navy

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

La Royal Navy conserva la mayor flota del mundo porque debe cubrir un imperio más amplio, una red global de bases y un volumen comercial planetario. En 1875 puede disponer de aproximadamente 42–48 ironclads en servicio, construcción o reserva, además de más de 50 corbetas, sloops y cañoneras y una gran cantidad de auxiliares.

Valinor dispone de menos tonelaje pesado, pero concentra una proporción elevada de sus recursos en rutas marítimas y mantiene una red mundial propia. La comparación coherente es:

Reino Unido: primera potencia naval mundial, superior en tonelaje, reservas, bases y capacidad de reemplazo.

Valinor: segunda gran potencia marítima global, inferior en volumen pero capaz de operar simultáneamente en varios océanos.

Estados Unidos: potencia industrial en ascenso, pero con una marina activa menor y todavía en reconstrucción tras la Guerra Civil.

La rivalidad anglo-valinari produce guerras de corso, bloqueos, disputas por puertos, competencia por protectorados y tratados de neutralidad. La existencia de presencia mundial valinari no elimina la superioridad británica: hace que la competencia sea global y que la Royal Navy deba repartir sus fuerzas entre más teatros.

### 30.8. Evolución histórica

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

> La sangre abre el derecho; el juramento lo legitima; el Consejo lo confirma; los santuarios lo registran; las ciudades y las guarniciones lo hacen efectivo.

### Resolución AM1 — Armada de 1973 y transición a turbinas de gas

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Se incorpora como reconstrucción AM1 una fuerza naval de referencia de 1973 de 421 plataformas. Es una estimación intermedia entre las referencias de 1960 (408) y 1980 (427), no un inventario observado. La fuerza comprende 7 portaaviones, 15 cruceros, 42 destructores, 54 fragatas/escoltas, 50 corbetas, 22 lanchas misilísticas, 56 patrulleros, 44 submarinos, 33 buques anfibios, 24 unidades de contramedidas de minas y 74 auxiliares.

Se fija la trayectoria de turbinas de gas: ensayos valinari en 1952–1958; primeras series en lanchas y escoltas ligeros en 1958–1965; adopción masiva en destructores, fragatas, corbetas y buques rápidos en 1965–1970; perfeccionamiento de plantas combinadas, protección salina, control automático y mantenimiento modular en 1970–1979. En 1973 predomina gas en destructores modernos, buena parte de fragatas/escoltas y la mayoría de corbetas y lanchas rápidas. Portaaviones convencionales conservan vapor; los nucleares producen vapor desde reactores; submarinos nucleares usan ciclo de vapor; patrulleros de permanencia, anfibios y auxiliares favorecen diésel por autonomía y consumo.

Las fechas de botadura, entrada en servicio y retiro por generación, así como velocidades, dotaciones, armas, sensores y variantes, constan en [[12_Militar/03_Armada/AM1 Armada 1973 — reconstrucción y turbinas|12_Militar/AM1 Armada 1973 — reconstrucción y turbinas]]. Los nombres Nénar y Míriel para misiles de la propuesta de 1973 quedan identificados como denominaciones de trabajo de esta reconstrucción.

### Familia de destructores Gil-galad — secuencia generacional

Estado del material recuperado: VIGENTE. Fuente: Canon Markdown anterior a V16.4. Precedencia A092.

Se fija una convención única para la familia: Gil-galad I designa la generación de guerra; II, los destructores de posguerra a vapor; III, el primer diseño de serie con turbinas de gas; IV, los cascos digitales de los años noventa; V, los buques de red/AESA inicial de los años 2000; y VI, la generación diseñada desde los años 2020. La familia se renueva por cascos y generaciones: no implica que un diseño único permanezca 85 años en servicio.

La reconstrucción de 1973 contabiliza 12 Gil-galad II de posguerra. La generación III comienza a entrar en servicio desde 1978. La cifra AM1 de 1980 para la familia es agregada durante el reemplazo II–III; no autoriza a sumar dos veces los cascos ni a asignar doce buques a cada generación. Para 2026 se registran 24 destructores de generaciones IV y V; la VI no se cuenta como operativa antes de su fecha prevista de entrada en servicio.

La ficha técnica con misiones, prestaciones, armamento, sensores, propulsión y ciclos de casco se encuentra en [[12_Militar/03_Armada/Destructores Gil-galad — evolución de la familia|12_Militar/Destructores Gil-galad — evolución de la familia]]. Esta secuencia prevalece sobre numeraciones anteriores que asignaban el mismo ordinal a generaciones distintas.

La secuencia generacional Gil-galad se normaliza en la ficha [[12_Militar/03_Armada/Destructores Gil-galad — evolución de la familia|12_Militar/Destructores Gil-galad — evolución de la familia]]; sus fechas de familia no equivalen a la vida de un casco individual.

## Anexos cuantitativos A092

## Matriz territorial maestra A092

Registro 2026. Son 14 cuentas del Reino, ocho federales externas y Harnen como protectorado operativo. Númenor, Rhunost, ciudades, puertos y capitales están incluidos en sus cuentas superiores.

| ID | Unidad | Ámbito | Población M | PIB PPA | Urbana M | Rural M |
| --- | --- | --- | --- | --- | --- | --- |
| T01 | Valinor a Tyl | Reino | 26,00 | 3,10 | 23,00 | 3,00 |
| T02 | Arnor | Reino | 145,00 | 20,00 | 131,50 | 13,50 |
| T03 | Calenardhon Austral | Reino | 88,00 | 11,50 | 80,00 | 8,00 |
| T04 | Sírënandë | Reino | 55,00 | 3,50 | 48,00 | 7,00 |
| T05 | Venezuela Federal | Reino | 50,00 | 4,50 | 46,00 | 4,00 |
| T06 | Provincia del Orinoco | Reino | 15,00 | 2,20 | 11,50 | 3,50 |
| T07 | Colombia Costera | Reino | 53,00 | 7,20 | 47,30 | 5,70 |
| T08 | Panamá Federal | Reino | 17,00 | 2,50 | 15,80 | 1,20 |
| T09 | Trinidad | Reino | 8,00 | 1,20 | 7,20 | 0,80 |
| T10 | Tobago | Reino | 1,00 | 0,10 | 0,75 | 0,25 |
| T11 | Bahamas | Reino | 6,00 | 0,80 | 5,40 | 0,60 |
| T12 | Bermudas | Reino | 2,00 | 0,40 | 1,90 | 0,10 |
| T13 | Barbados | Reino | 5,00 | 0,50 | 4,50 | 0,50 |
| T14 | Nosselië Toliva | Reino | 10,00 | 1,00 | 9,00 | 1,00 |
| T15 | Malaca | Federal externa | 16,00 | 2,97 | 14,80 | 1,20 |
| T16 | Hawái | Federal externa | 4,00 | 1,35 | 3,80 | 0,20 |
| T17 | Fiyi | Federal externa | 3,00 | 0,42 | 2,25 | 0,75 |
| T18 | Polinesia | Federal externa | 2,50 | 0,35 | 1,80 | 0,70 |
| T19 | Micronesia | Federal externa | 1,50 | 0,26 | 1,00 | 0,50 |
| T20 | Eryndor | Federal externa | 2,00 | 0,18 | 1,95 | 0,05 |
| T21 | Harnen | Protectorado operativo | 8,00 | 0,52 | 6,60 | 1,40 |
| T22 | Islandia | Federal externa | 3,50 | 0,55 | 3,22 | 0,28 |
| T23 | Groenlandia | Federal externa | 2,00 | 0,40 | 1,70 | 0,30 |

Población y PIB heredados. La urbanización de Islandia y Groenlandia es hipótesis A092, 92 % y 85 %. No se inventan áreas o capitales ausentes.

### Capitales superficies y perímetros

| Unidad | Capital de referencia | Superficie | Perímetro y exclusiones |
| --- | --- | --- | --- |
| Valinor a Tyl | Pendiente de fijación canónica | 53.200 km² | Valinor 16 M + Tol Eressëa 5 M + Systreyjar 5 M |
| Arnor | Annúminas (Toronto) | No fijada en fuente vigente examinada | Incluye Númenor/Terranova; no añadir la isla aparte |
| Calenardhon Austral | Pelargir Austral (Porto Alegre) | No fijada en fuente vigente examinada | Regiones australes fijadas en canon; no Brasil completo |
| Sírënandë | Sirion (Georgetown) | 462.323 km² | Guyana, Surinam y Guayana Francesa; excluye Brasil |
| Venezuela Federal | Tirith Anor (Caracas) | No fijada en fuente vigente examinada | Jurisdicciones de §35.1; excluye la Provincia del Orinoco |
| Provincia del Orinoco | Barad Oron (Puerto Ordaz) | No fijada en fuente vigente examinada | 10 M en parte venezolana + 5 M en parte colombiana |
| Colombia Costera | Vinyamar (Barranquilla) | No fijada en fuente vigente examinada | Departamentos de §31.1; excluye los diez asignados a Orinoco |
| Panamá Federal | Tirion del Istmo (Ciudad de Panamá) | No fijada en fuente vigente examinada | República de Panamá completa; canal incluido |
| Trinidad | Harlond Sur (Puerto España) | No fijada en fuente vigente examinada | Isla y dependencias asignadas; Tobago separado |
| Tobago | Dol Amroth Menel (Scarborough) | No fijada en fuente vigente examinada | Jurisdicción de Tobago; excluye Trinidad |
| Bahamas | Eryn Lasgalen (Nassau) | No fijada en fuente vigente examinada | Archipiélago asignado a Bahamas |
| Bermudas | Tol Galen (Hamilton) | No fijada en fuente vigente examinada | Archipiélago de Bermudas |
| Barbados | Lond Daer (Bridgetown) | No fijada en fuente vigente examinada | Jurisdicción insular de Barbados |
| Nosselië Toliva | Eressëa Menel (Las Palmas) | 7.493 km² | Canarias, incluida en el Reino |
| Malaca | Osgiliath del Este (Kuala Lumpur) | No fijada en fuente vigente examinada | Península malaya y Singapur; excluye Sabah y Sarawak |
| Hawái | Alqualondë del Pacífico (Honolulu) | No fijada en fuente vigente examinada | Archipiélago hawaiano; excluye Polinesia federal |
| Fiyi | Eglarest Austral (Suva) | No fijada en fuente vigente examinada | Archipiélago de Fiyi; excluye Tonga y Samoa |
| Polinesia | Eressëa del Sur (Papeete) | No fijada en fuente vigente examinada | Samoa, Tonga, Cook, Polinesia Francesa, Wallis y Futuna, Tuvalu, Niue, Tokelau y Samoa Americana |
| Micronesia | Rhunost del Mar (Hagåtña) | No fijada en fuente vigente examinada | Guam, Marianas del Norte, Palaos, Estados Federados de Micronesia, Marshall y Kiribati |
| Eryndor | Manama (Manama) | 765 km² | Baréin; unidad federal directa |
| Harnen | Harnost (Mascate) | 309.500 km² | Omán con Rhunost/Musandam incluido |
| Islandia | Pendiente de fijación canónica | 103.000 km² | Territorio autónomo externo al Reino |
| Groenlandia | Pendiente de fijación canónica | 2.166.000 km² | Territorio autónomo externo al Reino |

### Cuentas por territorio

| Unidad | PIB | Impuestos netos | VAB | Producción | Insumos |
| --- | --- | --- | --- | --- | --- |
| Valinor a Tyl | 3,10000 | 0,13950 | 2,96050 | 4,63156 | 1,67106 |
| Arnor | 20,00000 | 0,92000 | 19,08000 | 30,83561 | 11,75561 |
| Calenardhon Austral | 11,50000 | 0,49450 | 11,00550 | 19,67038 | 8,66488 |
| Sírënandë | 3,50000 | 0,13300 | 3,36700 | 6,01240 | 2,64540 |
| Venezuela Federal | 4,50000 | 0,21600 | 4,28400 | 7,80535 | 3,52135 |
| Provincia del Orinoco | 2,20000 | 0,07040 | 2,12960 | 4,02204 | 1,89244 |
| Colombia Costera | 7,20000 | 0,36000 | 6,84000 | 12,08992 | 5,24992 |
| Panamá Federal | 2,50000 | 0,15500 | 2,34500 | 4,11435 | 1,76935 |
| Trinidad | 1,20000 | 0,05400 | 1,14600 | 2,05230 | 0,90630 |
| Tobago | 0,10000 | 0,00550 | 0,09450 | 0,15857 | 0,06407 |
| Bahamas | 0,80000 | 0,05200 | 0,74800 | 1,19785 | 0,44985 |
| Bermudas | 0,40000 | 0,02000 | 0,38000 | 0,55660 | 0,17660 |
| Barbados | 0,50000 | 0,02900 | 0,47100 | 0,76191 | 0,29091 |
| Nosselië Toliva | 1,00000 | 0,05500 | 0,94500 | 1,57080 | 0,62580 |
| Malaca | 2,97000 | 0,11880 | 2,85120 | 5,37347 | 2,52227 |
| Hawái | 1,35000 | 0,07155 | 1,27845 | 2,06110 | 0,78265 |
| Fiyi | 0,42000 | 0,02100 | 0,39900 | 0,70048 | 0,30148 |
| Polinesia | 0,35000 | 0,01925 | 0,33075 | 0,57717 | 0,24642 |
| Micronesia | 0,26000 | 0,01040 | 0,24960 | 0,44310 | 0,19350 |
| Eryndor | 0,18000 | 0,00900 | 0,17100 | 0,24628 | 0,07528 |
| Harnen | 0,52000 | 0,01820 | 0,50180 | 0,86678 | 0,36498 |
| Islandia | 0,55000 | 0,03000 | 0,52000 | 0,83597 | 0,31597 |
| Groenlandia | 0,40000 | 0,02000 | 0,38000 | 0,61650 | 0,23650 |

## Cuentas sectoriales conciliadas A092

Billones PPA de 2026. Las 21 matrices heredadas reciben ajustes de redondeo explícitos de hasta 0,0001 por territorio. Islandia y Groenlandia tienen matrices nuevas de planificación, no estadísticas observadas. Los PIB y poblaciones se conservan.

### Valinor a Tyl

Población 26,00 M. PIB 3,10000. Impuestos netos 0,13950. VAB 2,96050. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04486 | 0,01525 | 0,02961 |
| B | Minería y energía | 0,18797 | 0,06955 | 0,11842 |
| C | Manufactura y reparación | 1,18420 | 0,65131 | 0,53289 |
| D | Construcción e infraestructura | 0,28466 | 0,13664 | 0,14802 |
| E | Comercio, alojamiento y servicios personales | 0,37006 | 0,13322 | 0,23684 |
| F | Transporte y logística | 0,48533 | 0,18928 | 0,29605 |
| G | Finanzas, seguros y servicios empresariales | 0,77908 | 0,18698 | 0,59210 |
| H | Información, telecomunicaciones, software e I+D | 0,80014 | 0,20804 | 0,59210 |
| I | Servicios inmobiliarios | 0,21662 | 0,03899 | 0,17763 |
| J | Administración y servicios sociales | 0,27864 | 0,04180 | 0,23684 |
| Total |  | 4,63156 | 1,67106 | 2,96050 |

### Arnor

Población 145,00 M. PIB 20,00000. Impuestos netos 0,92000. VAB 19,08000. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,82957 | 0,25717 | 0,57240 |
| B | Minería y energía | 2,27821 | 0,75181 | 1,52640 |
| C | Manufactura y reparación | 11,13000 | 5,78760 | 5,34240 |
| D | Construcción e infraestructura | 2,12000 | 0,97520 | 1,14480 |
| E | Comercio, alojamiento y servicios personales | 2,02364 | 0,68804 | 1,33560 |
| F | Transporte y logística | 2,15419 | 0,81859 | 1,33560 |
| G | Finanzas, seguros y servicios empresariales | 3,76579 | 0,90379 | 2,86200 |
| H | Información, telecomunicaciones, software e I+D | 4,50500 | 1,26140 | 3,24360 |
| I | Servicios inmobiliarios | 0,69805 | 0,12565 | 0,57240 |
| J | Administración y servicios sociales | 1,33116 | 0,18636 | 1,14480 |
| Total |  | 30,83561 | 11,75561 | 19,08000 |

### Calenardhon Austral

Población 88,00 M. PIB 11,50000. Impuestos netos 0,49450. VAB 11,00550. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 1,64261 | 0,54206 | 1,10055 |
| B | Minería y energía | 2,03178 | 0,71112 | 1,32066 |
| C | Manufactura y reparación | 8,19014 | 4,66838 | 3,52176 |
| D | Construcción e infraestructura | 1,48151 | 0,71112 | 0,77039 |
| E | Comercio, alojamiento y servicios personales | 1,24256 | 0,47217 | 0,77039 |
| F | Transporte y logística | 1,49227 | 0,61183 | 0,88044 |
| G | Finanzas, seguros y servicios empresariales | 1,25777 | 0,37733 | 0,88044 |
| H | Información, telecomunicaciones, software e I+D | 1,13292 | 0,36253 | 0,77039 |
| I | Servicios inmobiliarios | 0,41271 | 0,08254 | 0,33017 |
| J | Administración y servicios sociales | 0,78611 | 0,12580 | 0,66031 |
| Total |  | 19,67038 | 8,66488 | 11,00550 |

### Sírënandë

Población 55,00 M. PIB 3,50000. Impuestos netos 0,13300. VAB 3,36700. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,62160 | 0,21756 | 0,40404 |
| B | Minería y energía | 1,35766 | 0,51591 | 0,84175 |
| C | Manufactura y reparación | 1,84383 | 1,06942 | 0,77441 |
| D | Construcción e infraestructura | 0,47138 | 0,23569 | 0,23569 |
| E | Comercio, alojamiento y servicios personales | 0,33670 | 0,13468 | 0,20202 |
| F | Transporte y logística | 0,48100 | 0,21164 | 0,26936 |
| G | Finanzas, seguros y servicios empresariales | 0,29709 | 0,09507 | 0,20202 |
| H | Información, telecomunicaciones, software e I+D | 0,27153 | 0,10318 | 0,16835 |
| I | Servicios inmobiliarios | 0,08524 | 0,01790 | 0,06734 |
| J | Administración y servicios sociales | 0,24637 | 0,04435 | 0,20202 |
| Total |  | 6,01240 | 2,64540 | 3,36700 |

### Venezuela Federal

Población 50,00 M. PIB 4,50000. Impuestos netos 0,21600. VAB 4,28400. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,50400 | 0,16128 | 0,34272 |
| B | Minería y energía | 1,10793 | 0,46533 | 0,64260 |
| C | Manufactura y reparación | 2,63631 | 1,60815 | 1,02816 |
| D | Construcción e infraestructura | 0,56581 | 0,26593 | 0,29988 |
| E | Comercio, alojamiento y servicios personales | 0,64260 | 0,25704 | 0,38556 |
| F | Transporte y logística | 0,63467 | 0,29195 | 0,34272 |
| G | Finanzas, seguros y servicios empresariales | 0,62832 | 0,15708 | 0,47124 |
| H | Información, telecomunicaciones, software e I+D | 0,52726 | 0,18454 | 0,34272 |
| I | Servicios inmobiliarios | 0,18360 | 0,05508 | 0,12852 |
| J | Administración y servicios sociales | 0,37485 | 0,07497 | 0,29988 |
| Total |  | 7,80535 | 3,52135 | 4,28400 |

### Provincia del Orinoco

Población 15,00 M. PIB 2,20000. Impuestos netos 0,07040. VAB 2,12960. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,34348 | 0,13052 | 0,21296 |
| B | Minería y energía | 1,06480 | 0,51110 | 0,55370 |
| C | Manufactura y reparación | 1,17128 | 0,70277 | 0,46851 |
| D | Construcción e infraestructura | 0,27104 | 0,12197 | 0,14907 |
| E | Comercio, alojamiento y servicios personales | 0,17174 | 0,06526 | 0,10648 |
| F | Transporte y logística | 0,33405 | 0,16369 | 0,17036 |
| G | Finanzas, seguros y servicios empresariales | 0,15211 | 0,04563 | 0,10648 |
| H | Información, telecomunicaciones, software e I+D | 0,20609 | 0,07831 | 0,12778 |
| I | Servicios inmobiliarios | 0,06173 | 0,01914 | 0,04259 |
| J | Administración y servicios sociales | 0,24572 | 0,05405 | 0,19167 |
| Total |  | 4,02204 | 1,89244 | 2,12960 |

### Colombia Costera

Población 53,00 M. PIB 7,20000. Impuestos netos 0,36000. VAB 6,84000. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 1,30286 | 0,48206 | 0,82080 |
| B | Minería y energía | 1,23344 | 0,48104 | 0,75240 |
| C | Manufactura y reparación | 3,83707 | 2,26387 | 1,57320 |
| D | Construcción e infraestructura | 0,68400 | 0,34200 | 0,34200 |
| E | Comercio, alojamiento y servicios personales | 0,78492 | 0,30612 | 0,47880 |
| F | Transporte y logística | 1,24364 | 0,55964 | 0,68400 |
| G | Finanzas, seguros y servicios empresariales | 1,17257 | 0,35177 | 0,82080 |
| H | Información, telecomunicaciones, software e I+D | 0,91881 | 0,30321 | 0,61560 |
| I | Servicios inmobiliarios | 0,25333 | 0,04813 | 0,20520 |
| J | Administración y servicios sociales | 0,65928 | 0,11208 | 0,54720 |
| Total |  | 12,08992 | 5,24992 | 6,84000 |

### Panamá Federal

Población 17,00 M. PIB 2,50000. Impuestos netos 0,15500. VAB 2,34500. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,18038 | 0,06313 | 0,11725 |
| B | Minería y energía | 0,15129 | 0,05749 | 0,09380 |
| C | Manufactura y reparación | 1,05525 | 0,63315 | 0,42210 |
| D | Construcción e infraestructura | 0,23450 | 0,11725 | 0,11725 |
| E | Comercio, alojamiento y servicios personales | 0,39746 | 0,16296 | 0,23450 |
| F | Transporte y logística | 0,86852 | 0,39952 | 0,46900 |
| G | Finanzas, seguros y servicios empresariales | 0,68396 | 0,19151 | 0,49245 |
| H | Información, telecomunicaciones, software e I+D | 0,34485 | 0,11035 | 0,23450 |
| I | Servicios inmobiliarios | 0,11439 | 0,02059 | 0,09380 |
| J | Administración y servicios sociales | 0,08375 | 0,01340 | 0,07035 |
| Total |  | 4,11435 | 1,76935 | 2,34500 |

### Trinidad

Población 8,00 M. PIB 1,20000. Impuestos netos 0,05400. VAB 1,14600. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,08426 | 0,02696 | 0,05730 |
| B | Minería y energía | 0,34380 | 0,17190 | 0,17190 |
| C | Manufactura y reparación | 0,54571 | 0,31651 | 0,22920 |
| D | Construcción e infraestructura | 0,11019 | 0,05289 | 0,05730 |
| E | Comercio, alojamiento y servicios personales | 0,15280 | 0,06112 | 0,09168 |
| F | Transporte y logística | 0,29638 | 0,12448 | 0,17190 |
| G | Finanzas, seguros y servicios empresariales | 0,19100 | 0,05348 | 0,13752 |
| H | Información, telecomunicaciones, software e I+D | 0,14105 | 0,04937 | 0,09168 |
| I | Servicios inmobiliarios | 0,08426 | 0,02696 | 0,05730 |
| J | Administración y servicios sociales | 0,10285 | 0,02263 | 0,08022 |
| Total |  | 2,05230 | 0,90630 | 1,14600 |

### Tobago

Población 1,00 M. PIB 0,10000. Impuestos netos 0,00550. VAB 0,09450. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,01620 | 0,00486 | 0,01134 |
| B | Minería y energía | 0,01303 | 0,00547 | 0,00756 |
| C | Manufactura y reparación | 0,02700 | 0,01566 | 0,01134 |
| D | Construcción e infraestructura | 0,01031 | 0,00464 | 0,00567 |
| E | Comercio, alojamiento y servicios personales | 0,02835 | 0,01134 | 0,01701 |
| F | Transporte y logística | 0,02062 | 0,00928 | 0,01134 |
| G | Finanzas, seguros y servicios empresariales | 0,01080 | 0,00324 | 0,00756 |
| H | Información, telecomunicaciones, software e I+D | 0,01145 | 0,00389 | 0,00756 |
| I | Servicios inmobiliarios | 0,01112 | 0,00356 | 0,00756 |
| J | Administración y servicios sociales | 0,00969 | 0,00213 | 0,00756 |
| Total |  | 0,15857 | 0,06407 | 0,09450 |

### Bahamas

Población 6,00 M. PIB 0,80000. Impuestos netos 0,05200. VAB 0,74800. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,03300 | 0,01056 | 0,02244 |
| B | Minería y energía | 0,02720 | 0,01224 | 0,01496 |
| C | Manufactura y reparación | 0,14248 | 0,08264 | 0,05984 |
| D | Construcción e infraestructura | 0,08160 | 0,03672 | 0,04488 |
| E | Comercio, alojamiento y servicios personales | 0,24129 | 0,09169 | 0,14960 |
| F | Transporte y logística | 0,24933 | 0,09973 | 0,14960 |
| G | Finanzas, seguros y servicios empresariales | 0,15370 | 0,04150 | 0,11220 |
| H | Información, telecomunicaciones, software e I+D | 0,11164 | 0,03684 | 0,07480 |
| I | Servicios inmobiliarios | 0,06411 | 0,01923 | 0,04488 |
| J | Administración y servicios sociales | 0,09350 | 0,01870 | 0,07480 |
| Total |  | 1,19785 | 0,44985 | 0,74800 |

### Bermudas

Población 2,00 M. PIB 0,40000. Impuestos netos 0,02000. VAB 0,38000. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,00543 | 0,00163 | 0,00380 |
| B | Minería y energía | 0,00000 | 0,00000 | 0,00000 |
| C | Manufactura y reparación | 0,04222 | 0,02322 | 0,01900 |
| D | Construcción e infraestructura | 0,02764 | 0,01244 | 0,01520 |
| E | Comercio, alojamiento y servicios personales | 0,07355 | 0,02795 | 0,04560 |
| F | Transporte y logística | 0,06230 | 0,02430 | 0,03800 |
| G | Finanzas, seguros y servicios empresariales | 0,19000 | 0,04560 | 0,14440 |
| H | Información, telecomunicaciones, software e I+D | 0,06514 | 0,01954 | 0,04560 |
| I | Servicios inmobiliarios | 0,04282 | 0,01242 | 0,03040 |
| J | Administración y servicios sociales | 0,04750 | 0,00950 | 0,03800 |
| Total |  | 0,55660 | 0,17660 | 0,38000 |

### Barbados

Población 5,00 M. PIB 0,50000. Impuestos netos 0,02900. VAB 0,47100. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,03413 | 0,01058 | 0,02355 |
| B | Minería y energía | 0,00812 | 0,00341 | 0,00471 |
| C | Manufactura y reparación | 0,13144 | 0,07492 | 0,05652 |
| D | Construcción e infraestructura | 0,05233 | 0,02407 | 0,02826 |
| E | Comercio, alojamiento y servicios personales | 0,15443 | 0,06023 | 0,09420 |
| F | Transporte y logística | 0,09745 | 0,04093 | 0,05652 |
| G | Finanzas, seguros y servicios empresariales | 0,07850 | 0,02198 | 0,05652 |
| H | Información, telecomunicaciones, software e I+D | 0,06926 | 0,02216 | 0,04710 |
| I | Servicios inmobiliarios | 0,05383 | 0,01615 | 0,03768 |
| J | Administración y servicios sociales | 0,08242 | 0,01648 | 0,06594 |
| Total |  | 0,76191 | 0,29091 | 0,47100 |

### Nosselië Toliva

Población 10,00 M. PIB 1,00000. Impuestos netos 0,05500. VAB 0,94500. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,15242 | 0,05792 | 0,09450 |
| B | Minería y energía | 0,15750 | 0,06300 | 0,09450 |
| C | Manufactura y reparación | 0,27659 | 0,16319 | 0,11340 |
| D | Construcción e infraestructura | 0,11571 | 0,05901 | 0,05670 |
| E | Comercio, alojamiento y servicios personales | 0,15750 | 0,06300 | 0,09450 |
| F | Transporte y logística | 0,23211 | 0,09981 | 0,13230 |
| G | Finanzas, seguros y servicios empresariales | 0,10800 | 0,03240 | 0,07560 |
| H | Información, telecomunicaciones, software e I+D | 0,12694 | 0,04189 | 0,08505 |
| I | Servicios inmobiliarios | 0,08269 | 0,01654 | 0,06615 |
| J | Administración y servicios sociales | 0,16134 | 0,02904 | 0,13230 |
| Total |  | 1,57080 | 0,62580 | 0,94500 |

### Malaca

Población 16,00 M. PIB 2,97000. Impuestos netos 0,11880. VAB 2,85120. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,12960 | 0,04406 | 0,08554 |
| B | Minería y energía | 0,36790 | 0,13980 | 0,22810 |
| C | Manufactura y reparación | 2,57966 | 1,49620 | 1,08346 |
| D | Construcción e infraestructura | 0,39917 | 0,19958 | 0,19959 |
| E | Comercio, alojamiento y servicios personales | 0,32719 | 0,12760 | 0,19959 |
| F | Transporte y logística | 0,61097 | 0,26883 | 0,34214 |
| G | Finanzas, seguros y servicios empresariales | 0,31680 | 0,08870 | 0,22810 |
| H | Información, telecomunicaciones, software e I+D | 0,46869 | 0,12655 | 0,34214 |
| I | Servicios inmobiliarios | 0,10560 | 0,02006 | 0,08554 |
| J | Administración y servicios sociales | 0,06789 | 0,01089 | 0,05700 |
| Total |  | 5,37347 | 2,52227 | 2,85120 |

### Hawái

Población 4,00 M. PIB 1,35000. Impuestos netos 0,07155. VAB 1,27845. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,03934 | 0,01377 | 0,02557 |
| B | Minería y energía | 0,09988 | 0,03596 | 0,06392 |
| C | Manufactura y reparación | 0,58111 | 0,32542 | 0,25569 |
| D | Construcción e infraestructura | 0,16885 | 0,07936 | 0,08949 |
| E | Comercio, alojamiento y servicios personales | 0,15981 | 0,05753 | 0,10228 |
| F | Transporte y logística | 0,26002 | 0,10661 | 0,15341 |
| G | Finanzas, seguros y servicios empresariales | 0,19264 | 0,05201 | 0,14063 |
| H | Información, telecomunicaciones, software e I+D | 0,29886 | 0,06874 | 0,23012 |
| I | Servicios inmobiliarios | 0,07795 | 0,01403 | 0,06392 |
| J | Administración y servicios sociales | 0,18264 | 0,02922 | 0,15342 |
| Total |  | 2,06110 | 0,78265 | 1,27845 |

### Fiyi

Población 3,00 M. PIB 0,42000. Impuestos netos 0,02100. VAB 0,39900. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,11774 | 0,04592 | 0,07182 |
| B | Minería y energía | 0,06191 | 0,02600 | 0,03591 |
| C | Manufactura y reparación | 0,14323 | 0,08737 | 0,05586 |
| D | Construcción e infraestructura | 0,05819 | 0,03026 | 0,02793 |
| E | Comercio, alojamiento y servicios personales | 0,08115 | 0,03327 | 0,04788 |
| F | Transporte y logística | 0,08705 | 0,03917 | 0,04788 |
| G | Finanzas, seguros y servicios empresariales | 0,03023 | 0,01028 | 0,01995 |
| H | Información, telecomunicaciones, software e I+D | 0,03069 | 0,01074 | 0,01995 |
| I | Servicios inmobiliarios | 0,02046 | 0,00450 | 0,01596 |
| J | Administración y servicios sociales | 0,06983 | 0,01397 | 0,05586 |
| Total |  | 0,70048 | 0,30148 | 0,39900 |

### Polinesia

Población 2,50 M. PIB 0,35000. Impuestos netos 0,01925. VAB 0,33075. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,08133 | 0,03172 | 0,04961 |
| B | Minería y energía | 0,03482 | 0,01497 | 0,01985 |
| C | Manufactura y reparación | 0,08704 | 0,05396 | 0,03308 |
| D | Construcción e infraestructura | 0,05630 | 0,02984 | 0,02646 |
| E | Comercio, alojamiento y servicios personales | 0,10302 | 0,04018 | 0,06284 |
| F | Transporte y logística | 0,09188 | 0,04226 | 0,04962 |
| G | Finanzas, seguros y servicios empresariales | 0,03405 | 0,01090 | 0,02315 |
| H | Información, telecomunicaciones, software e I+D | 0,03456 | 0,01140 | 0,02316 |
| I | Servicios inmobiliarios | 0,01696 | 0,00373 | 0,01323 |
| J | Administración y servicios sociales | 0,03721 | 0,00746 | 0,02975 |
| Total |  | 0,57717 | 0,24642 | 0,33075 |

### Micronesia

Población 1,50 M. PIB 0,26000. Impuestos netos 0,01040. VAB 0,24960. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04092 | 0,01596 | 0,02496 |
| B | Minería y energía | 0,03807 | 0,01561 | 0,02246 |
| C | Manufactura y reparación | 0,08960 | 0,05466 | 0,03494 |
| D | Construcción e infraestructura | 0,03640 | 0,01893 | 0,01747 |
| E | Comercio, alojamiento y servicios personales | 0,04160 | 0,01664 | 0,02496 |
| F | Transporte y logística | 0,09984 | 0,04493 | 0,05491 |
| G | Finanzas, seguros y servicios empresariales | 0,02569 | 0,00822 | 0,01747 |
| H | Información, telecomunicaciones, software e I+D | 0,03353 | 0,01106 | 0,02247 |
| I | Servicios inmobiliarios | 0,01280 | 0,00282 | 0,00998 |
| J | Administración y servicios sociales | 0,02465 | 0,00467 | 0,01998 |
| Total |  | 0,44310 | 0,19350 | 0,24960 |

### Eryndor

Población 2,00 M. PIB 0,18000. Impuestos netos 0,00900. VAB 0,17100. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,00132 | 0,00046 | 0,00086 |
| B | Minería y energía | 0,00276 | 0,00105 | 0,00171 |
| C | Manufactura y reparación | 0,02036 | 0,01181 | 0,00855 |
| D | Construcción e infraestructura | 0,01644 | 0,00789 | 0,00855 |
| E | Comercio, alojamiento y servicios personales | 0,02332 | 0,00793 | 0,01539 |
| F | Transporte y logística | 0,02948 | 0,01238 | 0,01710 |
| G | Finanzas, seguros y servicios empresariales | 0,09427 | 0,02074 | 0,07353 |
| H | Información, telecomunicaciones, software e I+D | 0,03279 | 0,00885 | 0,02394 |
| I | Servicios inmobiliarios | 0,01460 | 0,00263 | 0,01197 |
| J | Administración y servicios sociales | 0,01094 | 0,00154 | 0,00940 |
| Total |  | 0,24628 | 0,07528 | 0,17100 |

### Harnen

Población 8,00 M. PIB 0,52000. Impuestos netos 0,01820. VAB 0,50180. Estado MODELO ECON-03 HEREDADO CONCILIADO.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,04632 | 0,01621 | 0,03011 |
| B | Minería y energía | 0,25090 | 0,09032 | 0,16058 |
| C | Manufactura y reparación | 0,22173 | 0,12638 | 0,09535 |
| D | Construcción e infraestructura | 0,06887 | 0,03375 | 0,03512 |
| E | Comercio, alojamiento y servicios personales | 0,04182 | 0,01673 | 0,02509 |
| F | Transporte y logística | 0,11445 | 0,04921 | 0,06524 |
| G | Finanzas, seguros y servicios empresariales | 0,04301 | 0,01290 | 0,03011 |
| H | Información, telecomunicaciones, software e I+D | 0,03690 | 0,01181 | 0,02509 |
| I | Servicios inmobiliarios | 0,01255 | 0,00251 | 0,01004 |
| J | Administración y servicios sociales | 0,03023 | 0,00516 | 0,02507 |
| Total |  | 0,86678 | 0,36498 | 0,50180 |

### Islandia

Población 3,50 M. PIB 0,55000. Impuestos netos 0,03000. VAB 0,52000. Estado HIPÓTESIS NUEVA A092.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,06400 | 0,02240 | 0,04160 |
| B | Minería y energía | 0,19067 | 0,07627 | 0,11440 |
| C | Manufactura y reparación | 0,16640 | 0,08320 | 0,08320 |
| D | Construcción e infraestructura | 0,07564 | 0,03404 | 0,04160 |
| E | Comercio, alojamiento y servicios personales | 0,07429 | 0,02229 | 0,05200 |
| F | Transporte y logística | 0,10400 | 0,04160 | 0,06240 |
| G | Finanzas, seguros y servicios empresariales | 0,04550 | 0,00910 | 0,03640 |
| H | Información, telecomunicaciones, software e I+D | 0,05200 | 0,01560 | 0,03640 |
| I | Servicios inmobiliarios | 0,02447 | 0,00367 | 0,02080 |
| J | Administración y servicios sociales | 0,03900 | 0,00780 | 0,03120 |
| Total |  | 0,83597 | 0,31597 | 0,52000 |

### Groenlandia

Población 2,00 M. PIB 0,40000. Impuestos netos 0,02000. VAB 0,38000. Estado HIPÓTESIS NUEVA A092.

| Código | Sector | Producción | Insumos | VAB |
| --- | --- | --- | --- | --- |
| A | Agricultura, silvicultura y pesca | 0,08769 | 0,03069 | 0,05700 |
| B | Minería y energía | 0,19000 | 0,07600 | 0,11400 |
| C | Manufactura y reparación | 0,09120 | 0,04560 | 0,04560 |
| D | Construcción e infraestructura | 0,06909 | 0,03109 | 0,03800 |
| E | Comercio, alojamiento y servicios personales | 0,02714 | 0,00814 | 0,01900 |
| F | Transporte y logística | 0,06333 | 0,02533 | 0,03800 |
| G | Finanzas, seguros y servicios empresariales | 0,00950 | 0,00190 | 0,00760 |
| H | Información, telecomunicaciones, software e I+D | 0,02714 | 0,00814 | 0,01900 |
| I | Servicios inmobiliarios | 0,01341 | 0,00201 | 0,01140 |
| J | Administración y servicios sociales | 0,03800 | 0,00760 | 0,03040 |
| Total |  | 0,61650 | 0,23650 | 0,38000 |

### Ajustes de redondeo

| Territorio | Campo | Antes | Después | Cambio VAB |
| --- | --- | --- | --- | --- |
| Calenardhon Austral | CI J | 0.12578 | 0.12580 | -0.00002 |
| Provincia del Orinoco | CI J | 0.05406 | 0.05405 | 0.00001 |
| Malaca | CI J | 0.01086 | 0.01089 | -0.00003 |
| Polinesia | CI J | 0.00744 | 0.00746 | -0.00002 |
| Micronesia | CI J | 0.00468 | 0.00467 | 0.00001 |
| Eryndor | CI J | 0.00153 | 0.00154 | -0.00001 |
| Harnen | CI J | 0.00514 | 0.00516 | -0.00002 |
