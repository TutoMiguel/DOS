# Cronología maestra atlántica de la Unión Valinoriana


Estado: VIGENTE V17.8 A106, con A092 y A093 conservadas. Las decisiones expresas posteriores del autor prevalecen sobre V16.3. Tol Eressëa 20–40 y Groenlandia 55–75 d. C.; poblaciones antiguas conservadas por ámbito.

* **2026 clasificación editorial:** Islandia y Groenlandia son unidades federales externas al Reino; 2026 no es primera incorporación histórica.
* **2026 cuentas conciliadas:** 481 + 37 + 5,5 = 523,5 millones; externas vigentes 42,5. PIB PPA 58,50 + 7,00 = 65,50 billones; los 0,95 de Islandia y Groenlandia ya están incluidos en las externas.

## Fundación y expansión inicial

* **998–990 a. C.:** ciclo de visiones de Míriel Elerwen.
* **990 a. C.:** Concilio de Forostar en Escania oriental; unión política de las Casas.
* **980 a. C.:** creación electiva de la Corona Occidental.
* **975 a. C.:** Primera Marcha de Harald I.
* **950 a. C.:** Pacto de Forlond; financiación, abastecimiento y límites de la Corona.
* **900 a. C.:** normalización de la Escritura Real del Alto Tengwar.
* **889 a. C.:** Pacto Naval Federal y creación de la Armada Federal Permanente.
* **975–650 a. C.:** exploración progresiva del Atlántico, Madeira, Canarias y Azores; fechas locales aún escalonadas.
* **650 a. C.:** conexión consolidada con Taur-en-Mor y primer recuento general de la red de Casas y aliados.
* **495 a. C.:** Gran Catastro de puertos, dominios y comunidades.
* **470 a. C.:** Concilio del Gran Mar; confirmación de dominio directo, vasallaje, protección y alianza.

## Expansión oriental y acumulación cultural

* **930 a. C.:** primeros contactos comerciales con redes fenicias del Mediterráneo occidental; intercambio de vocabulario náutico y técnicas de escritura.
* **706 a. C.:** contactos con Egipto y centros de navegación del Mediterráneo oriental; comienzan los registros comparados de astronomía, medicina y administración.
* **512 a. C.:** apertura de rutas regulares hacia el mar Rojo; se formalizan Casas de Traducción portuarias.
* **438 a. C.:** convenio de intercambio con Adén y redes del golfo de Adén.
* **401 a. C.:** reconocimiento de Socotra como escala científica y botánica.
* **291 a. C.:** contactos con Musandam y Ormuz; intercambio de cartografía, matemáticas y derecho mercantil.
* **248 a. C.:** primer convenio con Baréin; Eryndor queda como enclave cultural y comercial asociado.
* **219 a. C.:** acuerdos iniciales con Kuwait y el litoral mesopotámico.
* **451 d. C.:** convenio de copiado y preservación con bibliotecas de Constantinopla.
* **1005 d. C.:** convenio de astronomía, medicina y filosofía con Dar al-Hikma en El Cairo.
* **1200–1500:** contactos institucionales con Al-Qarawiyyin, Toledo, Bolonia, París, Cambridge, Padua, Salamanca, Lovaina y Coimbra.
* **1500–1800:** convenios científicos con Harvard, la Royal Society y universidades japonesas, rusas y norteamericanas.
* **Desde el primer contacto oriental:** la política de expansión combina comercio, diplomacia, ciencia, traducción, educación, archivo y navegación.

## Tol Eressëa, Terranova y Valinor

* **c. 180 a. C.:** primera expedición meridional que alcanza el arco caribeño.
* **c. 150 a. C.:** primer contacto documentado de los Valinari con comunidades del Caribe.
* **120–50 a. C.:** factorías estacionales, intercambios y pactos comerciales en el Caribe.
* **1–150 d. C.:** expansión de contactos hacia el Orinoco y las costas septentrionales de Sudamérica.
* **20–40 d. C.:** descubrimiento de Tol Eressëa.
* **400–500 d. C.:** expediciones desde Tol Eressëa alcanzan por primera vez la costa de Terranova.
* **Siglos V–VII d. C.:** reconocimiento estacional de Terranova; pesca, madera, agua, cartografía y campamentos de escala.
* **650–750 d. C.:** expedición desde Tol Eressëa hacia el sur y sureste; descubrimiento formal de Valinor.
* **750–850 d. C.:** primer asentamiento permanente en Valinor y desarrollo inicial de Nueva Tirion.
* **920–980 d. C.:** asentamiento permanente de Númenor en Terranova y fundación posterior de Armenelos.

## Expansión medieval y moderna

* **1000–1400 d. C.:** contactos e integración negociada con Fiji, Tonga, Polinesia y Micronesia.
* **1200–1600 d. C.:** transformación gradual de Malaca en unidad federal mediante tratados.
* **1400–1700 d. C.:** integración de Hawái y Fiji como estados mediante tratados de larga duración.
* **Siglos XV–XVIII:** expansión de factorías, ciudades pactadas y estados asociados en América.
* **Siglos XVIII–XIX:** industrialización temprana, ferrocarriles, minería, astilleros y urbanización.
* **1890:** creación de Andúnië Austral como ciudad federal arrendada en el estrecho de Magallanes.

## Revoluciones industriales y comunicaciones

* **1839:** fundación de COFOVAL como corporación federal de fomento; comienza la apropiación anual de desarrollo productivo, infraestructura y conocimiento.
* **1850:** industrialización inicial consolidada; vapor, hierro, ferrocarriles, telégrafo y astilleros mecanizados.
* **1870–1900:** cables submarinos, telefonía, electricidad, acero, química y motores de combustión.
* **1870–1913:** la apropiación de COFOVAL alcanza 0,15 % del PIB y financia ferrocarriles, energía, metalurgia, puertos y astilleros.
* **1895–1930:** Servicio Radiomarítimo Federal y expansión de la radio.
* **1914–1945:** la apropiación de COFOVAL alcanza 0,25 % del PIB para resiliencia, investigación aplicada y diversificación industrial.
* **1930–1945:** radar, criptografía, aviación y cálculo estratégico.
* **1946–1957:** centros de cálculo y redes computacionales centralizadas.
* **1946–1980:** la apropiación de COFOVAL alcanza 0,40 % del PIB y se orienta a electrificación, telecomunicaciones, investigación y plantas piloto.
* **1958:** creación del Programa OceanNet.
* **1959:** OceanNet inicia servicio digital institucional limitado sobre radio, microondas, cable convencional y líneas dedicadas.
* **1961–1962:** pruebas de conmutación de paquetes y enlaces satelitales.
* **1968:** OceanNet adquiere estatuto federal con la reforma de Polinesia y Micronesia.
* **1969:** consolidación institucional de OceanNet como red digital federal distribuida; no es su primer año de servicio.
* **1981–2000:** la apropiación de COFOVAL alcanza 0,50 % del PIB para fibra, redes digitales y proveedores tecnológicos.
* **1983:** adopción del protocolo federal común.
* **1990–2000:** apertura civil y comercial de OceanNet.
* **2001–2025:** la apropiación alcanza 0,55 % del PIB para centros de datos, energía, ciencia, logística y semiconductores.
* **2000–2026:** automatización, biotecnología, satélites, energía diversificada y urbanización avanzada.
* **2026:** la apropiación de COFOVAL es 0,60 % del PIB federal (393.000 millones PPA sobre 65,50 billones); su techo de financiación movilizada es 1,40 % (917.000 millones, incluida la apropiación). La financiación externa solo se cuenta si se contrata efectivamente.
* **2026:** COFOVAL consolida el balance físico de planificación de semiconductores: 7,50 millones de obleas equivalentes demandadas, 6,90 de producción local, 1,35 importadas, 0,65 exportadas y 0,10 añadidas a inventarios; no son cifras de producción auditada.
* **2026:** se aprueba la estrategia federal de la Tercera Revolución Industrial en catorce decisiones. Las Decisiones 1–2 mantienen sus desarrollos de semiconductores y telecomunicaciones; las Decisiones 3–14 abarcan continuidad, computación, automatización, ciberseguridad, identidad, datos, investigación, estándares, energía, acceso, competencia y gobernanza. La ventaja de diez años se fija como objetivo selectivo de despliegue amplio frente a rivales por tecnología. No sustituye la regla específica de siete años para el adelanto de aplicación en telecomunicaciones. Las capacidades, presupuestos y metas sin línea base quedan pendientes de medición y auditoría; la aprobación no modifica automáticamente el PIB ni las partidas vigentes. Véase [[00_Canon/Integraciones V16/A091_Estrategia_digital_y_decisiones_3_14|A091]].



### Desarrollo histórico integrado de la Tercera Revolución Industrial

- **1950–1953:** se fortalecen electrónica, cálculo científico, criptografía, control especializado y equipos de investigación; aún no existe una red digital federal general.
- **1954–1958:** redes precursoras y pruebas de enlaces, terminales y procedimientos de OceanNet. Es etapa preparatoria, no operación plena.
- **1958–1959:** se crea el Programa OceanNet en 1958 y comienza servicio digital institucional limitado en 1959.
- **1961–1962:** se ensayan conmutación de paquetes y enlaces satelitales; son pruebas técnicas, no cobertura universal.
- **1968–1969:** estatuto federal en 1968 y consolidación institucional en 1969, posteriores al inicio operativo.
- **1970–1979:** ampliación gradual hacia universidades, puertos, observatorios, industria y administración, todavía con acceso especializado.
- **1980–1989:** interoperabilidad, protocolos comunes y corredores ópticos; se mantienen los hitos técnicos y el criterio de siete años de la ficha de telecomunicaciones.
- **1990–2000:** apertura civil y comercial progresiva a banca, educación, medios, comercio y servicios públicos.
- **2001–2010:** banda ancha, fibra, movilidad y centros de datos amplían la conectividad y elevan necesidades de energía, personal y seguridad.
- **2011–2020:** plataformas, nube, sensores, análisis y automatización sectorial aumentan productividad y dependencia de redes y proveedores.
- **2021–2026:** se integran ciberseguridad, electrónica estratégica, centros de datos e inteligencia artificial aplicada. El objetivo de diez años de ventaja es selectivo por tecnología y rival, no una afirmación uniforme.

La expansión se evalúa mediante series territoriales de cobertura y calidad, productividad sectorial, inversión y costos de ciclo de vida, empleo y reconversión, consumo energético y material, privacidad, resiliencia y capacidad local de mantenimiento. Cada dato se clasifica como observado, estimado, objetivo o pendiente. Los presupuestos deben conciliarse con COFOVAL y ECON-03; la aprobación estratégica no modifica automáticamente el PIB ni las partidas. Las responsabilidades legales se asignan a instituciones existentes salvo vacío probado. El desarrollo integral y sus criterios de auditoría están en [[11_Ciencia y Tecnologia/Tercera Revolución Industrial 1950-2026]].

## Consolidación política contemporánea

* **1536:** Eryndor (Baréin) adquiere estatuto federal directo dentro de la estructura oriental.
* **1611:** Rhunost (Musandam) se incorpora como unidad federal estratégica.
* **1800–1950:** consolidación progresiva de protectorados, puertos asociados y enclaves mediterráneos y del mar Rojo.
* **1958–2026:** integración de los enclaves orientales en Beleg Valinor, manteniendo soberanías diferenciadas según tratado.
* **2026:** queda vigente la jerarquía **Valinor → Valinor a Tyl → Aranath Valinor → Gwaith Valinor → Beleg Valinor → Gwaith Aear**. Aranath Valinor se define como reino constituyente de Gwaith Valinor: todos sus territorios pertenecen a la Federación a través del Reino, aunque no sean miembros federales directos. Las unidades federales externas al Reino se vinculan directamente al gobierno federal.
* **2026:** Nosselië Toliva (Canarias) queda dentro de Aranath Valinor y, por medio del Reino constituyente, dentro de Gwaith Valinor. No se cuenta como adición federal externa. Su superficie canónica es 7.493 km² y su población 10 millones.
* **2026:** Eryndor (Baréin) y Harnen (Omán) pasan de protectorados a estados federados de Gwaith Valinor; Rhunost (Musandam) queda como provincia autónoma estratégica dentro de Harnen.
* **2026:** corrección proporcional de Eryndor y Harnen: 10 millones de habitantes y 0,70 billones PPA conjuntos. Son unidades federales externas al Reino; Rhunost permanece dentro de Harnen. Gwaith Valinor alcanza 523,5 millones; Beleg Valinor 724,5–879,5 millones (rango rector A092; desglose exterior incompleto); Gwaith Aear rango de aliados todavía no conciliado (antecedente 1.115,5–1.515,5 millones).

## Complejo industrial estratégico

* **1850–1880:** máquinas de vapor ferroviarias y navales.
* **1880–1910:** motores de combustión, generadores y primeros motores aeronáuticos.
* **1910–1940:** motores diésel para blindados, submarinos y buques.
* **1940–1960:** turbinas de gas para aviación y generación eléctrica.
* **1958–1968:** transistores, circuitos integrados y electrónica asociada a OceanNet.
* **1969–1980:** microprocesadores federales, radares y sistemas de control.
* **1980–2000:** motores modulares, combustibles sintéticos, circuitos resistentes y propulsión híbrida.
* **1995–2010:** fabricación avanzada de procesadores para satélites, radares y aeronaves.
* **2010–2026:** inteligencia artificial, procesadores neuromórficos, turbinas avanzadas y propulsión naval integrada.
* **2026:** la cadena estratégica queda integrada desde la minería y refinación hasta circuitos, procesadores, motores, turbinas y sistemas militares.
* **2026 (estimación económica anterior, sustituida):** el rango federal de 67–81 billones PPA, la participación de 12 % para industria militar/aeroespacial y las exportaciones de 5–8 billones se conservan como antecedentes de planificación; no son magnitudes validadas por las cuentas territoriales ECON-03 vigentes.
* **2026 (ECON-03 vigente):** se aprueban como canon las delimitaciones operativas, poblaciones, distribuciones urbanas/rurales, núcleos urbanos y cuentas territoriales A–J de las 21 unidades. La población queda en 481 millones para el Reino y 523,5 millones para la Federación. La conciliación central fija PIB PPA de 58,50 billones para el Reino y 7,00 para las unidades federales externas; el total federal es 65,50 billones (redondeado a 66).
* **2026 (cierre contable ECON-03):** producción bruta menos consumo intermedio equivale a VAB; VAB más impuestos netos sobre productos equivale a PIB. Los agregados territoriales no suman producción bruta entre territorios. Las cuentas son estimaciones canónicas del mundo ficticio, no estadísticas observadas; empleo, productividad y comercio interterritorial quedan como refinamientos posteriores.
* **2026:** la Círdan IV queda definida como fragata oceánica equivalente o ligeramente superior a la Type 26 contemporánea: casco silencioso, propulsión eléctrica integrada, turbina de gas, sensores antisubmarinos, helicóptero, drones y enlaces OceanNet.
* **2030–2037 (planificado):** entrada progresiva de la clase Voronwë como generación posterior a la Type 26 y sustituta de las Círdan IV.

## Evolución de las clases navales

* **1850–1900:** arsenales de vapor, buques blindados, torpederos y primeros patrulleros.
* **1900–1945:** destructores iniciales, submarinos convencionales, cruceros y aviación naval.
* **1945–1965:** portaaviones, submarinos de largo alcance, buques logísticos y radares navales.
* **1965–1985:** clases Gil-galad, Círdan inicial y Ulmo; integración de misiles, sonar y OceanNet temprano.
* **1985–2005:** clases Círdan II–III, Pelargir, Andúnië y primeros drones navales; producción modular, radar 4d aesa.
* **2005–2026:** Círdan IV, Eärendil, Telperion, Palantír, Menel, Esgaroth y Abyssal; misiles hipersonicos y vigilancia distribuida.
* **2026:** la Armada opera una familia completa de portaaviones, escoltas, submarinos, buques logísticos, drones y unidades de rescate.
* **2022:** comienza la construcción de Voronwë. **2026–2033:** entrada en servicio y relevo progresivo de Círdan IV por lotes; los 64 escoltas tipo fragata de 2026 incluyen ambas generaciones.

## Evolución de radares navales

* **1958–1970:** radares tridimensionales iniciales.
* **1970–1985:** antenas de escaneo electrónico y procesamiento digital.
* **1985–2000:** primeros radares AESA navales.
* **2000–2015:** integración de sensores navales con OceanNet.
* **2015–2026:** despliegue del Palantír-4D en buques, bases costeras y aeronaves.
* **2018–2022:** investigación y prototipos del Palantír Aeglos.
* **2022–2025:** pruebas costeras y aéreas del Aeglos.
* **2025–2029:** modernización de destructores Gil-galad con Aeglos.
* **2029–2040:** incorporación progresiva del Aeglos en fragatas Voronwë.
* **2040–2045:** despliegue completo en portaaviones, bases y aeronaves de alerta temprana.

## Magallanes y Andúnië Austral

* **850–1000:** reconocimiento valinoriano del estrecho de Magallanes.
* **1500–1700:** escalas científicas, cartografía austral y observación de corrientes.
* **1780:** primer observatorio meteorológico permanente.
* **1845:** estación hidrográfica y faro cooperativo con Chile.
* **1890:** fundación de Andúnië Austral como ciudad científica arrendada bajo soberanía chilena.
* **1938:** creación del Instituto Austral de Oceanografía.
* **1945:** integración con los programas antárticos valinorianos.
* **1958:** conexión de Andúnië Austral con OceanNet.
* **1970:** instalación de radares meteorológicos, sísmicos y oceanográficos.
* **1990:** ampliación del puerto, laboratorios y aeropuerto científico.
* **2010:** incorporación de sistemas de alerta de tsunamis y volcanes.
* **2026:** Andúnië Austral se consolida como principal nodo científico, antártico y logístico de Gwaith Aear en el extremo sur.

## Gran Guerra del Pacífico

* **1848:** Tratado de Valparaíso entre Chile y la Unión Valinoriana.
* **1876:** Pacto del Pacífico Austral; cooperación naval, seguros, formación de oficiales y logística.
* **1879:** Chile ocupa Antofagasta; Perú activa su alianza defensiva con Bolivia.
* **1879–1880:** Chile obtiene supremacía naval y captura anticipadamente el Huáscar.
* **1880:** caen Tarapacá, Tacna y Arica.
* **1881:** desembarcos chilenos y caída de Lima.
* **1882–1883:** resistencia peruana y agotamiento boliviano.
* **1884:** Argentina inicia la Operación de Garantía Continental y entra en el conflicto.
* **1884–1885:** campañas de Icalma, Pino Hachado, Mamuil Malal, Zapala, Uspallata y Río Gallegos.
* **1886:** Tratado de Nueva Tirion; Chile incorpora el litoral boliviano, Arica, Tacna, Mollendo, Tierra del Fuego, Santa Cruz meridional, Neuquén occidental y la alta cordillera mendocina.
* **Después de 1886:** Chile se consolida como potencia marítima del Pacífico sur y mantiene alianza estratégica con Valinor.

### Consolidación del retcon de 1883–1886

* **1883:** Argentina decide intervenir antes de la derrota definitiva de Perú y Bolivia.
* **1884:** comienza la Operación de Garantía Continental y la Operación Cordillera Oriental.
* **1884:** Chile vence en Aluminé y ocupa Junín de los Andes.
* **1885:** Chile vence en Zapala y controla Neuquén occidental.
* **1885:** Chile vence tácticamente en Uspallata y controla Las Cuevas, Portillo y los pasos de la alta cordillera mendocina.
* **1885:** Chile ocupa Río Gallegos y consolida el frente austral.
* **1886:** Tratado de Nueva Tirion; se fijan las cesiones territoriales a Chile y termina la Guerra del Pacífico ampliada.

## Estado demográfico industrial

* **1850:** 34 000 000 habitantes; 6 800 000 urbanos.
* **1900:** 72 000 000 habitantes; 25 200 000 urbanos.
* **1950:** 142 000 000 habitantes; 82 360 000 urbanos.
* **2000:** 257 000 000 habitantes; 187 610 000 urbanos.
* **2026:** Valinor, 16 millones; Valinor a Tyl, 26 millones; Aranath Valinor, 481 millones; Gwaith Valinor, 523,5 millones. Beleg Valinor alcanza 724,5–879,5 millones (rango rector A092; desglose exterior incompleto) y Gwaith Aear rango de aliados todavía no conciliado (antecedente 1.115,5–1.515,5 millones). Las cifras son acumulativas y no deben sumarse entre niveles.

## Estado canónico

## Evolución de la teología de Eru, los Ainur y los Maiar

* **Periodo fundacional:** las comunidades migrantes transmiten relatos sobre Eru como principio creador y sobre los Ainur como primeros pensamientos o principios tutelares.
* **990 a. C.:** el Concilio de Forostar incorpora juramentos religiosos y fórmulas de legitimidad vinculadas a Eru, sin establecer una teocracia.
* **Siglos posteriores:** los Ainur se convierten en categorías para explicar la memoria de fundadores, sabios, héroes y órdenes religiosas.
* **Antes del siglo VI a. C.:** relatos sobre intermediarias Maiar se integran en genealogías nobles y tradiciones de santuarios.
* **575–550 a. C.:** la tradición de la antepasada Maiar de Telcontar se utiliza para explicar el prestigio de la rama retornada; la interpretación política mantiene su genealogía humana.
* **Edad media valinaria:** templos, archivos, escuelas y órdenes de guardianes sistematizan las categorías de Eru, Ainur y Maiar.
* **Edad moderna:** historiadores y teólogos diferencian doctrina, literatura épica, memoria oral y evidencia histórica.
* **833 d. C.:** la Casa Real Telcontar conserva el mito de origen, pero el Estado reconoce que sus rasgos físicos y su legitimidad proceden de herencia humana, instituciones y pactos políticos.
* **Canon V16:** Eru, Ainur y Maiar quedan definidos como categorías religiosas y culturales, no como especies ni entidades verificables.

## Desarrollo religioso y relaciones interconfesionales

* **1000 a. C.–500 d. C.:** predomina la tradición valinari de Eru; los Ainur y Maiar se interpretan como principios, fundadores, sabios e intermediarios sacralizados. Aparecen contactos mediterráneos y comunidades mercantiles judías y cristianas.
* **990 a. C.:** el Concilio de Forostar incorpora juramentos religiosos sin establecer una teocracia ni permitir que la Corona se declare encarnación de Eru.
* **500–1200:** las rutas atlánticas y mediterráneas intensifican el intercambio con judaísmo, cristianismo y primeras redes islámicas; se desarrollan traducción, medicina, archivos y derecho mercantil.
* **1200–1600:** la expansión hacia Egipto, el mar Rojo, Adén, Socotra, Omán y Malaca fortalece la cooperación con sociedades musulmanas. Las rutas del Índico y Asia introducen relaciones estables con monasterios budistas.
* **1600–1800:** se consolidan tratados portuarios, protección de peregrinos, hospitales interconfesionales, cementerios y tribunales mixtos limitados.
* **1800–1956:** la libertad de culto se institucionaliza; comunidades judías, católicas, musulmanas y budistas participan en educación, medicina, comercio y diplomacia.
* **1956–2026:** el pluralismo religioso se integra en el régimen constitucional. OceanNet conecta universidades, archivos, hospitales y centros de ayuda de distintas comunidades.

La relación histórica con otros credos se formula como pluralismo pactado. Los conflictos religiosos no se convierten automáticamente en guerras doctrinales: se distinguen las disputas de fe de los conflictos políticos, territoriales, comerciales y estratégicos.

* **Siglos X–VIII a. C.:** se forman templos locales, santuarios de las estrellas y primeras Casas de la Memoria.
* **Siglos VII–V a. C.:** las Tradiciones de la Unidad, los Guardianes, las Custodias y la tradición Marítima adquieren funciones diferenciadas.
* **Periodo de la Corona pactada:** los ritos de nacimiento, mayoría de edad, matrimonio y muerte se registran junto con los pactos civiles.
* **Expansión atlántica:** las capellanías navales y las órdenes de guardianes protegen viajeros, hospitales, archivos y refugios.
* **Edad media:** las fiestas de Forostar, Elerwen, los Pactos y los Navegantes se consolidan en el calendario valinari.
* **Siglos XVII–XVIII:** aumentan los debates sobre jurisdicción religiosa, impuestos, escuelas y autoridad de las Casas.
* **Siglo XIX:** los registros civiles, universidades, hospitales y tribunales adquieren autonomía progresiva respecto de los templos.
* **1956:** el Estado reconoce libertad de culto y separa administración, ciencia y autoridad religiosa.
* **2026:** la identidad religiosa valinari permanece vigente dentro de un sistema pluralista constitucional.

## Cronología dinástica de la Casa Telcontar

* **560 a. C.:** Harald II Telcontar es coronado primer monarca de la Casa.
* **550 a. C.:** el Pacto de la Corona Telcontar fija la sucesión hereditaria preferente, limitada por el Consejo de las 24 Casas.
* **560 a. C.–407 d. C.:** se suceden treinta monarcas de la primera línea dinástica; la Corona mantiene el equilibrio entre herencia, elección confirmatoria y fueros.
* **430 d. C.:** Eärnil II Telcontar abdica; es la primera abdicación reconocida del registro dinástico.
* **430–441 d. C.:** Regencia del Consejo de la Corona, con participación de las 24 Casas, Telcontar, la Guardia Real, los puertos principales y los custodios de archivos y santuarios.
* **441–804 d. C.:** Baranor II es coronado y se suceden doce monarcas de las ramas Baranor, Círdan, Falastur, Calenhir, Arathorn, Elessar, Hador, Galdor, Eäron, Thalion y Aranwë.
* **804 d. C.:** Elendur III Telcontar ocupa la Corona.
* **829 d. C.:** muere Elendur III y se inicia la sucesión de Thalion IV.
* **833 d. C.:** Thalion IV Telcontar es coronado en Nueva Tirion y figura como monarca vigente.

El registro completo de nacimiento, coronación, abdicación y muerte de los 44 monarcas se conserva en [[../00_Canon/Canon V16 Maestro|Canon V16 Maestro]], sección «Registro dinástico de la Casa Telcontar».

## Desarrollo naval, aeronaval y estratégico

* **1900–1914:** la Armada se estructura alrededor de vapor, carbón, cruceros, torpederos, cañoneras, primeros submarinos y estaciones telegráficas.
* **1914–1930:** se crean flotillas submarinas, bases de hidroaviones, escuelas de convoy, centros de escucha y estaciones meteorológicas; Islandia adquiere valor como escala del Atlántico Norte.
* **1930–1945:** se incorporan radar costero, aviación de patrulla, criptografía, defensa antiaérea, buques de desembarco y submarinos de largo alcance; Groenlandia recibe estaciones meteorológicas y de comunicaciones.
* **1945–1956:** se crean el Comando Estratégico Marítimo, la aviación naval de reacción, los submarinos oceánicos, los portaaviones modernos, las bases árticas y los centros de investigación nuclear.
* **1956:** se establece el Comando del Atlántico Norte con bases en Islandia y Groenlandia.
* **1956–1969:** las bases incorporan centros de cálculo, radar integrado, enlaces digitales, satélites y control logístico informatizado.
* **1969:** OceanNet conecta progresivamente flotas, arsenales, aeródromos, universidades, hospitales y centros de datos.
* **1970–2000:** se incorporan submarinos de propulsión nuclear, misiles antibuque, defensa aérea naval, helicópteros antisubmarinos, satélites y guerra electrónica.
* **2000–2026:** se despliegan inteligencia artificial, drones, radares Palantír-4D y Palantír Aeglos, submarinos no tripulados y sistemas de defensa antimisiles.
* **1945 y 1960:** AM1 conserva reconstrucciones de 368 y 408 unidades respectivamente; sirven para explicar la transición y no son inventarios medidos.
* **1980:** la composición canónica de referencia suma 427 unidades en categorías separadas: 7 portaaviones, 14 cruceros, 36 destructores, 56 fragatas/escoltas, 50 corbetas, 24 lanchas misilísticas, 60 patrulleros, 42 submarinos, 34 anfibios, 26 MCM y 78 auxiliares.
* **2026:** el inventario canónico suma 615 plataformas: 595 buques tripulados y 20 vehículos navales no tripulados; distribución: 11 portaaviones, 54 submarinos, 190 combatientes de superficie, 34 anfibios, 220 plataformas de patrulla/vigilancia/servicio y 106 auxiliares. La disponibilidad estimada de 449 es una hipótesis de planificación. Véase [[12_Militar/03_Armada/AM1 Armada 1875-2026|AM1 Armada 1875–2026]].

La economía naval se integra con acero, motores, turbinas, electrónica, radares, astilleros, aeronáutica, combustibles, seguros y logística. Islandia aporta energía geotérmica, pesca, aluminio y reparación naval; Groenlandia aporta minerales estratégicos, hidroelectricidad, investigación polar, comunicaciones y defensa.

## Incorporación atlántica septentrional de Islandia y Groenlandia

* **720–650 a. C.:** navegantes valinarios reconocen Islandia como escala del corredor septentrional; no se produce una anexión inmediata.
* **600–300 a. C.:** se mantienen estaciones estacionales de pesca, navegación y observación en Islandia.
* **300 a. C.–300 d. C.:** expediciones de largo alcance identifican rutas hacia Groenlandia y establecen puntos temporales de abastecimiento.
* **700–950:** se consolidan comunidades marítimas permanentes en Islandia y se reabre el corredor hacia el Ártico.
* **950:** Islandia queda bajo protectorado marítimo pactado.
* **1050:** comienza un protectorado groenlandés discontinuo, dependiente de las condiciones de navegación y abastecimiento.
* **1120–1150:** incorporación pactista de Islandia con autonomía marítima; antecedente del régimen federal moderno. V16.3-02.
* **1250–1500:** la presencia administrativa en Groenlandia se reduce por aislamiento y clima; la soberanía se mantiene como pretensión histórica, pero la administración efectiva es intermitente.
* **1600–1800:** se recuperan las rutas polares, la cartografía y las estaciones de observación.
* **1850:** se restablece de forma permanente la administración groenlandesa.
* **1900–1945:** se amplían puertos, minería, aviación, meteorología y comunicaciones.
* **1945:** Groenlandia pasa a ser centro de investigación polar, vigilancia y logística ártica.
* **1952–1956:** se construyen el Instituto Ártico de Física Nuclear, radares, estaciones de alerta temprana y centros de cohetería.
* **1956:** reconocimiento constitucional de Islandia y Groenlandia en el régimen federal moderno; creación del Comando del Atlántico Norte. V16.3-02.
* **1957–1958:** Valinor realiza su primera prueba nuclear dentro de la secuencia de desarrollo del programa federal; Groenlandia participa como centro científico y de seguridad, no como único lugar de producción.
* **1958–1969:** Islandia y Groenlandia se conectan progresivamente a la Red Federal de Comunicaciones Marítimas y después a OceanNet.
* **2026:** Islandia alcanza 3,5 millones de habitantes y 0,55 billones de dólares PPA; Groenlandia alcanza 2 millones de habitantes y 0,40 billones. La adición conjunta es de 5,5 millones de habitantes, 2.269.000 km² y 0,95 billones de dólares PPA.

### Desarrollo militar y tecnológico septentrional

* **1945–1956:** se despliegan patrullas antisubmarinas, rompehielos, radares, estaciones meteorológicas y protección de cables.
* **1956:** la Armada incorpora el Comando del Atlántico Norte, con bases en Islandia y Groenlandia, aviones de patrulla marítima y buques oceanográficos.
* **1956:** la capacidad nuclear valinoriana se clasifica como potencia de umbral avanzado, con dispositivos experimentales y sin arsenal estratégico desplegado.
* **1959–1961:** se establece una disuasión nuclear mínima y se integran aeronaves, misiles y centros de mando.
* **1960–1980:** Groenlandia amplía la investigación de materiales, energía, cohetería, comunicaciones y vigilancia espacial.
* **2000–2026:** ambos territorios se incorporan a la infraestructura digital, energética, científica y logística de Gwaith Valinor.

Esta cronología incorpora la secuencia atlántica revisada, la expansión cultural oriental y la escala demográfica acumulativa vigente como **\[RETCON AUTORIZADO]**. Las cifras históricas de 1850–2000 se conservan como serie demográfica de desarrollo; la escala política vigente de 2026 es la de Valinor 16 millones, Aranath Valinor 481 millones y Gwaith Valinor 523,5 millones, sin sumar entidades anidadas. Aranath Valinor es un reino constituyente: todos sus territorios, incluida Nosselië Toliva, pertenecen a Gwaith Valinor por medio del Reino. El PIB federal se consolida sumando el PIB del Reino y el de las unidades federales externas; el PIB del Reino se obtiene sumando sus territorios internos.

## Auditoría de coherencia documental — actualizada al 31 de octubre de 2026

La cronología se integra con el Canon Maestro y la precedencia acumulativa. Quedan fijados: escala 16/26/481/523,5 millones; Islandia y Groenlandia como territorios federales autónomos; Aranath Valinor como reino constituyente de Gwaith Valinor; todos los territorios del Reino —incluida Nosselië Toliva— dentro de la Federación por medio del Reino; Eryndor y Harnen como unidades federales externas; Systreyjar dentro de Valinor a Tyl; convenios culturales orientales con fechas aproximadas; y el cierre territorial ECON-03 de 58,50 billones PPA para el Reino y 65,50 para la Federación. Las cifras económicas agregadas sustituidas quedan solo como antecedentes. La integración septentrional incorpora el Comando del Atlántico Norte, la capacidad nuclear de umbral de 1956 y una infraestructura científica, militar y logística ártica.

## Alturas consolidadas de representación visual de las 84 Casas

Estas alturas pertenecen a la dirección artística de los prompts de imagen y no constituyen datos biográficos obligatorios ni rasgos genéticos. Se miden de planta a coronilla, sin calzado ni adornos; los dos representantes deben aparecer sobre el mismo plano de suelo. La Casa Telcontar conserva su excepción aprobada de 1,97 m y 1,88 m.

| Casa | Hombre | Mujer |
|---|---:|---:|
| Casa Alqualondë | 1,95 m | 1,75 m |
| Casa Annúminas | 1,88 m | 1,82 m |
| Casa Armenelos | 2,02 m | 1,80 m |
| Casa Barad Calen | 1,97 m | 1,83 m |
| Casa Calenhad | 2,00 m | 1,84 m |
| Casa Calenor | 1,82 m | 1,80 m |
| Casa Círdan | 1,79 m | 1,81 m |
| Casa Dol Amroth | 1,78 m | 1,76 m |
| Casa Eldalondë | 1,83 m | 1,73 m |
| Casa Elwing | 1,98 m | 1,76 m |
| Casa Eressëa Menel | 2,01 m | 1,75 m |
| Casa Eryn Lasgalen | 1,80 m | 1,84 m |
| Casa Esgal | 1,93 m | 1,79 m |
| Casa Fornost | 1,81 m | 1,77 m |
| Casa Harlond | 1,92 m | 1,74 m |
| Casa Harnost | 1,94 m | 1,82 m |
| Casa Minas Anor | 1,99 m | 1,79 m |
| Casa Mithlond | 1,86 m | 1,74 m |
| Casa Noldor | 1,77 m | 1,73 m |
| Casa Pelargir | 1,85 m | 1,81 m |
| Casa Rhunost | 1,87 m | 1,77 m |
| Casa Taur-en-Mor | 1,90 m | 1,78 m |
| Casa Teleri | 1,91 m | 1,83 m |
| Casa Vanyar | 1,84 m | 1,78 m |
| Casa Aerandir | 1,94 m | 1,80 m |
| Casa Aglaran | 1,88 m | 1,80 m |
| Casa Angren | 1,92 m | 1,84 m |
| Casa Baranor | 2,02 m | 1,78 m |
| Casa Belegor | 1,97 m | 1,81 m |
| Casa Celepharn | 1,83 m | 1,84 m |
| Casa Círdanir | 1,96 m | 1,78 m |
| Casa Duilin | 1,78 m | 1,74 m |
| Casa Elentir | 1,86 m | 1,84 m |
| Casa Erestor | 1,99 m | 1,77 m |
| Casa Eärond | 1,84 m | 1,76 m |
| Casa Falastur | 1,89 m | 1,73 m |
| Casa Falathar | 1,87 m | 1,75 m |
| Casa Gwindor | 1,81 m | 1,75 m |
| Casa Hallas | 2,00 m | 1,82 m |
| Casa Lindor | 1,93 m | 1,77 m |
| Casa Maethor | 1,90 m | 1,76 m |
| Casa Meneldir | 1,98 m | 1,74 m |
| Casa Nimrodel | 1,80 m | 1,82 m |
| Casa Ostor | 1,77 m | 1,83 m |
| Casa Tarond | 1,95 m | 1,73 m |
| Casa Thoron | 1,79 m | 1,80 m |
| Casa Tumladen | 1,85 m | 1,79 m |
| Casa Voronwë | 1,91 m | 1,81 m |
| Casa Aegnor | 1,77 m | 1,81 m |
| Casa Amdir | 1,84 m | 1,74 m |
| Casa Amrod | 1,91 m | 1,79 m |
| Casa Anardil | 1,98 m | 1,84 m |
| Casa Araphor | 1,86 m | 1,82 m |
| Casa Ardamir | 1,79 m | 1,77 m |
| Casa Barahir | 1,93 m | 1,75 m |
| Casa Belegund | 2,00 m | 1,80 m |
| Casa Brandir | 1,81 m | 1,73 m |
| Casa Calenard | 2,01 m | 1,73 m |
| Casa Dírhael | 1,88 m | 1,78 m |
| Casa Ecthelion | 1,95 m | 1,83 m |
| Casa Erchirion | 2,02 m | 1,76 m |
| Casa Erellont | 1,96 m | 1,76 m |
| Casa Estelmo | 1,83 m | 1,81 m |
| Casa Findegil | 1,90 m | 1,74 m |
| Casa Folcred | 1,97 m | 1,79 m |
| Casa Forlong | 1,78 m | 1,84 m |
| Casa Galdor | 1,85 m | 1,77 m |
| Casa Hador | 1,92 m | 1,82 m |
| Casa Hareth | 1,99 m | 1,75 m |
| Casa Harlind | 1,89 m | 1,83 m |
| Casa Imrahil | 1,80 m | 1,81 m |
| Casa Iorlas | 1,87 m | 1,73 m |
| Casa Malbeth | 1,94 m | 1,78 m |
| Casa Ohtar | 2,01 m | 1,83 m |
| Casa Oropher | 1,82 m | 1,76 m |
| Casa Rúmilion | 1,82 m | 1,78 m |
| Casa Saeros | 1,89 m | 1,81 m |
| Casa Targon | 1,96 m | 1,74 m |
| Casa Tuor | 1,77 m | 1,79 m |
| Casa Vorondil | 1,84 m | 1,73 m |
| Casa Wídfara | 1,91 m | 1,77 m |
| Casa Yavannor | 1,98 m | 1,82 m |
| Casa Zirin | 1,79 m | 1,75 m |
| Casa Telcontar | 1,97 m | 1,88 m |
## Secuencia ampliada de enclaves y posiciones asociadas

- **900–650 a. C.:** reconocimiento de rutas atlánticas y del océano Índico.
- **400 a. C.–1200 d. C.:** escalas estacionales, cartografía y acuerdos marítimos.
- **1200–1450:** factorías y puertos asociados en Madeira, Cabo Verde, Santo Tomé y rutas africanas.
- **1460–1520:** formalización de Eärendil (Cabo Verde).
- **1490–1550:** consolidación de Tol Morwen (Santo Tomé y Príncipe).
- **1500–1750:** acuerdos en Bijagós, Gibraltar, Curaçao y rutas australes.
- **1770–1815:** estación de Eressëa Índica (Seychelles).
- **1815–1914:** formalización de Barad Nimras (Gibraltar).
- **1880–1910:** creación del protectorado marítimo de Nanduhirion (Palau).
- **1900–1950:** especialización de Forlond Austral y Amon Uilos.
- **1958–2026:** integración de la red mundial en OceanNet.
## Comercio mediterráneo y circulación del conocimiento

- **c.1000–800 a. C.:** contactos indirectos mediante redes bálticas, continentales y atlánticas.
- **c.800–200 a. C.:** ampliación de intercambios con ámbitos ibéricos, norteafricanos, fenicios, griegos y púnicos.
- **c.200 a. C.–300 d. C.:** circulación de técnicas, textos, especialistas y bienes mediante redes romanas y mediterráneas.
- **300–800:** fragmentación, conservación parcial de archivos y reforma educativa valinari.
- **800–1300:** síntesis de conocimientos mediterráneos, islámicos, bizantinos, magrebíes e ibéricos.
- **1300–1500:** conexión complementaria entre Mediterráneo, mar Rojo, Índico y Malaca.
- **1500–1800:** imprenta, oficinas, contratos, puertos asociados y expansión de la circulación técnica.
- **1815:** Barad Nimras (Gibraltar) se establece como base naval arrendada y puerto asociado, no como territorio federal.
- **1850–1950:** vapor, telégrafo, radio, meteorología, cables y redes de investigación.
- **1954–1958:** redes precursoras de OceanNet.
- **1959:** OceanNet inicia un servicio digital institucional limitado; la cobertura y los servicios se amplían gradualmente.
- **1960–2026:** expansión computacional, institucional, civil y global de OceanNet.
## Telecomunicaciones, fibra y redes inalámbricas

- **1850:** la Red Telegráfica del Gran Mar enlaza capitales y puertos.
- **1870–1900:** cables submarinos y telefonía forman la Red de los Heraldos del Mar.
- **1895–1930:** radio costera, radiofaros, meteorología y enlaces con buques complementan el cable.
- **1954–1958:** el Programa OceanNet prueba líneas dedicadas, conmutación y radio/microondas.
- **1959:** OceanNet presta servicio digital institucional limitado; no hay cobertura civil general.
- **1962–1965:** Valinor ensaya estaciones terrenas después de las demostraciones internacionales de satélites de comunicaciones.
- **1970:** tras la demostración mundial de fibra de baja pérdida, comienzan investigación aplicada y pilotos valinari.
- **1973–1978:** pilotos de telefonía móvil, microondas y fibra institucional; expansión por etapas, no servicio universal.
- **1981:** entra en servicio limitado el primer corredor óptico submarino transoceánico valinari, siete años antes del TAT-8 mundial de 1988.
- **1983:** se adopta el protocolo federal común para interconectar redes civiles y sectoriales.
- **1984–1995:** fibra, estaciones móviles y rutas redundantes alcanzan capitales, puertos, universidades y nodos de OceanNet.
- **1990–2005:** se amplían acceso civil y comercial, banda ancha inicial y conectividad educativa.
- **2006–2018:** fibra hasta ciudades y centros comarcales, redes móviles de datos y satélites de respaldo.
- **2019–2026:** actualización de fibra y redes móviles de alta capacidad, seguridad y redundancia intercontinental e insular.

El adelanto de siete años se aplica frente a difusión internacional amplia cuando la tecnología ya ha sido demostrada; no se usa para anticipar pruebas, componentes o estándares aún inexistentes. Las fechas y límites de implementación se detallan en [[A090_Infraestructura_troncal_telecomunicaciones]].

## Esgal Nénar

- **300–500:** contactos marítimos con el corredor del Gambia y Casamance.
- **500–750:** estaciones comerciales y de abastecimiento.
- **750–950:** acuerdos fluviales con autoridades locales.
- **950:** establecimiento del protectorado pactado de Esgal Nénar.
- **1200–1800:** expansión agrícola, comercial y portuaria.
- **1800–1950:** vapor, ferrocarril, telégrafo, minería y puertos industriales.
- **1958–2026:** OceanNet, energía, investigación tropical y logística oceánica.

## Comercio valinari temprano, 1000–500 a. C.

Durante este periodo, el comercio valinari se organiza como una red marítima regional. No existe todavía un sistema imperial ni una presencia estable en el Mediterráneo; la economía depende de puertos, mercados estacionales, rutas costeras y pactos entre comunidades.

### Eje de Escania

Escania constituye el principal núcleo comercial y demográfico valinari. Sus puertos conectan el Øresund, el Kattegat, el Báltico occidental, las costas noruegas, Dinamarca y el mar del Norte. Helsingborg controla el paso del Øresund; Lund concentra administración, culto e intercambio terrestre; Malmö articula el mercado meridional; Ystad y Simrishamn sirven a la navegación báltica; Kristianstad, Åhus y Bromölla canalizan cereales, sal, madera y productos fluviales; Trelleborg y Falsterbo conectan con Dinamarca y el mar del Norte.

Escania exporta cereales, pescado conservado, pieles, madera, cerámica, herramientas y textiles. Importa metales, ámbar, ganado, sal y bienes de prestigio.

### Rutas noruegas y danesas

Noruega aporta marineros, madera, hierro, pieles, aceite, pescado seco y conocimiento náutico. Las rutas parten del Oslofjord, Vestfold, Østfold, Rogaland, Hordaland, Sogn, Møre y Trøndelag. Las comunidades septentrionales participan de forma más limitada y proporcionan pieles, pescado, grasa animal y productos árticos.

Dinamarca desempeña el papel de corredor marítimo, fuente de migración y zona de intermediación entre el Báltico y el mar del Norte. No es territorio valinari ni origen fundacional de una Casa Mayor: su función es la de espacio de contacto, tránsito, matrimonios y llegada de familias integradas a las comunidades valinarias.

### Báltico, mar del Norte y Atlántico

El Báltico es el principal espacio de expansión comercial temprana. Las rutas alcanzan Bornholm, Gotland, Öland, las costas bálticas de Suecia, el golfo de Finlandia y las costas orientales. Se intercambian ámbar, pieles, cera, miel, madera, hierro, pescado y otros bienes regionales.

El mar del Norte permite contactos con las costas germánicas, Frisia, las islas británicas y el norte de Francia. En esta fase los contactos son principalmente comerciales y no constituyen una política de conquista sistemática. Hacia el oeste se desarrolla una exploración costera gradual del Atlántico nororiental, condicionada por el clima, la navegación y la seguridad de los puertos.

### Mediterráneo conocido de forma indirecta

El Mediterráneo forma parte del horizonte geográfico e intelectual valinari, pero no de su espacio político o colonial durante 1000–500 a. C. Su conocimiento llega por mercancías, relatos de comerciantes daneses, germánicos y atlánticos, objetos de lujo, metales trabajados, cerámicas y rutas terrestres o fluviales europeas.

No existen en esta etapa puertos valinari permanentes en el Mediterráneo, enclaves diplomáticos estables, provincias mediterráneas, control de Gibraltar ni redes comerciales directas y continuas con Egipto, Fenicia, Grecia, Italia o el Levante. Los contactos mediterráneos posteriores se desarrollan gradualmente y no deben proyectarse retrospectivamente sobre la primera organización valinari.

### Instituciones comerciales

El intercambio se estructura mediante mercados locales, ferias regionales, rutas de larga distancia y pactos portuarios. Estos últimos regulan derechos de atraque, tasas, reparación de barcos, protección de comerciantes, neutralidad temporal, devolución de mercancías y seguridad de almacenes.

Las Casas Mayores controlan recursos y rutas interiores. Las Casas Menores se especializan en navegación, exploración, cartografía, traducción, fundación de factorías y protección de convoyes. Las Casas Vasallas todavía no forman una estructura plenamente desarrollada; sus antecedentes aparecen como capitanías, administradores portuarios, ramas matrimoniales y comunidades asociadas.

### Evolución del periodo

- **1000–990 a. C.:** crisis de las comunidades originarias, fragmentación de rutas y competencia por alimentos, puertos y metales.
- **990–950 a. C.:** el Concilio de Forostar protege mercados, almacenes y puertos neutrales.
- **950–850 a. C.:** recuperación de las rutas entre Escania, Noruega, Dinamarca y el Báltico occidental.
- **850–750 a. C.:** expansión hacia el mar del Norte y aparición de factorías temporales.
- **750–700 a. C.:** reconocimiento sistemático de las islas atlánticas orientales.
- **700–600 a. C.:** crisis de abastecimiento y aumento de la dependencia de pactos de protección.
- **600–550 a. C.:** retorno de la Casa Telcontar desde su autoexilio finlandés y reorganización de rutas.
- **550–500 a. C.:** el pacto de 550 a. C. subordina la coordinación comercial a la Corona, conservando derechos portuarios de las Casas.

La estructura comercial de 1000–500 a. C. es marítima, regional, descentralizada y dependiente de puertos y pactos. Constituye la base de la expansión atlántica posterior sin convertir a Valinor en una potencia transcontinental prematura.

## Profundización cronológica de la teología valinari

* **1000–990 a. C.:** los cultos regionales de memoria ancestral, naturaleza, estrellas, fuentes y juramentos conviven sin una doctrina única.
* **990 a. C.:** el Concilio de Forostar reconoce a Ilúvatar como principio común, incorpora juramentos religiosos y separa autoridad sacerdotal, autoridad política e investigación.
* **950–850 a. C.:** los santuarios organizan archivos, calendarios, graneros y mediación entre Casas; los Ainur se interpretan como principios tutelares.
* **850–700 a. C.:** las Casas marítimas, agrícolas, metalúrgicas y exploradoras desarrollan tradiciones funcionales asociadas a los Valar.
* **700–600 a. C.:** las Casas de la Memoria y los santuarios astronómicos sistematizan relatos sobre Valar y Maiar, sin convertirlos en entidades verificables.
* **600–550 a. C.:** el mito de la antepasada Maiar de Telcontar adquiere relevancia durante el retorno de la rama exiliada; la interpretación histórica conserva una genealogía humana.
* **550–500 a. C.:** el pacto de la Corona establece que el monarca protege pactos, santuarios, graneros, rutas y comunidades, pero no gobierna por derecho divino.
* **Siglos posteriores:** templos, escuelas, archivos, capellanías y órdenes de guardianes consolidan la tradición sin eliminar sus diferencias regionales.
* **Canon V16:** Ilúvatar, Ainur, Valar y Maiar quedan definidos como categorías religiosas, literarias y culturales de una sociedad humana realista.

## Religión valinari entre 1000 y 500 a. C.

* **1000–990 a. C.:** la tradición común se articula alrededor de memoria ancestral, naturaleza, juramentos, fuentes, bosques y protección comunitaria; todavía no existe una iglesia centralizada.
* **990 a. C.:** el Concilio de Forostar reconoce la protección de santuarios, graneros y archivos, valida juramentos y separa parcialmente autoridad religiosa y mando militar.
* **950–850 a. C.:** los santuarios recuperan genealogías, calendarios y registros dañados durante la crisis; se consolidan guardianes, escribas y mediadores.
* **850–700 a. C.:** el comercio amplía conocimientos astronómicos, médicos y náuticos; las Casas desarrollan tradiciones funcionales agrícolas, marítimas, guerreras, comerciales y exploradoras.
* **700–600 a. C.:** las crisis de rutas y abastecimiento provocan disputas por santuarios, fuentes, graneros y genealogías, sin destruir la tradición común.
* **600–550 a. C.:** el retorno de Telcontar fortalece la idea de una Corona protectora de pactos, santuarios y comunidades; el mito de la antepasada Maiar se conserva como tradición religiosa, mientras la genealogía histórica permanece humana.
* **550–500 a. C.:** la Corona pactada coordina protección de santuarios, fuentes, graneros, rutas y archivos sin imponer una iglesia única.
* **Hacia 500 a. C.:** existen calendarios regionales coordinados, sacerdocios reconocidos, rituales comunes de juramento, normas funerarias compartidas y protección legal de fuentes y bosques.

La religión sigue siendo descentralizada, pero ya funciona como tradición común capaz de sostener la Corona, el derecho de pactos y la identidad histórica valinari.

## Agricultura y metalurgia entre 1000 y 500 a. C.

* **1000–990 a. C.:** las guerras interrumpen siembra, extracción, talleres, rutas de carbón y almacenamiento.
* **990 a. C.:** Forostar protege graneros, fuentes, herrerías y depósitos, y arbitra sobre tierras, minas y herramientas.
* **950–700 a. C.:** se recuperan tierras, rutas de mineral, talleres y registros de semillas; aumentan herramientas de hierro, herrajes navales y excedentes agrícolas.
* **700–550 a. C.:** las crisis impulsan reciclaje de metal, depósitos, graneros comunales y comercio de alimentos duraderos.
* **600–550 a. C.:** Telcontar coordina Casas agrícolas, mineras y portuarias.
* **550–500 a. C.:** la Corona coordina minas, talleres, graneros, rutas y arsenales en emergencias, manteniendo derechos locales.

## Organización militar entre 1000 y 500 a. C.

* **1000–990 a. C.:** defensas de clan, milicias y séquitos de Casa; las guerras interrumpen graneros, talleres y rutas.
* **990 a. C.:** Forostar regula guerras privadas, protege santuarios, graneros, prisioneros y puertos neutrales.
* **950–850 a. C.:** se recuperan fortificaciones, astilleros, convoyes y señales costeras.
* **850–700 a. C.:** se especializan capitanías navales, exploradores y talleres de armas; aumenta la vigilancia del Báltico y el mar del Norte.
* **700–550 a. C.:** la expansión atlántica y las crisis de abastecimiento convierten logística, metal y alimentos en asuntos militares.
* **600–550 a. C.:** Telcontar reúne flotas, redes septentrionales y alianzas para la defensa común.
* **550–500 a. C.:** la Corona coordina la defensa general sin eliminar las fuerzas, fueros y milicias de las Casas.

## Profundización militar entre 1000 y 500 a. C.

* **1000–990 a. C.:** las Casas movilizan séquitos y milicias; las guerras interrumpen rutas, graneros y talleres.
* **990–950 a. C.:** Forostar establece coordinación de mando, protección de prisioneros, neutralidad portuaria y límites al saqueo.
* **950–850 a. C.:** se consolidan campamentos, fortificaciones, astilleros, señales y convoyes.
* **850–700 a. C.:** se especializan exploradores, guardias de puerto, zapadores, reparadores navales y mensajeros.
* **700–600 a. C.:** la logística, inteligencia, sanidad y protección de suministros se vuelven parte de la doctrina militar.
* **600–550 a. C.:** Telcontar reúne flotas, redes septentrionales y alianzas; aparece una guardia real limitada.
* **550–500 a. C.:** la Corona coordina defensa, convoyes y emergencias sin eliminar las fuerzas y fueros de las Casas.

## Casas participantes en campañas militares, 1000–500 a. C.

La participación de las Casas se define por función y territorio. Las Casas Mayores proporcionan mando, recursos y contingentes; las Casas Menores actúan como capitanías, exploradoras, comerciantes, cartógrafas y protectoras de convoyes. Las Casas Vasallas participan bajo la autoridad de su Casa tutelar y no reciben mando independiente salvo delegación expresa.

### Guerra de los Graneros del Este, 1000–994 a. C.

**Casas Mayores:** Esgal, Calenor, Calenhad, Annúminas y Minas Anor.  
**Casas Menores:** Tumladen, Lindor, Maethor y Nimrodel.  
**Funciones:** defensa de graneros, transporte fluvial, registro de reservas y movilización agrícola.

### Conflicto del Øresund, 997–990 a. C.

**Casas Mayores:** Círdan, Pelargir, Harlond, Teleri y Alqualondë.  
**Casas Menores:** Falastur, Eärond, Aerandir y Círdanir.  
**Funciones:** patrulla del estrecho, escolta mercante, control de atraques y negociación con Dinamarca.

### Campaña de Forostar, 990–985 a. C.

**Casas Mayores:** Annúminas, Fornost, Noldor, Minas Anor y Vanyar.  
**Casas Menores:** Erestor, Meneldir, Gwindor y Aglaran.  
**Funciones:** imposición de arbitrajes, custodia de archivos, protección de santuarios y coordinación de contingentes.

### Guerra de las Rutas Noruegas, 965–950 a. C.

**Casas Mayores:** Mithlond, Harlond, Alqualondë, Eressëa Menel y Teleri.  
**Casas Menores:** Aerandir, Falathar, Voronwë y Thoron.  
**Funciones:** navegación de fiordos, intercambio de madera y hierro, reconocimiento costero y pactos con comunidades noruegas.

### Campaña de Åhus y las Marismas, 930–920 a. C.

**Casas Mayores:** Esgal, Calenhad, Eldalondë y Calenor.  
**Casas Menores:** Tumladen, Nimrodel, Duilin y Belegor.  
**Funciones:** diques, canales, salinas, agricultura, defensa fluvial y protección de obras hidráulicas.

### Guerra de las Tres Costas, 900–885 a. C.

**Casas Mayores:** Pelargir, Mithlond, Teleri, Alqualondë y Taur-en-Mor.  
**Casas Menores:** Ostor, Círdanir, Falastur, Eärond y Baranor.  
**Funciones:** convoyes, bloqueo, diplomacia portuaria y protección del comercio entre Báltico, Kattegat y mar del Norte.

### Campaña de las Islas del Ámbar, 860–845 a. C.

**Casas Mayores:** Eressëa Menel, Alqualondë, Eryn Lasgalen, Taur-en-Mor y Vanyar.  
**Casas Menores:** Aerandir, Falathar, Voronwë, Elentir y Celepharn.  
**Funciones:** cartografía, exploración insular, traducción, factorías temporales y protección de convoyes.

### Guerra de los Puertos Neutrales, 780–765 a. C.

**Casas Mayores:** Harnost, Harlond, Mithlond, Vanyar y Pelargir.  
**Casas Menores:** Baranor, Celepharn, Hallas, Aglaran y Lindor.  
**Funciones:** defensa de mercados, neutralidad portuaria, crédito comercial, mediación y sanciones económicas.

### Campaña de las Rutas Atlánticas, 720–700 a. C.

**Casas Mayores:** Eressëa Menel, Alqualondë, Teleri, Eldalondë y Círdan.  
**Casas Menores:** Aerandir, Falathar, Voronwë, Thoron y Elentir.  
**Funciones:** exploración, astronomía, señales costeras, depósitos de agua, rescate y retorno seguro.

### Crisis de las Minas y los Arsenales, 690–675 a. C.

**Casas Mayores:** Noldor, Barad Calen, Calenor, Minas Anor y Esgal.  
**Casas Menores:** Angren, Gwindor, Erestor, Maethor y Ostor.  
**Funciones:** hierro, carbón, talleres, armas, herrajes navales, protección de artesanos y arbitraje de reservas.

### Guerra de los Graneros del Norte, 640–625 a. C.

**Casas Mayores:** Annúminas, Calenhad, Rhunost, Esgal y Eldalondë.  
**Casas Menores:** Tumladen, Nimrodel, Lindor, Meneldir y Belegor.  
**Funciones:** transporte de cereal, pesca seca, protección de graneros, convoyes y rutas entre Escania y Noruega.

### Guerra de la Sucesión Occidental, 590–560 a. C.

**Casa Real en formación:** Telcontar.  
**Casas Mayores:** Annúminas, Fornost, Círdan, Harlond, Harnost, Pelargir y Eressëa Menel.  
**Casas Menores:** Falastur, Círdanir, Elentir, Ostor, Meneldir y Aerandir.  
**Funciones:** control de Helsingborg, archivos genealógicos, arsenales, graneros, rutas del Øresund, mediación y apoyo a la sucesión.

Las Casas Vasallas participan como contingentes dependientes de estas Casas Mayores. Su aportación se concentra en guardias de puerto, infantería local, escolta de convoyes, administración de graneros, talleres y defensa de santuarios. Ninguna Casa Vasalla altera por sí sola el equilibrio constitucional de las 24 Casas Mayores.

## Regencia de la Corona, 430–441 d. C.

Tras la abdicación de **Eärnil II Telcontar** en 430 d. C., la sucesión no se resuelve mediante una coronación inmediata. **Baranor II**, heredero reconocido, todavía no asume formalmente la Corona hasta 441 d. C.

Durante estos once años gobierna una **Regencia del Consejo de la Corona**, integrada por representantes del Consejo de las 24 Casas, la Casa Telcontar, la Guardia Real, los principales puertos y los custodios de los archivos y santuarios reales. La Regencia mantiene la continuidad administrativa, protege las rutas y convoca la confirmación sucesoria.

Baranor II puede ejercer funciones militares, diplomáticas y ceremoniales durante la regencia, pero su coronación oficial se produce en 441 d. C. El periodo no constituye un reinado adicional ni una interrupción del orden dinástico.

## Armada Valinoreana mundial en 1875

En 1875 Valinor ya es una potencia marítima mundial. Su presencia procede de rutas recorridas desde la Antigüedad, puertos asociados, protectorados, enclaves navales, estaciones de carbón, comunidades mercantiles y acuerdos de navegación. No administra todos esos puntos como provincias: distingue soberanía federal, protectorado, enclave, concesión y puerto asociado.

La Armada Real es inferior a la Royal Navy británica en tonelaje total y número de buques, pero no es una fuerza regional limitada. Puede mantener escuadras en el Atlántico norte, Caribe, África occidental, Mediterráneo, mar Rojo, Índico, Malaca, Pacífico y rutas árticas.

### Fuerza de combate

| Tipo | Unidades valinari en 1875 | Función |
|---|---:|---|
| Ironclads oceánicos | 16 | combate de escuadra y protección de rutas principales |
| Ironclads costeros y monitores | 12 | defensa de puertos, estrechos y enclaves |
| Cruceros protegidos o de casco compuesto | 18 | presencia mundial, exploración y guerra comercial |
| Corbetas de vapor y vela | 28 | estaciones navales, escolta y diplomacia |
| Sloops y avisos armados | 24 | mensajería, patrulla y enlace entre puertos |
| Cañoneras | 42 | ríos, protectorados, costas y defensa de enclaves |
| Torpederos | 24 | defensa portuaria y ataques nocturnos |
| Buques de desembarco y transportes armados | 14 | operaciones anfibias y refuerzo territorial |
| **Total de combate y apoyo armado** | **178** | incluye unidades de primera línea y ligeras |

De estos buques, aproximadamente 105 están activos, 35 se encuentran en mantenimiento o reserva y 38 cumplen tareas de instrucción, patrulla local o transporte armado.

### Clases principales

Los **Círdan I** son seis ironclads oceánicos de 7.000–8.500 toneladas, con cuatro cañones rayados de 10–12 pulgadas, piezas secundarias de 6 pulgadas, blindaje de ciudadela y velocidad aproximada de 12–13 nudos.

Los **Aulë** son ocho ironclads costeros y monitores de 3.500–4.500 toneladas, armados con dos cañones de 10–12 pulgadas y piezas secundarias. Protegen Helsingborg, Nueva Tirion, Calenport, Panamá, Nosselië Toliva, Islandia y Groenlandia.

Los **Eärendil** son ocho cruceros protegidos de largo alcance, complementados por diez cruceros de segunda línea. Llevan cañones de 4,7–6 pulgadas, piezas rápidas y tubos lanzatorpedos experimentales.

Las corbetas **Pelargir**, los avisos **Rómenna**, las cañoneras **Harlond** y los torpederos **Forlond** forman la red de presencia mundial. No todos poseen el mismo nivel tecnológico: la flota combina vapor, vela auxiliar, hierro, acero temprano, artillería de avancarga, retrocarga y torpedos experimentales.

### Fuerza logística

La presencia mundial requiere una logística mayor que la de una armada regional. Valinor mantiene aproximadamente:

| Tipo de unidad logística | Cantidad |
|---|---:|
| Carboneros y buques de combustible | 32 |
| Transportes militares | 18 |
| Buques de munición y almacén | 12 |
| Remolcadores y buques de reparación | 20 |
| Buques hospital | 8 |
| Buques hidrográficos y oceanográficos | 16 |
| Buques escuela y de instrucción | 12 |
| Patrulleros y guardacostas | 36 |
| **Total logístico y auxiliar** | **154** |

La flota completa, sumando combate, patrulla, transporte y auxiliares, alcanza aproximadamente **332 buques**, aunque solo una parte puede concentrarse en una misma crisis.

### Red mundial de apoyo

Las principales zonas de apoyo son:

- **Atlántico norte:** Valinor, Arnor, Númenor, Islandia, Groenlandia y Systreyjar.
- **Atlántico medio:** Nosselië Toliva, Azores, Madeira y estaciones asociadas.
- **Caribe y Panamá:** Panamá Federal, Bahamas, Bermudas, Trinidad, Tobago y puertos asociados.
- **África occidental:** Eärendil, Tol Morwen, Esgal Nénar y estaciones de comercio.
- **Mediterráneo:** Barad Nimras, Alqualondë, Eglarest y Pelargir como bases arrendadas o puertos asociados.
- **mar Rojo y golfo:** Amon Rûdh, Harlond, Círdan, Harnen, Eryndor y Rhunost según su estatuto político.
- **Índico y Asia:** Malaca, Eressëa Índica y rutas hacia los estados del Pacífico.
- **Pacífico:** Hawái, Fiyi, Polinesia, Micronesia y Nanduhirion.

La red no implica que todos los puntos sean territorio federal. Su valor reside en carbón, agua, reparación, inteligencia, sanidad, almacenamiento y relevo de tripulaciones.

### Comparación con la Royal Navy

La Royal Navy conserva la mayor flota del mundo porque debe cubrir un imperio más amplio, una red global de bases y un volumen comercial planetario. En 1875 puede disponer de aproximadamente 42–48 ironclads en servicio, construcción o reserva, además de más de 50 corbetas, sloops y cañoneras y una gran cantidad de auxiliares.

Valinor dispone de menos tonelaje pesado, pero concentra una proporción elevada de sus recursos en rutas marítimas y mantiene una red mundial propia. La comparación coherente es:

- **Reino Unido:** primera potencia naval mundial, superior en tonelaje, reservas, bases y capacidad de reemplazo.
- **Valinor:** segunda gran potencia marítima global, inferior en volumen pero capaz de operar simultáneamente en varios océanos.
- **Estados Unidos:** potencia industrial en ascenso, pero con una marina activa menor y todavía en reconstrucción tras la Guerra Civil.

La rivalidad anglo-valinari produce guerras de corso, bloqueos, disputas por puertos, competencia por protectorados y tratados de neutralidad. La existencia de presencia mundial valinari no elimina la superioridad británica: hace que la competencia sea global y que la Royal Navy deba repartir sus fuerzas entre más teatros.

## Educación y acumulación del conocimiento

* **1956–2026:** la educación pública se consolida como competencia coordinada del Estado federal y los territorios. En 2026 la inversión educativa equivale al 6 % del PIB federal; el 75 % procede del Estado federal, el 24 % de estados, provincias y territorios y el 1 % de la Corona mediante las Becas Reales de Educación.
* **2026:** el Fondo Federal de Becas financia acceso, permanencia, transporte, alimentación, formación técnica, investigación y regiones remotas. La Autoridad Federal de Becas administra el sistema con criterios públicos y participación de la Corona sin mayoría de voto.
* **2026:** la doctrina educativa se integra con la economía, la banca, la tecnología y la Armada. La educación se reconoce como el principal multiplicador de la primacía valinari: forma especialistas, acelera la investigación aplicada, mejora la productividad, sostiene el crédito y mantiene la capacidad naval e industrial. La primacía es conjunta y sistémica, no una afirmación de ventaja uniforme en cada tecnología.
* **2026:** el circuito canónico queda formulado como educación → especialistas → investigación → producción → comercio y crédito → ingresos → nueva educación e investigación. La inversión educativa permanece en el 6 % del PIB federal; la investigación militar, la infraestructura, los astilleros, los bancos de desarrollo y la industria se contabilizan en sus propios presupuestos.

## Secuencia atlántica y Mediterráneo

* **1000–990 a. C.:** comienza la migración de comunidades procedentes de las subzonas históricas de Escania y de las provincias noruegas.
* **990–850 a. C.:** las Casas fundacionales establecen asentamientos, santuarios, puertos y redes de parentesco en el Báltico, Dinamarca, Noruega y el mar del Norte.
* **850–700 a. C.:** el centro político, económico y naval se desplaza progresivamente hacia las rutas occidentales.
* **650 a. C.:** Escania deja de ser el centro político y demográfico principal. Conserva población, santuarios, propiedades, ramas familiares y memoria genealógica; Helsingborg permanece como origen ancestral de Telcontar.
* **650–550 a. C.:** las Casas organizan puertos, graneros, talleres, astilleros, santuarios y depósitos documentales fuera de Escania.
* **550 a. C.:** el pacto de consolidación de la Corona Telcontar estabiliza la sociedad marítima occidental sin borrar sus raíces escanianas y noruegas.
* **550–300 a. C.:** la Corona amplía las rutas del mar del Norte, el Atlántico oriental y el Mediterráneo; aparecen escuelas portuarias, convoyes, factorías y acuerdos de protección.
* **300–100 a. C.:** la exploración se extiende hacia las islas septentrionales; se perfeccionan cartas de navegación, estaciones de agua y reparación.
* **100 a. C.–20 d. C.:** las expediciones combinan navegación atlántica, comercio mediterráneo y reconocimiento de las islas del norte.
* **20–40 d. C.:** descubrimiento de Tol Eressëa; se establecen estaciones iniciales de agua, reparación, observación, cartografía y archivo.
* **50 d. C.:** Tol Eressëa es el primer gran descubrimiento oceánico occidental. Groenlandia todavía no posee reconocimiento estable; Númenor/Terranova, Arnor, América continental y Valinor aún no están incorporados.

* **650–550 a. C.:** el desarrollo valinari se redistribuye entre Escania, Noruega, Dinamarca, el Báltico, el mar del Norte, Systreyjar y Nosselië Toliva. Escania conserva santuarios, propiedades y memoria genealógica, pero deja de ser el centro político.
* **550–300 a. C.:** Systreyjar se consolida como centro insular de coordinación marítima y Nosselië Toliva como escala atlántica oriental vinculada con África y el Mediterráneo.
* **450–150 a. C.:** Sicilia, Malta, Chipre, Creta, el Egeo, Egipto, Alejandría y el Levante funcionan como espacios de comercio, traducción, medicina, astronomía, derecho y navegación; no son provincias valinarias.
* **300–50 a. C.:** la red mediterránea y atlántica combina conocimientos de mares fríos, navegación oceánica, cartografía, construcción naval y observación astronómica.
* **20–40 d. C.:** descubrimiento de Tol Eressëa; se establecen estaciones iniciales de agua, reparación, observación, cartografía y archivo.
* **50 d. C.:** Tol Eressëa es el primer gran descubrimiento oceánico occidental. Groenlandia todavía no posee reconocimiento estable; Númenor/Terranova, Arnor, América continental y Valinor aún no están incorporados.

* **55–75 d. C.:** reconocimiento de Groenlandia desde Tol Eressëa. Entre 70 y 110 se mantienen puestos estacionales, sin integración provincial plena.
* **85 d. C.:** Tol Eressëa ya posee estaciones insulares tempranas; Groenlandia es una escala noratlántica; Númenor/Terranova, América continental y el territorio de Valinor todavía no están incorporados.
* **400–500 d. C.:** expediciones hacia Terranova; el asentamiento permanente de Númenor corresponde a 920–980. Sustituye 140–180 para la llegada y 180–240 para el asentamiento. V16.3-R01.
* **920–980 d. C.:** asentamiento permanente de Númenor y fundación posterior de Armenelos; sustituye las estaciones permanentes atribuidas a 180–240. V16.3-R01.
* **350–450 d. C.:** reconocimiento geográfico de Valinor después de Tol Eressëa y Groenlandia, gracias a la navegación oceánica acumulada de los marinos valinari.
* **Siglos V–IX d. C.:** asentamiento y consolidación territorial progresiva de Valinor.
* **Hacia 930 a. C.:** reconocimiento del Mediterráneo occidental. La ruta mediterránea es independiente de la secuencia atlántica septentrional.
* **Siglos IX–I a. C.:** contactos indirectos, comercio, traducción y reconocimiento mediterráneo; no existe una presencia territorial valinaria estable.
* **Siglos I–V d. C.:** aumento de agentes, escalas, acuerdos portuarios y diplomacia en Alejandría, Cartago, Constantinopla, Beirut y otros centros, sin convertirlos en provincias valinarias.

* **874 a. C.:** primer desembarco documentado en Sicilia.
* **823 a. C.:** reconocimiento de Malta como escala de agua y reparación.
* **781 a. C.:** primer contacto con las rutas de Chipre y el Mediterráneo oriental.
* **742 a. C.:** reconocimiento de Creta y del Egeo.
664 a. C.: contacto o acuerdo con autoridades del delta egipcio; lugar y texto pendientes. A107 R04 sustituye la referencia anacrónica a Alejandría. La delegación de 129 d. C. se conserva.
* **587 a. C.:** fundación de una estación permanente de agua y reparación en Malta.
* **548 a. C.:** tratado de navegación y defensa portuaria con Chipre.
* **476 a. C.:** reconocimiento del paso de Bab el-Mandeb.
* **438 a. C.:** primera factoría comercial estable en Adén.
* **401 a. C.:** reconocimiento de Socotra como estación científica y botánica.
* **291 a. C.:** reconocimiento de Musandam y Ormuz.
* **219 a. C.:** acuerdos iniciales con el litoral mesopotámico y Kuwait.
* **74 d. C.:** reconocimiento del litoral occidental del Bab el-Mandeb.
* **129 d. C.:** renovación del tratado con Alejandría y creación de una representación consular.
* **188 d. C.:** convención de seguridad de convoyes en Adén.
* **247 d. C.:** formalización del protectorado marítimo de Socotra.
* **312 d. C.:** tratado general de navegación con Omán, como Estado aliado autónomo.

* **Siglo VII–hacia 702:** Reforma Educativa Fundacional; ampliación de escuelas permanentes e itinerantes, preparación de maestros y aprendizaje técnico. Amplía instituciones anteriores y no crea cobertura universal instantánea.
* **Siglo VIII:** expansión regional de bibliotecas, traducción y catálogos; las redes de copia y consulta se normalizan por etapas.
* **Siglo IX:** aplicación náutica de observaciones celestes, derroteros y registros meteorológicos; expansión de las Academias del Mar surgidas hacia 700.
* **Siglos IX–X:** astilleros sostenidos, especialización de oficios y normalización de informes; la reforma naval de 880–970 atraviesa ambos siglos.
* **Siglo XI:** cartografía de rutas conocidas, atlas y colecciones náuticas crecientes, sin mapas planetarios exactos.
* **Siglo XII:** recuentos fiscales, agrarios, mercantiles y portuarios más periódicos; Consejos Atlánticos permanentes desde 1135.
* **Siglo XIII:** crédito, cobertura de riesgos, contratos y enseñanza mercantil; expansión tropical americana entre 1230–1290 y rutas africanas.
* **Siglo XIV:** agentes en India hacia 1310–1320 y acuerdo de Malaca de 1324; la crisis demográfica americana impide una lectura de progreso sin costes.
* **Siglo XV:** campañas de copia, correspondencia, bibliotecas y preparación editorial; adopción contextual de técnicas de impresión.
* **Siglo XVI:** ampliación de talleres de impresión, manuales y textos escolares; Secretaría Común y redes documentales después de 1512.
* **Siglo XVII:** academias y protocolos experimentales; ciencia tropical y cuadernos de Tomás Angarion, 1627–1673; intensificación técnico-administrativa desde c. 1650.
* **Siglo XVIII:** perfeccionamiento naval, hidráulico, manufacturero y registral; Primera Industrialización desde c. 1740.
* **Siglo XIX:** vapor, ferrocarriles, telégrafo, siderurgia, grandes astilleros y obras interoceánicas; canal desde 1845, apertura en 1872 y Segunda Industrialización desde c. 1880.
* **1880–1945:** expansión de laboratorios, electricidad, química, ingeniería naval, medicina tropical y ciencias del mar.
* **1945–1975:** ampliación universitaria, becas e investigación pública; reorganización federal de 1958, Programa de Ciencias del Mar de 1963, Instituto de Sistemas Marítimos de Númenor de 1965 y Escuela Federal de Documentación de Tol Eressëa de 1966.
* **1995–2025:** digitalización, logística automatizada e interoperabilidad; Carta de Sistemas Inteligentes de 2024.
* **2026:** evaluación de sistemas inteligentes y continuidad del escenario contemporáneo, sin fijar proyecciones posteriores como hechos.

La divergencia tecnológica se fija como una ventaja orientativa de **20–80 años en sectores concretos**, condicionada por energía, materiales, salud, capital, talleres, instituciones y difusión. No equivale a superioridad tecnológica general. Durante 300–800 d. C. se deterioran copias regionales y materiales pedagógicos, pero los archivos principales conservan el núcleo del conocimiento; la Corona inicia una estatización progresiva de su custodia sin absorber de inmediato las escuelas locales.

* **1000–990 a. C.:** transmisión familiar, religiosa y artesanal; memoria oral, genealogías y calendarios.
* **990–850 a. C.:** Forostar protege archivos, registros, juramentos y formación de escribas.
* **850–500 a. C.:** aparecen escuelas funcionales de navegación, astronomía, agricultura, metalurgia, medicina, derecho y comercio.
* **500 a. C.–300 d. C.:** la Corona amplía escuelas portuarias, observatorios y archivos.
* **300–800 d. C.:** se pierden o deterioran copias regionales y se interrumpen rutas, pero los archivos principales conservan el núcleo del conocimiento gracias a las Siete Copias.
* **500–800 d. C.:** el saber se concentra en archivos de la Corona, grandes santuarios y Casas de la Memoria; comienza su estatización.
* **800–1000:** la recuperación institucional extiende alfabetización y educación mediante copias certificadas.
* **1005:** convenio de astronomía, medicina y filosofía con Dar al-Hikma.
* **1200–1800:** universidades, imprenta, academias, bibliotecas y educación técnica.
* **1800–2026:** industrialización educativa, ciencia aplicada, telecomunicaciones y OceanNet.

## Demografía y migraciones, 1000 a. C.–800 d. C.

La escala demográfica activa se recalcula cada cien años y distingue población total, Valinari de linaje, mestizos y portuarios, población local superviviente y personas esclavizadas o dependientes. La categoría censal de población local desaparece aproximadamente cien años después de la incorporación de cada territorio; esto no implica la desaparición física de todas las personas originarias.

| Fecha | Total | Valinari | Mestizos/portuarios | Locales | Dependientes | Migración nórdica | Migración no nórdica |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1000 a. C. | 180.000 | 135.000 | 9.000 | 27.000 | 9.000 | 0 | 0 |
| 900 a. C. | 225.000 | 162.000 | 18.000 | 33.750 | 11.250 | 25.000 | 15.000 |
| 800 a. C. | 280.000 | 196.000 | 28.000 | 42.000 | 14.000 | 50.000 | 30.000 |
| 700 a. C. | 350.000 | 238.000 | 42.000 | 52.500 | 17.500 | 75.000 | 45.000 |
| 600 a. C. | 410.000 | 266.500 | 61.500 | 61.500 | 20.500 | 105.000 | 63.000 |
| 500 a. C. | 466.750 | 289.385 | 93.350 | 56.010 | 28.005 | 155.000 | 93.000 |
| 400 a. C. | 650.000 | 390.000 | 156.000 | 65.000 | 39.000 | 220.000 | 132.000 |
| 300 a. C. | 900.000 | 522.000 | 243.000 | 72.000 | 63.000 | 285.000 | 171.000 |
| 200 a. C. | 1.200.000 | 720.000 | 336.000 | 60.000 | 84.000 | 350.000 | 210.000 |
| 100 a. C. | 1.500.000 | 930.000 | 420.000 | 45.000 | 105.000 | 415.000 | 249.000 |
| 1 d. C. | 1.750.000 | 1.137.500 | 472.500 | 17.500 | 122.500 | 480.000 | 288.000 |
| 100 d. C. | 2.050.000 | 1.394.000 | 553.500 | 0 | 102.500 | 500.000 | 300.000 |
| 200 d. C. | 2.450.000 | 1.592.500 | 735.000 | 0 | 122.500 | 605.000 | 363.000 |
| 300 d. C. | 2.950.000 | 1.829.000 | 973.500 | 0 | 147.500 | 710.000 | 426.000 |
| 400 d. C. | 3.550.000 | 2.130.000 | 1.242.500 | 0 | 177.500 | 815.000 | 489.000 |
| 500 d. C. | 4.876.000 | 2.828.080 | 1.804.120 | 0 | 243.800 | 920.000 | 552.000 |
| 600 d. C. | 5.750.000 | 3.277.500 | 2.185.000 | 0 | 287.500 | 1.045.000 | 627.000 |
| 700 d. C. | 6.650.000 | 3.724.000 | 2.593.500 | 0 | 332.500 | 1.170.000 | 702.000 |
| 800 d. C. | 7.588.500 | 4.173.675 | 3.035.400 | 0 | 379.425 | 1.295.000 | 777.000 |

La migración no nórdica equivale al 60 % de la nórdica y se integra principalmente en comunidades mestizas, portuarias, artesanales, agrícolas y dependientes. Las cifras migratorias son llegadas brutas acumuladas y no se suman mecánicamente a la población total.

## Historia monetaria trabajo y controversias religiosas

Estos hitos desarrollan procesos ya situados dentro de la monarquía pactista. Las fechas de una reforma distinguen su adopción de su aplicación territorial.

- **1000–300 a. C.:** intercambio doméstico, metales pesados, equivalencias locales y contribuciones de Casa y Corona.
- **300 a. C.–700 d. C.:** desarrollo de unidades de cuenta portuarias, monedas locales y extranjeras y contratos registrados.
- **430–525 d. C.:** Controversia de las Potestades; disputas doctrinales, educativas y patrimoniales bajo la continuidad de la Corona Telcontar.
- **Hacia 525:** pactos locales de conciencia y protección de comunidades, sin régimen constitucional uniforme.
- **700–1512:** evolución de participaciones de expedición, coberturas mercantiles, compensación y mutualidades marítimas.
- **1000–500 a. C.:** reservas, préstamos entre Casas, fondos de reparación naval, contribuciones de convoyes y arbitraje en santuarios anticipan funciones que en otras potencias aparecerían mucho después.
- **500–50 a. C.:** crédito portuario, anticipos sobre cosechas y cargamentos, inversión colectiva de Casas y depósitos protegidos.
- **50 a. C.–500 d. C.:** seguros rudimentarios, financiación de factorías y puertos, letras de obligación y fondos de reconstrucción.
- **500–1400:** tesorerías, contabilidad profesional, sociedades mercantiles, cámaras de compensación, seguros y compañías de navegación; desarrollo funcional aproximadamente un siglo antes que los modelos europeos comparables.
- **780–851:** conflictos de imágenes; protección y uso de representaciones religiosas y de la memoria.
- **808–820:** episodios de violencia vinculados a imágenes y autoridades de culto.
- **821 y 851:** disposiciones de protección y restitución en los conflictos de imágenes.
- **805–864:** conflictos de juramentos y fórmulas de compromiso.
- **842:** Congreso de las Fórmulas; reconocimiento de compromisos equivalentes, registrados y verificables.
- **864:** Pacto de las Dos Reverencias; convivencia, protección del culto y fórmulas alternativas dentro de los pactos del Reino.
- **1512–1705:** ampliación de cajas comunes y cuentas interterritoriales, subordinadas al orden monárquico y los acuerdos territoriales.
- **1705:** fortalecimiento de reglas comunes de contabilidad, presupuesto y emisión; transición con medios de pago y equivalencias locales.
- **1600–1705:** se consolidan reservas, compensación, emisión regulada y supervisión monetaria funcional, sin convertir retrospectivamente estas instituciones en un banco central contemporáneo.
- **1736–1750:** Crisis Financiera de Armenelos; insolvencias, garantías duplicadas, investigación y reforma de supervisión.
- **Desde c. 1740:** industrialización y crecimiento de riesgos laborales, reclamaciones e inspección.
- **1845–1852:** estudios y preparación del Canal de Panamá (Panamá).
- **1850:** Estatuto de Nombres y Continuidad Civil para identificación, nóminas y reclamaciones; no supone cambio obligatorio de nombres ni linajes.
- **1852–1862:** infraestructuras y campamentos del canal.
- **1858–1868:** Crisis del Canal; sobrecostes, impagos, problemas sanitarios y reorganizaciones parciales.
- **1862–1868:** excavación principal, coexistente con la crisis y sus reformas.
- **1868–1872:** autoridad operativa reorganizada, pruebas hidráulicas, formación y ajustes.
- **1872:** apertura operativa del canal y desarrollo de peajes, mantenimiento y obligaciones territoriales.
- **1945–1975:** ampliación de protección social y, desde la reforma de 1958, coordinación y portabilidad territorial de derechos.
- **1958–2026:** el sistema federal integra Tesorería, Autoridad Monetaria, banca de desarrollo, banca privada, seguros, fondos territoriales, educación, investigación, industria, Armada y OceanNet.

La Crisis de la Custodia de los siglos III–V y su reforma de 450–500 siguen siendo un proceso propio sobre esclavitud y dignidad humana. La abolición general no recibe aquí una fecha nueva. Los archivos principales conservan el conocimiento mediante siete copias, con pérdidas regionales de copias y acceso.

Fichas de desarrollo: [[08_Economia/Historia monetaria y fiscal valinari|historia monetaria]], [[13_Sociedad/Trabajo y Oficios|trabajo]], [[05_Religion/Controversias religiosas 430-864 dC|controversias religiosas]] y [[08_Economia/Canal de Panamá 1845-1872|canal]].


## Sucesión de la Corona, 500 a. C.–500 d. C.

La sucesión valinari es hereditaria y condicionada. La Casa Real proporciona el linaje, pero el heredero debe aceptar los pactos fundamentales y ser confirmado por el Consejo de las Casas, los santuarios, las guarniciones y las principales ciudades portuarias.

El orden preferente es descendiente directo, hermano o hermana, rama colateral, miembro reconocido o candidato pactado en una crisis. Se admiten regencias, abdicaciones, matrimonios de reconciliación y deposiciones excepcionales por ruptura grave de los pactos.

- **500–300 a. C.:** reconocimiento sucesorio con fuerte influencia del Consejo.
- **300–50 a. C.:** fortalecimiento de la herencia dinástica por la expansión territorial y comercial.
- **50 a. C.–200 d. C.:** designación más estable del heredero y juramento de los mandos navales.
- **200–500 d. C.:** regulación de regencias, archivos, sucesión y reconocimiento territorial.

Forostar (Helsingborg) mantiene la capitalidad política y la Casa Telcontar conserva la continuidad dinástica. Númenor es capital naval, pero no sustituye jurídicamente a Forostar.

## Integración acumulativa transversal

**2026:** educación, finanzas, logística naval, ganadería, recursos naturales, hogar, parentesco y cultura naval quedan coordinados como un sistema histórico de capacidades. La primacía valinari depende de esa integración y no de una superioridad uniforme en cada sector. Se mantienen las correcciones territoriales vigentes: Númenor corresponde a Terranova, Tol Eressëa es una entidad distinta, Barad Nimras/Gibraltar es una base arrendada desde 1815 y Ceuta y Melilla no son distritos federales automáticos.


## Integración AM1 — cronología naval e industrial

- **1750–1880:** arsenales, talleres metalúrgicos, máquinas de vapor y siderurgia naval preparan la construcción industrial.
- **1875:** inventario de referencia de 332 unidades: 178 de combate/apoyo armado y 154 auxiliares.
- **1882–1914:** adopción gradual de turbinas, acero naval, blindaje, torpedos, radio y control central de tiro, con pruebas, lotes y servicio distinguidos.
- **1914–1945:** expansión de submarinos, aviación embarcada, radar, convoyes y construcción en serie.
- **1945–1960:** reconstrucciones de fuerza AM1 de 368 y 408 unidades, no inventarios medidos; se desarrollan portaaviones, submarinos oceánicos, radares y logística moderna.
- **Desde 1945:** un refit integral principal de media vida por casco, con reparaciones y actualizaciones menores diferenciadas.
- **1960–1980:** producción de escoltas y buques especializados; la composición canónica de referencia en 1980 suma 427 unidades.
- **1980–2005:** construcción modular, mejora de sensores, propulsión y sistemas digitales, con reemplazo de cascos por generaciones.
- **2005–2026:** integración de propulsión eléctrica, radares AESA, OceanNet, vehículos no tripulados y mantenimiento predictivo.
- **2026:** inventario estructural de 615 plataformas; la disponibilidad de 449 es hipótesis, no dato medido.

Ficha técnica: [[12_Militar/03_Armada/AM1 Armada 1875-2026|AM1 Armada 1875–2026]].

## 1952–1979 — Turbinas navales y composición de la Armada en 1973

- **1952–1958:** Valinor ensaya turbinas aeronáuticas adaptadas a propulsión naval, reductores, filtros de admisión y protección contra corrosión salina.
- **1958–1965:** primeras series en lanchas, patrulleros y escoltas ligeros; nacen equipos y rutinas de cambio modular.
- **1965–1970:** se masifica la turbina en destructores, fragatas, corbetas y lanchas; aparecen combinaciones diésel-gas para equilibrar velocidad y autonomía.
- **1970–1979:** se perfeccionan COGOG, CODOG y CODAG, el control de planta y los intervalos de mantenimiento. El vapor permanece en portaaviones convencionales y en el ciclo secundario de los nucleares; diésel sigue en submarinos convencionales, anfibios, patrulleros de permanencia y auxiliares.
- **1973:** reconstrucción AM1 de 421 plataformas, entre las referencias de 1960 y 1980. No representa un recuento histórico medido. Véase [[12_Militar/03_Armada/AM1 Armada 1973 — reconstrucción y turbinas]].

## Evolución de la familia de destructores Gil-galad

- **1940–1945:** Gil-galad I, destructores de guerra a vapor.
- **1952–1960:** construcción de Gil-galad II, generación de posguerra que permanece en servicio durante los años sesenta y parte de los setenta.
- **1972–1980:** construcción de Gil-galad III, primera generación de serie con turbinas de gas; entra en servicio desde 1978 y reemplaza a la generación II por lotes.
- **1990–1998:** construcción de Gil-galad IV, diseño digital de defensa aérea.
- **2005–2013:** construcción de Gil-galad V, con integración de red y radar AESA inicial.
- **2020–2030:** construcción prevista de Gil-galad VI; entrada en servicio escalonada desde 2027–2035.

La reconstrucción AM1 de 1973 atribuye 12 unidades a Gil-galad II. El inventario de 1980 contabiliza la familia de manera agregada durante la transición II–III. En 2026, los 24 destructores corresponden a generaciones IV y V; la VI aún no se cuenta como operativa. Véase [[12_Militar/03_Armada/Destructores Gil-galad — evolución de la familia]].

## Acumulativa A092 y cierre contable V16 4

* **20–40 d. C.:** descubrimiento vigente de Tol Eressëa. Sustituye la fecha 340–350 de V16.3.
* **55–75 d. C.:** reconocimiento de Groenlandia desde las rutas de Tol Eressëa.
* **50 y 85 d. C.:** se conservan los rangos demográficos por ámbito; no se suman núcleo directo, población dependiente y redes vinculadas.
* **2026 constitucional:** 515,5 millones y 64,98 billones PPA, con Harnen fuera del ámbito constitucional.
* **2026 operativo ECON-03:** 523,5 millones y 65,50 billones PPA, con los 8 millones y 0,52 billones de Harnen ya incluidos una vez.
* **2026 Beleg:** rango rector 724,5–879,5 millones; subtotal identificado 535 y residuo por asignar 189,5–344,5.
* **2026 Gwaith Aear:** Chile es aliado documentado; Andúnië se incluye en Chile. No se fija un total demográfico sin padrón ni se añaden países enteros por acuerdos portuarios.
* **2026 modelos A092:** nuevas matrices de Islandia y Groenlandia, urbanización septentrional, disponibilidad simulada 449/615, reparto presupuestario e hipótesis industriales. No son datos observados.

Véase [[Acumulativa A092 V16.4]] y [[Matriz territorial maestra A092]].


## Integración militar A093 y desarrollo terrestre

Las introducciones siguientes pertenecen al desarrollo narrativo A092 incorporado en V16.5. No son fechas de incorporación territorial ni cifras de disponibilidad.

- **1911:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#BA-11 Hador|BA-11 Hador]].
- **1917:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CP-17 Belegost|CP-17 Belegost]].
- **1926:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CL-26 Duilin|CL-26 Duilin]].
- **1932:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-32 Barahir|TP-32 Barahir]].
- **1934:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CM-34 Gondolin|CM-34 Gondolin]].
- **1938:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CL-38 Nimrodel|CL-38 Nimrodel]].
- **1941:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CM-41 Anárion|CM-41 Anárion]].
- **1942:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-42 Haleth|TP-42 Haleth]].
- **1944:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CP-44 Beleg|CP-44 Beleg]].
- **1952:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CU-52 Elendil|CU-52 Elendil]].
- **1955:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-55 Bregor|TP-55 Bregor]].
- **1963:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CB-63 Elendil II|CB-63 Elendil II]].
- **1965:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-65 Círdan|TP-65 Círdan]].
- **1969:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CA-69 Falathar|CA-69 Falathar]].
- **1972:** introducción de [[12_Militar/02_Ejército/Blindados/Artillería autopropulsada#AAP-72 Aulë|AAP-72 Aulë]].
- **1974:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#VT-74 Mablung|VT-74 Mablung]].
- **1978:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CB-78 Elendil III|CB-78 Elendil III]].
- **1984:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-84 Beregond|TP-84 Beregond]].
- **1988:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#VC-88 Galdor|VC-88 Galdor]].
- **1991:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CB-91 Elendil IV|CB-91 Elendil IV]].
- **2003:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-03 Erkenbrand|TP-03 Erkenbrand]].
- **2006:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CB-06 Elendil V|CB-06 Elendil V]].
- **2009:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#VC-09 Haldir|VC-09 Haldir]].
- **2012:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#VBR-12 Hirgon|VBR-12 Hirgon]].
- **2015:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CE-15 Ecthelion|CE-15 Ecthelion]].
- **2019:** introducción de [[12_Militar/02_Ejército/Blindados/VCI y transportes#TP-19 Voronwë|TP-19 Voronwë]].
- **2023:** introducción de [[12_Militar/02_Ejército/Blindados/Carros y exploradores#CB-23 Elendil VI|CB-23 Elendil VI]].

## Redes navales y control de drones A093

- **1955–1970:** coordinación por radio y procedimientos comunes; marco narrativo integrado, con equipos y lotes pendientes de identificación.
- **1970–1985:** primeros enlaces digitales e intercambio limitado con determinadas flotillas; no implantación simultánea en toda la Armada.
- **1985–2000:** imagen táctica compartida más madura y coordinación regional.
- **2000–2019:** integración progresiva de sensores y sistemas; cooperación avanzada solo en equipos compatibles y validados.
- **Desde 2020:** la Armada utiliza buques que controlan drones de ataque, por decisión expresa del autor. Clases, cantidades y pertenencia a categorías administrativas siguen pendientes.

## Programa terrestre de turbina propuesto

- **2002 propuesto:** inicio del programa CBT-16.
- **2008 propuesto:** demostrador móvil.
- **2016 propuesto:** introducción limitada; no demuestra producción o validación del rendimiento.
- **Objetivo técnico:** 42 % térmico neto al eje sobre PCI en punto nominal; APU diésel de 25–30 kW eléctricos para servicios estacionarios con la turbina principal apagada. Producción y autonomía pendientes.

Véase [[00_Canon/Integraciones V16/Acumulativa A093 V16.5|Resoluciones A093]] y [[12_Militar/03_Armada/Redes navales y transición a drones|Redes navales]]. El escenario 80 fragatas, 40 corbetas y 96 OPV no sustituye el inventario vigente 64, 72 y 80.


## Integración exportadora V17 3 A101

Base: Maestro V17.2 A100 y reconstrucción E1 incorporada por el autor el 10 de noviembre de 2026. Corte narrativo 31 de diciembre de 2026. Los hitos de aceptación son ficción histórica aprobada, no evidencia documental. A100 conserva cero expedientes con C4 documental acreditado.

### Firmas y actuaciones C3 de A099

- **1887 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1887-CHL-01|EXP-1887-CHL-01]], Chile, Mantenimiento naval y formación técnica. La firma no prueba entrega ni cobro.
- **1896 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1896-PRT-01|EXP-1896-PRT-01]], Portugal, Lanchas torpederas costeras. La firma no prueba entrega ni cobro.
- **1908 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1908-CHL-01|EXP-1908-CHL-01]], Chile, Dirección óptica de tiro y repuestos. La firma no prueba entrega ni cobro.
- **1913 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1913-BRA-01|EXP-1913-BRA-01]], Brasil, Reacondicionamiento de destructores. La firma no prueba entrega ni cobro.
- **1927 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1927-CHL-01|EXP-1927-CHL-01]], Chile, Taller de torpedos y capacitación. La firma no prueba entrega ni cobro.
- **1934 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1934-PRT-01|EXP-1934-PRT-01]], Portugal, Torpedos T-24 Falathar. La firma no prueba entrega ni cobro.
- **1948 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1948-NZL-01|EXP-1948-NZL-01]], Nueva Zelanda, Radar naval y capacitación. La firma no prueba entrega ni cobro.
- **1956 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1956-CHL-01|EXP-1956-CHL-01]], Chile, Modernización de sensores de escoltas. La firma no prueba entrega ni cobro.
- **1966 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1966-PER-01|EXP-1966-PER-01]], Perú, Torpedos T-61 Ossë. La firma no prueba entrega ni cobro.
- **1968 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1968-PRT-01|EXP-1968-PRT-01]], Portugal, Radares y sistema de dirección de tiro. La firma no prueba entrega ni cobro.
- **1974 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1974-CHL-01|EXP-1974-CHL-01]], Chile, Lanchas misileras y soporte, Falmar-II separado. La firma no prueba entrega ni cobro.
- **1975 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1975-CHL-02|EXP-1975-CHL-02]], Chile, Falmar-II para paquete de lanchas. La firma no prueba entrega ni cobro.
- **1978 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1978-IDN-01|EXP-1978-IDN-01]], Indonesia, Corbetas de exportación (no Calenport de inventario). La firma no prueba entrega ni cobro.
- **1983 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1983-PER-01|EXP-1983-PER-01]], Perú, Falmar-III de exportación. La firma no prueba entrega ni cobro.
- **1986 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1986-CHL-01|EXP-1986-CHL-01]], Chile, Modernización de escoltas y CMS. La firma no prueba entrega ni cobro.
- **1988 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1988-ZAF-01|EXP-1988-ZAF-01]], Sudáfrica, Estudio comercial sin entrega, sujeto a restricciones. Estudio sin suministro ni exportación.
- **1993 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1993-BRA-01|EXP-1993-BRA-01]], Brasil, CMS y sensores para corbetas nacionales. La firma no prueba entrega ni cobro.
- **1998 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India, Licencia de Falmar-IV, fabricación extranjera. La firma no prueba entrega ni cobro.
- **2001 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2001-CHL-01|EXP-2001-CHL-01]], Chile, Refit de fragatas y sostenimiento. La firma no prueba entrega ni cobro.
- **2004 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2004-PHL-01|EXP-2004-PHL-01]], Filipinas, OPV de exportación, sin misil estándar. La firma no prueba entrega ni cobro.
- **2009 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2009-PRT-01|EXP-2009-PRT-01]], Portugal, Falmar-V y apoyo logístico. La firma no prueba entrega ni cobro.
- **2012 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2012-IDN-01|EXP-2012-IDN-01]], Indonesia, Modernización de 2 corbetas y radares. La firma no prueba entrega ni cobro.
- **2015 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2015-CHL-01|EXP-2015-CHL-01]], Chile, Sensores, CMS y soporte multianual. La firma no prueba entrega ni cobro.
- **2018 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2018-NZL-01|EXP-2018-NZL-01]], Nueva Zelanda, Vigilancia costera y enlaces no protegidos. La firma no prueba entrega ni cobro.
- **2021 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2021-PHL-01|EXP-2021-PHL-01]], Filipinas, Falmar-V de exportación. La firma no prueba entrega ni cobro.
- **2023 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2023-CHL-01|EXP-2023-CHL-01]], Chile, Sostenimiento y digitalización de flota. La firma no prueba entrega ni cobro.
- **2025 · C3:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2025-IND-01|EXP-2025-IND-01]], India, Integración de sensores y formación. La firma no prueba entrega ni cobro.

### Hitos de ejecución E1 por año

- **1888 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1887-CHL-01|EXP-1887-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-1887-CHL-01-H01.
- **1889 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1887-CHL-01|EXP-1887-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-1887-CHL-01-H02.
- **1891 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1887-CHL-01|EXP-1887-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-1887-CHL-01-H03.
- **1892 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1887-CHL-01|EXP-1887-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-1887-CHL-01-H04.
- **1898 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1896-PRT-01|EXP-1896-PRT-01]], Portugal: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1896-PRT-01-H01.
- **1899 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1896-PRT-01|EXP-1896-PRT-01]], Portugal: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1896-PRT-01-H02.
- **1910 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1908-CHL-01|EXP-1908-CHL-01]], Chile: aceptacion servicio, 1 lote óptica y repuestos. ID editorial A101-EXP-1908-CHL-01-H01.
- **1912 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1908-CHL-01|EXP-1908-CHL-01]], Chile: cierre tecnico, sin cantidad de bienes fijada. ID editorial A101-EXP-1908-CHL-01-H02.
- **1915 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1913-BRA-01|EXP-1913-BRA-01]], Brasil: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1913-BRA-01-H01.
- **1916 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1913-BRA-01|EXP-1913-BRA-01]], Brasil: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1913-BRA-01-H02.
- **1930 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1927-CHL-01|EXP-1927-CHL-01]], Chile: aceptacion servicio, 1 instalación. ID editorial A101-EXP-1927-CHL-01-H01.
- **1931 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1927-CHL-01|EXP-1927-CHL-01]], Chile: cierre formacion, sin cantidad de bienes fijada. ID editorial A101-EXP-1927-CHL-01-H02.
- **1935 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1934-PRT-01|EXP-1934-PRT-01]], Portugal: aceptacion bien, 12 torpedos. ID editorial A101-EXP-1934-PRT-01-H01.
- **1936 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1934-PRT-01|EXP-1934-PRT-01]], Portugal: aceptacion bien, 12 torpedos. ID editorial A101-EXP-1934-PRT-01-H02.
- **1937 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1934-PRT-01|EXP-1934-PRT-01]], Portugal: aceptacion bien, 12 torpedos. ID editorial A101-EXP-1934-PRT-01-H03.
- **1950 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1948-NZL-01|EXP-1948-NZL-01]], Nueva Zelanda: aceptacion bien, 2 radares. ID editorial A101-EXP-1948-NZL-01-H01.
- **1951 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1948-NZL-01|EXP-1948-NZL-01]], Nueva Zelanda: aceptacion bien, 2 radares. ID editorial A101-EXP-1948-NZL-01-H02.
- **1952 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1948-NZL-01|EXP-1948-NZL-01]], Nueva Zelanda: cierre formacion, sin cantidad de bienes fijada. ID editorial A101-EXP-1948-NZL-01-H03.
- **1958 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1956-CHL-01|EXP-1956-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1956-CHL-01-H01.
- **1959 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1956-CHL-01|EXP-1956-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1956-CHL-01-H02.
- **1960 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1956-CHL-01|EXP-1956-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1956-CHL-01-H03.
- **1968 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1966-PER-01|EXP-1966-PER-01]], Perú: aceptacion bien, 16 torpedos. ID editorial A101-EXP-1966-PER-01-H01.
- **1969 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1966-PER-01|EXP-1966-PER-01]], Perú: aceptacion bien, 16 torpedos. ID editorial A101-EXP-1966-PER-01-H02.
- **1970 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1966-PER-01|EXP-1966-PER-01]], Perú: aceptacion bien, 16 torpedos. ID editorial A101-EXP-1966-PER-01-H03.
- **1970 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1968-PRT-01|EXP-1968-PRT-01]], Portugal: aceptacion bien, 2 sistemas. ID editorial A101-EXP-1968-PRT-01-H01.
- **1972 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1968-PRT-01|EXP-1968-PRT-01]], Portugal: aceptacion bien, 2 sistemas. ID editorial A101-EXP-1968-PRT-01-H02.
- **1976 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1974-CHL-01|EXP-1974-CHL-01]], Chile: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1974-CHL-01-H01.
- **1977 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1974-CHL-01|EXP-1974-CHL-01]], Chile: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1974-CHL-01-H02.
- **1977 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1975-CHL-02|EXP-1975-CHL-02]], Chile: aceptacion bien, 8 misiles. ID editorial A101-EXP-1975-CHL-02-H01.
- **1978 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1974-CHL-01|EXP-1974-CHL-01]], Chile: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1974-CHL-01-H03.
- **1978 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1975-CHL-02|EXP-1975-CHL-02]], Chile: aceptacion bien, 8 misiles. ID editorial A101-EXP-1975-CHL-02-H02.
- **1979 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1974-CHL-01|EXP-1974-CHL-01]], Chile: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1974-CHL-01-H04.
- **1979 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1975-CHL-02|EXP-1975-CHL-02]], Chile: aceptacion bien, 8 misiles. ID editorial A101-EXP-1975-CHL-02-H03.
- **1980 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1975-CHL-02|EXP-1975-CHL-02]], Chile: aceptacion bien, 8 misiles. ID editorial A101-EXP-1975-CHL-02-H04.
- **1982 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1978-IDN-01|EXP-1978-IDN-01]], Indonesia: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1978-IDN-01-H01.
- **1984 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1978-IDN-01|EXP-1978-IDN-01]], Indonesia: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-1978-IDN-01-H02.
- **1985 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1983-PER-01|EXP-1983-PER-01]], Perú: aceptacion bien, 10 misiles. ID editorial A101-EXP-1983-PER-01-H01.
- **1986 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1983-PER-01|EXP-1983-PER-01]], Perú: aceptacion bien, 10 misiles. ID editorial A101-EXP-1983-PER-01-H02.
- **1987 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1983-PER-01|EXP-1983-PER-01]], Perú: aceptacion bien, 10 misiles. ID editorial A101-EXP-1983-PER-01-H03.
- **1988 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1983-PER-01|EXP-1983-PER-01]], Perú: aceptacion bien, 10 misiles. ID editorial A101-EXP-1983-PER-01-H04.
- **1989 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1986-CHL-01|EXP-1986-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1986-CHL-01-H01.
- **1991 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1986-CHL-01|EXP-1986-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-1986-CHL-01-H02.
- **1996 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1993-BRA-01|EXP-1993-BRA-01]], Brasil: aceptacion bien, 1 sistemas CMS. ID editorial A101-EXP-1993-BRA-01-H01.
- **1997 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1993-BRA-01|EXP-1993-BRA-01]], Brasil: aceptacion bien, 1 sistemas CMS. ID editorial A101-EXP-1993-BRA-01-H02.
- **1999 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1993-BRA-01|EXP-1993-BRA-01]], Brasil: aceptacion bien, 2 sistemas CMS. ID editorial A101-EXP-1993-BRA-01-H03.
- **2001 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India: transferencia documental, sin cantidad de bienes fijada. ID editorial A101-EXP-1998-IND-01-H01.
- **2003 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India: fabricacion extranjera, 20 misiles bajo licencia. ID editorial A101-EXP-1998-IND-01-H02.
- **2004 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India: fabricacion extranjera, 30 misiles bajo licencia. ID editorial A101-EXP-1998-IND-01-H03.
- **2004 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2001-CHL-01|EXP-2001-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-2001-CHL-01-H01.
- **2005 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2001-CHL-01|EXP-2001-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-2001-CHL-01-H02.
- **2006 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India: fabricacion extranjera, 30 misiles bajo licencia. ID editorial A101-EXP-1998-IND-01-H04.
- **2007 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2001-CHL-01|EXP-2001-CHL-01]], Chile: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-2001-CHL-01-H03.
- **2007 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2004-PHL-01|EXP-2004-PHL-01]], Filipinas: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-2004-PHL-01-H01.
- **2008 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-1998-IND-01|EXP-1998-IND-01]], India: fabricacion extranjera, 40 misiles bajo licencia. ID editorial A101-EXP-1998-IND-01-H05.
- **2008 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2004-PHL-01|EXP-2004-PHL-01]], Filipinas: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-2004-PHL-01-H02.
- **2010 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2004-PHL-01|EXP-2004-PHL-01]], Filipinas: aceptacion bien, 1 cascos nuevos. ID editorial A101-EXP-2004-PHL-01-H03.
- **2011 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2009-PRT-01|EXP-2009-PRT-01]], Portugal: aceptacion bien, 12 misiles. ID editorial A101-EXP-2009-PRT-01-H01.
- **2012 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2009-PRT-01|EXP-2009-PRT-01]], Portugal: aceptacion bien, 12 misiles. ID editorial A101-EXP-2009-PRT-01-H02.
- **2014 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2009-PRT-01|EXP-2009-PRT-01]], Portugal: aceptacion bien, 12 misiles. ID editorial A101-EXP-2009-PRT-01-H03.
- **2015 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2012-IDN-01|EXP-2012-IDN-01]], Indonesia: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-2012-IDN-01-H01.
- **2017 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2012-IDN-01|EXP-2012-IDN-01]], Indonesia: aceptacion servicio, 1 intervenciones sobre cascos. ID editorial A101-EXP-2012-IDN-01-H02.
- **2017 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2015-CHL-01|EXP-2015-CHL-01]], Chile: aceptacion bien, 1 sistemas. ID editorial A101-EXP-2015-CHL-01-H01.
- **2019 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2015-CHL-01|EXP-2015-CHL-01]], Chile: aceptacion bien, 1 sistemas. ID editorial A101-EXP-2015-CHL-01-H02.
- **2021 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2015-CHL-01|EXP-2015-CHL-01]], Chile: aceptacion bien, 1 sistemas. ID editorial A101-EXP-2015-CHL-01-H03.
- **2021 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2018-NZL-01|EXP-2018-NZL-01]], Nueva Zelanda: aceptacion fase, sin cantidad de bienes fijada. ID editorial A101-EXP-2018-NZL-01-H01.
- **2022 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2018-NZL-01|EXP-2018-NZL-01]], Nueva Zelanda: aceptacion fase, sin cantidad de bienes fijada. ID editorial A101-EXP-2018-NZL-01-H02.
- **2023 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2015-CHL-01|EXP-2015-CHL-01]], Chile: aceptacion bien, 1 sistemas. ID editorial A101-EXP-2015-CHL-01-H04.
- **2024 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2018-NZL-01|EXP-2018-NZL-01]], Nueva Zelanda: aceptacion fase, sin cantidad de bienes fijada. ID editorial A101-EXP-2018-NZL-01-H03.
- **2024 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2021-PHL-01|EXP-2021-PHL-01]], Filipinas: aceptacion bien, 8 misiles. ID editorial A101-EXP-2021-PHL-01-H01.
- **2025 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2021-PHL-01|EXP-2021-PHL-01]], Filipinas: aceptacion bien, 8 misiles. ID editorial A101-EXP-2021-PHL-01-H02.
- **2025 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2023-CHL-01|EXP-2023-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-2023-CHL-01-H01.
- **2026 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2021-PHL-01|EXP-2021-PHL-01]], Filipinas: aceptacion bien, 8 misiles. ID editorial A101-EXP-2021-PHL-01-H03.
- **2026 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2023-CHL-01|EXP-2023-CHL-01]], Chile: aceptacion hito, 1 hitos. ID editorial A101-EXP-2023-CHL-01-H02.
- **2026 · E1:** [[12_Militar/03_Armada/Exportaciones navales A099 A101#EXP-2025-IND-01|EXP-2025-IND-01]], India: actividad inicial, sin cantidad de bienes fijada. ID editorial A101-EXP-2025-IND-01-H01.

### Límites del corte y continuidad prevista

- **2027–2029 previsto:** hitos pendientes de Chile 2023; no programa completo en 2026.
- **2027–2030 previsto:** continuación e integración de India 2025; la actividad inicial de 2026 no prueba aceptación.
- **E2 alternativo:** acepta un casco indonesio en 1985 y el último OPV filipino en 2011; ocho Falmar-V filipinos pendientes a cierre de 2026. No sumar a E1.
- **E3 alternativo:** noventa unidades licenciadas indias y treinta pendientes; no es fabricación nacional valinoriana.

Las fechas de FAT, SAT, transferencia física y producción nacional anual no se igualan a los años de aceptación. Los once cascos para terceros no modifican la Armada; las 216 armas están dentro de rangos A095 antibuque. Las 120 licenciadas extranjeras van en cuenta independiente.

[[00_Canon/Integraciones V16/Acumulativa A101 Reconstrucción exportadora|Acumulativa A101]]


## Integración A102 Industria automotriz y Fuerza Aérea

Hitos narrativos adoptados el 10 de noviembre de 2026; los intervalos de desarrollo y escenarios conservan su naturaleza. A102 integra A094 automotriz y A095 aérea, no A094 defensa ni A095 antibuque. Los acontecimientos son historia ficticia, no prueba documental.

- **1820–1850:** Ascensiones experimentales y observación meteorológica; antecedentes narrativos de la aerostación.
- **1850–1880:** Observación militar con globos y cooperación con ingenieros.
- **1880–1900:** Aerostación organizada y formación; talleres mecánicos y primeras experiencias automotrices.
- **1886–1892:** Automóviles experimentales de combustión en la secuencia narrativa adoptada.
- **1888:** Origen narrativo de Motores de Arnor; constitución legal y plantas sin dato.
- **1892–1897:** Pequeñas series comerciales de automóviles.
- **1895–1900:** Aplicaciones eléctricas urbanas; no baterías modernas ni alcance de larga distancia inferido.
- **1896:** Origen narrativo de Electromecánica de Valinor.
- **1902:** Origen narrativo de Automóviles de Annúminas.
- **1904–1907:** Experimentación aeronáutica con aeroplanos y motores.
- **1906:** Vuelo motorizado controlado reconocido en el programa valinari, sin prioridad mundial atribuida.
- **1909:** Escuela militar de vuelo y mantenimiento.
- **1910–1929:** Introducción y extensión gradual de líneas móviles automotrices y normalización de piezas.
- **1911:** Origen narrativo de Automóviles Calen; Hador conserva su catálogo militar separado.
- **1912:** Servicio Aeronáutico Militar permanente e introducción inicial del O-12 Meneldir.
- **1917:** Introducción inicial del C-17 Thorondir.
- **1918:** Origen narrativo de Vehículos Industriales Australes.
- **1926:** Independencia de la Fuerza Aérea de Valinor; aviación naval diferenciada. Duilin conserva su desarrollo terrestre.
- **1938:** Introducción inicial del C-38 Sorontar.
- **1940:** Introducción inicial del T-40 Menelcar.
- **1940–1945:** Investigación de reacción; no fuerza operativa de reacción inferida.
- **1943:** Introducción inicial del B-43 Beleg convencional, distinto del blindado terrestre.
- **1946:** Demostrador valinari de reacción.
- **1948–1952:** Evaluación y pequeñas series de reacción.
- **1952:** Servicio inicial regular del C-52 Thorondor I; expansión posterior sin sustitución inmediata de hélices.
- **1958:** Reorganización como Fuerza Aérea Federal de Valinor; normas jurídicas concretas sin dato. Se conserva el programa OceanNet.
- **1959–1969:** Servicio institucional inicial y consolidación de OceanNet; sin red global madura atribuida a 1959.
- **1966:** Introducción inicial del C-66 Thorondor II.
- **1967:** Origen narrativo de Malaca Movilidad.
- **1984:** Introducción inicial del C-84 Soron I.
- **1990:** Introducción inicial del AE-90 Menelvagor.
- **1995–2010:** Plataformas comunes e hibridación automotriz por etapas.
- **2004:** Introducción inicial del C-04 Soron II.
- **2010:** Introducción inicial del U-10 Tirmen para vigilancia y reconocimiento.
- **2010–2026:** Electrificación progresiva, fabricación de paquetes y celdas diferenciada, coexistencia de motorizaciones.
- **2018:** Introducción inicial del C-18 Soron III; prestaciones de firma sin cuantificar.
- **2020:** Se conserva A093: control naval de drones de ataque desde buques, sin transferencia automática al inventario aéreo.
- **2026:** Escenario automotriz central 12 millones/año, banda 10–14; producción observada, parque, empleo y exportaciones sin fijar.
- **2026:** Cantidades, matrículas, disponibilidad y presupuesto aéreo pendientes; no se derivan de años de introducción.

[[08_Economia/Industria automotriz 1880-2026|Industria automotriz A094]] · [[12_Militar/04_Fuerzas Aéreas/Historia de la Fuerza Aérea A095|Historia aérea A095]] · [[00_Canon/Integraciones V16/Integración A102 automotriz y aérea|Integración A102]]


## Integración A103 Vëantur y relevo de Círdan I

Fechas narrativas adoptadas por instrucción del autor del 10 de noviembre de 2026. Los IDs son editoriales, no matrículas. Este bloque desarrolla el plan de sustitución de 1884; no acredita disponibilidad ni inventario naval total por año.

- **1884:** Autorización de cuatro Vëantur y decisión de relevo gradual de Círdan I; se priorizan cascos nuevos y reformas parciales en los anteriores.
- **1885:** Comienza Vëantur A103-VEA-01. Se abre el periodo 1885–1888 de reformas parciales Círdan, sin sustitución adoptada de sus plantas principales.
- **1886:** Comienza Vëantur A103-VEA-02.
- **1888:** Comienza Vëantur A103-VEA-03.
- **1889:** Entra en servicio Vëantur 01; comienza Vëantur 04. Círdan C75-01 y C75-02 pasan a segunda línea.
- **1890:** Entra en servicio Vëantur 02; Círdan C75-03 y C75-04 pasan a segunda línea.
- **1891:** Perímetro A103: dos Vëantur incorporados y dos en construcción; seis Círdan en inventario, cuatro de segunda línea y dos de primera línea transitoria. No equivale a disponibilidad.
- **1892:** Entra en servicio Vëantur 03; Círdan C75-05 y C75-06 pasan a segunda línea. Comienza la ventana Anárion ya existente; programa separado.
- **1893:** Entra en servicio Vëantur 04; completa la serie de cuatro.
- **1894:** El capital de turbina de referencia continúa como perfil sin nombre y cantidad; no se identifica con Vëantur ni Anárion.
- **1895:** Se conserva el inicio aproximado de servicio Anárion. La nueva serie es distinta de los cuatro Vëantur.
- **1898:** Retiro narrativo de Círdan C75-01.
- **1900:** Retiro narrativo de Círdan C75-02; cuatro Vëantur continúan incorporados. Los ocho Anárion de programa no se presumen todos operativos en 1900.
- **1902:** Retiro narrativo de Círdan C75-03.
- **1904:** Retiro narrativo de Círdan C75-04.
- **1906:** Retiro narrativo de Círdan C75-05.
- **1907:** Retiro narrativo de Vëantur 01.
- **1908:** Retiro narrativo de Círdan C75-06; se conserva el cierre de servicio de su familia.
- **1909:** Retiro narrativo de Vëantur 02.
- **1911:** Retiro narrativo de Vëantur 03.
- **1913:** Retiro narrativo de Vëantur 04; termina el servicio de la clase antes de 1914.

[[00_Canon/Integraciones V16/Acumulativa A103 Clase Vëantur y relevo de Círdan I|Resolución A103]] · [[12_Militar/03_Armada/Clase Vëantur 1884-1913|Clase Vëantur]]


## Integración A104 Desarrollo naval e industria

Esta resolución prevalece sobre hitos anteriores afectados. Fechas anuales adoptadas narrativamente; los objetivos industriales no acreditan recepción. [[00_Canon/Integraciones V16/Acumulativa A104 Desarrollo naval e industria militar|Resolución A104]]

- **1888 — ANP01-GG75-01:** paso a segunda línea.
- **1888 — ANP01-GG75-02:** paso a segunda línea.
- **1888 — Programa Tarannon:** autorización inicial de dos capitales de turbina.
- **1889 — ANP01-EAR-01:** paso a segunda línea.
- **1889 — ANP01-EAR-02:** paso a segunda línea.
- **1889 — ANP01-TAR-01:** inicio de construcción.
- **1890 — ANP01-GG75-03:** paso a segunda línea.
- **1890 — ANP01-GG75-04:** paso a segunda línea.
- **1891 — ANP01-EAR-03:** paso a segunda línea.
- **1891 — ANP01-EAR-04:** paso a segunda línea.
- **1891 — Programa Anárion de escuadra:** autorización de ocho unidades de referencia.
- **1892 — ANP01-ANA-01:** inicio de construcción.
- **1892 — ANP01-GG75-05:** paso a segunda línea.
- **1892 — ANP01-GG75-06:** paso a segunda línea.
- **1892 — ANP01-TAR-02:** inicio de construcción.
- **1893 — ANP01-ANA-02:** inicio de construcción.
- **1894 — ANP01-ANA-03:** inicio de construcción.
- **1894 — ANP01-EAC-01:** inicio de construcción.
- **1894 — ANP01-EAC-02:** inicio de construcción.
- **1894 — ANP01-TAR-01:** entrada en servicio.
- **1895 — ANP01-ANA-01:** entrada en servicio.
- **1895 — ANP01-ANA-04:** inicio de construcción.
- **1895 — ANP01-EAC-03:** inicio de construcción.
- **1895 — ANP01-EAC-04:** inicio de construcción.
- **1895 — ANP01-GG75-01:** retiro del servicio naval activo.
- **1895 — ANP01-RME-01:** inicio de construcción.
- **1895 — ANP01-RME-02:** inicio de construcción.
- **1896 — ANP01-ANA-02:** entrada en servicio.
- **1896 — ANP01-ANA-05:** inicio de construcción.
- **1896 — ANP01-EAC-01:** botadura objetivo.
- **1896 — ANP01-EAC-02:** botadura objetivo.
- **1896 — ANP01-EAC-05:** inicio de construcción.
- **1896 — ANP01-EAC-06:** inicio de construcción.
- **1896 — ANP01-EAR-01:** retiro del servicio naval activo.
- **1896 — ANP01-PEL-01:** inicio de construcción.
- **1896 — ANP01-PEL-02:** inicio de construcción.
- **1896 — ANP01-REO-01:** inicio de construcción.
- **1896 — ANP01-RME-03:** inicio de construcción.
- **1896 — ANP01-RME-04:** inicio de construcción.
- **1896 — Programa Tarannon:** continuidad de dos adicionales; serie total de cuatro.
- **1897 — ANP01-ANA-03:** entrada en servicio.
- **1897 — ANP01-ANA-06:** inicio de construcción.
- **1897 — ANP01-EAC-01:** entrada en servicio.
- **1897 — ANP01-EAC-02:** entrada en servicio.
- **1897 — ANP01-EAC-03:** botadura objetivo.
- **1897 — ANP01-EAC-04:** botadura objetivo.
- **1897 — ANP01-EAC-07:** inicio de construcción.
- **1897 — ANP01-EAC-08:** inicio de construcción.
- **1897 — ANP01-FDD-01:** inicio de construcción.
- **1897 — ANP01-FDD-02:** inicio de construcción.
- **1897 — ANP01-FDD-03:** inicio de construcción.
- **1897 — ANP01-FDD-04:** inicio de construcción.
- **1897 — ANP01-GG75-02:** retiro del servicio naval activo.
- **1897 — ANP01-PEL-01:** botadura objetivo.
- **1897 — ANP01-PEL-02:** botadura objetivo.
- **1897 — ANP01-PEL-03:** inicio de construcción.
- **1897 — ANP01-PEL-04:** inicio de construcción.
- **1897 — ANP01-RME-01:** botadura objetivo.
- **1897 — ANP01-RME-02:** botadura objetivo.
- **1897 — ANP01-RME-05:** inicio de construcción.
- **1897 — ANP01-RME-06:** inicio de construcción.
- **1897 — ANP01-TAR-02:** entrada en servicio.
- **1897 — ANP01-TAR-03:** inicio de construcción.
- **1898 — ANP01-ANA-04:** entrada en servicio.
- **1898 — ANP01-ANA-07:** inicio de construcción.
- **1898 — ANP01-EAC-03:** entrada en servicio.
- **1898 — ANP01-EAC-04:** entrada en servicio.
- **1898 — ANP01-EAC-05:** botadura objetivo.
- **1898 — ANP01-EAC-06:** botadura objetivo.
- **1898 — ANP01-EAC-09:** inicio de construcción.
- **1898 — ANP01-EAC-10:** inicio de construcción.
- **1898 — ANP01-EAR-02:** retiro del servicio naval activo.
- **1898 — ANP01-FDD-05:** inicio de construcción.
- **1898 — ANP01-FDD-06:** inicio de construcción.
- **1898 — ANP01-FDD-07:** inicio de construcción.
- **1898 — ANP01-FDD-08:** inicio de construcción.
- **1898 — ANP01-FTP-01:** inicio de construcción.
- **1898 — ANP01-FTP-02:** inicio de construcción.
- **1898 — ANP01-FTP-03:** inicio de construcción.
- **1898 — ANP01-FTP-04:** inicio de construcción.
- **1898 — ANP01-PEL-01:** entrada en servicio.
- **1898 — ANP01-PEL-02:** entrada en servicio.
- **1898 — ANP01-PEL-03:** botadura objetivo.
- **1898 — ANP01-PEL-04:** botadura objetivo.
- **1898 — ANP01-PEL-05:** inicio de construcción.
- **1898 — ANP01-PEL-06:** inicio de construcción.
- **1898 — ANP01-REO-02:** inicio de construcción.
- **1898 — ANP01-RME-01:** entrada en servicio.
- **1898 — ANP01-RME-02:** entrada en servicio.
- **1898 — ANP01-RME-03:** botadura objetivo.
- **1898 — ANP01-RME-04:** botadura objetivo.
- **1898 — ANP01-RME-07:** inicio de construcción.
- **1899 — ANP01-ANA-05:** entrada en servicio.
- **1899 — ANP01-ANA-08:** inicio de construcción.
- **1899 — ANP01-EAC-05:** entrada en servicio.
- **1899 — ANP01-EAC-06:** entrada en servicio.
- **1899 — ANP01-EAC-07:** botadura objetivo.
- **1899 — ANP01-EAC-08:** botadura objetivo.
- **1899 — ANP01-EAC-11:** inicio de construcción.
- **1899 — ANP01-EAC-12:** inicio de construcción.
- **1899 — ANP01-FDD-01:** botadura objetivo.
- **1899 — ANP01-FDD-02:** botadura objetivo.
- **1899 — ANP01-FDD-03:** botadura objetivo.
- **1899 — ANP01-FDD-04:** botadura objetivo.
- **1899 — ANP01-FDD-09:** inicio de construcción.
- **1899 — ANP01-FDD-10:** inicio de construcción.
- **1899 — ANP01-FDD-11:** inicio de construcción.
- **1899 — ANP01-FDD-12:** inicio de construcción.
- **1899 — ANP01-FTP-01:** botadura objetivo.
- **1899 — ANP01-FTP-02:** botadura objetivo.
- **1899 — ANP01-FTP-03:** botadura objetivo.
- **1899 — ANP01-FTP-04:** botadura objetivo.
- **1899 — ANP01-FTP-05:** inicio de construcción.
- **1899 — ANP01-FTP-06:** inicio de construcción.
- **1899 — ANP01-FTP-07:** inicio de construcción.
- **1899 — ANP01-FTP-08:** inicio de construcción.
- **1899 — ANP01-GG75-03:** retiro del servicio naval activo.
- **1899 — ANP01-PEL-03:** entrada en servicio.
- **1899 — ANP01-PEL-04:** entrada en servicio.
- **1899 — ANP01-PEL-05:** botadura objetivo.
- **1899 — ANP01-PEL-06:** botadura objetivo.
- **1899 — ANP01-PEL-07:** inicio de construcción.
- **1899 — ANP01-PEL-08:** inicio de construcción.
- **1899 — ANP01-REO-01:** botadura objetivo.
- **1899 — ANP01-RME-03:** entrada en servicio.
- **1899 — ANP01-RME-04:** entrada en servicio.
- **1899 — ANP01-RME-05:** botadura objetivo.
- **1899 — ANP01-RME-06:** botadura objetivo.
- **1899 — ANP01-RME-08:** inicio de construcción.
- **1899 — ANP01-TAR-04:** inicio de construcción.
- **1900 — ANP01-ANA-06:** entrada en servicio.
- **1900 — ANP01-EAC-07:** entrada en servicio.
- **1900 — ANP01-EAC-08:** entrada en servicio.
- **1900 — ANP01-EAR-03:** retiro del servicio naval activo.
- **1900 — ANP01-FDD-01:** entrada en servicio.
- **1900 — ANP01-FDD-02:** entrada en servicio.
- **1900 — ANP01-FDD-03:** entrada en servicio.
- **1900 — ANP01-FDD-04:** entrada en servicio.
- **1900 — ANP01-FDD-05:** botadura objetivo.
- **1900 — ANP01-FDD-06:** botadura objetivo.
- **1900 — ANP01-FDD-07:** botadura objetivo.
- **1900 — ANP01-FDD-08:** botadura objetivo.
- **1900 — ANP01-FDD-13:** inicio de construcción.
- **1900 — ANP01-FDD-14:** inicio de construcción.
- **1900 — ANP01-FDD-15:** inicio de construcción.
- **1900 — ANP01-FDD-16:** inicio de construcción.
- **1900 — ANP01-FTP-01:** entrada en servicio.
- **1900 — ANP01-FTP-02:** entrada en servicio.
- **1900 — ANP01-FTP-03:** entrada en servicio.
- **1900 — ANP01-FTP-04:** entrada en servicio.
- **1900 — ANP01-FTP-05:** botadura objetivo.
- **1900 — ANP01-FTP-06:** botadura objetivo.
- **1900 — ANP01-FTP-07:** botadura objetivo.
- **1900 — ANP01-FTP-08:** botadura objetivo.
- **1900 — ANP01-FTP-09:** inicio de construcción.
- **1900 — ANP01-FTP-10:** inicio de construcción.
- **1900 — ANP01-FTP-11:** inicio de construcción.
- **1900 — ANP01-FTP-12:** inicio de construcción.
- **1900 — ANP01-PEL-05:** entrada en servicio.
- **1900 — ANP01-PEL-06:** entrada en servicio.
- **1900 — ANP01-PEL-07:** botadura objetivo.
- **1900 — ANP01-PEL-08:** botadura objetivo.
- **1900 — ANP01-PEL-09:** inicio de construcción.
- **1900 — ANP01-PEL-10:** inicio de construcción.
- **1900 — ANP01-REO-01:** entrada en servicio.
- **1900 — ANP01-REO-03:** inicio de construcción.
- **1900 — ANP01-RME-05:** entrada en servicio.
- **1900 — ANP01-RME-06:** entrada en servicio.
- **1900 — ANP01-RME-07:** botadura objetivo.
- **1901 — ANP01-ANA-07:** entrada en servicio.
- **1901 — ANP01-EAC-01:** primera carena mayor planificada.
- **1901 — ANP01-EAC-02:** primera carena mayor planificada.
- **1901 — ANP01-EAC-09:** botadura objetivo.
- **1901 — ANP01-EAC-10:** botadura objetivo.
- **1901 — ANP01-FDD-05:** entrada en servicio.
- **1901 — ANP01-FDD-06:** entrada en servicio.
- **1901 — ANP01-FDD-07:** entrada en servicio.
- **1901 — ANP01-FDD-08:** entrada en servicio.
- **1901 — ANP01-FDD-09:** botadura objetivo.
- **1901 — ANP01-FDD-10:** botadura objetivo.
- **1901 — ANP01-FDD-11:** botadura objetivo.
- **1901 — ANP01-FDD-12:** botadura objetivo.
- **1901 — ANP01-FDD-17:** inicio de construcción.
- **1901 — ANP01-FDD-18:** inicio de construcción.
- **1901 — ANP01-FDD-19:** inicio de construcción.
- **1901 — ANP01-FDD-20:** inicio de construcción.
- **1901 — ANP01-FTP-05:** entrada en servicio.
- **1901 — ANP01-FTP-06:** entrada en servicio.
- **1901 — ANP01-FTP-07:** entrada en servicio.
- **1901 — ANP01-FTP-08:** entrada en servicio.
- **1901 — ANP01-FTP-09:** botadura objetivo.
- **1901 — ANP01-FTP-10:** botadura objetivo.
- **1901 — ANP01-FTP-11:** botadura objetivo.
- **1901 — ANP01-FTP-12:** botadura objetivo.
- **1901 — ANP01-FTP-13:** inicio de construcción.
- **1901 — ANP01-FTP-14:** inicio de construcción.
- **1901 — ANP01-FTP-15:** inicio de construcción.
- **1901 — ANP01-FTP-16:** inicio de construcción.
- **1901 — ANP01-GG75-04:** retiro del servicio naval activo.
- **1901 — ANP01-PEL-07:** entrada en servicio.
- **1901 — ANP01-PEL-08:** entrada en servicio.
- **1901 — ANP01-PEL-09:** botadura objetivo.
- **1901 — ANP01-PEL-10:** botadura objetivo.
- **1901 — ANP01-PEL-11:** inicio de construcción.
- **1901 — ANP01-REO-02:** botadura objetivo.
- **1901 — ANP01-REO-04:** inicio de construcción.
- **1901 — ANP01-RME-07:** entrada en servicio.
- **1901 — ANP01-RME-08:** botadura objetivo.
- **1901 — Industria y combustible:** inicio objetivo de implantación CSNR, pilotos de líquido y bancos diésel; capacidades sujetas a recepción.
- **1902 — ANP01-ANA-08:** entrada en servicio.
- **1902 — ANP01-EAC-03:** primera carena mayor planificada.
- **1902 — ANP01-EAC-04:** primera carena mayor planificada.
- **1902 — ANP01-EAC-09:** entrada en servicio.
- **1902 — ANP01-EAC-10:** entrada en servicio.
- **1902 — ANP01-EAR-04:** retiro del servicio naval activo.
- **1902 — ANP01-FDD-09:** entrada en servicio.
- **1902 — ANP01-FDD-10:** entrada en servicio.
- **1902 — ANP01-FDD-11:** entrada en servicio.
- **1902 — ANP01-FDD-12:** entrada en servicio.
- **1902 — ANP01-FDD-13:** botadura objetivo.
- **1902 — ANP01-FDD-14:** botadura objetivo.
- **1902 — ANP01-FDD-15:** botadura objetivo.
- **1902 — ANP01-FDD-16:** botadura objetivo.
- **1902 — ANP01-FDD-21:** inicio de construcción.
- **1902 — ANP01-FDD-22:** inicio de construcción.
- **1902 — ANP01-FDD-23:** inicio de construcción.
- **1902 — ANP01-FDD-24:** inicio de construcción.
- **1902 — ANP01-FTP-09:** entrada en servicio.
- **1902 — ANP01-FTP-10:** entrada en servicio.
- **1902 — ANP01-FTP-11:** entrada en servicio.
- **1902 — ANP01-FTP-12:** entrada en servicio.
- **1902 — ANP01-FTP-13:** botadura objetivo.
- **1902 — ANP01-FTP-14:** botadura objetivo.
- **1902 — ANP01-FTP-15:** botadura objetivo.
- **1902 — ANP01-FTP-16:** botadura objetivo.
- **1902 — ANP01-FTP-17:** inicio de construcción.
- **1902 — ANP01-FTP-18:** inicio de construcción.
- **1902 — ANP01-FTP-19:** inicio de construcción.
- **1902 — ANP01-FTP-20:** inicio de construcción.
- **1902 — ANP01-PEL-01:** primera carena mayor planificada.
- **1902 — ANP01-PEL-02:** primera carena mayor planificada.
- **1902 — ANP01-PEL-09:** entrada en servicio.
- **1902 — ANP01-PEL-10:** entrada en servicio.
- **1902 — ANP01-PEL-11:** botadura objetivo.
- **1902 — ANP01-REO-02:** entrada en servicio.
- **1902 — ANP01-RME-01:** primera carena mayor planificada.
- **1902 — ANP01-RME-02:** primera carena mayor planificada.
- **1902 — ANP01-RME-08:** entrada en servicio.
- **1902 — ANP01-TAR-03:** entrada en servicio.
- **1903 — ANP01-EAC-05:** primera carena mayor planificada.
- **1903 — ANP01-EAC-06:** primera carena mayor planificada.
- **1903 — ANP01-EAC-11:** botadura objetivo.
- **1903 — ANP01-EAC-12:** botadura objetivo.
- **1903 — ANP01-FDD-01:** primera carena mayor planificada.
- **1903 — ANP01-FDD-02:** primera carena mayor planificada.
- **1903 — ANP01-FDD-03:** primera carena mayor planificada.
- **1903 — ANP01-FDD-04:** primera carena mayor planificada.
- **1903 — ANP01-FDD-13:** entrada en servicio.
- **1903 — ANP01-FDD-14:** entrada en servicio.
- **1903 — ANP01-FDD-15:** entrada en servicio.
- **1903 — ANP01-FDD-16:** entrada en servicio.
- **1903 — ANP01-FDD-17:** botadura objetivo.
- **1903 — ANP01-FDD-18:** botadura objetivo.
- **1903 — ANP01-FDD-19:** botadura objetivo.
- **1903 — ANP01-FDD-20:** botadura objetivo.
- **1903 — ANP01-FTP-01:** primera carena mayor planificada.
- **1903 — ANP01-FTP-02:** primera carena mayor planificada.
- **1903 — ANP01-FTP-03:** primera carena mayor planificada.
- **1903 — ANP01-FTP-04:** primera carena mayor planificada.
- **1903 — ANP01-FTP-13:** entrada en servicio.
- **1903 — ANP01-FTP-14:** entrada en servicio.
- **1903 — ANP01-FTP-15:** entrada en servicio.
- **1903 — ANP01-FTP-16:** entrada en servicio.
- **1903 — ANP01-FTP-17:** botadura objetivo.
- **1903 — ANP01-FTP-18:** botadura objetivo.
- **1903 — ANP01-FTP-19:** botadura objetivo.
- **1903 — ANP01-FTP-20:** botadura objetivo.
- **1903 — ANP01-FTP-21:** inicio de construcción.
- **1903 — ANP01-FTP-22:** inicio de construcción.
- **1903 — ANP01-FTP-23:** inicio de construcción.
- **1903 — ANP01-FTP-24:** inicio de construcción.
- **1903 — ANP01-GG75-05:** retiro del servicio naval activo.
- **1903 — ANP01-PEL-03:** primera carena mayor planificada.
- **1903 — ANP01-PEL-04:** primera carena mayor planificada.
- **1903 — ANP01-PEL-11:** entrada en servicio.
- **1903 — ANP01-PEL-12:** inicio de construcción.
- **1903 — ANP01-REO-03:** botadura objetivo.
- **1903 — ANP01-RME-03:** primera carena mayor planificada.
- **1903 — ANP01-RME-04:** primera carena mayor planificada.
- **1904 — ANP01-EAC-07:** primera carena mayor planificada.
- **1904 — ANP01-EAC-08:** primera carena mayor planificada.
- **1904 — ANP01-EAC-11:** entrada en servicio.
- **1904 — ANP01-EAC-12:** entrada en servicio.
- **1904 — ANP01-FDD-05:** primera carena mayor planificada.
- **1904 — ANP01-FDD-06:** primera carena mayor planificada.
- **1904 — ANP01-FDD-07:** primera carena mayor planificada.
- **1904 — ANP01-FDD-08:** primera carena mayor planificada.
- **1904 — ANP01-FDD-17:** entrada en servicio.
- **1904 — ANP01-FDD-18:** entrada en servicio.
- **1904 — ANP01-FDD-19:** entrada en servicio.
- **1904 — ANP01-FDD-20:** entrada en servicio.
- **1904 — ANP01-FDD-21:** botadura objetivo.
- **1904 — ANP01-FDD-22:** botadura objetivo.
- **1904 — ANP01-FDD-23:** botadura objetivo.
- **1904 — ANP01-FDD-24:** botadura objetivo.
- **1904 — ANP01-FTP-05:** primera carena mayor planificada.
- **1904 — ANP01-FTP-06:** primera carena mayor planificada.
- **1904 — ANP01-FTP-07:** primera carena mayor planificada.
- **1904 — ANP01-FTP-08:** primera carena mayor planificada.
- **1904 — ANP01-FTP-17:** entrada en servicio.
- **1904 — ANP01-FTP-18:** entrada en servicio.
- **1904 — ANP01-FTP-19:** entrada en servicio.
- **1904 — ANP01-FTP-20:** entrada en servicio.
- **1904 — ANP01-FTP-21:** botadura objetivo.
- **1904 — ANP01-FTP-22:** botadura objetivo.
- **1904 — ANP01-FTP-23:** botadura objetivo.
- **1904 — ANP01-FTP-24:** botadura objetivo.
- **1904 — ANP01-PEL-05:** primera carena mayor planificada.
- **1904 — ANP01-PEL-06:** primera carena mayor planificada.
- **1904 — ANP01-PEL-12:** botadura objetivo.
- **1904 — ANP01-REO-01:** primera carena mayor planificada.
- **1904 — ANP01-REO-03:** entrada en servicio.
- **1904 — ANP01-REO-04:** botadura objetivo.
- **1904 — ANP01-RME-05:** primera carena mayor planificada.
- **1904 — ANP01-RME-06:** primera carena mayor planificada.
- **1904 — ANP01-TAR-04:** entrada en servicio.
- **1904 — GCO-15:** primero de cuatro patrulleros de vapor a líquido; siguientes objetivos 1905, 1906 y 1907.
- **1905 — ANP01-FDD-09:** primera carena mayor planificada.
- **1905 — ANP01-FDD-10:** primera carena mayor planificada.
- **1905 — ANP01-FDD-11:** primera carena mayor planificada.
- **1905 — ANP01-FDD-12:** primera carena mayor planificada.
- **1905 — ANP01-FDD-21:** entrada en servicio.
- **1905 — ANP01-FDD-22:** entrada en servicio.
- **1905 — ANP01-FDD-23:** entrada en servicio.
- **1905 — ANP01-FDD-24:** entrada en servicio.
- **1905 — ANP01-FTP-09:** primera carena mayor planificada.
- **1905 — ANP01-FTP-10:** primera carena mayor planificada.
- **1905 — ANP01-FTP-11:** primera carena mayor planificada.
- **1905 — ANP01-FTP-12:** primera carena mayor planificada.
- **1905 — ANP01-FTP-21:** entrada en servicio.
- **1905 — ANP01-FTP-22:** entrada en servicio.
- **1905 — ANP01-FTP-23:** entrada en servicio.
- **1905 — ANP01-FTP-24:** entrada en servicio.
- **1905 — ANP01-GG75-06:** retiro del servicio naval activo.
- **1905 — ANP01-PEL-07:** primera carena mayor planificada.
- **1905 — ANP01-PEL-08:** primera carena mayor planificada.
- **1905 — ANP01-PEL-12:** entrada en servicio.
- **1905 — ANP01-REO-04:** entrada en servicio.
- **1905 — ANP01-RME-07:** primera carena mayor planificada.
- **1906 — ANP01-EAC-09:** primera carena mayor planificada.
- **1906 — ANP01-EAC-10:** primera carena mayor planificada.
- **1906 — ANP01-FDD-13:** primera carena mayor planificada.
- **1906 — ANP01-FDD-14:** primera carena mayor planificada.
- **1906 — ANP01-FDD-15:** primera carena mayor planificada.
- **1906 — ANP01-FDD-16:** primera carena mayor planificada.
- **1906 — ANP01-FTP-13:** primera carena mayor planificada.
- **1906 — ANP01-FTP-14:** primera carena mayor planificada.
- **1906 — ANP01-FTP-15:** primera carena mayor planificada.
- **1906 — ANP01-FTP-16:** primera carena mayor planificada.
- **1906 — ANP01-PEL-09:** primera carena mayor planificada.
- **1906 — ANP01-PEL-10:** primera carena mayor planificada.
- **1906 — ANP01-REO-02:** primera carena mayor planificada.
- **1906 — ANP01-RME-08:** primera carena mayor planificada.
- **1907 — ANP01-FDD-17:** primera carena mayor planificada.
- **1907 — ANP01-FDD-18:** primera carena mayor planificada.
- **1907 — ANP01-FDD-19:** primera carena mayor planificada.
- **1907 — ANP01-FDD-20:** primera carena mayor planificada.
- **1907 — ANP01-FTP-17:** primera carena mayor planificada.
- **1907 — ANP01-FTP-18:** primera carena mayor planificada.
- **1907 — ANP01-FTP-19:** primera carena mayor planificada.
- **1907 — ANP01-FTP-20:** primera carena mayor planificada.
- **1907 — ANP01-PEL-11:** primera carena mayor planificada.
- **1908 — ANP01-EAC-11:** primera carena mayor planificada.
- **1908 — ANP01-EAC-12:** primera carena mayor planificada.
- **1908 — ANP01-FDD-21:** primera carena mayor planificada.
- **1908 — ANP01-FDD-22:** primera carena mayor planificada.
- **1908 — ANP01-FDD-23:** primera carena mayor planificada.
- **1908 — ANP01-FDD-24:** primera carena mayor planificada.
- **1908 — ANP01-FTP-21:** primera carena mayor planificada.
- **1908 — ANP01-FTP-22:** primera carena mayor planificada.
- **1908 — ANP01-FTP-23:** primera carena mayor planificada.
- **1908 — ANP01-FTP-24:** primera carena mayor planificada.
- **1908 — ANP01-REO-03:** primera carena mayor planificada.
- **1908 — Desarrollo diésel:** evaluación 1908–1912 de serie de patrulla tras aceptación; no entrada garantizada.
- **1908 — Ámbito reconstruido:** 200 incorporados al cierre; cuatro Tarannon; no inventario nacional completo.
- **1909 — ANP01-PEL-12:** primera carena mayor planificada.
- **1909 — ANP01-REO-04:** primera carena mayor planificada.
- **1910 — ANP01-ANA-01:** paso a segunda línea.
- **1910 — ANP01-ANA-02:** paso a segunda línea.
- **1911 — ANP01-ANA-03:** paso a segunda línea.
- **1911 — ANP01-ANA-04:** paso a segunda línea.
- **1911 — ANP01-TAR-01:** paso a segunda línea.
- **1912 — ANP01-ANA-05:** paso a segunda línea.
- **1912 — ANP01-ANA-06:** paso a segunda línea.
- **1912 — ANP01-FDD-01:** paso a segunda línea.
- **1912 — ANP01-FDD-02:** paso a segunda línea.
- **1912 — ANP01-FDD-03:** paso a segunda línea.
- **1912 — ANP01-FDD-04:** paso a segunda línea.
- **1912 — ANP01-FTP-01:** paso a segunda línea.
- **1912 — ANP01-FTP-02:** paso a segunda línea.
- **1912 — ANP01-FTP-03:** paso a segunda línea.
- **1912 — ANP01-FTP-04:** paso a segunda línea.
- **1913 — ANP01-ANA-07:** paso a segunda línea.
- **1913 — ANP01-ANA-08:** paso a segunda línea.
- **1913 — ANP01-FDD-05:** paso a segunda línea.
- **1913 — ANP01-FDD-06:** paso a segunda línea.
- **1913 — ANP01-FDD-07:** paso a segunda línea.
- **1913 — ANP01-FDD-08:** paso a segunda línea.
- **1913 — ANP01-FTP-05:** paso a segunda línea.
- **1913 — ANP01-FTP-06:** paso a segunda línea.
- **1913 — ANP01-FTP-07:** paso a segunda línea.
- **1913 — ANP01-FTP-08:** paso a segunda línea.
- **1913 — ANP01-TAR-02:** paso a segunda línea.
- **1914 — ANP01-FDD-09:** paso a segunda línea.
- **1914 — ANP01-FDD-10:** paso a segunda línea.
- **1914 — ANP01-FDD-11:** paso a segunda línea.
- **1914 — ANP01-FDD-12:** paso a segunda línea.
- **1914 — ANP01-FTP-09:** paso a segunda línea.
- **1914 — ANP01-FTP-10:** paso a segunda línea.
- **1914 — ANP01-FTP-11:** paso a segunda línea.
- **1914 — ANP01-FTP-12:** paso a segunda línea.
- **1915 — ANP01-EAC-01:** paso a segunda línea.
- **1915 — ANP01-EAC-02:** paso a segunda línea.
- **1915 — ANP01-FDD-13:** paso a segunda línea.
- **1915 — ANP01-FDD-14:** paso a segunda línea.
- **1915 — ANP01-FDD-15:** paso a segunda línea.
- **1915 — ANP01-FDD-16:** paso a segunda línea.
- **1915 — ANP01-FTP-13:** paso a segunda línea.
- **1915 — ANP01-FTP-14:** paso a segunda línea.
- **1915 — ANP01-FTP-15:** paso a segunda línea.
- **1915 — ANP01-FTP-16:** paso a segunda línea.
- **1915 — ANP01-TAR-01:** retiro del servicio naval activo.
- **1915 — ANP01-TAR-03:** paso a segunda línea.
- **1916 — ANP01-ANA-01:** retiro del servicio naval activo.
- **1916 — ANP01-EAC-03:** paso a segunda línea.
- **1916 — ANP01-EAC-04:** paso a segunda línea.
- **1916 — ANP01-FDD-17:** paso a segunda línea.
- **1916 — ANP01-FDD-18:** paso a segunda línea.
- **1916 — ANP01-FDD-19:** paso a segunda línea.
- **1916 — ANP01-FDD-20:** paso a segunda línea.
- **1916 — ANP01-FTP-17:** paso a segunda línea.
- **1916 — ANP01-FTP-18:** paso a segunda línea.
- **1916 — ANP01-FTP-19:** paso a segunda línea.
- **1916 — ANP01-FTP-20:** paso a segunda línea.
- **1916 — ANP01-PEL-01:** paso a segunda línea.
- **1916 — ANP01-PEL-02:** paso a segunda línea.
- **1916 — ANP01-RME-01:** paso a segunda línea.
- **1916 — ANP01-RME-02:** paso a segunda línea.
- **1917 — ANP01-EAC-05:** paso a segunda línea.
- **1917 — ANP01-EAC-06:** paso a segunda línea.
- **1917 — ANP01-FDD-21:** paso a segunda línea.
- **1917 — ANP01-FDD-22:** paso a segunda línea.
- **1917 — ANP01-FDD-23:** paso a segunda línea.
- **1917 — ANP01-FDD-24:** paso a segunda línea.
- **1917 — ANP01-FTP-21:** paso a segunda línea.
- **1917 — ANP01-FTP-22:** paso a segunda línea.
- **1917 — ANP01-FTP-23:** paso a segunda línea.
- **1917 — ANP01-FTP-24:** paso a segunda línea.
- **1917 — ANP01-PEL-03:** paso a segunda línea.
- **1917 — ANP01-PEL-04:** paso a segunda línea.
- **1917 — ANP01-RME-03:** paso a segunda línea.
- **1917 — ANP01-RME-04:** paso a segunda línea.
- **1917 — ANP01-TAR-04:** paso a segunda línea.
- **1918 — ANP01-ANA-02:** retiro del servicio naval activo.
- **1918 — ANP01-EAC-07:** paso a segunda línea.
- **1918 — ANP01-EAC-08:** paso a segunda línea.
- **1918 — ANP01-PEL-05:** paso a segunda línea.
- **1918 — ANP01-PEL-06:** paso a segunda línea.
- **1918 — ANP01-REO-01:** paso a segunda línea.
- **1918 — ANP01-RME-05:** paso a segunda línea.
- **1918 — ANP01-RME-06:** paso a segunda línea.
- **1919 — ANP01-PEL-07:** paso a segunda línea.
- **1919 — ANP01-PEL-08:** paso a segunda línea.
- **1919 — ANP01-RME-07:** paso a segunda línea.
- **1920 — ANP01-ANA-03:** retiro del servicio naval activo.
- **1920 — ANP01-EAC-09:** paso a segunda línea.
- **1920 — ANP01-EAC-10:** paso a segunda línea.
- **1920 — ANP01-FDD-01:** retiro propuesto.
- **1920 — ANP01-FDD-02:** retiro propuesto.
- **1920 — ANP01-FDD-03:** retiro propuesto.
- **1920 — ANP01-FDD-04:** retiro propuesto.
- **1920 — ANP01-FTP-01:** retiro propuesto.
- **1920 — ANP01-FTP-02:** retiro propuesto.
- **1920 — ANP01-FTP-03:** retiro propuesto.
- **1920 — ANP01-FTP-04:** retiro propuesto.
- **1920 — ANP01-PEL-09:** paso a segunda línea.
- **1920 — ANP01-PEL-10:** paso a segunda línea.
- **1920 — ANP01-REO-02:** paso a segunda línea.
- **1920 — ANP01-RME-08:** paso a segunda línea.
- **1920 — ANP01-TAR-02:** retiro del servicio naval activo.
- **1921 — ANP01-ANA-04:** retiro del servicio naval activo.
- **1921 — ANP01-FDD-05:** retiro propuesto.
- **1921 — ANP01-FDD-06:** retiro propuesto.
- **1921 — ANP01-FDD-07:** retiro propuesto.
- **1921 — ANP01-FDD-08:** retiro propuesto.
- **1921 — ANP01-FTP-05:** retiro propuesto.
- **1921 — ANP01-FTP-06:** retiro propuesto.
- **1921 — ANP01-FTP-07:** retiro propuesto.
- **1921 — ANP01-FTP-08:** retiro propuesto.
- **1921 — ANP01-PEL-11:** paso a segunda línea.
- **1922 — ANP01-ANA-05:** retiro del servicio naval activo.
- **1922 — ANP01-EAC-11:** paso a segunda línea.
- **1922 — ANP01-EAC-12:** paso a segunda línea.
- **1922 — ANP01-FDD-09:** retiro propuesto.
- **1922 — ANP01-FDD-10:** retiro propuesto.
- **1922 — ANP01-FDD-11:** retiro propuesto.
- **1922 — ANP01-FDD-12:** retiro propuesto.
- **1922 — ANP01-FTP-09:** retiro propuesto.
- **1922 — ANP01-FTP-10:** retiro propuesto.
- **1922 — ANP01-FTP-11:** retiro propuesto.
- **1922 — ANP01-FTP-12:** retiro propuesto.
- **1922 — ANP01-REO-03:** paso a segunda línea.
- **1923 — ANP01-ANA-06:** retiro del servicio naval activo.
- **1923 — ANP01-EAC-01:** retiro propuesto.
- **1923 — ANP01-EAC-02:** retiro propuesto.
- **1923 — ANP01-FDD-13:** retiro propuesto.
- **1923 — ANP01-FDD-14:** retiro propuesto.
- **1923 — ANP01-FDD-15:** retiro propuesto.
- **1923 — ANP01-FDD-16:** retiro propuesto.
- **1923 — ANP01-FTP-13:** retiro propuesto.
- **1923 — ANP01-FTP-14:** retiro propuesto.
- **1923 — ANP01-FTP-15:** retiro propuesto.
- **1923 — ANP01-FTP-16:** retiro propuesto.
- **1923 — ANP01-PEL-01:** retiro propuesto.
- **1923 — ANP01-PEL-02:** retiro propuesto.
- **1923 — ANP01-PEL-12:** paso a segunda línea.
- **1923 — ANP01-REO-04:** paso a segunda línea.
- **1923 — ANP01-TAR-03:** retiro del servicio naval activo.
- **1924 — ANP01-ANA-07:** retiro del servicio naval activo.
- **1924 — ANP01-EAC-03:** retiro propuesto.
- **1924 — ANP01-EAC-04:** retiro propuesto.
- **1924 — ANP01-FDD-17:** retiro propuesto.
- **1924 — ANP01-FDD-18:** retiro propuesto.
- **1924 — ANP01-FDD-19:** retiro propuesto.
- **1924 — ANP01-FDD-20:** retiro propuesto.
- **1924 — ANP01-FTP-17:** retiro propuesto.
- **1924 — ANP01-FTP-18:** retiro propuesto.
- **1924 — ANP01-FTP-19:** retiro propuesto.
- **1924 — ANP01-FTP-20:** retiro propuesto.
- **1924 — ANP01-PEL-03:** retiro propuesto.
- **1924 — ANP01-PEL-04:** retiro propuesto.
- **1925 — ANP01-ANA-08:** retiro del servicio naval activo.
- **1925 — ANP01-EAC-05:** retiro propuesto.
- **1925 — ANP01-EAC-06:** retiro propuesto.
- **1925 — ANP01-FDD-21:** retiro propuesto.
- **1925 — ANP01-FDD-22:** retiro propuesto.
- **1925 — ANP01-FDD-23:** retiro propuesto.
- **1925 — ANP01-FDD-24:** retiro propuesto.
- **1925 — ANP01-FTP-21:** retiro propuesto.
- **1925 — ANP01-FTP-22:** retiro propuesto.
- **1925 — ANP01-FTP-23:** retiro propuesto.
- **1925 — ANP01-FTP-24:** retiro propuesto.
- **1925 — ANP01-PEL-05:** retiro propuesto.
- **1925 — ANP01-PEL-06:** retiro propuesto.
- **1925 — ANP01-REO-01:** retiro propuesto.
- **1925 — ANP01-RME-01:** retiro propuesto.
- **1925 — ANP01-RME-02:** retiro propuesto.
- **1925 — ANP01-TAR-04:** retiro del servicio naval activo.
- **1926 — ANP01-EAC-07:** retiro propuesto.
- **1926 — ANP01-EAC-08:** retiro propuesto.
- **1926 — ANP01-PEL-07:** retiro propuesto.
- **1926 — ANP01-PEL-08:** retiro propuesto.
- **1926 — ANP01-RME-03:** retiro propuesto.
- **1926 — ANP01-RME-04:** retiro propuesto.
- **1927 — ANP01-PEL-09:** retiro propuesto.
- **1927 — ANP01-PEL-10:** retiro propuesto.
- **1927 — ANP01-REO-02:** retiro propuesto.
- **1927 — ANP01-RME-05:** retiro propuesto.
- **1927 — ANP01-RME-06:** retiro propuesto.
- **1928 — ANP01-EAC-09:** retiro propuesto.
- **1928 — ANP01-EAC-10:** retiro propuesto.
- **1928 — ANP01-PEL-11:** retiro propuesto.
- **1928 — ANP01-RME-07:** retiro propuesto.
- **1929 — ANP01-REO-03:** retiro propuesto.
- **1929 — ANP01-RME-08:** retiro propuesto.
- **1930 — ANP01-EAC-11:** retiro propuesto.
- **1930 — ANP01-EAC-12:** retiro propuesto.
- **1930 — ANP01-PEL-12:** retiro propuesto.
- **1930 — ANP01-REO-04:** retiro propuesto.

Las demás altas, bajas y capacidades de auxiliares, patrulleros e industria se conservan en el registro integrado A104 y en los bloques específicos del antecedente v15; las previsiones no se convierten en entregas acreditadas.


### Calendario individual complementario del registro A104

Se incluyen fechas conocidas o adoptadas de auxiliares, patrulleros y supervivientes fuera de los 106 registros principales. Un alta antigua sin fecha individual se mantiene sin dato; 1900 como umbral de cálculo no se convierte en fecha de incorporación. Los retiros son horizontes narrativos donde así se indica en la fuente.

- **1884 — ANP01-CT75-01:** retiro; alcance y condición según registro A104.
- **1884 — ANP01-FT75-01:** retiro; alcance y condición según registro A104.
- **1885 — ANP01-CT75-02:** retiro; alcance y condición según registro A104.
- **1885 — ANP01-FT75-02:** retiro; alcance y condición según registro A104.
- **1885 — ANP01-HF75-01:** retiro; alcance y condición según registro A104.
- **1885 — ANP01-T87-01:** inicio de construcción; alcance y condición según registro A104.
- **1886 — ANP01-A75-ALM-05:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-COL-09:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-COL-10:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-HID-03:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-HOS-01:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-INS-01:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-PAT-01:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-REM-07:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-REM-08:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-REM-09:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-REP-03:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-TRA-01:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-A75-TRA-02:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-CT75-03:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-FT75-03:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-HF75-02:** retiro; alcance y condición según registro A104.
- **1886 — ANP01-T87-02:** inicio de construcción; alcance y condición según registro A104.
- **1887 — ANP01-A75-ALM-06:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-A75-COL-11:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-A75-REM-10:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-A75-REM-11:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-A75-REP-04:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-A75-TRA-03:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-CT75-04:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-FT75-04:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-HF75-03:** retiro; alcance y condición según registro A104.
- **1887 — ANP01-T87-01:** entrada en servicio; alcance y condición según registro A104.
- **1888 — ANP01-A75-ALM-07:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-COL-12:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-HID-04:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-HOS-02:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-INS-02:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-PAT-02:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-REM-12:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-REM-13:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-TRA-04:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-A75-TRA-05:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-CT75-05:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-FT75-05:** retiro; alcance y condición según registro A104.
- **1888 — ANP01-HF75-04:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-ALM-08:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-COL-13:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-REM-14:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-REM-15:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-REP-05:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-A75-TRA-06:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-CA75-01:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-CT75-06:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-FA75-01:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-FT75-06:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-HF75-05:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-RA75-01:** retiro; alcance y condición según registro A104.
- **1889 — ANP01-T87-02:** entrada en servicio; alcance y condición según registro A104.
- **1889 — VAE-REF-01:** entrada en servicio; alcance y condición según registro A104.
- **1890 — ANP01-A75-COL-14:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-INS-03:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-PAT-03:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-REM-16:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-REM-17:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-REP-06:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-TRA-07:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-A75-TRA-08:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-AUX-ALM-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-AUX-COL-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-AUX-HOS-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-AUX-REP-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-AUX-TRA-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-CA75-02:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-CT75-07:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-FA75-02:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-FT75-07:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-GCO-01:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-GCO-02:** inicio de construcción; alcance y condición según registro A104.
- **1890 — ANP01-HF75-06:** retiro; alcance y condición según registro A104.
- **1890 — ANP01-RA75-02:** retiro; alcance y condición según registro A104.
- **1890 — VAE-REF-02:** entrada en servicio; alcance y condición según registro A104.
- **1891 — ANP01-A75-ALM-09:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-COL-15:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-HID-05:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-HOS-03:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-REM-18:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-REM-19:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-A75-TRA-09:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-AU75-01:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-AUX-COL-02:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-AUX-HID-01:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-AUX-REM-01:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-AUX-REM-02:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-AUX-TRA-02:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-CA75-03:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-CT75-08:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-FA75-03:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-FT75-08:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-GCO-03:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-GFL-01:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-GFL-02:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-GPT-01:** inicio de construcción; alcance y condición según registro A104.
- **1891 — ANP01-HF75-07:** retiro; alcance y condición según registro A104.
- **1891 — ANP01-RA75-03:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-ALM-10:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-COL-16:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-INS-04:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-PAT-04:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-REM-20:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-REM-21:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-REP-07:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-TRA-10:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-A75-TRA-11:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-AU75-02:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-AUX-ALM-02:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-AUX-COL-03:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-AUX-HID-02:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-AUX-REM-03:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-AUX-REP-02:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-AUX-TRA-03:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-CA75-04:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-CT75-09:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-FA75-04:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-FT75-09:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-GCO-01:** entrada en servicio; alcance y condición según registro A104.
- **1892 — ANP01-GCO-02:** entrada en servicio; alcance y condición según registro A104.
- **1892 — ANP01-GCO-04:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-GCO-05:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-GFL-01:** entrada en servicio; alcance y condición según registro A104.
- **1892 — ANP01-GFL-02:** entrada en servicio; alcance y condición según registro A104.
- **1892 — ANP01-GFL-03:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-GPT-01:** entrada en servicio; alcance y condición según registro A104.
- **1892 — ANP01-GPT-02:** inicio de construcción; alcance y condición según registro A104.
- **1892 — ANP01-HF75-08:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-HO75-01:** retiro; alcance y condición según registro A104.
- **1892 — ANP01-RA75-04:** retiro; alcance y condición según registro A104.
- **1892 — VAE-REF-03:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-A75-ALM-11:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-A75-COL-17:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-A75-REM-22:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-A75-REM-23:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-A75-REP-08:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-A75-TRA-12:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-AL75-01:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-AU75-03:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-AUX-ALM-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-COL-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-COL-04:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-AUX-HID-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-HOS-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-HOS-02:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-AUX-REM-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-REM-02:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-REM-04:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-AUX-REP-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-TRA-01:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-AUX-TRA-04:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-CA75-05:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-CT75-10:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-FA75-05:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-FT75-10:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-GCO-03:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-GCO-06:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-GFL-03:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-GFL-04:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-GPT-02:** entrada en servicio; alcance y condición según registro A104.
- **1893 — ANP01-GPT-03:** inicio de construcción; alcance y condición según registro A104.
- **1893 — ANP01-HF75-09:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-HO75-02:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-RA75-05:** retiro; alcance y condición según registro A104.
- **1893 — ANP01-SY75-01:** retiro; alcance y condición según registro A104.
- **1893 — VAE-REF-04:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-A75-ALM-12:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-COL-18:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-HID-06:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-HOS-04:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-INS-05:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-PAT-05:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-REM-24:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-REM-25:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-TRA-13:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-A75-TRA-14:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-AL75-02:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-AU75-04:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-AUX-ALM-03:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-COL-02:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-AUX-COL-05:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-HID-02:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-AUX-HID-03:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-REM-03:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-AUX-REM-05:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-REM-06:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-REP-03:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-AUX-TRA-02:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-AUX-TRA-05:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-CA75-06:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-CT75-11:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-FA75-06:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-FT75-11:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-GCO-04:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-GCO-05:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-GCO-07:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-GFL-04:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-GFL-05:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-GPT-03:** entrada en servicio; alcance y condición según registro A104.
- **1894 — ANP01-GPT-04:** inicio de construcción; alcance y condición según registro A104.
- **1894 — ANP01-HF75-10:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-HO75-03:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-P75-01:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-RA75-06:** retiro; alcance y condición según registro A104.
- **1894 — ANP01-SY75-02:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-A75-COL-19:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-A75-REM-26:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-A75-REM-27:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-A75-REP-09:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-A75-TRA-15:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-AL75-03:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-AU75-05:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-AUX-ALM-02:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-AUX-COL-03:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-AUX-COL-06:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-AUX-REM-04:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-AUX-REM-07:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-AUX-REP-02:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-AUX-TRA-03:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-AUX-TRA-06:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-CA75-07:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-CT75-12:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-EPR-01:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-FA75-07:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-FT75-12:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-GCO-06:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-GCO-08:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-GCO-09:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-GFL-05:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-GFL-06:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-GPT-04:** entrada en servicio; alcance y condición según registro A104.
- **1895 — ANP01-GPT-05:** inicio de construcción; alcance y condición según registro A104.
- **1895 — ANP01-HF75-11:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-HO75-04:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-P75-02:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-RA75-07:** retiro; alcance y condición según registro A104.
- **1895 — ANP01-SY75-03:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-ALM-13:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-COL-20:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-INS-06:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-PAT-06:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-REM-28:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-REM-29:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-REP-10:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-TRA-16:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-A75-TRA-17:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-AL75-04:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-AU75-06:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-AUX-COL-04:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-COL-07:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-AUX-HID-03:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-HID-04:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-AUX-HOS-02:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-REM-05:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-REM-06:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-REM-08:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-AUX-TRA-04:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-AUX-TRA-07:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-CA75-08:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-FA75-08:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-GCO-07:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-GCO-10:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-GFL-06:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-GFL-07:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-GPT-05:** entrada en servicio; alcance y condición según registro A104.
- **1896 — ANP01-GPT-06:** inicio de construcción; alcance y condición según registro A104.
- **1896 — ANP01-HF75-12:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-HO75-05:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-P75-03:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-R75-01:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-RA75-08:** retiro; alcance y condición según registro A104.
- **1896 — ANP01-SY75-04:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-ALM-14:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-COL-21:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-HID-07:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-HOS-05:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-REM-30:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-REM-31:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-A75-TRA-18:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-AL75-05:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-AU75-07:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-AUX-ALM-03:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-AUX-ALM-04:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-AUX-COL-05:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-AUX-COL-08:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-AUX-HOS-03:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-AUX-REM-07:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-AUX-REM-09:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-AUX-REP-03:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-AUX-REP-04:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-AUX-TRA-05:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-AUX-TRA-08:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-CA75-09:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-EPR-02:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-FA75-09:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-GCO-08:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-GCO-09:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-GCO-11:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-GFL-07:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-GFL-08:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-GPT-06:** entrada en servicio; alcance y condición según registro A104.
- **1897 — ANP01-GPT-07:** inicio de construcción; alcance y condición según registro A104.
- **1897 — ANP01-HF75-13:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-HO75-06:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-MT75-01:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-P75-04:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-R75-02:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-RA75-09:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-SY75-05:** retiro; alcance y condición según registro A104.
- **1897 — ANP01-TR75-01:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-ALM-15:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-COL-22:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-INS-07:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-PAT-07:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-REM-32:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-REM-33:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-REP-11:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-TRA-19:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-A75-TRA-20:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-AL75-06:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-AU75-08:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-AUX-COL-06:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-AUX-HID-04:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-AUX-HID-05:** inicio de construcción; alcance y condición según registro A104.
- **1898 — ANP01-AUX-REM-08:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-AUX-REM-10:** inicio de construcción; alcance y condición según registro A104.
- **1898 — ANP01-AUX-TRA-06:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-CA75-10:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-FA75-10:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-GCO-10:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-GCO-12:** inicio de construcción; alcance y condición según registro A104.
- **1898 — ANP01-GFL-08:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-GFL-09:** inicio de construcción; alcance y condición según registro A104.
- **1898 — ANP01-GPT-07:** entrada en servicio; alcance y condición según registro A104.
- **1898 — ANP01-HF75-14:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-HO75-07:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-MT75-02:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-P75-05:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-R75-03:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-RA75-10:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-SY75-06:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-T87-01:** retiro; alcance y condición según registro A104.
- **1898 — ANP01-TR75-02:** retiro; alcance y condición según registro A104.
- **1898 — C75-REF-01:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-A75-COL-23:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-A75-REM-34:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-A75-REM-35:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-A75-TRA-21:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-AL75-07:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-AUX-ALM-05:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-AUX-COL-07:** entrada en servicio; alcance y condición según registro A104.
- **1899 — ANP01-AUX-COL-09:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-AUX-REM-09:** entrada en servicio; alcance y condición según registro A104.
- **1899 — ANP01-AUX-REP-05:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-AUX-TRA-07:** entrada en servicio; alcance y condición según registro A104.
- **1899 — ANP01-AUX-TRA-09:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-CA75-11:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-EPR-03:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-FA75-11:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-GCO-11:** entrada en servicio; alcance y condición según registro A104.
- **1899 — ANP01-GFL-09:** entrada en servicio; alcance y condición según registro A104.
- **1899 — ANP01-GFL-10:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-GPT-08:** inicio de construcción; alcance y condición según registro A104.
- **1899 — ANP01-HF75-15:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-HO75-08:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-MT75-03:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-P75-06:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-R75-04:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-RA75-11:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-SY75-07:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-T87-02:** retiro; alcance y condición según registro A104.
- **1899 — ANP01-TR75-03:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-ALM-16:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-COL-24:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-HID-08:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-HOS-06:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-INS-08:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-PAT-08:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-REM-36:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-REP-12:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-A75-TRA-22:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-AL75-08:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-AUX-ALM-04:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-COL-08:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-HID-05:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-HOS-03:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-REM-10:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-REM-11:** inicio de construcción; alcance y condición según registro A104.
- **1900 — ANP01-AUX-REP-04:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-AUX-TRA-08:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-CA75-12:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-EPR-04:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-FA75-12:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-GCO-12:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-GCO-13:** inicio de construcción; alcance y condición según registro A104.
- **1900 — ANP01-GFL-10:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-GPT-08:** entrada en servicio; alcance y condición según registro A104.
- **1900 — ANP01-HF75-16:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-HO75-09:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-MT75-04:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-P75-07:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-R75-05:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-RA75-12:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-SY75-08:** retiro; alcance y condición según registro A104.
- **1900 — ANP01-TR75-04:** retiro; alcance y condición según registro A104.
- **1900 — C75-REF-02:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-A75-ALM-01:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-A75-COL-01:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-A75-HID-01:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-A75-REM-01:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-A75-REP-01:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-AUX-COL-10:** inicio de construcción; alcance y condición según registro A104.
- **1901 — ANP01-AUX-TRA-10:** inicio de construcción; alcance y condición según registro A104.
- **1901 — ANP01-GCO-14:** inicio de construcción; alcance y condición según registro A104.
- **1901 — ANP01-GFL-11:** inicio de construcción; alcance y condición según registro A104.
- **1901 — ANP01-GPT-09:** inicio de construcción; alcance y condición según registro A104.
- **1901 — ANP01-HO75-10:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-P75-08:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-R75-06:** retiro; alcance y condición según registro A104.
- **1901 — ANP01-TR75-05:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-A75-ALM-02:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-A75-COL-02:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-A75-HID-02:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-A75-REM-02:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-A75-REP-02:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-AUX-ALM-05:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-AUX-COL-09:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-AUX-REM-11:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-AUX-REP-05:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-AUX-TRA-09:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-EPR-05:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-GCO-13:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-GCO-15:** inicio de construcción; alcance y condición según registro A104.
- **1902 — ANP01-GFL-11:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-GFL-12:** inicio de construcción; alcance y condición según registro A104.
- **1902 — ANP01-GPT-09:** entrada en servicio; alcance y condición según registro A104.
- **1902 — ANP01-HO75-11:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-P75-09:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-R75-07:** retiro; alcance y condición según registro A104.
- **1902 — ANP01-TR75-06:** retiro; alcance y condición según registro A104.
- **1902 — C75-REF-03:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-A75-ALM-03:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-A75-COL-03:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-A75-REM-03:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-AUX-HOS-04:** inicio de construcción; alcance y condición según registro A104.
- **1903 — ANP01-GCO-14:** entrada en servicio; alcance y condición según registro A104.
- **1903 — ANP01-GCO-16:** inicio de construcción; alcance y condición según registro A104.
- **1903 — ANP01-GFL-12:** entrada en servicio; alcance y condición según registro A104.
- **1903 — ANP01-GFL-13:** inicio de construcción; alcance y condición según registro A104.
- **1903 — ANP01-GPT-10:** inicio de construcción; alcance y condición según registro A104.
- **1903 — ANP01-HO75-12:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-P75-10:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-R75-08:** retiro; alcance y condición según registro A104.
- **1903 — ANP01-TR75-07:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-A75-ALM-04:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-A75-COL-04:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-A75-REM-04:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-AUX-COL-10:** entrada en servicio; alcance y condición según registro A104.
- **1904 — ANP01-AUX-COL-11:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-AUX-TRA-10:** entrada en servicio; alcance y condición según registro A104.
- **1904 — ANP01-AUX-TRA-11:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-EPR-06:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-GCO-15:** entrada en servicio; alcance y condición según registro A104.
- **1904 — ANP01-GCO-17:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-GFL-13:** entrada en servicio; alcance y condición según registro A104.
- **1904 — ANP01-GFL-14:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-GPT-10:** entrada en servicio; alcance y condición según registro A104.
- **1904 — ANP01-HO75-13:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-LOG-COL-01:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-LOG-COL-02:** inicio de construcción; alcance y condición según registro A104.
- **1904 — ANP01-P75-11:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-R75-09:** retiro; alcance y condición según registro A104.
- **1904 — ANP01-TR75-08:** retiro; alcance y condición según registro A104.
- **1904 — C75-REF-04:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-A75-COL-05:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-A75-REM-05:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-GCO-16:** entrada en servicio; alcance y condición según registro A104.
- **1905 — ANP01-GCO-18:** inicio de construcción; alcance y condición según registro A104.
- **1905 — ANP01-GFL-14:** entrada en servicio; alcance y condición según registro A104.
- **1905 — ANP01-HO75-14:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-LOG-COL-03:** inicio de construcción; alcance y condición según registro A104.
- **1905 — ANP01-LOG-COL-04:** inicio de construcción; alcance y condición según registro A104.
- **1905 — ANP01-P75-12:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-R75-10:** retiro; alcance y condición según registro A104.
- **1905 — ANP01-TR75-09:** retiro; alcance y condición según registro A104.
- **1906 — ANP01-A75-COL-06:** retiro; alcance y condición según registro A104.
- **1906 — ANP01-A75-REM-06:** retiro; alcance y condición según registro A104.
- **1906 — ANP01-AUX-HOS-04:** entrada en servicio; alcance y condición según registro A104.
- **1906 — ANP01-EPR-07:** retiro; alcance y condición según registro A104.
- **1906 — ANP01-GCO-17:** entrada en servicio; alcance y condición según registro A104.
- **1906 — ANP01-TR75-10:** retiro; alcance y condición según registro A104.
- **1906 — C75-REF-05:** retiro; alcance y condición según registro A104.
- **1907 — ANP01-A75-COL-07:** retiro; alcance y condición según registro A104.
- **1907 — ANP01-AUX-ALM-06:** inicio de construcción; alcance y condición según registro A104.
- **1907 — ANP01-AUX-COL-11:** entrada en servicio; alcance y condición según registro A104.
- **1907 — ANP01-AUX-COL-12:** inicio de construcción; alcance y condición según registro A104.
- **1907 — ANP01-AUX-REP-06:** inicio de construcción; alcance y condición según registro A104.
- **1907 — ANP01-AUX-TRA-11:** entrada en servicio; alcance y condición según registro A104.
- **1907 — ANP01-AUX-TRA-12:** inicio de construcción; alcance y condición según registro A104.
- **1907 — ANP01-GCO-18:** entrada en servicio; alcance y condición según registro A104.
- **1907 — ANP01-LOG-COL-01:** entrada en servicio; alcance y condición según registro A104.
- **1907 — ANP01-LOG-COL-02:** entrada en servicio; alcance y condición según registro A104.
- **1907 — ANP01-TR75-11:** retiro; alcance y condición según registro A104.
- **1907 — VAE-REF-01:** retiro; alcance y condición según registro A104.
- **1908 — ANP01-AUX-HID-06:** inicio de construcción; alcance y condición según registro A104.
- **1908 — ANP01-AUX-REM-12:** inicio de construcción; alcance y condición según registro A104.
- **1908 — ANP01-EPR-08:** retiro; alcance y condición según registro A104.
- **1908 — ANP01-LOG-COL-03:** entrada en servicio; alcance y condición según registro A104.
- **1908 — ANP01-LOG-COL-04:** entrada en servicio; alcance y condición según registro A104.
- **1908 — ANP01-TR75-12:** retiro; alcance y condición según registro A104.
- **1908 — C75-REF-06:** retiro; alcance y condición según registro A104.
- **1909 — ANP01-TR75-13:** retiro; alcance y condición según registro A104.
- **1909 — VAE-REF-02:** retiro; alcance y condición según registro A104.
- **1910 — ANP01-AUX-ALM-06:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-AUX-COL-12:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-AUX-HID-06:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-AUX-REM-12:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-AUX-REP-06:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-AUX-TRA-12:** entrada en servicio; alcance y condición según registro A104.
- **1910 — ANP01-TR75-14:** retiro; alcance y condición según registro A104.
- **1911 — VAE-REF-03:** retiro; alcance y condición según registro A104.
- **1913 — VAE-REF-04:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-ALM-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-COL-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-HID-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-HOS-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-REM-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-REM-02:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-REP-01:** retiro; alcance y condición según registro A104.
- **1918 — ANP01-AUX-TRA-01:** retiro; alcance y condición según registro A104.
- **1919 — ANP01-AUX-COL-02:** retiro; alcance y condición según registro A104.
- **1919 — ANP01-AUX-HID-02:** retiro; alcance y condición según registro A104.
- **1919 — ANP01-AUX-REM-03:** retiro; alcance y condición según registro A104.
- **1919 — ANP01-AUX-TRA-02:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-A75-COL-08:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-AUX-ALM-02:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-AUX-COL-03:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-AUX-REM-04:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-AUX-REP-02:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-AUX-TRA-03:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-GCO-01:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-GCO-02:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-GFL-01:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-GFL-02:** retiro; alcance y condición según registro A104.
- **1920 — ANP01-GPT-01:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-COL-04:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-HID-03:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-HOS-02:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-REM-05:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-REM-06:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-AUX-TRA-04:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-GCO-03:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-GFL-03:** retiro; alcance y condición según registro A104.
- **1921 — ANP01-GPT-02:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-AUX-ALM-03:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-AUX-COL-05:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-AUX-REM-07:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-AUX-REP-03:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-AUX-TRA-05:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-GCO-04:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-GCO-05:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-GFL-04:** retiro; alcance y condición según registro A104.
- **1922 — ANP01-GPT-03:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-AUX-COL-06:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-AUX-HID-04:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-AUX-REM-08:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-AUX-TRA-06:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-GCO-06:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-GFL-05:** retiro; alcance y condición según registro A104.
- **1923 — ANP01-GPT-04:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-AUX-COL-07:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-AUX-REM-09:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-AUX-TRA-07:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-GCO-07:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-GFL-06:** retiro; alcance y condición según registro A104.
- **1924 — ANP01-GPT-05:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-ALM-04:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-COL-08:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-HID-05:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-HOS-03:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-REM-10:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-REP-04:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-AUX-TRA-08:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-GCO-08:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-GCO-09:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-GFL-07:** retiro; alcance y condición según registro A104.
- **1925 — ANP01-GPT-06:** retiro; alcance y condición según registro A104.
- **1926 — ANP01-GCO-10:** retiro; alcance y condición según registro A104.
- **1926 — ANP01-GFL-08:** retiro; alcance y condición según registro A104.
- **1926 — ANP01-GPT-07:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-AUX-ALM-05:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-AUX-COL-09:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-AUX-REM-11:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-AUX-REP-05:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-AUX-TRA-09:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-GCO-11:** retiro; alcance y condición según registro A104.
- **1927 — ANP01-GFL-09:** retiro; alcance y condición según registro A104.
- **1928 — ANP01-GCO-12:** retiro; alcance y condición según registro A104.
- **1928 — ANP01-GFL-10:** retiro; alcance y condición según registro A104.
- **1928 — ANP01-GPT-08:** retiro; alcance y condición según registro A104.
- **1929 — ANP01-AUX-COL-10:** retiro; alcance y condición según registro A104.
- **1929 — ANP01-AUX-TRA-10:** retiro; alcance y condición según registro A104.
- **1930 — ANP01-GCO-13:** retiro; alcance y condición según registro A104.
- **1930 — ANP01-GFL-11:** retiro; alcance y condición según registro A104.
- **1930 — ANP01-GPT-09:** retiro; alcance y condición según registro A104.
- **1931 — ANP01-AUX-HOS-04:** retiro; alcance y condición según registro A104.
- **1931 — ANP01-GCO-14:** retiro; alcance y condición según registro A104.
- **1931 — ANP01-GFL-12:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-AUX-COL-11:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-AUX-TRA-11:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-GCO-15:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-GFL-13:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-GPT-10:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-LOG-COL-01:** retiro; alcance y condición según registro A104.
- **1932 — ANP01-LOG-COL-02:** retiro; alcance y condición según registro A104.
- **1933 — ANP01-GCO-16:** retiro; alcance y condición según registro A104.
- **1933 — ANP01-GFL-14:** retiro; alcance y condición según registro A104.
- **1933 — ANP01-LOG-COL-03:** retiro; alcance y condición según registro A104.
- **1933 — ANP01-LOG-COL-04:** retiro; alcance y condición según registro A104.
- **1934 — ANP01-GCO-17:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-ALM-06:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-COL-12:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-HID-06:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-REM-12:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-REP-06:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-AUX-TRA-12:** retiro; alcance y condición según registro A104.
- **1935 — ANP01-GCO-18:** retiro; alcance y condición según registro A104.


## Integración A105 Corte naval y organización de 1891

[[00_Canon/Integraciones V16/Acumulativa A105 Armada de Valinor en 1891|Resolución A105 Armada de 1891]]

- **1887:** Se conserva el alta del demostrador de turbina T87-01; no pertenece a los 48 Forlond posteriores.
- **1889:** Se conservan las incorporaciones de Vëantur 01 y T87-02 y la obra iniciada de Tarannon 01.
- **1890:** Se conserva la incorporación de Vëantur 02 y el paso a segunda línea de los Círdan y Gil-galad correspondientes.
- **1891:** Al cierre hay 18 acorazados incorporados: 2 Vëantur, 6 Círdan históricos, 4 Eärendil pesados y 6 Gil-galad iniciales. Seis posiciones de primera línea: dos Vëantur y cuatro antiguos transitorios; doce de segunda línea. Disponibilidad efectiva sin dato.
- **1891:** En construcción aparte: Vëantur 03, Vëantur 04 y Tarannon 01. Los ocho Anárion están autorizados y comienzan obras desde 1892. No son incorporados de 1891.
- **1891:** Se adopta la organización en escuadra de concentración, divisiones de cruceros, fuerzas territoriales y servicio logístico y de arsenales. No se fijan destinos ni mandos nominales por casco.
- **1891:** La reconstrucción provisional del ámbito comprende 239 identidades: 18 acorazados con presencia definida, 2 demostradores con alta fechada, 115 candidatos de crucero y servicio territorial y 104 auxiliares candidatos. No se adopta censo nacional ni se inventan altas antiguas.
- **1891:** Se conserva el carbón como combustible principal, modernización por expediente y construcción escalonada. No se anticipan la red de diques posterior, CSNR, patrulleros de líquido, diésel, radar ni ASW madura.
- **1892:** Se conserva el servicio de Vëantur 03 y el final de primera línea transitoria de Círdan 05–06 y Gil-galad 05–06; comienzan Anárion y Tarannon 02 según su calendario.
- **1893:** Se conserva el servicio de Vëantur 04 y la conclusión de su serie de cuatro.
- **1894:** Se conserva el primer servicio de Tarannon; la Armada de 1891 no lo incluye como incorporado.


## Integración A106 Renovación naval y desarrollo industrial de 1891 a 2026

[[00_Canon/Integraciones V16/Acumulativa A106 Armada e industria naval 1891-2026|Resolución A106 Armada e industria naval]]

Prevalece esta conciliación sobre entradas anteriores incompatibles; originales y perímetros se conservan. Ningún corte expresa disponibilidad simultánea.

- **1891:** Se conserva íntegro el corte A105; no se suman los tres capitales en obra.
- **1900–1905:** Ciryatan identifica los cuatro exploradores ya comprendidos en las veinticuatro unidades; conservar calendarios A104.
- **1914:** Programas parcialmente incorporados; separar fuerzas combatientes, patrulla y apoyo.
- **1920:** Objetivo auxiliar 110; nodriza experimental es conversión dentro del transporte, no un casco adicional.
- **1928:** Nargothrond experimental procede de conversión civil distinta de la nodriza.
- **1930:** Programas Eregion, Osgiliath, Nimras y Elenna II parcialmente incorporados; no confundir programa con presencia.
- **1940:** Inicio aceptado del programa Aulë I, que enmienda el antecedente de 1943.
- **1945:** Corte narrativo 325: incluye 51 supervivientes, además del ámbito parcial de 274. Catorce Mithlond I ya incorporados; estreno exacto pendiente.
- **1948:** Retiro objetivo de Nargothrond.
- **1952:** Finalización objetivo de los ocho Aulë I y retiro escalonado de los capitales pesados retenidos.
- **1955:** Arranque de la serie moderna Círdan según ficha específica; separado del acorazado homónimo de 1875.
- **1959:** OceanNet operativa; no implica integración naval digital completa.
- **1960:** Corte narrativo 431, todo submarino contado es convencional; nueve portaaviones convencionales. Ocho Mithlond II y seis Nimrodel II incorporados; estrenos exactos pendientes.
- **1965:** Inicio de construcción del Aulë II nuclear según precedencia aceptada; no se coloca en servicio en 1960.
- **1969:** Consolidación OceanNet; integración gradual por equipos y plataformas.
- **1970 / 1975:** Primeras incorporaciones de los dos Aulë II nucleares.
- **1970–1979:** Retiro objetivo escalonado de Aulë I.
- **1980:** Conservar 427 y categorías vigentes; los doce Gil-galad familiares se reparten diez II y dos III.
- **1983:** Hito de protocolo OceanNet conservado; sin instalarlo retroactivamente en toda la flota.
- **1995–2000:** Veinte Círdan IV incorporados al corte 2000 dentro de un total de 62 fragatas y escoltas.
- **2000:** Corte narrativo 490; subtotal AM1 464 más seis cruceros y veinte lanchas.
- **2026:** Se conservan 615 plataformas: 595 tripuladas y veinte no tripuladas. A106 adopta el enlace de los bloques 50 a 54 sin modificar cantidades ni categorías.
- **2018, 2020, 2023 y 2026:** Incorporaciones narrativas escalonadas de los cuatro Telperion; nombres y matrículas individuales pendientes.
- **2022:** Comienzan obras Voronwë; la recepción inicial se mantiene desde 2026 y el relevo hasta 2033.
- **2025–2026:** La fuerza ligera embarcada de 2026 comprende dos Varda II y dos III dentro de cuatro ligeros; no se trasladan esas configuraciones a Varda I.
- **2026:** Los tres portaaviones convencionales se distribuyen en una posición Anárion II, una Elwing I y una Aldarion I.
- **2026:** Los 24 Gil-galad se reparten doce IV y doce V; ninguna incorporación VI antes de 2027. Se conservan 64 Círdan/Voronwë sin reparto nominal inferido.
- **2026:** Se adoptan Gondolin para dieciocho escoltas especializados ASW y Doriath para doce AAW, dentro de treinta; Malaca identifica la familia de setenta patrulleros rápidos.
- **2026:** Se retira antes o al corte la categoría independiente de lanchas misilísticas y las líneas antiguas fijadas en 50–53, sin sumarlas a sus sucesores. Las bajas concretas por casco siguen pendientes.
- **2026:** La hipótesis 449 disponibles permanece simulación, sin convertirla en estado observado.
- **2027–2033:** Horizontes futuros: primeras incorporaciones Gil-galad VI desde 2027 y continuidad del relevo Voronwë; no se suman a la fuerza operativa de 2026.


## Integración territorial A107 CIL01 y CIL02

Adopción narrativa del 13 de noviembre de 2026. Las ventanas se conservan sin convertirlas en años exactos; obras, capacidades y censos siguen pendientes. [[00_Canon/Integraciones V16/Resolución A107 CIL01 y CIL02|Resolución A107]]

- **Siglos III–I a. C. — CIL01:** Agentes y operaciones estacionales en la red cilicia; sin provincia ni soberanía.
- **Siglos I–II d. C. — CIL01:** Residencia y concesión portuaria en Cilicia; primer año exacto pendiente.
- **610–650 — CIL01:** Crisis, cierres y renegociaciones cilicias; no nueva Guerra del Orontes adoptada.
- **Hacia 1520 — CIL01:** Confirmación ficticia de derechos y residencia bajo autoridad otomana competente.
- **Después de 1574 — CIL01:** Marco otomano comercial y marítimo delimitado; año exacto y texto pendientes.
- **1600–1630 — Australia Occidental:** Reconocimientos desde la red de Malaca.
- **1630–1650 — Australia Occidental:** Primeros establecimientos y acuerdos locales; no control total del interior.
- **1648 — Australia Occidental:** Carta narrativa de establecimientos occidentales.
- **1650–1750 — Australia Occidental:** Crisis epidémicas regionales y abusos; sin porcentaje uniforme ni mestizaje como causa.
- **1736 — Australia Occidental:** Ordenanza de socorro y visitas; aplicación y resultados no presuntos.
- **1784 — Australia Occidental:** Consejo de distritos occidentales.
- **1832 — Australia Occidental:** Acuerdo anglo-valinari narrativo; delimitación fina y documentación pendientes.
- **1868 — Australia Occidental:** Carta de autonomía y gobierno responsable.
- **1912 — Australia Occidental:** Revisión electoral local; no estreno universal de igualdad.
- **1958 — Australia Occidental:** Acuerdo fiscal y de recursos; porcentajes sin fijar.
- **1996 — Australia Occidental:** Ley de archivos y reparación; ciudadanía común.
- **1924 — CIL01:** Normalización comercial y patrimonial bajo soberanía turca.
- **1955 — CIL01:** Convenio portuario y agroindustrial ficticio con Turquía.
- **Desde 1985 — CIL01:** Diversificación logística y formativa; no recepción de plantas por inferencia.
- **1956 — Egipto y Túnez:** Relaciones soberanas; orientación valinoriana de respeto a soberanía egipcia y continuidad negociada.
- **1967–1975 — Egipto:** Cierre de Suez conservado como límite logístico; Pelargir no reabre el canal.
- **900–1100 — CIL02:** Crecimiento de núcleos caribeños y presencia localizada en Florida y golfo.
- **1100–1250 — CIL02:** Consolidación de puertos y corredores interoceánicos; presencia pacífica sostenible.
- **1150–1350 — California:** Reconocimientos y primeros establecimientos; no provincia completa desde el primer viaje.
- **1250–1400 — CIL02:** Integración política creciente de Caribe y Centroamérica, con control desigual.
- **Hacia 1400 — CIL02:** Núcleo central y caribeño consolidado; CIL02 interior todavía en formación.
- **1400–1700 — CIL02:** Ampliación de jurisdicciones, acuerdos y conflictos con poderes locales y exteriores.
- **1700–1850 — CIL02:** Regularización posterior de once provincias y coordinación continental.
- **1850–1950 — CIL02:** Ferrocarriles, industria y redes articulan las provincias; no puertos medievales convertidos automáticamente en metrópolis.
- **2026 — A107:** Pertenencia del Caribe, Centroamérica y once provincias al Reino; Australia Occidental novena unidad externa. Cabo Verde sigue condicionado. Total ampliado sin cuantificar.
