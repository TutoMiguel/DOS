---
tipo: puerto asociado
estado_canonico: puerto asociado con perímetro pendiente
canon: V17.9 A107
---
# Pelargir (Alejandría)

Puerto asociado de Pelargir/Alejandría bajo soberanía egipcia. Sede administrativa canónica: Pelargir del Norte. Perímetro de instalaciones pendiente; no todo Egipto. A107 corrige el rótulo antiguo de protectorado; la ruta de archivo se conserva para no romper enlaces.

## Datos territoriales normalizados

- **Población:** 
No fijada de forma explícita en esta ficha.
- **Economía y función:** 
No fijada de forma explícita en esta ficha; consultar ECON-03 y el Canon V16.
- **Dependencia administrativa:** 
No fijada de forma explícita en esta ficha.
- **Criterio editorial:** se conservan los datos canónicos existentes; los campos no fijados quedan expresamente pendientes y no se completan por inferencia.

## Referencias relacionadas

- [[02_Geografia/Índice Geográfico|Índice Geográfico]]
- [[00_Indice Territorial/Índice Territorial V16|Índice Territorial V16]]
- [[04_Mapa Politico/Índice Político|Índice Político]]
- [[08_Economia/ECON-03 Resumen|ECON-03 Resumen]]
- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[00_Canon/Registro de Cambios|Registro de Cambios]]
- [[00_Canon/Regla Primordial de Nomenclatura Urbana|Regla Primordial de Nomenclatura Urbana]]
- [[00_Indice Territorial/Índice Jerárquico Gwaith Valinor|Índice Jerárquico Gwaith Valinor]]
- [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]
- [[01_Cronologia/Red de Protectorados|Red de Protectorados]]
- [[02_Geografia/Beleg Valinor|Beleg Valinor]]
- [[02_Geografia/Entidades Politicas/Índice de Entidades Políticas|Índice de Entidades Políticas]]
- [[02_Geografia/Red Oriental de Enclaves y Protectorados|Red Oriental de Enclaves y Protectorados]]
- [[02_Geografia/Regiones/Calenardhon Austral|Calenardhon Austral]]
- [[04_Mapa Politico/Capitales/Capitales del Canon V16|Capitales del Canon V16]]
- [[04_Mapa Politico/Capitales/Pelargir Austral|Pelargir Austral]]
- [[04_Mapa Politico/Capitales/Pelargir del Norte|Pelargir del Norte]]
- [[04_Mapa Politico/Ciudades/Alejandría|Alejandría]]
- [[04_Mapa Politico/Protectorados/Índice de Protectorados|Índice de Protectorados]]
- [[09_Politica/Auditoría de Prompts Visuales de las Casas|Auditoría de Prompts Visuales de las Casas]]
- [[09_Politica/Casas Mayores/Casa Pelargir|Casa Pelargir]]
- [[09_Politica/Casas Mayores/Índice de Casas Mayores|Índice de Casas Mayores]]
- [[09_Politica/Casas Vasallas/Casa Galdor|Casa Galdor]]
- [[09_Politica/Casas Vasallas/Índice de Casas Vasallas|Índice de Casas Vasallas]]
- [[09_Politica/Distribución capilar de las nueve Casas Mayores pendientes|Distribución capilar de las nueve Casas Mayores pendientes]]
- [[09_Politica/Índice de Casas Nobles|Índice de Casas Nobles]]
- [[09_Politica/Matriz Heráldica y Funcional de las Casas|Matriz Heráldica y Funcional de las Casas]]
- [[09_Politica/Perfil Fenotípico/Casas Mayores|Casas Mayores]]
- [[09_Politica/Perfil Fenotípico/Perfil Fenotípico del reino|Perfil Fenotípico del reino]]
- [[09_Politica/Prompts Visuales de las 84 Casas|Prompts Visuales de las 84 Casas]]
- [[09_Politica/Registro de representantes de las Casas|Registro de representantes de las Casas]]
- [[10_Archivo/Documentos de trabajo integrados/actualizaciones_acumulativas_canon_v12|actualizaciones_acumulativas_canon_v12]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Optimizado v14|Canon Maestro Optimizado v14]]
- [[10_Archivo/Documentos de trabajo integrados/Canon Maestro Unificado v13|Canon Maestro Unificado v13]]
- [[10_Archivo/Documentos de trabajo integrados/Canon-Maestro-Unificado-Edicion-14|Canon-Maestro-Unificado-Edicion-14]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_enclaves_medio_oriente_v12|enmienda_canon_enclaves_medio_oriente_v12]]
- [[10_Archivo/Documentos de trabajo integrados/enmienda_canon_provincia_calendardhon_austral_v12|enmienda_canon_provincia_calendardhon_austral_v12]]
- [[10_Archivo/Documentos de trabajo integrados/prompts_visuales_actualizados|prompts_visuales_actualizados]]
- [[12_Militar/03_Armada/Evolución Naval 1850-2026|Evolución Naval 1850-2026]]
