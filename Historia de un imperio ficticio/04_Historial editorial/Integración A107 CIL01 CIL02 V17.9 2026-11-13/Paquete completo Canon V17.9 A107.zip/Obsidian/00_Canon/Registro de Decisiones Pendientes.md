---
tipo: registro de decisiones
canon: V17.8 A106
revision: V16.2
estado: cerrado; una tarea editorial de catálogo continúa
actualizado: 2026-11-12
---

## Revisión vigente V17 8 A106

Integrados ANP 02 y su auditoría, incluidos los bloques 50 a 54 por orden del autor de 12 de noviembre de 2026. Se conservan 427 unidades de referencia en 1980 y 615 plataformas en 2026. Las resoluciones A106 prevalecen sobre las tablas anteriores incompatibles; los datos materiales desconocidos conservan su condición. [[00_Canon/Integraciones V16/Acumulativa A106 Armada e industria naval 1891-2026|Resolución A106 Armada e industria naval]]

# Registro de decisiones y tareas editoriales

| ID | Resolución | Estado V16.2 |
|---|---|---|
| DEC-001 | Harnost (Mascate) es la capital administrativa canónica del protectorado de Harnen. | Cerrada; Harnen continúa siendo protectorado. |
| DEC-002 | Se adoptan las capitales administrativas ya inventariadas para las unidades federadas Malaca, Hawái, Fiyi, Polinesia y Micronesia. | Cerrada; no modifica la estructura federal. |
| DEC-003 | Se adoptan las capitales y sedes ya inventariadas para Harnen, Kheled-zâram, Círdan, Harlond, Amon Rûdh y los puertos asociados Alqualondë, Eglarest y Pelargir. | Cerrada; protectorados y puertos asociados conservan su condición política. |
| DEC-004 | Las ciudades secundarias que solo aparecen en tablas pueden recibir fichas cuando se completen sus datos y enlaces. La aparición en una tabla conserva validez canónica; no se inventan datos faltantes. | Reclasificada como trabajo editorial continuo, no como decisión canónica abierta. |

Los nombres adoptados y su clasificación se encuentran en [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Canon V16 Maestro]] y [[04_Mapa Politico/Capitales/Capitales del Canon V16|Índice de capitales]]. Las ciudades no se suman dos veces a población o ECON-03.

## Referencias relacionadas

[[00_Canon/Registro de Cambios]] · [[00_Canon/Panel de Control V16]] · [[00_Canon/Canon V16 Maestro#Resoluciones canónicas acumulativas V16.2|Resoluciones V16.2]]


## Continuidad V17.4 A102

Las decisiones históricas DEC-001 a DEC-004 conservan su estado. A094 automotriz y A095 aérea quedan integradas; sus pendientes de documentación y aplicación se consultan en [[00_Canon/Integraciones V16/Pendientes materiales A102]].


## Pendientes conservados tras A106

No quedan bloques ANP02 pendientes de aceptación. Siguen sin dato los años iniciales exactos y cascos de determinadas series, correspondencias nominales de generaciones, aptitud de reconstrucciones, matrículas, presupuestos, pruebas y recepciones. La orden de integrar no rellena esos campos con ceros ni con documentación inventada. Los pendientes A102 y A101 se conservan.


## Actualización territorial V17 9 A107

CIL01 y CIL02 integradas por orden del autor el 13 de noviembre de 2026. Las esperas anteriores quedan superadas. Australia Occidental es novena unidad externa; el Caribe insular, Centroamérica y once provincias norteamericanas pertenecen al Reino en 2026. Cabo Verde conserva una adhesión condicionada. Las cifras de población, PIB, superficie y totales territoriales anteriores a A107 corresponden al perímetro conciliado A106, no al Reino ampliado por CIL01 y CIL02. El total ampliado queda sin cuantificar; no se asignan ceros a los territorios nuevos. Las cuentas ya existentes se conservan una sola vez.

[[00_Canon/Integraciones V16/Resolución A107 CIL01 y CIL02|Resolución A107]] · [[00_Canon/Integraciones V16/CIL01 Red cilicia Australia y socios|CIL01]] · [[00_Canon/Integraciones V16/CIL02 América central Caribe y Norteamérica|CIL02]] · [[02_Geografia/Territorios Federales/Australia Occidental/Australia Occidental|Australia Occidental]] · [[02_Geografia/Provincias/CIL02/Índice de provincias CIL02|Once provincias]] · [[02_Geografia/Regiones/Centroamérica del Reino|Centroamérica]] · [[02_Geografia/Regiones/Caribe insular del Reino|Caribe]]
