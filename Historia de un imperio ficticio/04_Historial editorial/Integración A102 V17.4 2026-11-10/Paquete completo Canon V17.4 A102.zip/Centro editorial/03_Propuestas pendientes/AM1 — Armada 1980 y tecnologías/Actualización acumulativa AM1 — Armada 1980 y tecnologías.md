# AM1 — Armada valinari, 1875–2026

**Estado:** integración aprobada en Canon V16. Inventarios y políticas adoptados; reconstrucciones, disponibilidad y presupuestos llevan su calificación propia. Véase [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]] y [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]].

**Estado histórico de la propuesta:** el texto siguiente conserva condiciones de su fase de trabajo. La integración posterior ya está incorporada al maestro; prevalecen sus resoluciones vigentes.
**Alcance:** presupuesto naval comparado con EE. UU.; composición y evolución de la Armada; tecnologías, construcción, modernización de media vida e Infantería de Marina.
**Límite de la operación histórica:** aquella actualización modificaba únicamente AM1. No actualiza Canon V16, cronologías, Word ni Obsidian.

## 1. Decisión rectora

La Armada combina dos escalones. La **masa crítica** se compone de fragatas multipropósito, corbetas oceánicas, submarinos convencionales, patrulleros, buques anfibios y logísticos construidos en series mantenibles. La **punta de lanza** reúne un número menor de portaaviones, submarinos nucleares, destructores de defensa aérea, sensores avanzados y nodos de mando. La punta de lanza obtiene prioridad de investigación y financiación, pero no absorbe recursos que impidan sostener tripulaciones, municiones, mantenimiento, bases y transporte.

La superioridad tecnológica es selectiva y medible: Valinor busca llegar antes a la integración operativa de capacidades prioritarias, manteniendo una ventaja objetivo de 7–10 años donde la ciencia, la industria y la formación la hagan plausible. No se atribuye esa ventaja a todas las clases ni a todos los sistemas.

## 2. Regla presupuestaria: mismo porcentaje del PIB estadounidense

Para cada periodo se compara el presupuesto del **Departamento de la Marina estadounidense** —Navy más Marine Corps, cuando la fuente lo permite— con el PIB de EE. UU. en el mismo año. El porcentaje comparable se aplica al PIB valinari del mismo periodo:

**Presupuesto naval valinari = PIB valinari × (presupuesto comparable del Departamento de la Marina de EE. UU. / PIB de EE. UU.).**

Se usa una serie anual cuando existan definiciones homogéneas. En el siglo XIX y en las guerras mundiales se publicarán intervalos o años de referencia, porque las cuentas históricas cambian de apropiaciones a gastos ejecutados y no siempre separan las mismas funciones. No se proyecta el porcentaje de un año sobre todo el periodo.

### Referencias cuantitativas

| Año de referencia | EE. UU.: presupuesto marítimo y PIB | Porcentaje orientativo | Aplicación a Valinor |
|---|---|---:|---|
| 1875 | Apropiación naval estadounidense: 19,102 millones USD; PIB nominal estimado: 8,331 millones USD | **0,23 %** | Multiplicar el PIB valinari estimado de 1875 por 0,23 %. Ambos valores históricos son aproximados y deben conservar la misma base de precios. |
| 1980 | Presupuesto/apropiación naval estadounidense: alrededor de 47,0 mil millones USD; PIB: 2,857 billones USD | **1,65 %** | Si se conserva el PIB valinari de planificación de 1980 en torno a 5,73 billones de dólares internacionales, el presupuesto marítimo resultante sería **94,4 mil millones** de esa misma base. Es una estimación de trabajo, no gasto canónico. |
| 2026 | Solicitud del Department of the Navy: 292,2 mil millones USD; incluye Navy y Marine Corps. Frente a un PIB nominal estadounidense del orden de 31–33 billones, equivale aproximadamente a 0,9 %. | **aprox. 0,9 %** | Aplicando el mismo porcentaje al PIB canónico valinari de 65,5 billones PPA: **aprox. 590 mil millones PPA**. Es una conversión para planificación; PPA no equivale a dólares presupuestarios nominales. |

La referencia de 1875 proviene de la serie de presupuestos navales del NHHC y de una reconstrucción histórica del PIB; la de 1980 usa la serie presupuestaria naval y el PIB anual de FRED; el presupuesto estadounidense FY2026 de 292,2 mil millones incluye fuerzas navales y marines. El presupuesto FY2026 estadounidense también presenta una fuerza de 287 buques de batalla, como comparación de escala institucional, no como equivalencia directa con el inventario valinari. [NHHC, presupuesto naval histórico](https://www.history.navy.mil/research/library/online-reading-room/title-list-alphabetically/b/budget-of-the-us-navy-1794-to-2004.html), [FRED, PIB de EE. UU.](https://fred.stlouisfed.org/data/MKTGDPUSA646NWDB), [Department of the Navy, presupuesto FY2026](https://www.secnav.navy.mil/fmc/fmb/Documents/26pres/Highlights_Book.pdf).

**Regla de lectura:** los porcentajes históricos estadounidenses no son una constante. Los cálculos valinari son una regla comparativa de esfuerzo fiscal, no una afirmación de que el presupuesto naval por sí solo produzca automáticamente una flota determinada. Costos de personal, salarios, construcción, mantenimiento, doctrina y disponibilidad deben cerrar la conciliación de cada periodo.

## 3. Regla de diseño y modernización desde 1945

Todo buque cuya construcción comienza desde 1945 se diseña para **una modernización mayor de media vida**, aproximadamente entre los años 12 y 18 de servicio según la clase. La actualización se programa una sola vez por casco; después se permiten reparaciones y reemplazos equivalentes, pero no se presenta cada reparación como una segunda modernización integral.

Cada diseño deja reservas verificables:

- 15–20 % de margen de peso y estabilidad para sensores, cableado y armas futuras;
- 20–30 % de margen de generación eléctrica y refrigeración en escoltas avanzados; en unidades simples, una reserva menor pero protegida;
- conductos, espacios y puntos de montaje para nuevos mástiles, antenas, consolas y equipos de comunicaciones;
- arquitectura modular de combate con interfaces documentadas;
- acceso físico a maquinaria y cableado para reducir horas de astillero;
- compatibilidad con pruebas en tierra antes de instalar equipos en el casco.

No se exige que todas las reservas se ocupen. La modernización de media vida renueva el CMS, radares, sonar, comunicaciones, guerra electrónica y control de daños; el casco y la propulsión se conservan solo si su inspección estructural y costo de ciclo de vida lo justifican. Los buques que no superan esa evaluación se retiran en vez de recibir una modernización antieconómica.

## 4. Evolución por periodos y composición indicativa

Las cantidades de 1875 se tratan como línea histórica de AM1. Las cantidades de 1900 en adelante son propuestas de trabajo y representan buques incorporados o en servicio al cierre del año indicado; no son inventarios canónicos aprobados. El total incluye auxiliares donde se indica; no suma lanchas menores ni aeronaves.

### 1875 — vapor, acero y artillería

**Inventario de referencia: 332 unidades**: 178 buques armados y 154 auxiliares. Tecnología dominante: casco de hierro/acero, carbón, máquinas alternativas compuestas, navegación astronómica y óptica, telémetro inicial, señales visuales y radio aún experimental. No hay radar, sonar moderno ni CMS.

| Clase / tipo                                                                                                              | Cantidad | Desplazamiento y dimensiones orientativas | Dotación; velocidad; alcance       | Propulsión, armamento y sensores                                                                                  | Astilleros y servicio propuesto                                    |
| ------------------------------------------------------------------------------------------------------------------------- | -------: | ----------------------------------------- | ---------------------------------- | ----------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| Acorazado Círdan (1875; distinto de la fragata Círdan de 1955)                                                            |        6 | 7.000–8.500 t; 105–120 m                  | 480–620; 14–16 kn; 2.500–3.500 mn  | Carbón, máquina compuesta, 2 ejes; 4 cañones de 254–305 mm, piezas secundarias de 120–152 mm; óptica y telémetros | Nueva Tirion/Armenelos; construcción 1872–79; servicio 1875–1908   |
| Eärendil, acorazado pesado                                                                                                |        4 | 8.000–10.000 t; 115–130 m                 | 550–700; 13–15 kn; 2.500–3.000 mn  | Vapor compuesto, 2 ejes; batería pesada 280–305 mm y secundarias; observación óptica                              | Armenelos; 1869–77; servicio 1871–1902                             |
| Gil-galad, acorazado de transición                                                                                        |        6 | 6.000–7.500 t; 100–115 m                  | 430–560; 14–16 kn; 2.500–3.500 mn  | Vapor compuesto; piezas principales 240–280 mm, secundarias 120–152 mm; dirección de tiro óptica                  | Nueva Tirion/Armenelos; 1870–80; servicio 1874–1905                |
| Aulë, monitor                                                                                                             |        8 | 2.500–4.000 t; 65–85 m                    | 180–280; 10–13 kn; alcance costero | Bajo francobordo, vapor, 1–2 torres de 254–305 mm; óptica; misión litoral                                         | Calenport; construcción 1866–78; servicio 1868–1898                |
| Minas Tirith, monitor oceánico                                                                                            |        4 | 3.500–5.000 t; 75–95 m                    | 230–330; 12–14 kn                  | Vapor compuesto; 2 cañones pesados y batería menor; telémetros                                                    | Calenport/Armenelos; 1870–80; servicio 1872–1900                   |
| Eärendil, crucero protegido                                                                                               |        8 | 3.500–5.000 t; 95–115 m                   | 300–420; 16–19 kn; 3.000–4.000 mn  | Vapor, 2 ejes; cañones de 152–203 mm; telémetro óptico, sextante, corredera                                       | Pelargir Austral; 1872–82; servicio 1875–1908                      |
| Rómenna, crucero de estación                                                                                              |       10 | 2.000–3.200 t; 80–100 m                   | 220–330; 15–18 kn                  | Vapor; piezas de 120–152 mm; óptica y señales                                                                     | Pelargir/Calenport; 1871–82; servicio 1875–1905                    |
| Pelargir, corbeta oceánica                                                                                                |       12 | 1.200–2.000 t; 65–85 m                    | 120–200; 12–15 kn; 2.500–3.500 mn  | Vela auxiliar y vapor; 76–120 mm; compás, sextante, señales                                                       | Pelargir; 1873–83; servicio 1875–1905                              |
| Alqualondë, corbeta de enlace                                                                                             |        8 | 900–1.500 t; 55–75 m                      | 90–150; 12–14 kn                   | Vapor/vela; 76–102 mm; comunicaciones visuales y mensajería                                                       | Calenport; 1870–82; servicio 1873–1900                             |
| Systreyjar, corbeta ligera                                                                                                |        8 | 700–1.200 t; 50–70 m                      | 75–130; 11–14 kn                   | Vapor/vela; piezas ligeras de 57–102 mm; navegación costera                                                       | Systreyjar y Calenport; 1872–82; servicio 1875–1900                |
| Rómenna, aviso                                                                                                            |       12 | 500–900 t; 45–60 m                        | 50–90; 13–16 kn                    | Vapor; cañones ligeros; señales, navegación y despacho                                                            | Calenport; 1870–82; servicio 1873–1900                             |
| Forlond, aviso                                                                                                            |       12 | 400–800 t; 40–55 m                        | 45–80; 12–15 kn                    | Vapor; armamento ligero; mensajería y patrulla                                                                    | Forlond; 1871–82; servicio 1874–1900                               |
| Harlond, cañonera oceánica                                                                                                |       14 | 600–1.000 t; 45–65 m                      | 60–100; 11–14 kn                   | Vapor, 1–2 ejes; cañones de 76–120 mm; telémetro óptico                                                           | Pelargir; 1872–84; servicio 1875–1905                              |
| Harlond, cañonera fluvial                                                                                                 |       16 | 150–350 t; 25–40 m                        | 25–50; 7–10 kn                     | Calado reducido, vapor; cañones ligeros; óptica                                                                   | astilleros fluviales de Sírënandë; 1872–85; servicio 1875–1900     |
| Calasir, cañonera costera                                                                                                 |       12 | 250–500 t; 30–45 m                        | 35–65; 8–12 kn                     | Vapor; piezas ligeras; patrulla y escolta                                                                         | Calasir/Pelargir; 1873–84; servicio 1875–1900                      |
| Forlond, torpedero                                                                                                        |       12 | 100–180 t; 30–40 m                        | 25–40; 18–22 kn; radio corto       | Vapor rápido; torpedos de 356–450 mm y cañón ligero; observación visual                                           | Forlond; 1873–80; servicio 1875–1895                               |
| Calenhad, torpedero ligero                                                                                                |       12 | 50–100 t; 20–30 m                         | 15–25; 16–20 kn                    | Vapor; torpedos y arma ligera; costa/puerto                                                                       | Calenport; 1873–82; servicio 1875–1895                             |
| Transporte armado                                                                                                         |       14 | 1.500–4.000 t                             | 80–180; 10–14 kn; 3.000–5.000 mn   | Vapor/vela; defensa ligera, radio experimental tardía                                                             | Pelargir/Númenor; 1870–85; servicio 1875–1910                      |
| Auxiliares: carbón/combustible, transportes, almacenes, remolque/reparación, hospital, hidrografía, instrucción, patrulla |      154 | 100–8.000 t                               | 15–250; 7–16 kn                    | Velas y vapor; equipos de navegación, sondeo y señal; sin CMS                                                     | red de astilleros territoriales; servicio según subclase 1870–1920 |

### 1900 y 1914 — acorazados, torpedos y radio

| Año / clases principales | Cantidad propuesta | Parámetros y rol | Construcción y vida de servicio |
|---|---:|---|---|
| 1900: acorazados de escuadra Anárion | 8 | 10.000–14.000 t; 16–18 kn; 600–800 tripulantes; artillería principal 280–305 mm, secundarias 120–152 mm; telégrafo sin hilos y dirección óptica | Armenelos/Nueva Tirion; construcciones 1892–1902; servicio aprox. 1895–1925 |
| 1900: cruceros acorazados Eärendil | 12 | 7.000–10.000 t; 20–23 kn; 450–650; artillería 152–203 mm | Pelargir/Armenelos; 1894–1904; 1897–1930 |
| 1900: cruceros ligeros Rómenna y corbetas Pelargir | 24 | 2.000–5.000 t; 18–23 kn; 180–400; cañones 102–152 mm, torpedos | Calenport/Pelargir; 1895–1905; 1898–1930 |
| 1900: destructores Forlond y torpederos | 48 | 250–800 t; 25–30 kn; 50–110; torpedos 450 mm, cañones 57–102 mm | Forlond y astilleros insulares; 1897–1905; 1900–1925 |
| 1900: cañoneras y patrulleros | 42 | 200–1.000 t; 10–16 kn; piezas ligeras | estaciones atlánticas, ríos y puertos; 1890–1905; servicio variable hasta 1935 |
| 1900: auxiliares | 90 | carbón, transporte, reparación, hidrográfico y hospital | cadena de astilleros; 1890–1910; servicio según inspección |
| 1914: acorazados tipo dreadnought Anárion II | 12 | 20.000–27.000 t; 21–23 kn; 850–1.100 tripulantes; 8–10 piezas de 305–343 mm; telémetros, radio y control centralizado de tiro | Nueva Tirion/Armenelos; 1907–17; servicio 1910–1945, con retiradas graduales |
| 1914: cruceros de batalla Gil-galad | 6 | 25.000–30.000 t; 26–29 kn; blindaje más ligero, piezas 305–343 mm | Armenelos; 1909–17; servicio 1912–1945 |
| 1914: cruceros protegidos/ligeros | 24 | 4.000–10.000 t; 25–30 kn; 350–650; cañones 102–152 mm, torpedos | Pelargir/Calenport; 1905–18; 1910–1940 |
| 1914: destructores y torpederos | 72 | 700–1.500 t; 28–34 kn; 90–160; torpedos, cañones 76–120 mm | Forlond/Calenport; 1907–18; 1910–1940 |
| 1914: submarinos | 24 | 500–1.500 t; 35–65 dotación; diésel-eléctrico; torpedos y minas | Númenor; 1905–18; 1910–1940 |
| 1914: auxiliares, minadores y transportes | 110 | logística oceánica ampliada y reparación adelantada | Pelargir/Númenor; 1900–20; rotación hasta 1945 |

En 1900–1914 la flota utiliza turbinas de vapor progresivamente en cruceros y destructores, y calderas de mayor presión; carbón sigue siendo común y el petróleo aparece primero como combustible auxiliar o mixto. El radar y el sonar no son capacidades de servicio.

### 1945, 1960 y 1980 — portaaviones, submarinos y flota de sensores

| Año | Portaaviones | Cruceros | Destructores | Fragatas | Corbetas | Lanchas misilísticas | Patrulla | Submarinos | Anfibios | MCM | Auxiliares | Total orientativo |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1945 | 8 | 18 | 54 | 42 | 42 | 0 | 18 | 38 | 28 | 20 | 100 | 368 |
| 1960 | 9 | 16 | 48 | 52 | 50 | 20 | 50 | 46 | 32 | 20 | 65 | 408 |
| 1980 | 7 | 14 | 36 | 56 | 50 | 24 | 60 | 42 | 34 | 26 | 78 | **427** |

Las composiciones de **1945 y 1960 son reconstrucciones de AM1** para mostrar la transición; no son cifras canónicas ni inventarios medidos. La columna de 1980 es el desglose de referencia de este documento. En ella, las **50 corbetas**, las **24 lanchas misilísticas**, las **60 unidades de patrulla** y las **78 auxiliares** son categorías separadas.

#### Desglose técnico por clases, 1980

| Familia y clase | Cantidad | Tipo y escala | Propulsión, prestaciones y dotación | Armamento, sensores, astilleros y servicio |
|---|---:|---|---|---|
| Portaaviones Aulë II / Anárion I / Varda I | 7 (2 / 3 / 2) | Aulë II nuclear, 68–75 mil t; Anárion I convencional, 45–55 mil t; Varda I ligero/ASW, 22–28 mil t | 25–32 kn; dotación total con ala aérea, aproximadamente 1.500–5.300 según tipo | Defensa antiaérea y señuelos; radar de alerta y control aéreo; CMS de ala embarcada. Armenelos/Nueva Tirion para grandes; Pelargir Austral/Calenport para convencionales y ligeros. Construcción aprox. 1955–79; retiro por casco 1990–2015. |
| Cruceros Turgon / Eärendil / Noldor | 14 (4 / 6 / 4) | AAW, multimisión y mando; 8.000–14.000 t | 27–32 kn; 450–700 tripulantes; 5.000–8.000 mn | Cañón 127–152 mm, misiles antiaéreos y antibuque, torpedos; radar 2D/3D, sonar según variante y CMS digital en lotes tardíos. Armenelos/Pelargir; servicio 1960–2005. |
| Destructores Gil-galad / Beleg / Ossë | 36 (12 / 16 / 8) | Defensa aérea, antisubmarina y propósito general; 4.500–8.000 t | 29–32 kn; 260–420 personas; 4.000–6.000 mn | Cañón 127 mm, misiles de zona/local y antibuque, torpedos; radar 3D, sonar de casco/remolcado en ASW, EW y CMS integrado. Nueva Tirion/Armenelos/Pelargir Austral; construcción 1960–80, retiro 2005–2020. |
| Fragatas Círdan / Mithlond / Nimrodel | 56 (36 / 12 / 8) | Multipropósito y escolta oceánica/de convoy; 3.000–4.800 t | 25–29 kn; 190–260 personas; 4.000–5.500 mn | Cañón 76–127 mm, misiles de punto y antibuque, torpedos; radar 2D/3D por bloque, sonar de casco/remolcado y CMS analógico-digital. Calenport/Pelargir Austral. Programa Círdan moderno desde 1955; reemplazo generacional y refit según casco. |
| Corbetas Calenport / Eglarest | 50 (30 / 20) | Oceánicas y litorales; 900–2.200 t | 24–29 kn; 85–155 personas; 2.000–4.000 mn | Cañón 57–76 mm; misiles antibuque en parte de los cascos; radar de superficie, electroóptica, sonar ASW en algunas unidades y CMS compacto. Calenport/Pelargir/astilleros insulares; servicio 1965–2000. |
| Lanchas lanzamisiles Nosselië | 24 | Ataque litoral rápido; 350–700 t | 35–43 kn; 40–65 tripulantes; 700–1.300 mn | Cañón ligero, misiles antibuque, radar de superficie y enlace táctico. Astilleros insulares; servicio 1970–1995. |
| Submarinos Arnor / Eärendil / Tolfalas / Ossë | 42 (6 / 12 / 18 / 6) | Estratégicos, ataque nuclear, convencionales y especiales; 1.000–16.000 t según misión | Dotación 25–160; autonomía prolongada en nucleares y de semanas en convencionales | Torpedos, minas y misiles según tipo; sonar pasivo/de proa, interceptación acústica y navegación inercial; recepción LF/comunicaciones discretas. Armenelos/Númenor; construcción 1955–80, retiro por casco hasta 2000–2030. |
| Anfibios Aranath / Pelargir / Forlond / Andúnië | 34 (6 / 8 / 12 / 8) | Asalto LPH, LPD, desembarco LST y apoyo logístico; 2.000–30.000 t | 15–25 kn; 80–800 tripulantes, más fuerza embarcada | Radar de navegación/vigilancia, comunicaciones de grupo, CMS defensivo y armas de punto. Pelargir Austral/Calenport/Armenelos; construcción 1955–80, servicio aproximado 1980–2010. |
| Contramedidas de minas Amon Sûl / Menel | 26 (18 / 8) | Cazaminas y mando/apoyo; 500–3.000 t | 12–20 kn; 35–120 personas | Sonar de búsqueda, vehículos de inspección, casco de baja firma, CMS de misión y comunicaciones seguras. Calenport/Númenor; servicio 1960–2005. |
| Patrulla Sírënandë / Malaca | 60 (30 / 30) | OPV oceánico y patrullero rápido; 500–3.500 t | 18–32 kn; 35–120 personas | Cañón 30–76 mm, radar de superficie, electroóptica y CMS de vigilancia marítima. Calenport, Sírënandë y astilleros insulares; servicio 1960–2010. |
| Auxiliares Aulë / Ecthelion / Harlond / Númenor / Estel / Eärendil / Palantír / Alcarondas | 78 (14 / 12 / 12 / 8 / 6 / 8 / 10 / 8) | Petroleros, reabastecedores, transportes, talleres, hospitales, salvamento, oceanografía y comunicaciones; 2.000–35.000 t | 15–24 kn; dotación de 70–400 según misión | Radar de navegación y comunicaciones HF/VHF/UHF; satélite en las unidades tardías; armamento ligero o ninguno. Pelargir Austral, Armenelos, Númenor y Calenport; ciclos de 20–35 años. |

**Comprobación del total 1980:** 7 portaaviones + 14 cruceros + 36 destructores + 56 fragatas/escoltas + 50 corbetas + 24 lanchas misilísticas + 42 submarinos + 34 anfibios + 26 contramedidas de minas + 60 patrulleros + 78 auxiliares = **427 unidades**. Las 60 de patrulla y las 78 auxiliares se cuentan aparte; las 50 corbetas no incluyen las 24 lanchas lanzamisiles.

#### Reconstrucción por clase, 1945

Desglose de trabajo para explicar el total orientativo de **368**. Las velocidades y ventanas de servicio son aproximaciones de AM1; no constituyen inventario canónico.

| Tipo y clase | Cantidad | Velocidad / alcance | Propulsión y función | Armamento/sensores de época y servicio estimado |
|---|---:|---|---|---|
| Portaaviones Aulë I | 8 | 24–28 kn; 7.000–9.000 mn | Turbinas de vapor; cobertura aérea de flota y apoyo antisubmarino | Artillería antiaérea, dirección óptica/radar temprano y control central de vuelo; 1945–1970. |
| Cruceros Turgon I / Eärendil II / Rómenna II | 18 (6 / 6 / 6) | 28–32 kn; 5.000–8.000 mn | Turbina de vapor; mando, exploración, escolta y defensa antiaérea | Cañones 127–203 mm, antiaéreos, torpedos; radar temprano y control de tiro óptico/radar; 1938–1965 según casco. |
| Destructores Gil-galad I / Beleg I / Ossë I | 54 (18 / 18 / 18) | 30–36 kn; 3.000–5.000 mn | Turbinas de vapor; escolta de portaaviones, ASW y ataque de superficie | Cañones 102–127 mm, torpedos, cargas de profundidad y sonar; radar de búsqueda en lotes tardíos; 1940–1965. |
| Fragatas Mithlond I / Nimrodel I | 42 (20 / 22) | 20–26 kn; 3.000–5.000 mn | Vapor, algunas unidades diésel; escolta de convoy y patrulla oceánica | Cañones 76–102 mm, cañones ligeros, cargas de profundidad y sonar; 1940–1965. |
| Corbetas Pelargir II / Alqualondë II | 42 (24 / 18) | 16–22 kn; 2.000–4.000 mn | Diésel o vapor; escolta litoral, enlace y protección de convoy | Cañones 57–102 mm, cargas de profundidad en variantes ASW, radar de navegación; 1940–1960. |
| Lanchas misilísticas | 0 | — | — | No forman parte de la composición de 1945. |
| Patrulleros Sírënandë I / Malaca I | 18 (10 / 8) | 16–27 kn; 1.500–4.000 mn | Diésel; patrulla oceánica y vigilancia rápida | Cañón ligero, radar de superficie en las unidades tardías, radio HF; 1940–1965. |
| Submarinos Arnor I / Eärendil I / Tolfalas I / Ossë I | 38 (8 / 10 / 16 / 4) | 15–22 kn en superficie; 8–12 kn sumergidos | Diésel-eléctrica; patrulla oceánica, ataque, defensa litoral y misiones especiales | Torpedos y minas; hidrófonos/sonar de primera generación y radar de superficie en mástil; 1940–1970. |
| Anfibios Aranath I / Pelargir I / Forlond I / Andúnië I | 28 (4 / 8 / 10 / 6) | 12–20 kn; alcance de transporte oceánico | Diésel o vapor; asalto, transporte de tropas, desembarco de vehículos y logística | Artillería ligera, radar de navegación y comunicaciones de convoy; 1940–1970. |
| Contramedidas de minas Amon Sûl I / Menel I | 20 (14 / 6) | 12–16 kn; 2.000–4.000 mn | Diésel; búsqueda de minas, dragado y mando de grupo | Sonar de búsqueda, barrido mecánico y armas ligeras; 1940–1965. |
| Auxiliares Aulë / Ecthelion / Harlond / Númenor / Estel / Eärendil / Palantír / Alcarondas | 100 (20 / 16 / 18 / 10 / 8 / 10 / 10 / 8) | 12–20 kn; 4.000–10.000 mn según casco | Diésel/vapor; combustible, reabastecimiento, transporte, reparación, sanidad, salvamento, ciencia y comunicaciones | Radar de navegación y radio; normalmente sin armamento o con defensa ligera; servicio aproximado 1940–1975, por función y casco. |

**Suma 1945:** 8 + 18 + 54 + 42 + 42 + 0 + 18 + 38 + 28 + 20 + 100 = **368**.

#### Reconstrucción por clase, 1960

Desglose de trabajo para explicar el total orientativo de **408**. Las cifras separan corbetas de lanchas misilísticas y conservan patrulla y auxiliares como grupos propios.

| Tipo y clase | Cantidad | Velocidad / alcance | Propulsión y función | Armamento/sensores de época y servicio estimado |
|---|---:|---|---|---|
| Portaaviones Aulë I / Anárion I | 9 (6 / 3) | 25–30 kn; 8.000–12.000 mn | Vapor/turbina; seis cascos de generación anterior y tres portaaviones de flota nuevos, para cobertura aérea oceánica | Defensa antiaérea, radar de alerta/control aéreo y dirección de operaciones embarcadas; Aulë I 1945–1970; Anárion I entra en servicio alrededor de 1960 y se retira por casco entre 1995–2005. |
| Cruceros Turgon II / Eärendil III / Noldor I | 16 (5 / 6 / 5) | 28–32 kn; 5.000–8.000 mn | Turbina de vapor; defensa aérea, escolta oceánica, mando y exploración | Cañones 127–152 mm, misiles antiaéreos tempranos por sublote, torpedos; radares 2D/3D iniciales, sonar según variante; 1950–1985. |
| Destructores Gil-galad II / Beleg II / Ossë II | 48 (16 / 20 / 12) | 30–34 kn; 4.000–6.000 mn | Turbina de vapor, con unidades experimentales de turbina de gas; AAW, ASW y propósito general | Cañón 76–127 mm, misiles tempranos en unidades especializadas, torpedos y cargas de profundidad; radar 2D/3D y sonar; 1950–1985. |
| Fragatas Círdan I / Mithlond II / Nimrodel II | 52 (24 / 16 / 12) | 24–29 kn; 4.000–5.500 mn | Diésel/turbina; escolta oceánica, convoy, ASW y presencia | Cañón 76–127 mm, torpedos, armas ASW; radar 2D, sonar de casco y CMS analógico/electromecánico; Círdan I desde 1960, las otras series se retiran gradualmente hasta 1990. |
| Corbetas Pelargir III / Alqualondë III / Systreyjar II | 50 (20 / 15 / 15) | 18–25 kn; 2.000–4.000 mn | Diésel; escolta costera, enlace interinsular y patrulla | Cañón 57–102 mm, radar de navegación/superficie y sonar solo en sublotes ASW; 1948–1980 aprox. |
| Lanchas misilísticas Forlond I | 20 | 32–40 kn; 600–1.200 mn | Diésel rápido; defensa litoral y ataque de superficie | Cañón ligero y misiles antibuque de primera generación; radar de superficie y enlace táctico; 1960–1980 aprox. |
| Patrulleros Sírënandë I / Malaca I | 50 (30 / 20) | 18–30 kn; 2.000–6.000 mn | Diésel; vigilancia oceánica, control de rutas y patrulla rápida | Cañón 30–76 mm, radar de superficie, radio HF y electroóptica temprana; 1955–1985, con reemplazo por lotes. |
| Submarinos Arnor / Eärendil / Tolfalas / Ossë | 46 (6 / 12 / 22 / 6) | 15–25 kn en superficie; 10–20 kn sumergidos, según planta | Diésel-eléctrica y primeros cascos nucleares; disuasión, ataque, patrulla convencional y misiones especiales | Torpedos, minas y misiles en subclases estratégicas; sonar pasivo/de proa, navegación inercial y comunicaciones de baja exposición; 1955–1990 por generaciones. |
| Anfibios Aranath / Pelargir / Forlond / Andúnië | 32 (6 / 8 / 12 / 6) | 14–22 kn; alcance oceánico de transporte | Diésel/turbina; asalto, LPD, desembarco y logística | Radar de navegación, comunicaciones de grupo, cañones y defensa puntual; 1955–1990 por casco. |
| Contramedidas de minas Amon Sûl / Menel | 20 (14 / 6) | 12–18 kn; 2.000–5.000 mn | Diésel; caza de minas, apoyo y mando | Sonar de búsqueda, barrido, primeros vehículos remotos y baja firma magnética; 1955–1990. |
| Auxiliares Aulë / Ecthelion / Harlond / Númenor / Estel / Eärendil / Palantír / Alcarondas | 65 (10 / 8 / 10 / 8 / 5 / 6 / 10 / 8) | 14–22 kn; 5.000–10.000 mn según misión | Diésel; combustible, reabastecimiento, transportes, talleres, hospitales, salvamento, oceanografía y mando/comunicaciones | Radar de navegación, HF/VHF y enlaces de datos iniciales; defensa ligera o ninguna; 1955–1990 según inspección y misión. |

**Suma 1960:** 9 + 16 + 48 + 52 + 50 + 20 + 50 + 46 + 32 + 20 + 65 = **408**. Las fechas y divisiones por subclase son reconstrucciones de AM1; su función es explicar la transición hacia la estructura de 1980, no establecer cifras históricas canónicas.

### 2000 — red distribuida y flota de transición

| Tipo / clase de referencia | Cantidad indicativa | Especificación de generación |
|---|---:|---|
| Portaaviones de flota y ligeros | 9 | Nuclear y convencional; 25–32 kn; ala mixta tripulada; CMS aéreo enlazado a escoltas |
| Submarinos estratégicos, nucleares de ataque y convencionales | 52 | 8 SSBN, 16 SSN, 22 convencionales oceánicos, 6 especializados; sonar de flanco y navegación inercial mejorada |
| Destructores Gil-galad modernizados / nueva serie | 28 | 7.000–10.000 t; 29–32 kn; 300–420 tripulantes; radar 3D de escaneo electrónico en buques punteros; CMS de arquitectura modular |
| Fragatas Círdan II–IV | 62 | 3.500–6.000 t; 26–30 kn; 170–240 tripulantes; propulsión combinada, radar 3D, sonar remolcado, helicóptero; CMS digital integrado |
| Corbetas y patrulleros | 125 | 500–2.500 t; diésel, radar compacto, electroóptica y CMS modular reducido |
| Anfibios | 38 | LHD/LPD/LST; conectividad para mando de fuerza desembarcada y apoyo humanitario |
| MCM y auxiliares | 150 | vehículos no tripulados iniciales de inspección, logística oceánica y soporte a OceanNet |

Comienzan a operar enlaces de datos más robustos y radares de barrido electrónico en unidades seleccionadas. AESA se despliega gradualmente, no como dotación universal en 2000. Las modernizaciones Círdan IV de 2005–15 pertenecen a su único refit integral de media vida.

### 2026 — inventario canónico de referencia de 615 plataformas navales

La cifra canónica de **615 plataformas** incluye 20 vehículos navales no tripulados: equivale a 595 buques tripulados y 20 plataformas autónomas o remotamente supervisadas. La cifra de **449** disponibles es una hipótesis de planificación para un ciclo ordinario, no una medición de disponibilidad observada; las demás plataformas se distribuyen entre mantenimiento, entrenamiento, reserva, modernización y reacondicionamiento.

| Clase / familia | Cantidad | Dimensiones, dotación, velocidad y alcance | Propulsión, armas, sensores y construcción |
|---|---:|---|---|
| Portaaviones nucleares Telperion | 4 | 75.000–95.000 t; 300–335 m; 2.400–3.200 marinos + 1.500–2.000 ala aérea; 30+ kn; autonomía de combustible muy larga, limitada por víveres y mantenimiento | Reactores nucleares; defensa puntual, señuelos/EW; radar AESA de vigilancia aérea y control de vuelo, enlaces tácticos, CMS aéreo distribuido. Construcción: Armenelos; integración de sensores en Nueva Tirion. |
| Portaaviones convencionales Anárion II / Elwing I / Aldarion I | 3 | 45.000–65.000 t; 270–310 m; 2.000–2.900 + ala aérea; 27–30 kn; 8.000–12.000 mn | Turbinas de vapor/gas según generación; defensa cercana; radares AESA/3D; CMS aéreo. Nueva Tirion/Armenelos. |
| Portaaviones ligeros STOVL Varda II–III | 4 | 25.000–40.000 t; 220–260 m; 900–1.500 + ala aérea; 24–28 kn; 7.000–9.000 mn | Diésel/turbina; defensa puntual; radar 3D/AESA compacto, control aéreo táctico; Calenport/Pelargir Austral. |
| Submarinos estratégicos Arnor II–IV | 10 | 12.000–18.000 t sumergidos; 130–170 m; 130–160 personas; baja velocidad de patrulla silenciosa, autonomía de meses | Nuclear; disuasión estratégica y torpedos defensivos; sonar de proa/flancos/remolcado, sensores de interceptación, navegación inercial; Armenelos. |
| Submarinos nucleares de ataque Eärendil II–IV | 18 | 6.000–10.000 t; 100–130 m; 90–130 personas; alta velocidad máxima clasificada en canon técnico público, alcance de misión oceánico | Nuclear; torpedos pesados, minas y misiles conforme al canon; sonar de gran apertura, CMS acústico, mástiles electroópticos; Armenelos/Nueva Tirion. |
| Submarinos convencionales AIP Tolfalas II–IV | 18 | 2.000–4.000 t; 65–90 m; 40–65 personas; semanas sumergidos según perfil, 6.000–9.000 mn de tránsito | Diésel-eléctrico/AIP; torpedos y minas; sonar pasivo, navegación inercial y comunicación esporádica; Númenor. |
| Submarinos especiales Aeglos y rescate Falathar | 8 | 1.000–4.000 t; 45–95 m; 25–70 personas | Diésel-eléctrico o nuclear según misión; rescate, investigación, buceo, inteligencia oceanográfica; sensores acústicos y de navegación; Númenor/Armenelos. |
| Destructores Gil-galad de defensa aérea | 24 | 8.000–12.000 t; 155–190 m; 280–380 personas; 30–32 kn; 5.000–7.000 mn | Turbina/diésel o propulsión eléctrica integrada por sublote; cañón medio, misiles de defensa de área y punto, antibuque y torpedos; radar AESA multifunción, CMS de grupo y EW. Armenelos/Pelargir Austral. |
| Fragatas Círdan/Voronwë multipropósito | 64 | 4.500–7.000 t; 125–155 m; 150–220 personas; 26–30 kn; 5.000–7.000 mn | CODLAG/CODOG o eléctrica según bloque; cañón medio, misiles de punto/área local, antibuque y torpedos; radar AESA compacto, sonar casco/remolcado, CMS común. Calenport/Pelargir Austral. |
| Corbetas oceánicas Calenport | 72 | 1.800–3.000 t; 90–115 m; 70–115 personas; 25–29 kn; 3.500–5.000 mn | Diésel; cañón 57–76 mm, misiles defensivos/antibuque según misión; radar 3D compacto, electroóptica, CMS escalable; astilleros regionales/insulares. |
| Escoltas especializados ASW/AAW | 30 | 3.500–6.500 t; 110–145 m; 100–190 personas; 25–30 kn; 4.000–6.000 mn | Diésel-eléctrica o turbina; equipo ASW o radar/armamento AAW; CMS de misión; Calenport/Nueva Tirion. |
| Buques de asalto/anfibios | 14 | 15.000–40.000 t; 180–260 m; 300–900 tripulantes + fuerza embarcada | Diésel/turbina; aeronaves, lanchas, vehículos; defensa puntual, radares de aproximación y CMS de grupo anfibio; Pelargir Austral/Armenelos. |
| LPD/LSD de desembarco | 20 | 8.000–25.000 t; 130–210 m; 150–450 + tropas | Diésel; dique inundable, grúas, radar de navegación y enlaces de fuerza; Pelargir Austral. |
| OPV Sírënandë | 80 | 2.000–5.000 t; 90–125 m; 65–110 personas; 18–24 kn; 6.000–9.000 mn | Diésel; cañón ligero, UAV embarcado donde proceda; radar de vigilancia/superficie, electroóptica, CMS de seguridad marítima; Sírënandë/Calenport. |
| Patrulleros rápidos | 70 | 300–1.200 t; 45–80 m; 25–60 personas; 25–35 kn; 1.500–3.500 mn | Diésel; cañón 20–57 mm, sensores compactos y enlaces costeros; astilleros locales. |
| Guerra de minas | 30 | 500–2.500 t; 45–100 m; 35–100 personas; 12–20 kn; 2.000–5.000 mn | Diésel-eléctrica; casco no magnético donde corresponda; sonar de alta resolución, vehículos no tripulados y CMS MCM; Calenport/Númenor. |
| Hidrografía | 20 | 1.500–6.000 t; 60–120 m; 50–150 tripulantes/científicos; 12–20 kn | Diésel; ecosondas multihaz, sonar de cartografía, posicionamiento preciso y OceanNet científico; Númenor/Calenport. |
| Vehículos no tripulados navales | 20 | Unidades de superficie y submarinas de varias toneladas a tamaño de patrullero ligero; supervisión remota, no dotación embarcada permanente | Diésel/batería; vigilancia, cartografía y contramedidas; sensores electroópticos/acústicos; uso supervisado y recuperación desde buques nodriza. |
| Petroleros de flota | 20 | 25.000–50.000 t; 180–230 m; 100–180 personas; 18–22 kn; 10.000+ mn | Diésel; transferencia en navegación, radar y comunicaciones logísticas; Pelargir Austral. |
| Reabastecedores multipropósito | 18 | 20.000–40.000 t; 170–220 m; 180–300 personas; 18–24 kn; 8.000–10.000 mn | Diésel; combustible/carga/municiones en operaciones controladas, defensa propia ligera, enlace logístico; Pelargir/Armenelos. |
| Transportes estratégicos | 12 | 10.000–30.000 t; 120–200 m; 80–220 personas; 18–23 kn | Diésel; carga, vehículos y apoyo expedicionario; radar de navegación y CMS logístico; Pelargir Austral/Númenor. |
| Hospitales | 10 | 8.000–25.000 t; 140–220 m; 150–350 de tripulación y sanidad | Diésel; sin armamento ofensivo; navegación, comunicaciones médicas y protección humanitaria; conversión/construcción en Pelargir Austral. |
| Reparación/taller | 12 | 5.000–20.000 t; 120–190 m; 180–400 tripulación y técnicos | Diésel; talleres, repuestos y grúas; redes de mantenimiento; Númenor/Pelargir. |
| Oceanográficos | 10 | 2.000–8.000 t; 75–130 m; 70–180 personas | Diésel-eléctrica silenciosa; sonar científico, sensores meteorológicos y de fondo; Calenport/Númenor. |
| Salvamento y rescate | 8 | 2.000–8.000 t; 70–130 m; 60–160 personas | Diésel; sonar de trabajo, vehículos de rescate, buceo y remolque; Númenor. |
| Mando, comunicaciones y apoyo especializado | 16 | 2.000–12.000 t; 80–180 m; 80–300 personas | Diésel; 8 buques de mando/comunicaciones, 4 de rescate polar y 4 de mantenimiento avanzado; Nueva Tirion/Pelargir/Númenor. |

El desglose canónico suma **615** plataformas: 11 portaaviones +54 submarinos +190 escoltas/superficie de combate +34 anfibios +220 patrulla/vigilancia/servicios +106 auxiliares. Los 220 se desglosan en 80 OPV +70 patrulleros rápidos +30 MCM +20 hidrográficos +20 no tripulados. Los 106 auxiliares incluyen 90 unidades de las familias logísticas principales y 16 plataformas de mando/apoyo especializado. “Plataforma” incluye los 20 vehículos navales no tripulados; no son buques tripulados.

### Ventanas de construcción y servicio en la flota de 2026

Los intervalos señalan generaciones de clase y no una única vida idéntica para todos los cascos. Construcción es el periodo en que comienza el primer casco de la serie; servicio es la ventana de entrada y retirada de los lotes. Para clases de varias generaciones, el rango refleja lotes sucesivos.

| Familia/clase                           |   Inicio de construcción de la generación | Servicio previsto de la familia | Política de retiro                                                                                          |
| --------------------------------------- | ----------------------------------------: | ------------------------------: | ----------------------------------------------------------------------------------------------------------- |
| Portaaviones Telperion nuclear          |                                      2010 |                       2018–2065 | modernización de media vida 2032–40; retirar lotes según reactor/casco, sin refit integral repetido         |
| Portaaviones convencionales de flota    |                                 1985–2010 |                       1990–2055 | los cascos anteriores salen antes; cada casco recibe un refit principal                                     |
| Portaaviones ligeros STOVL              |                                 2000–2018 |                       2005–2060 | modernización media vida según edad; retirada si aviación y casco dejan de ser sostenibles                  |
| Submarino estratégico                   |                                 1970–2018 |                       1975–2065 | rotación por generaciones; refit de media vida y extensión estructural condicionada                         |
| Submarino nuclear de ataque             |                                 1965–2018 |                       1970–2060 | bloques de 30–40 años solo con reacondicionamiento nuclear y modernización única de combate                 |
| Submarino convencional AIP              |                                 1990–2020 |                       1995–2055 | ciclo aproximado de 25–35 años, sujeto a baterías, casco y seguridad AIP                                    |
| Submarino especial/inteligencia/rescate |                                 1960–2020 |                       1965–2055 | clases pequeñas sustituidas por función y disponibilidad, no por tonelaje                                   |
| Destructor Gil-galad AAW                |                                 1972–2020 |                       1978–2060 | transición de lotes tempranos a bloques actuales; refit de media vida y retiro a los 30–40 años             |
| Fragata Círdan/Voronwë                  | Círdan 1955; Círdan IV 1995; Voronwë 2022 |                       1960–2065 | Círdan IV sale gradualmente cuando Voronwë alcanza plena serie; cada casco recibe una modernización central |
| Corbeta Calenport                       |                                 1998–2022 |                       2002–2055 | refit único; sustitución seriada con cascos de vida más larga y electrónica modular                         |
| Escolta especializado ASW/AAW           |                                 1985–2020 |                       1990–2060 | priorizar cambio de misión/sensores en media vida; dar de baja si requiere reconstrucción de casco          |
| Buques de asalto anfibio                |                                 1970–2020 |                       1975–2060 | refit de media vida para comunicaciones, cubierta y mando; extensión estructural evaluada                   |
| LPD/LSD                                 |                                 1960–2022 |                       1965–2065 | 30–40 años según corrosión, maquinaria y disponibilidad de repuestos                                        |
| OPV Sírënandë                           |                                 1980–2022 |                       1985–2055 | vida de 25–35 años; modernización de sensores, no conversión a combatiente pesado                           |
| Patrullero rápido                       |                                 1980–2023 |                       1985–2055 | ciclos breves de 20–30 años por uso intensivo                                                               |
| Guerra de minas                         |                                 1960–2023 |                       1965–2060 | reemplazo de plataformas y vehículos no tripulados por bloques                                              |
| Hidrografía/oceanografía                |                                 1950–2023 |                       1955–2060 | renovar sensores científicos manteniendo cascos aptos; refit de misión una vez                              |
| Auxiliares logísticos                   |                                 1950–2024 |                       1955–2065 | 25–40 años; modernización de transferencia, comunicaciones y control de averías                             |

### Catálogo técnico ampliado: clases de 1980

Las fichas siguientes amplían las familias resumidas arriba. Cantidades, nombres, características y astilleros son propuestas AM1; el inventario de 427 suma por separado cada grupo. El **inicio de construcción** es el del primer casco de la clase, y el **periodo de servicio** es el rango previsto de entrada/salida de la familia. Velocidad y alcance son estimaciones de diseño.

#### Portaaviones

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Armamento, sensores y CMS | Astillero; construcción y servicio |
|---|---|---|---|---|
| Aulë nuclear / 2 | 68.000–75.000 t; 300–320 m; 2.800–3.400 tripulantes + 1.500–1.900 ala aérea | Nuclear, cuatro ejes; 30–32 kn; autonomía de propulsión larga, limitada por víveres y mantenimiento | Defensa puntual, señuelos y EW; radar 3D de alerta, control de vuelo, CMS aéreo de grupo; HF, VHF/UHF y satélite | Armenelos, integración en Nueva Tirion; construcción 1955–75; servicio 1960–2010 |
| Anárion convencional / 3 | 45.000–55.000 t; 270–295 m; 2.200–2.900 + 1.100–1.600 ala aérea | Vapor convencional; 28–30 kn; 8.000–10.000 mn a velocidad económica | Defensa cercana, señuelos; radares 2D/3D y de aproximación; CMS de operaciones aéreas; HF/VHF/UHF, enlace táctico y terminal satelital | Nueva Tirion/Armenelos; construcción 1958–78; servicio 1963–2010 |
| Varda ligero/ASW / 2 | 22.000–28.000 t; 210–235 m; 1.000–1.500 + 500–800 ala aérea | Vapor o planta mixta; 25–28 kn; 7.000–9.000 mn | Cañones/misiles defensivos; radar 2D/3D, control de helicópteros y coordinación ASW | Calenport/Pelargir Austral; construcción 1965–79; servicio 1970–2015 |

#### Cruceros

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Armamento, sensores y CMS | Astillero; construcción y servicio |
|---|---|---|---|---|
| Turgon AAW / 4 | 11.000–14.000 t; 175–195 m; 550–700 | Turbina de gas y diésel auxiliar; 30–32 kn; 5.000–6.500 mn | Cañón 127 mm, misiles antiaéreos de zona/local, antibuque y torpedos; radar 3D, control de tiro, EW y CMS de mando aéreo | Armenelos; construcción 1965–80; servicio 1970–2015 |
| Eärendil multimisión / 6 | 9.000–12.000 t; 165–185 m; 450–600 | Turbina de vapor o gas por lote; 30–32 kn; 5.500–7.000 mn | Cañón 127–152 mm, misiles antibuque/antiaéreos y torpedos; radar 2D/3D, sonar de casco, CMS digital en lotes tardíos | Pelargir Austral/Armenelos; construcción 1960–78; servicio 1965–2010 |
| Noldor mando / 4 | 8.000–10.000 t; 155–175 m; 500–650 | Vapor modernizado o turbina de gas; 27–30 kn; 6.000–8.000 mn | Cañón 127 mm y defensa puntual; radar 2D/3D, comunicaciones HF/VHF/UHF, enlace de flota y satélite de mando; CMS orientado a coordinación | Nueva Tirion/Pelargir Austral; construcción 1958–75; servicio 1963–2005 |

#### Destructores

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Armamento, sensores y CMS | Astillero; construcción y servicio |
|---|---|---|---|---|
| Gil-galad AAW / 12 | 6.500–8.000 t; 150–165 m; 330–420 | Turbina de gas con diésel auxiliar; 30–32 kn; 4.500–5.500 mn | Cañón 127 mm, misiles antiaéreos, antibuque, torpedos y defensa cercana; radar 3D, control de tiro, CMS digital en lotes tardíos | Nueva Tirion/Armenelos; construcción 1968–80; servicio 1973–2020 |
| Beleg ASW / 16 | 5.000–6.500 t; 140–155 m; 300–370 | Turbina/diésel; 29–31 kn; 4.500–6.000 mn | Cañón 127 mm, torpedos ligeros, armamento ASW y defensa puntual; sonar de casco, remolcado en lotes tardíos, helicóptero en la mayoría | Pelargir Austral/Calenport; construcción 1965–80; servicio 1970–2020 |
| Ossë multipropósito / 8 | 4.500–5.500 t; 130–145 m; 260–330 | Turbina de gas y diésel; 30–32 kn; 4.000–5.000 mn | Cañón 127 mm, misiles antibuque, defensa local y torpedos; radar 2D/3D, sonar de casco y CMS simplificado | Calenport/Pelargir Austral; construcción 1963–78; servicio 1968–2015 |

#### Fragatas, corbetas y lanchas misilísticas

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Armamento, sensores y CMS | Astillero; construcción y servicio |
|---|---|---|---|---|
| Círdan I / 36 | 3.800–4.800 t; 120–135 m; 210–260 | Turbina/diésel; diésel-eléctrica en algunos lotes; 27–29 kn; 4.500–5.500 mn | Cañón 76–127 mm, misiles antibuque y de punto, torpedos; radar 2D/superficie, sonar de casco, remolcado en parte de la clase; CMS analógico-digital, digital en lotes finales | Calenport/Pelargir Austral; programa inicia en 1955; servicio 1960–2005 |
| Mithlond de transición / 12 | 3.400–4.500 t; 115–130 m; 200–250 | Diésel/turbina; 26–29 kn; 4.000–5.500 mn | Cañón 76–114 mm, misiles antibuque/de punto y torpedos; radar 2D/3D modernizado, sonar de casco, CMS analógico-digital | Calenport/Pelargir Austral; construcción 1960–75; servicio 1965–2005 |
| Nimrodel ASW / 8 | 3.000–4.000 t; 110–125 m; 190–240 | Diésel/turbina o vapor modernizado; 25–28 kn; 4.000–5.000 mn | Cañón 76–114 mm, torpedos y armas antisubmarinas; radar de superficie, sonar de casco, helicóptero ligero si el casco lo permite | Númenor/Calenport; construcción 1950–65; servicio 1955–95 |
| Calenport oceánica / 30 | 1.500–2.200 t; 90–105 m; 115–155 | Diésel; 25–29 kn; 3.000–4.000 mn | Cañón 76 mm, misiles antibuque en parte de los cascos, defensa puntual y torpedos ASW por variante; radar de superficie/vigilancia local, electroóptica, sonar opcional y CMS compacto | Calenport/Pelargir Austral; construcción 1965–80; servicio 1970–2000 |
| Eglarest litoral / 20 | 900–1.300 t; 75–90 m; 85–120 | Diésel; 24–28 kn; 2.000–3.000 mn | Cañón 57–76 mm, armas ligeras, misiles antibuque en algunos; radar de superficie, navegación, electroóptica y CMS de patrulla | Calenport/astilleros regionales; construcción 1968–80; servicio 1973–2000 |
| Nosselië lanzamisiles / 24 | 350–700 t; 45–65 m; 40–65 | Diésel de alta potencia; 35–43 kn; 700–1.300 mn | Cañón 57–76 mm y misiles antibuque; radar de superficie/control de tiro, receptores pasivos y enlace táctico | Astilleros insulares/Calenport; construcción 1970–80; servicio 1975–95 |

#### Submarinos

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y autonomía | Armamento y sensores | Astillero; construcción y servicio |
|---|---|---|---|---|
| Arnor SSBN / 6 | 12.000–16.000 t sumergido; 140–165 m; 130–160 | Nuclear; 24–28 kn de diseño; patrullas de meses, limitadas por víveres y mantenimiento | Disuasión estratégica y torpedos defensivos; sonar de proa, escucha pasiva, navegación inercial y recepción de muy baja frecuencia | Armenelos; construcción 1965–80; servicio 1970–2030 según casco |
| Eärendil SSN / 12 | 6.000–8.000 t sumergido; 105–125 m; 95–125 | Nuclear; 25–30 kn de diseño; alcance oceánico | Torpedos pesados, minas y misiles según lote; sonar de proa, arreglos laterales en lotes avanzados y CMS acústico | Armenelos/Nueva Tirion; construcción 1965–80; servicio 1970–2030 |
| Tolfalas SSK / 18 | 1.800–3.000 t sumergido; 65–85 m; 45–65 | Diésel-eléctrico; 15–20 kn sumergido máximo; 6.000–9.000 mn de tránsito en superficie | Torpedos pesados y minas; sonar pasivo/de proa, comunicaciones breves y navegación inercial básica | Númenor; construcción 1960–80; servicio 1965–2005 |
| Ossë especializado / 6 | 1.000–2.500 t; 45–75 m; 25–60 más especialistas | Diésel-eléctrico o planta experimental; velocidades menores que las clases de combate | Rescate, investigación, buceo e inteligencia oceanográfica; sensores acústicos y de navegación | Númenor/Armenelos; construcción 1965–80; servicio 1970–2010 |

#### Anfibios y guerra de minas

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Equipo, armamento y sensores | Astillero; construcción y servicio |
|---|---|---|---|---|
| Aranath LPH/asalto / 6 | 18.000–30.000 t; 190–230 m; 500–800 + fuerza embarcada | Diésel/turbina; 22–25 kn; 8.000–10.000 mn | Helicópteros, lanchas y vehículos; defensa puntual, radar aéreo/navegación y CMS anfibio | Pelargir Austral/Armenelos; construcción 1960–80; servicio 1965–2015 |
| Pelargir LPD / 8 | 8.000–15.000 t; 150–180 m; 250–400 + tropas | Diésel; 20–23 kn; 6.000–8.000 mn | Dique inundable, carga y vehículos; defensa ligera, radar de navegación y comunicaciones de desembarco | Pelargir Austral; construcción 1965–80; servicio 1970–2015 |
| Forlond LST / 12 | 3.000–8.000 t; 100–140 m; 100–180 | Diésel; 16–20 kn; 5.000–7.000 mn | Transporte de vehículos/carga, piezas ligeras, radar de navegación y radio de convoy | Calenport/Pelargir Austral; construcción 1960–80; servicio 1965–2010 |
| Andúnië logístico / 8 | 2.000–6.000 t; 90–125 m; 80–150 | Diésel; 15–19 kn; 5.000–7.000 mn | Carga, combustible y suministros; armamento ligero, radar y comunicaciones logísticas | Pelargir Austral; construcción 1965–80; servicio 1970–2010 |
| Amon Sûl MCM / 18 | 500–1.200 t; 45–65 m; 35–60 | Diésel; 12–17 kn; 2.000–3.000 mn | Sonar de búsqueda, equipos de inspección y neutralización; casco de baja firma magnética | Calenport/Númenor; construcción 1960–80; servicio 1965–2005 |
| Menel mando MCM / 8 | 1.500–3.000 t; 75–105 m; 70–120 | Diésel; 15–20 kn; 4.000–6.000 mn | Sonar de vigilancia, centro de mando, radares de navegación, enlaces y talleres | Calenport; construcción 1965–80; servicio 1970–2010 |

#### Patrulla y auxiliares de 1980

| Clase / cantidad | Dimensiones y dotación | Propulsión, velocidad y alcance | Equipo y misión | Astillero; construcción y servicio |
|---|---|---|---|---|
| Sírënandë OPV / 30 | 2.000–3.500 t; 85–115 m; 70–120 | Diésel; 18–24 kn; 6.000–8.000 mn | Cañón 40–76 mm, radar de superficie, navegación, HF/VHF/UHF y CMS de vigilancia | Calenport/Sírënandë/Pelargir Austral; construcción 1960–80; servicio 1965–2010 |
| Malaca rápido / 30 | 500–1.200 t; 55–80 m; 35–75 | Diésel; 25–32 kn; 2.500–4.000 mn | Cañón 30–57 mm, radar de superficie, electroóptica y enlace táctico | Astilleros insulares/Calenport; construcción 1965–80; servicio 1970–2005 |
| Aulë petrolero / 14 | 20.000–35.000 t; dotación 180–220 | Diésel; 18–22 kn; 8.000–12.000 mn | Combustible, transferencia, radar y comunicaciones de convoy | Pelargir Austral/Armenelos; construcción 1955–80; servicio 1960–2015 |
| Ecthelion reabastecedor / 12 | 15.000–25.000 t; 250–400 | Diésel; 20–24 kn; 8.000–10.000 mn | Combustible y carga, equipos de transferencia y enlace de grupo | Pelargir Austral; construcción 1960–80; servicio 1965–2015 |
| Harlond transporte / 12 | 8.000–20.000 t; 100–220 | Diésel; 18–22 kn; 8.000–12.000 mn | Carga/vehículos, radar naval-mercante y comunicaciones logísticas | Pelargir Austral/Númenor; construcción 1955–80; servicio 1960–2015 |
| Númenor taller / 8 | 5.000–12.000 t; 180–350 técnicos y tripulantes | Diésel; 16–20 kn; 6.000–9.000 mn | Talleres, grúas, repuestos y reparación adelantada | Númenor; construcción 1955–80; servicio 1960–2015 |
| Estel hospital / 6 | 8.000–18.000 t; 150–350 personal sanitario y tripulación | Diésel; 18–22 kn; 7.000–10.000 mn | Hospital, comunicaciones médicas y navegación; sin armas ofensivas | Conversión/construcción en Pelargir Austral/Armenelos; 1960–80; servicio 1965–2020 |
| Eärendil salvamento / 8 | 3.000–8.000 t; 80–180 | Diésel; 16–20 kn; 5.000–8.000 mn | Remolque, buceo, sonar de trabajo y salvamento | Númenor/Calenport; construcción 1960–80; servicio 1965–2015 |
| Palantír oceanográfico / 10 | 2.000–6.000 t; 70–160 científicos y tripulación | Diésel-eléctrica; 15–20 kn; 6.000–10.000 mn | Cartografía submarina, ecosondas, sonar científico y transmisión de datos | Calenport/Númenor; construcción 1960–80; servicio 1965–2020 |
| Alcarondas I comunicaciones / 8 | 3.000–8.000 t; 100–220 | Diésel; 16–20 kn; 7.000–10.000 mn | HF/satélite, repetidores, enlaces y radar de navegación; defensa ligera | Nueva Tirion/Pelargir Austral; construcción 1965–80; servicio 1970–2020 |

### Catálogo de servicio 2026: ventanas por familia

Las fichas dimensionales, dotaciones, prestaciones, propulsión, armamento, sensores y astilleros de cada clase de 2026 están en la tabla anterior de este mismo capítulo. Esta tabla completa su cronología de construcción y servicio.

| Familia | Inicio de construcción de generación | Servicio previsto | Modernización/retiro |
|---|---:|---:|---|
| Telperion nuclear | 2010 | 2018–2065 | Refit de media vida previsto 2032–40; retirada según casco y reactor |
| Portaaviones convencionales | 1985–2010 | 1990–2055 | Lotes antiguos salen antes; un refit mayor por casco |
| Portaaviones ligeros STOVL | 2000–2018 | 2005–2060 | Refit según edad y estado estructural |
| Submarinos estratégicos | 1970–2018 | 1975–2065 | Modernización central y extensión sujeta a inspección |
| Submarinos nucleares de ataque | 1965–2018 | 1970–2060 | Reacondicionamiento nuclear; retirada si casco no justifica extensión |
| Submarinos AIP | 1990–2020 | 1995–2055 | Refit único; renovación de baterías/sistemas según seguridad |
| Submarinos especiales | 1960–2020 | 1965–2055 | Sustitución por misión y disponibilidad |
| Destructores Gil-galad | 1972–2020 | 1978–2060 | Refit de media vida; retiro normalmente a los 30–40 años |
| Fragatas Círdan/Voronwë | Círdan 1955; Círdan IV 1995; Voronwë 2022 | 1960–2065 | Reemplazo progresivo de Círdan IV por Voronwë |
| Corbetas Calenport | 1998–2022 | 2002–2055 | Refit único; reemplazo por series modulares |
| Escoltas especializados | 1985–2020 | 1990–2060 | No reconstruir cascos antieconómicos |
| Buques de asalto | 1970–2020 | 1975–2060 | Refit de comunicaciones, cubierta y mando |
| LPD/LSD | 1960–2022 | 1965–2065 | Vida aproximada 30–40 años según casco y maquinaria |
| OPV Sírënandë | 1980–2022 | 1985–2055 | Refit de sensores; no convertir en combatiente pesado |
| Patrulleros rápidos | 1980–2023 | 1985–2055 | Ciclos de 20–30 años por uso intensivo |
| Guerra de minas | 1960–2023 | 1965–2060 | Renovación por bloques de vehículos y plataformas |
| Hidrografía/oceanografía | 1950–2023 | 1955–2060 | Renovar sensores; refit de misión una vez |
| Auxiliares logísticos | 1950–2024 | 1955–2065 | Refit de transferencia, comunicaciones y control de averías |

## 5. Infantería de Marina y proyección rápida

La Infantería de Marina es el componente terrestre expedicionario de la Armada. Su misión no es ocupar indefinidamente territorios: protege puertos y evacuaciones, refuerza guarniciones, responde a crisis, ayuda tras desastres, asegura instalaciones navales y puede desembarcar temporalmente para restablecer comunicaciones o permitir la llegada de fuerzas civiles.

### Evolución

| Periodo | Organización y empleo |
|---|---|
| 1875–1900 | Batallones embarcados, guardias de arsenales y destacamentos de puerto; armas ligeras, artillería de desembarco y transporte en vapor. Fuerza profesional pequeña con milicias territoriales auxiliares. |
| 1900–1918 | Brigadas permanentes por cuenca oceánica, ingenieros, señales y sanidad; desembarcos desde transportes y buques-dique iniciales. |
| 1919–1945 | Regimientos expedicionarios con artillería, zapadores, comunicaciones y aviación de observación; desarrollo de lanchas y logística anfibia. |
| 1946–1980 | Fuerza anfibia moderna ligada a LPH/LPD/LST, helicópteros, vehículos anfibios y transporte aéreo; brigadas con rotación de respuesta inmediata. |
| 1981–2026 | Fuerza conjunta modular: unidades ligeras, mecanizadas y de seguridad portuaria; aviación de ala rotatoria y transporte, drones de reconocimiento, sanidad, ingeniería y logística. En 2026 se propone una reserva de respuesta humanitaria y evacuación con los mismos estándares de preparación que la fuerza de combate. |

### Estructura de 2026 propuesta

- **4 Mandos Expedicionarios Marítimos**, uno por Atlántico norte, Atlántico occidental/Caribe, Pacífico y rutas del Índico. Son cuarteles de generación y mando; no equivalen a cuatro ejércitos independientes.
- **4 divisiones ligeras de Infantería de Marina**, cada una con 2–3 brigadas, artillería móvil, defensa aérea de corto alcance, ingenieros, comunicaciones y sanidad.
- **8 brigadas de respuesta y seguridad territorial**, asignadas a puertos, archipiélagos, instalaciones críticas y refuerzo rápido; cada una con rotación de alerta, entrenamiento y descanso.
- **4 grupos de aviación expedicionaria** con helicópteros de transporte y rescate, aeronaves de apoyo logístico, UAV y destacamentos embarcados. Los cazas embarcados siguen bajo mando de aviación naval, aunque apoyen a los marines.
- **4 grupos logísticos anfibios** con ingenieros, depósitos, mantenimiento, agua, energía portátil, hospitales de campaña y transporte de vehículos.
- **Fuerza activa de planificación: 150.000–190.000**; reserva entrenada: 80.000–120.000. Son rangos propuestos, no cifras canónicas. La dotación permite relevos, seguridad de bases y respuesta simultánea limitada, no desplegar toda la fuerza a la vez.

El empleo se escalona: primera respuesta de elementos embarcados en 24–72 horas; una brigada reforzada en días a pocas semanas según distancia y transporte; una división requiere preparación logística y protección naval. No se promete llegada simultánea a todos los territorios. Los despliegues priorizan evacuación, ayuda civil y protección temporal; las operaciones prolongadas exigen autorización política, líneas de abastecimiento y reglas de relevo.

## 6. Arquitectura de tecnología naval

### Propulsión y energía

- **1875–1900:** vapor alternativo, calderas de carbón; transición experimental a calderas de mayor presión y turbinas en unidades rápidas. Dos o más ejes conforme al casco; diésel aún marginal.
- **1900–1945:** turbinas de vapor, carbón y luego petróleo; motores diésel en submarinos y auxiliares. Reducción de vibración y mejor control de calderas. La propulsión no supera por sí sola el límite del casco y del combustible.
- **1946–1970:** turbina de vapor en grandes buques, diésel y turbinas de gas en escoltas, energía nuclear en portaaviones/submarinos de punta; generación separada para radar y computación.
- **1970–2000:** combinaciones diésel-gas, automatización de planta, reducción de firma acústica; nuclear para plataformas que justifican el costo de ciclo de vida.
- **2000–2026:** propulsión eléctrica integrada en ciertas fragatas y buques especializados, turbina para sprint y diésel-eléctrica para búsqueda silenciosa; reactores navales solo en portaaviones y submarinos de alto valor. No se instala propulsión nuclear en escoltas por prestigio: exige tripulación técnica, infraestructura, combustible, seguridad y desmantelamiento.

### Sensores y radares

- **Hasta 1914:** observación visual, óptica, telémetros, sondas, compás, señales; radio de telegrafía inalámbrica hacia 1900.
- **1915–1945:** hidrófonos y sonar activo/pasivo; radar de alerta y control de tiro desde los años treinta y cuarenta; centros de información inicialmente manuales y electromecánicos.
- **1946–1969:** radar 2D/3D, IFF, sonar de casco y remolcado, procesamiento por operadores y computadoras tempranas. Se crea una imagen de combate común, pero no fusión algorítmica omnisciente.
- **1970–1999:** radares de procesamiento digital y barrido electrónico por lotes; sensores electroópticos, interceptación electrónica, enlaces tácticos, sonar de profundidad variable. AESA plenamente operativo primero en prototipos y unidades de punta.
- **2000–2026:** AESA de múltiples funciones, sensores pasivos distribuidos, sonar de gran apertura, arreglos remolcados, boyas acústicas, UAV, navegación resiliente y fusión de datos. El sistema Palantír‑2087V se asigna al procesamiento sonar de las clases avanzadas, no a toda la flota. En 2026 se conserva redundancia local: radar, sonar, navegación y control de armas deben funcionar degradados aunque OceanNet o el enlace satelital caigan.

### CMS, comunicaciones y ciberresiliencia

El CMS evoluciona de plot manual (1875), dirección electromecánica de tiro (1900–45), centro de información con consolas y computación central (1945–70), arquitectura digital integrada (1970–2000) a módulos interoperables con datos autenticados y fusión multisensor (2000–26). Automatiza seguimiento, clasificación y recomendación; una persona responsable autoriza el empleo de armas.

Comunicaciones por etapa: banderas/reflectores y mensajeros; radio HF; VHF/UHF y teletipo; enlaces de datos tácticos; satélite y fibra en tierra; OceanNet de uso naval-logístico desde su etapa operativa según cronología del canon. OceanNet no reemplaza enlaces de emergencia ni es una red de control de armas abierta. Se aplican separación de redes, operación sin conexión, autenticación, registros, llaves de reserva y procedimientos manuales.

## 7. Tecnología extranjera incorporada y atribución

Valinor puede adoptar tecnologías desarrolladas en otros países sin reescribir su origen histórico. Una tecnología se considera **capacidad valinari** si la industria local domina integración, adaptación, ensayo, mantenimiento, formación y una parte sustancial de la fabricación. Se registran autoría, licencia/transferencia y aportación propia por separado.

- **Estados Unidos:** diseño de grupos de portaaviones, integración de CMS y sensores, logística oceánica, sistemas de combate naval y estandarización de interfaces.
- **Reino Unido:** tradición antisubmarina, turbinas navales, diseño de fragatas oceánicas, sonar remolcado y doctrina de convoyes.
- **Francia:** autonomía de diseño, reactores navales, misiles y plataformas nacionales; integración de sensores y armas bajo control soberano.
- **Israel:** guerra electrónica, sensores compactos, enlaces, defensa puntual y ciclos rápidos de actualización; se adapta sin trasladar literalmente su escala geográfica.
- **Unión Soviética/Rusia:** ingeniería robusta de submarinos, misiles navales y soluciones para operar en ambientes extremos; adaptación con pruebas de fiabilidad y mantenimiento locales.
- **China:** construcción seriada, modularidad, automatización de astilleros y cadena industrial de gran volumen, especialmente desde finales del siglo XX. No se retroproyecta su escala moderna al siglo XIX.
- **Japón:** calidad de construcción, maquinaria, electrónica naval, acústica y precisión de producción.

El aprendizaje se realiza por licencias, intercambio científico, adquisiciones, ingeniería inversa legal donde corresponda y desarrollo propio. Valinor importa maquinaria especializada, software/propiedad intelectual y componentes de frontera cuando resulte más eficiente; retiene diseño, integración, reparación y producción de componentes estratégicos maduros conforme a la decisión industrial selectiva de AM1.

## 8. Comparación de escala y sostenibilidad

En 1980, la propuesta de 427 buques es menor que la fuerza activa estadounidense de referencia y superior a la británica en varias categorías, aunque los criterios de conteo no son idénticos. La US Navy contabilizaba 530 buques activos en su tabla histórica de fuerza; la fuerza británica se publica en categorías parlamentarias y excluye algunos auxiliares de forma distinta. [NHHC, niveles de fuerza](https://www.history.navy.mil/research/histories/ship-histories/us-ship-force-levels.html), [Hansard, barcos de la Royal Navy, 1980](https://api.parliament.uk/historic-hansard/written-answers/1981/may/18/royal-navy-ships).

En 2026, el inventario canónico de referencia de 615 plataformas no se compara directamente con los 287 buques de batalla de la proyección estadounidense: incluye patrulleros, auxiliares, hidrografía y vehículos no tripulados. Toda comparación presenta por separado **buques de combate comparables** y **plataformas navales totales**.

La sostenibilidad depende de cuatro pruebas anuales:

1. porcentaje de cascos disponibles y días de despliegue realmente sostenibles;
2. capacidad de los astilleros para construir y reparar simultáneamente sin atrasos crónicos;
3. existencias de municiones, repuestos, combustible y dotaciones certificadas;
4. costo de ciclo de vida dentro del techo presupuestario calculado por porcentaje del PIB estadounidense del mismo año.

Si una clase falla dos ciclos de revisión consecutivos, se reduce su número, se simplifica o se retira. No se sostiene una cifra de inventario a costa de buques permanentemente inoperativos.

## 9. Asuntos explícitamente abiertos

- La serie anual de PIB valinari 1875–2026 aún debe construirse para convertir todos los porcentajes comparativos en presupuestos nominales/PPA.
- En 1980 debe fijarse qué dato estadounidense se usa en toda la serie: apropiación, autoridad presupuestaria o gasto ejecutado; el cálculo de 47,0 mil millones es provisional.
- Las cantidades intermedias de 1900, 1914, 1945, 1960 y 2000 son escenarios de AM1, no datos confirmados.
- Los nombres de clase repetidos (Círdan, Eärendil, Aulë, Gil-galad) deben distinguirse siempre por tipo y generación.
- Los astilleros asignados son polos propuestos y requieren capacidad anual, diques, personal, suministro de acero y localización de mantenimiento.
- La distribución de 615 plataformas se adopta como estructura canónica de referencia; no constituye una lista nominal casco por casco ni demuestra disponibilidad efectiva. La disponibilidad de 449 sigue siendo una hipótesis que requiere una serie operacional para validarse.
- La Infantería de Marina de 150.000–190.000 activos y 80.000–120.000 reservas es una propuesta de escala; falta conciliarla con población, fuerzas terrestres, presupuesto de personal y transporte estratégico.

## Fuentes de referencia

- [Naval History and Heritage Command: presupuesto de la Marina de EE. UU. 1794–2014](https://www.history.navy.mil/research/library/online-reading-room/title-list-alphabetically/b/budget-of-the-us-navy-1794-to-2004.html)
- [Naval History and Heritage Command: niveles históricos de la flota estadounidense](https://www.history.navy.mil/research/histories/ship-histories/us-ship-force-levels.html)
- [FRED: PIB anual de EE. UU.](https://fred.stlouisfed.org/data/MKTGDPUSA646NWDB)
- [Department of the Navy: presupuesto FY2026](https://www.secnav.navy.mil/fmc/fmb/Documents/26pres/Highlights_Book.pdf)
- [Hansard: inventario de la Royal Navy, 1980](https://api.parliament.uk/historic-hansard/written-answers/1981/may/18/royal-navy-ships)
- [Royal Navy: fragata Type 26](https://www.royalnavy.mod.uk/equipment/ships/city-class)
- [U.S. Navy: sistema antisubmarino AN/SQQ‑89](https://www.navy.mil/Resources/Fact-Files/Display-FactFiles/Article/2166784/ansqq-89v-undersea-warfare-anti-submarine-warfare-combat-system/ansqq-89v-undersea-warfare-anti-submarine-warfare-combat-system/)
- [U.S. Navy: destructores Arleigh Burke](https://www.navy.mil/Resources/Fact-Files/Display-FactFiles/Article/2169871/destroyers-ddg-51/destroyers-ddg-51/)
+

## 10. Desarrollo acumulativo de la industria militar, 1750–2026

**Estatus:** canon V16 integrado. Las fechas anuales expresan fases de maduración industrial y no presuponen una invención nueva cada año. Se conservan los hitos canónicos de COFOVAL (1839), la flota de 1875, OceanNet (servicio institucional limitado desde 1959; consolidación institucional desde 1969) y un refit integral principal de media vida por casco construido desde 1945. Las capacidades por plataforma y los lotes concretos se desarrollan en sus fichas y no se extrapolan a toda la flota.

### 10.1 Desarrollo anual

#### 1750–1759: Arsenales artesanales y manufactura de vela
- **1750:** inventario de talleres, hornos y depósitos.
- **1751:** inspección de cañones, cureñas y munición.
- **1752:** ensayo de hierro y bronce para usos navales.
- **1753:** registro de corrosión, roturas y reparaciones.
- **1754:** normalización inicial de plantillas de inspección.
- **1755:** formación de aprendices de fundición y carpintería naval.
- **1756:** contratos de carbón vegetal, cobre y madera.
- **1757:** mejora de almacenes secos y seguridad contra incendios.
- **1758:** pruebas de reparación de casco, velamen y aparejo.
- **1759:** balance de producción, defectos y compras.

#### 1760–1769: Arsenales y contratos de Casas
- **1760:** actualización de contratos de suministro.
- **1761:** separación de lotes de pólvora y calibres.
- **1762:** reparación de bombas, cabrestantes y anclas.
- **1763:** prueba de intercambiabilidad de piezas sencillas.
- **1764:** registro de costes y tiempo fuera de servicio.
- **1765:** formación en medición y ajuste de piezas.
- **1766:** reservas de cadenas, aparejos y anclas.
- **1767:** ensayos de brea, barnices y protección salina.
- **1768:** planos de construcción y reparación en arsenales.
- **1769:** balance anual de producción y disponibilidad.

#### 1770–1779: Mecanización de talleres
- **1770:** incorporación de tornos y taladros hidráulicos.
- **1771:** estudio de fallas en cañones y montajes.
- **1772:** registro de origen y composición de metales.
- **1773:** mejora de moldes y repetibilidad de fundición.
- **1774:** plantillas para montar mecanismos navales.
- **1775:** ampliación de escuelas de artillería y talleres.
- **1776:** separación de zonas de fundición y pólvora.
- **1777:** medición de vida útil de herramientas.
- **1778:** inspección de buques antes y después de campaña.
- **1779:** revisión de contratos con criterios de calidad.

#### 1780–1789: Normalización y reparación naval
- **1780:** normalización de dimensiones navales seleccionadas.
- **1781:** comparación de fundiciones de Casas distintas.
- **1782:** registro común de repuestos esenciales.
- **1783:** reparación modular de bombas y válvulas.
- **1784:** reservas de madera curada y hierro.
- **1785:** criterios para aceptar o rechazar cañones.
- **1786:** inspección de almacenes de pólvora.
- **1787:** formación en planos y medición.
- **1788:** transporte prioritario a puertos principales.
- **1789:** informe anual de preparación de arsenales.

#### 1790–1799: Calibres normalizados y máquinas-herramienta
- **1790:** unificación de calibres y fichas de munición.
- **1791:** especificaciones comunes para cañones y montajes.
- **1792:** ampliación de máquinas-herramienta de arsenales.
- **1793:** bancos de prueba de pólvora y mecanismos.
- **1794:** trazabilidad de fabricante y fecha por lote.
- **1795:** prototipos de bombas y maquinaria portuaria.
- **1796:** inspección independiente del proveedor.
- **1797:** inventario de herramientas de reparación.
- **1798:** planos normalizados en contratos públicos.
- **1799:** revisión de costes, fallas y compras.

#### 1800–1809: Arsenales mecanizados
- **1800:** ampliación de talleres de bombas y maquinaria.
- **1801:** piezas de hierro con tolerancias más estrechas.
- **1802:** compatibilidad de repuestos entre buques.
- **1803:** máquinas estacionarias para muelles y talleres.
- **1804:** mejor almacenamiento y seguridad de pólvora.
- **1805:** formación de inspectores técnicos.
- **1806:** ampliación de grúas, varaderos y rampas.
- **1807:** ensayos de achique y ventilación.
- **1808:** inventario de hierro, cobre y madera.
- **1809:** auditoría de reparaciones y disponibilidad.

#### 1810–1819: Vapor experimental y talleres
- **1810:** prototipo de máquina de vapor estacionaria.
- **1811:** prueba de calderas para bombas y remolcadores.
- **1812:** medición de corrosión en hierro salino.
- **1813:** banco de prueba de ejes y engranajes.
- **1814:** fundición de piezas navales pesadas.
- **1815:** formación de caldereros y mecánicos.
- **1816:** protocolos de presión y seguridad industrial.
- **1817:** prueba de remolcadores de puerto.
- **1818:** medición del consumo de carbón.
- **1819:** selección de diseños aptos para producción.

#### 1820–1829: Maquinaria y transporte técnico
- **1820:** máquinas-herramienta para ejes y válvulas.
- **1821:** contratos de mantenimiento de calderas.
- **1822:** motores auxiliares en embarcaciones de servicio.
- **1823:** certificación de hierro para presión y estructura.
- **1824:** mejora del transporte de carbón.
- **1825:** cursos de dibujo mecánico.
- **1826:** comparación de hornos y máquinas.
- **1827:** depósitos de válvulas y bombas.
- **1828:** registro de vibración y fugas.
- **1829:** programación del siguiente lote de maquinaria.

#### 1830–1838: Infraestructura previa a COFOVAL
- **1830:** integración de arsenales con transporte e inversión.
- **1831:** estudio de cuellos de botella de carbón y mineral.
- **1832:** ampliación de enseñanza de ingeniería práctica.
- **1833:** pruebas de vapor en talleres y remolcadores.
- **1834:** comparación regional de hierro.
- **1835:** coordinación de compras de cobre y maquinaria.
- **1836:** rutas de suministro a astilleros.
- **1837:** registro de costes de diques y grúas.
- **1838:** preparación del programa industrial de largo plazo.

#### 1839–1849: COFOVAL e industria pesada
- **1839:** COFOVAL inicia apoyo a infraestructura industrial y naval.
- **1840:** levantamiento de necesidades de carbón, hierro y transporte.
- **1841:** financiación de fundiciones y talleres prioritarios.
- **1842:** becas de ingeniería y metalurgia.
- **1843:** coordinación territorial de calderas y ejes.
- **1844:** ampliación de diques y grúas.
- **1845:** registros de calidad y costes por contrato.
- **1846:** ensayos de laminados estructurales.
- **1847:** red de inspección metalúrgica.
- **1848:** evaluación de capacidades que conviene producir localmente.
- **1849:** COFOVAL inicia apoyo a infraestructura industrial y naval.

#### 1850–1859: Vapor naval y componentes
- **1850:** prueba de máquinas marinas más potentes.
- **1851:** talleres de hélices y ejes.
- **1852:** normalización de válvulas y calderas.
- **1853:** formación de mecánicos navales.
- **1854:** resistencia de hierro laminado para cascos.
- **1855:** producción de remaches y placas.
- **1856:** remolcadores integrados en la logística de astillero.
- **1857:** registro de vibración y fatiga.
- **1858:** reparación en puertos secundarios.
- **1859:** diseño de cascos para maquinaria más pesada.

#### 1860–1869: Hierro, blindaje y transición al acero
- **1860:** prueba de cascos de hierro en servicio.
- **1861:** ampliación de laminación de placas.
- **1862:** ensayos balísticos de placas y soportes.
- **1863:** control de remaches y juntas.
- **1864:** registro de resultados de blindaje.
- **1865:** gradas para cascos mayores.
- **1866:** formación en inspección estructural.
- **1867:** clasificación de acero por composición.
- **1868:** protección de maquinaria y pañoles.
- **1869:** plan de transición a acero naval.

#### 1870–1874: Preparación del inventario de 1875
- **1870:** construcción de cascos del programa de 1875.
- **1871:** prueba de placas, calderas y artillería.
- **1872:** expansión de carbón y repuestos de vapor.
- **1873:** normalización de herramientas de astillero.
- **1874:** formación de dotaciones de máquinas.

#### 1875–1884: Acero, blindaje y turbinas tempranas
- **1875:** sostenimiento industrial del inventario de 332 unidades.
- **1876:** separación productiva de acorazados, corbetas y auxiliares.
- **1877:** ampliación de talleres de placas y calderas.
- **1878:** ensayos de tratamientos superficiales por lote.
- **1879:** registro de defectos de casco y máquina.
- **1880:** depósitos de carbón en bases y estaciones.
- **1881:** turbina naval en banco de prueba.
- **1882:** primer buque de ensayo con turbina naval entra en servicio limitado, doce años antes de la aplicación de referencia; no se generaliza a la flota.
- **1883:** reparación de ejes y hélices en bases secundarias.
- **1884:** plan de sustitución de clases envejecidas.

#### 1885–1894: Metalurgia avanzada y turbina naval
- **1885:** ensayos de blindaje cementado propio.
- **1886:** prueba de placas de blindaje cementado de proceso valinari, precedida por investigación y metalurgia desde décadas anteriores.
- **1887:** buque de pruebas de turbina sujeto a ensayo en tierra.
- **1888:** lote limitado de placas cementadas supera ensayos de inspección y se instala en unidades prioritarias; aún no es estándar universal.
- **1889:** cañones de mayor presión y dirección de tiro.
- **1890:** laboratorio metalográfico y análisis de fallas.
- **1891:** mejora de lubricantes y calderas.
- **1892:** componentes comunes de maquinaria por clase.
- **1893:** pruebas costeras de radio.
- **1894:** serie naval de acero y propulsión mejorados.

#### 1895–1904: Series y radio marítima
- **1895:** producción seriada de piezas probadas.
- **1896:** turbinas en buques rápidos seleccionados.
- **1897:** radio inalámbrica en buques y estaciones.
- **1898:** bancos de prueba de transmisores.
- **1899:** normalización de proyectiles y montajes.
- **1900:** mecanización de laminado y mecanizado.
- **1901:** formación de radiooperadores y electricistas.
- **1902:** telémetros y dirección central de tiro.
- **1903:** depósitos de carbón, combustible y munición.
- **1904:** comparación de coste de turbina y máquina alternativa.

#### 1905–1914: Dreadnoughts y movilización
- **1905:** diseño de grandes acorazados y maquinaria.
- **1906:** diques para dreadnoughts y cruceros de batalla.
- **1907:** certificación de blindaje por lote.
- **1908:** motores diésel para submarinos.
- **1909:** radio y control centralizado de tiro.
- **1910:** reserva de hélices, ejes y calderas.
- **1911:** pruebas de torpedos y lanzadores.
- **1912:** escuelas de ingeniería naval y electricidad.
- **1913:** producción de minadores y buques logísticos.
- **1914:** plan de sostenimiento oceánico prolongado.

#### 1915–1924: Producción de guerra y reconversión
- **1915:** producción de munición y piezas de desgaste.
- **1916:** turnos de astillero para reparación urgente.
- **1917:** piezas comunes de destructores y escoltas.
- **1918:** mejora de motores diésel submarinos.
- **1919:** radio y radiogoniometría.
- **1920:** protección de producción civil esencial.
- **1921:** registro de daños para rediseño.
- **1922:** hidrófonos y escucha acústica.
- **1923:** reconversión de líneas de emergencia.
- **1924:** coste de mantenimiento de flotas.

#### 1925–1934: Aviación y acústica
- **1925:** motores aeronáuticos navales.
- **1926:** bancos de prueba de hélices y compresores.
- **1927:** combustibles y lubricantes.
- **1928:** hidrófonos para escoltas.
- **1929:** escuelas de mantenimiento aeronáutico.
- **1930:** catapultas y elevadores de cubierta.
- **1931:** torpedos y mecanismos de lanzamiento.
- **1932:** radares experimentales y electrónica.
- **1933:** óptica naval de precisión.
- **1934:** dispersión de proveedores ante crisis.

#### 1935–1944: Movilización, radar y sonar
- **1935:** contratos acelerados de escoltas y logística.
- **1936:** producción de radio, radar y acústica.
- **1937:** torpedos y cargas navales.
- **1938:** astilleros de apoyo para series normalizadas.
- **1939:** trazabilidad e inspección de lotes.
- **1940:** formación técnica a escala ampliada.
- **1941:** dispersión de combustible y repuestos.
- **1942:** centros de reparación avanzada.
- **1943:** contratos de movilización con privados.
- **1944:** reconversión parcial de fábricas civiles.

#### 1945–1954: Refits, laboratorios y diseño modular
- **1945:** reserva de crecimiento para refit único de media vida.
- **1946:** retiro de cascos cuyo refit no es rentable.
- **1947:** laboratorios de radar, sonar y comunicaciones.
- **1948:** mantenimiento nuclear especializado.
- **1949:** normalización de cableado y electrónica.
- **1950:** reservas de repuestos y herramientas.
- **1951:** equipos de integración de sensores.
- **1952:** bancos terrestres de CMS.
- **1953:** coordinación de astilleros públicos y privados.
- **1954:** programación de refit por clase.

#### 1955–1964: Nuclear, Círdan y OceanNet precursora
- **1955:** comienza el programa moderno de fragatas Círdan.
- **1956:** centros de construcción y mantenimiento nuclear.
- **1957:** radar 2D/3D en buques prioritarios.
- **1958:** líneas de datos dedicadas entre centros navales.
- **1959:** OceanNet alcanza funcionamiento operativo inicial entre centros navales, científicos y administrativos; la capacidad embarcada continúa limitada.
- **1960:** turbinas de gas y generadores.
- **1961:** sonar remolcado y procesamiento acústico.
- **1962:** talleres para submarinos.
- **1963:** pruebas de OceanNet; operación fijada en 1959.
- **1964:** seguridad de red y operación desconectada.

#### 1965–1974: CMS temprano y mantenimiento
- **1965:** Círdan II y estandarización de interfaces.
- **1966:** sensores conectados a centros de mando.
- **1967:** CMS digital temprano en unidades seleccionadas.
- **1968:** reparación de radar y sonar.
- **1969:** OceanNet obtiene consolidación institucional federal; se amplían nodos y protocolos comunes sin suponer conectividad permanente en cada buque.
- **1970:** enlaces tácticos.
- **1971:** helicópteros ASW y sonoboyas.
- **1972:** bancos de propulsión combinada.
- **1973:** refit de Círdan tempranos.
- **1974:** revisión de disponibilidad y coste.

#### 1975–1984: Industria de la flota 1980
- **1975:** construcción de Círdan III.
- **1976:** producción de destructores AAW y ASW.
- **1977:** turbina, diésel y generación a bordo.
- **1978:** radares y CMS digitales por bloques.
- **1979:** sonar remolcado para escoltas.
- **1980:** OceanNet para logística y mantenimiento.
- **1981:** series de Calenport, Eglarest y Nosselië.
- **1982:** auxiliares y anfibios.
- **1983:** auditoría de capacidad para la flota propuesta de 427.
- **1984:** diseño de sucesores y refits.

#### 1985–1994: Microelectrónica y arquitectura modular
- **1985:** transición Círdan III y módulos comunes.
- **1986:** radares 3D y guerra electrónica.
- **1987:** producción de electrónica madura.
- **1988:** simuladores de mantenimiento.
- **1989:** diseño de siguientes bloques.
- **1990:** reducción acústica submarina.
- **1991:** repositorios de software/configuración.
- **1992:** proveedores alternativos.
- **1993:** electroóptica en patrulleros.
- **1994:** refits definidos por casco.

#### 1995–2004: Círdan IV y combate integrado
- **1995:** comienza construcción Círdan IV.
- **1996:** redes entre buques, bases y arsenales.
- **1997:** integración de radar, sonar, EW y armas en CMS.
- **1998:** seguimiento digital de repuestos.
- **1999:** construcción modular por bloques.
- **2000:** satélites y navegación resiliente.
- **2001:** AESA en pruebas y plataformas de punta.
- **2002:** bancos de integración en tierra.
- **2003:** vehículos submarinos de inspección.
- **2004:** plan de refit Círdan IV para 2005–15.

#### 2005–2014: Refit, AESA y propulsión eléctrica
- **2005:** refit de media vida Círdan IV.
- **2006:** renovación de radar, CMS, comunicaciones y sonar.
- **2007:** margen eléctrico y refrigeración donde el diseño lo permita.
- **2008:** AESA para unidades prioritarias.
- **2009:** pruebas de propulsión eléctrica en clases adecuadas.
- **2010:** ciberseguridad y redes separadas.
- **2011:** mantenimiento predictivo.
- **2012:** producción local de sensores y componentes maduros.
- **2013:** compatibilidad con equipos licenciados.
- **2014:** certificación de un refit integral por casco.

#### 2015–2024: Autonomía selectiva y Voronwë
- **2015:** diseño de nueva fragata oceánica.
- **2016:** Palantír-2087V para sonar avanzado.
- **2017:** vehículos navales no tripulados.
- **2018:** analítica de flota y mantenimiento predictivo.
- **2019:** proveedores alternativos para piezas críticas.
- **2020:** fabricación aditiva de repuestos certificados.
- **2021:** reservas de semiconductores especializados.
- **2022:** comienza la construcción de la primera fragata Voronwë; se incorporan inspección automatizada de soldaduras y control digital de configuración al programa.
- **2023:** auditoría de capacidad de astilleros.
- **2024:** construcción de Voronwë desde 2022.

#### 2025–2026: Capacidad industrial integrada
- **2025:** conciliación de buques, personal, repuestos, munición y presupuesto.
- **2026:** cuadro de disponibilidad, astilleros, modernizaciones y proveedores.


### 10.2 Familias industriales y producción por tipo

| Familia industrial | Maduración y capacidades | Clases navales que sostiene |
|---|---|---|
| Minería y materiales | Hierro, carbón, cobre, níquel, cobalto, químicos, refractarios; extracción, transporte, reservas y control de origen. Ubicaciones mineras concretas dependen de estudios y fichas territoriales. | Cascos, placas, ejes, motores, generadores, cables, baterías, munición y sensores. |
| Siderurgia y metalurgia | Fundición, laminación, acero naval, aleaciones, blindajes, soldadura, tratamientos térmicos, metalografía y certificación de lotes. El blindaje cementado valinari es un proceso propio inspirado en el desarrollo internacional, no el producto histórico Vickers. | Acorazados Círdan/Eärendil/Gil-galad, dreadnoughts, destructores, submarinos, fragatas y portaaviones. |
| Máquinas, turbinas y motores | Máquinas de vapor y calderas; turbinas; diésel; turbinas de gas; reductores, ejes, cojinetes, generadores y control de planta. | Desde acorazados y cañoneras de vapor hasta Círdan/Voronwë, destructores, submarinos, petroleros y reabastecedores. |
| Astilleros y construcción | Diseño, corte, conformado, soldadura, montaje por bloques, botadura, integración, pruebas de mar y reparación; diques de construcción y mantenimiento planificados como red. | Acorazados, cruceros, destructores, fragatas, submarinos, anfibios, OPV y auxiliares. |
| Artillería, armas y municiones | Cañones, montajes, torpedos, minas, misiles por época, propelentes, espoletas, lotes de prueba y almacenamiento seguro. | Artillería de 57–305 mm en clases antiguas; armamento de superficie y submarino en clases modernas, de acuerdo con la época. |
| Aeronáutica naval | Motores, estructuras, aviónica, helicópteros, aviones embarcados, catapultas, elevadores, UAV y mantenimiento de cubiertas. | Portaaviones Aulë/Anárion/Varda y Telperion; helicópteros ASW y aeronaves de patrulla/logística. |
| Electrónica, radar y comunicaciones | Radio, radar 2D/3D, AESA por fases, antenas, cableado, satélite, navegación, OceanNet y seguridad electrónica. | De radios y telémetros a radares de grupo, CMS y enlaces redundantes. |
| Acústica y guerra submarina | Hidrófonos, sonar activo/pasivo, arreglos de casco/remolcados, sonoboyas, procesamiento, vehículos de inspección y Palantír-2087V en clases avanzadas. | Destructores Beleg, fragatas, submarinos, MCM y buques oceanográficos. |
| CMS y software | Trazado manual; dirección electromecánica; computación central; CMS digital modular; fusión multisensor y mantenimiento predictivo. | Cruceros de mando, destructores, fragatas, submarinos y buques anfibios, con capacidades distintas por clase. |
| Logística y reparación | Combustible, munición, remolque, hospitales, grúas, talleres, reabastecimiento, rescate, repuestos, diques y unidades móviles. | Toda la flota; auxiliares Aulë, Ecthelion, Harlond, Númenor, Estel, Eärendil, Palantír y Voronwë. |
| Infantería de Marina | Armas ligeras, comunicaciones, ingeniería, movilidad anfibia, sanidad, agua, energía portátil, vehículos, protección y entrenamiento. | Batallones embarcados, regimientos expedicionarios, brigadas, grupos anfibios y respuesta territorial. |
| Ensayo y certificación | Pruebas de materiales, presión, corrosión, vibración, fatiga, compatibilidad electromagnética, software y control de calidad. | Cada clase y cada lote; requisito para autorizar entrada en servicio y modernización de media vida. |

### 10.3 Fabricación y sostenimiento clase por clase

| Clases de AM1 | Base industrial necesaria | Política de fabricación y mantenimiento |
|---|---|---|
| Acorazados Círdan, Eärendil y Gil-galad (1875) | Acería pesada, placas, vapor, cañones, diques, grúas y telémetros ópticos. | Producción local progresiva; series cortas; repuestos centralizados en arsenales principales y talleres de base. |
| Monitores Aulë y Minas Tirith | Cascos de poco calado, torres, blindaje y máquinas compactas. | Compartir artillería y placas con buques mayores donde sea posible; mantener maquinaria y casco específicos de litoral. |
| Cruceros, corbetas, avisos y cañoneras | Cascos ligeros, motores, piezas medianas, navegación y almacenes de carbón. | Componentes comunes por familia; reparación regional y reconversión de cascos aptos a instrucción o apoyo. |
| Torpederos Forlond/Calenhad | Calderas compactas, cascos rápidos, torpedos, metalurgia y mantenimiento portuario. | Series cortas y construcción distribuida; retiro temprano si planta y casco dejan de ser rentables. |
| Anárion dreadnought y Gil-galad cruceros de batalla | Grandes placas, turbinas, artillería pesada, radio, dirección de tiro y diques mayores. | Concentrar integración y pruebas; asegurar repuestos de alto plazo de entrega; limitar cantidad a la capacidad de sostenimiento. |
| Submarinos de todas las generaciones | Casco resistente, soldadura, diésel, baterías, válvulas, sonar, navegación y, para nucleares, instalaciones de seguridad especializadas. | Centros específicos de construcción y mantenimiento; trazabilidad completa y reservas para componentes críticos. |
| Portaaviones Aulë/Anárion/Varda y Telperion | Grandes cascos, planta propulsora, generación eléctrica, control aéreo, cubierta, elevadores, talleres aeronáuticos y sistemas de mando. | Pocas unidades de alto coste; grupo aéreo, escoltas, auxiliares y diques se presupuestan como un solo sistema de fuerza. |
| Cruceros Turgon/Eärendil/Noldor | Turbinas, radar, CMS, comunicaciones, armas y centros de mando. | Subclases AAW, multimisión y mando comparten casco/maquinaria cuando sea viable; electrónica por bloques y bancos de prueba. |
| Destructores Gil-galad/Beleg/Ossë | Planta propulsora, radar, sonar, EW, CMS, helicópteros y generación eléctrica. | Interfaces comunes, repuestos compartidos y variante especializada definida desde el diseño. |
| Fragatas Círdan/Mithlond/Nimrodel/Voronwë | Construcción seriada, diésel/turbina, radar, sonar, helicóptero, CMS modular y reservas para refit. | Series por bloques y una sola modernización integral de media vida por casco desde 1945; Círdan IV reemplazado progresivamente por Voronwë. |
| Corbetas Calenport/Eglarest y lanchas Nosselië | Motores diésel, sensores compactos, comunicaciones, cañones y reparación regional. | Mantener costo bajo y alto contenido común; reservar sensores avanzados para variantes que los justifiquen. |
| Anfibios Aranath/Pelargir/Forlond/Andúnië | Cubiertas, diques inundables, rampas, grúas, comunicaciones, hospitales y mantenimiento de vehículos. | Diseñarlos para transporte, sostenimiento y ayuda humanitaria además de desembarco; incluir los grupos logísticos asociados. |
| MCM Amon Sûl/Menel | Cascos de baja firma, sonar de búsqueda, navegación, vehículos remotos y especialistas. | Renovar vehículos y sensores por bloques antes de reemplazar el casco; sostener formación técnica. |
| OPV Sírënandë y patrulleros Malaca | Casco robusto, diésel comercial adaptado, radar de superficie, electroóptica y comunicaciones. | Construcción territorial en serie; no transformarlos en combatientes pesados que encarezcan su función principal. |
| Auxiliares | Casco mercante/naval, transferencia de combustible, hospitales, talleres, remolque, hidrográfica y comunicaciones. | Priorizar interoperabilidad, disponibilidad y reparación; contar auxiliares en todo cálculo de alcance y presencia oceánica. |
| Vehículos no tripulados de 2026 | Sensores, baterías, enlaces, navegación, software, seguridad y recuperación. | Renovación frecuente de vehículos; diseño y software bajo control nacional, importación selectiva de componentes de frontera. |

### 10.4 Reglas de capacidad industrial

Cada programa debe demostrar capacidad anual de producción y reparación, personal cualificado, abastecimiento energético y material, proveedores alternativos, coste de ciclo de vida y auditoría independiente. La construcción de nuevos cascos no se considera lograda si aumenta la flota nominal pero provoca atrasos de mantenimiento o falta de dotaciones.

La concentración de construcción compleja en polos principales se equilibra con una red territorial de mantenimiento, formación y proveedores. La experiencia real de NAVSEA muestra la importancia de planificar conjuntamente astilleros públicos, supervisión de contratos, mantenimiento de portaaviones/submarinos y modernización industrial. [NAVSEA, astilleros](https://www.navsea.navy.mil/Home/Shipyards/), [NAVSEA, supervisión de construcción y reparación](https://www.navsea.navy.mil/Home/SUPSHIP/).

### 10.5 Estatus editorial

El desarrollo 1750–2026 se integra como cronología industrial de referencia del canon. Los intervalos describen maduración, producción seriada y expansión de capacidades; no afirman un avance aislado por año. Las cifras de unidades construidas, disponibilidad o inversión permanecen diferenciadas entre inventario canónico, hipótesis de planificación y datos aún no medidos.

### 10.6 Generaciones, nombres y ciclos de reemplazo de las clases

#### Regla para leer las fechas

Las fechas de esta sección describen **generaciones de diseño**, no la duración de una sola clase ni de cada casco. Una familia naval puede mantenerse durante muchas décadas porque se construyen generaciones sucesivas con cascos, sensores, armas y propulsión nuevos. Cada casco tiene su propio ciclo: construcción, entrada en servicio, una modernización integral de media vida cuando corresponda y retiro. Para buques de combate mayores se planifican normalmente 30–40 años de servicio; los patrulleros rápidos y vehículos no tripulados tienen ciclos menores. Desde 1945, el refit integral se hace una vez por casco, aproximadamente a mitad de vida; no se supone que una modernización tecnológica pueda rejuvenecer indefinidamente el casco.

Las ventanas son **planificación canónica de AM1**: «construcción» indica el inicio del primer lote; «servicio» la entrada aproximada de las primeras unidades; «retiro» el intervalo previsto para los últimos cascos de esa generación. La fecha final de una familia no significa que sus buques originales sigan activos hasta entonces.

#### Generaciones históricas ya registradas, 1875–1914

Esta matriz recoge fechas de las tablas históricas de AM1 y las ordena por tipo. Para estas clases, «retiro» es el último año aproximado de servicio consignado; en grupos cuyo texto original dice «aproximado», «variable» o «según inspección», se conserva esa incertidumbre.

| Clase / tipo y generación | Construcción | Servicio | Retiro aproximado |
|---|---:|---:|---:|
| Círdan, acorazado de 1875 | 1872–1879 | 1875–1908 | 1908 |
| Eärendil, acorazado pesado | 1869–1877 | 1871–1902 | 1902 |
| Gil-galad, acorazado de transición | 1870–1880 | 1874–1905 | 1905 |
| Aulë, monitor litoral | 1866–1878 | 1868–1898 | 1898 |
| Minas Tirith, monitor oceánico | 1870–1880 | 1872–1900 | 1900 |
| Eärendil, crucero protegido | 1872–1882 | 1875–1908 | 1908 |
| Rómenna, crucero de estación | 1871–1882 | 1875–1905 | 1905 |
| Pelargir, corbeta oceánica | 1873–1883 | 1875–1905 | 1905 |
| Alqualondë, corbeta de enlace | 1870–1882 | 1873–1900 | 1900 |
| Systreyjar, corbeta ligera | 1872–1882 | 1875–1900 | 1900 |
| Rómenna, aviso | 1870–1882 | 1873–1900 | 1900 |
| Forlond, aviso | 1871–1882 | 1874–1900 | 1900 |
| Harlond, cañonera oceánica | 1872–1884 | 1875–1905 | 1905 |
| Harlond, cañonera fluvial | 1872–1885 | 1875–1900 | 1900 |
| Calasir, cañonera costera | 1873–1884 | 1875–1900 | 1900 |
| Forlond, torpedero | 1873–1880 | 1875–1895 | 1895 |
| Calenhad, torpedero ligero | 1873–1882 | 1875–1895 | 1895 |
| Transportes armados, primera serie | 1870–1885 | 1875–1910 | 1910 |
| Auxiliares de carbón, transporte, hospital, taller e hidrografía | 1870–1885 | 1875–1920 | Variable por subclase e inspección |
| Anárion, acorazado de escuadra | 1892–1902 | 1895–1925 aprox. | 1925 aprox. |
| Eärendil, crucero acorazado | 1894–1904 | 1897–1930 | 1930 |
| Rómenna, crucero ligero / Pelargir, corbeta | 1895–1905 | 1898–1930 | 1930 |
| Forlond, destructor y torpedero | 1897–1905 | 1900–1925 | 1925 |
| Cañoneras y patrulleros de 1900 | 1890–1905 | 1900–1935, variable | 1935 o antes, según casco |
| Auxiliares de 1900 | 1890–1910 | Desde 1890–1910 | Según inspección y función |
| Anárion II, dreadnought | 1907–1917 | 1910–1945, retiro gradual | 1945 aprox. |
| Gil-galad, crucero de batalla | 1909–1917 | 1912–1945 | 1945 |
| Cruceros protegidos y ligeros de 1914 | 1905–1918 | 1910–1940 | 1940 |
| Destructores y torpederos de 1914 | 1907–1918 | 1910–1940 | 1940 |
| Submarinos de primera generación | 1905–1918 | 1910–1940 | 1940 |

Los nombres repetidos en la tabla corresponden a **tipos o generaciones diferentes**: por ejemplo, Eärendil acorazado y Eärendil crucero protegido; Rómenna crucero y Rómenna aviso. El nombre compartido no significa que sea un mismo diseño.

#### Portaaviones

| Familia y generación | Inicio de construcción | Servicio previsto | Retiro previsto | Nota de reemplazo |
|---|---:|---:|---:|---|
| Aulë I, portaaviones de cubierta axial convencional | 1943 | 1945–1970 | 1975–1985 | Primera generación de posguerra; sus cascos convencionales se retiran antes de 1980. |
| Anárion I, portaaviones de flota convencional | 1955 | 1960–1990 | 1995–2005 | Tres unidades nuevas en la reconstrucción de 1960; continuidad en el inventario de 1980. |
| Aulë II, portaaviones nuclear | 1965 | 1970–1995 | 2000–2015 | Dos unidades en la composición de 1980; generación nuclear posterior a Aulë I. |
| Anárion II, portaaviones de flota convencional | 1985 | 1990–2015 | 2020–2035 | Cascos tempranos se retiran antes; parte de la línea continúa con diseño nuevo. |
| Elwing I, portaaviones convencional de transición | 2000 | 2005–2030 | 2035–2048 | Serie limitada, optimizada para operaciones conjuntas y disponibilidad. |
| Aldarion I, portaaviones convencional de flota | 2010 | 2018–2040 | 2045–2058 | Última generación convencional de gran tamaño prevista en esta propuesta. |
| Telperion I, portaaviones nuclear | 2010 | 2018–2040 | 2055–2065 | Cuatro cascos previstos; refit de media vida 2032–2040, con retiro individual según casco y reactor. |
| Varda I–III, portaaviones ligeros/ASW y STOVL | 1965 / 2000 / 2018 | 1970–1990 / 2005–2025 / 2025–2045 | 2000–2015 / 2038–2048 / 2055–2065 | Varda I corresponde a los dos ligeros de 1980; Varda II y III aportan dos unidades cada uno al inventario propuesto de 2026. |

#### Submarinos

| Familia y generación | Inicio de construcción | Servicio previsto | Retiro previsto | Nota de reemplazo |
|---|---:|---:|---:|---|
| Arnor II–IV, submarino estratégico | 1980 / 2000 / 2018 | 1988–2008 / 2007–2027 / 2025–2045 | 2025–2035 / 2040–2048 / 2058–2068 | Relevo escalonado para conservar patrullas disponibles; cada casco tiene ciclo propio. |
| Eärendil II–IV, submarino nuclear de ataque | 1985 / 2000 / 2015 | 1992–2012 / 2007–2027 / 2022–2042 | 2028–2038 / 2038–2048 / 2052–2062 | Reemplazo por lotes; reacondicionamiento y seguridad nuclear incluidos en el ciclo. |
| Tolfalas II–IV, submarino convencional/AIP | 1990 / 2005 / 2020 | 1996–2016 / 2012–2032 / 2026–2046 | 2025–2035 / 2038–2048 / 2050–2060 | Vida condicionada por baterías, sistema AIP, corrosión y disponibilidad de repuestos. |
| Aeglos I, submarino especial | 1990 | 1997–2017 | 2027–2037 | Sustitución por misión y disponibilidad, no por equivalencia de tonelaje. |
| Falathar I, rescate y apoyo profundo | 2015 | 2022–2042 | 2050–2060 | Capacidad de rescate y operación profunda; vehículos auxiliares se renuevan antes que el buque nodriza. |

#### Combatientes de superficie y escoltas

| Familia y generación | Inicio de construcción | Servicio previsto | Retiro previsto | Nota de reemplazo |
|---|---:|---:|---:|---|
| Gil-galad II–IV, destructor de defensa aérea | 1990 / 2005 / 2020 | 1997–2017 / 2012–2032 / 2027–2047 | 2028–2038 / 2040–2048 / 2058–2068 | Los lotes III y IV reemplazan sucesivamente los cascos II; el nombre identifica la familia, no un diseño único. |
| Círdan I–IV, fragata multipropósito | 1955 / 1965 / 1975 / 1995 | 1960–1980 / 1970–1990 / 1980–2000 / 2000–2020 | 1988–1998 / 1998–2008 / 2008–2018 / 2035–2045 | Cada generación tiene cascos propios; Círdan IV se retira gradualmente al entrar Voronwë. |
| Voronwë I, fragata multipropósito | 2022 | 2026–2046 | 2058–2068 | Reemplazo generacional de Círdan IV; construcción seriada y refit único de media vida. |
| Mithlond I–II, escolta oceánico ligero | 1948 / 1968 | 1953–1973 / 1973–1993 | 1980–1990 / 2000–2010 | Nombre reservado a generaciones históricas; no duplica la familia Círdan/Voronwë. |
| Nimrodel I–II, escolta costero y de convoy | 1940 / 1958 | 1945–1965 / 1963–1983 | 1970–1980 / 1990–2000 | Reemplazado por fragatas y patrulleros especializados según misión. |
| Calenport I–III, corbeta multipropósito | 1998 / 2010 / 2022 | 2003–2023 / 2015–2035 / 2028–2048 | 2030–2040 / 2040–2048 / 2052–2062 | Series costeables para masa crítica; sensores y armas varían por bloque. |
| Eglarest I–II, corbeta litoral | 2005 / 2020 | 2012–2032 / 2027–2047 | 2038–2048 / 2055–2065 | Nombre para corbetas de escolta litoral, distinto de Calenport multipropósito. |
| Nosselië I–III, patrullero rápido | 1980 / 2000 / 2018 | 1985–2005 / 2005–2025 / 2022–2042 | 2005–2015 / 2028–2038 / 2042–2052 | Ciclos más cortos por uso intensivo; sin conversión a combatiente pesado. |
| Turgon II–IV, escolta especializado antiaéreo | 1985 / 2005 / 2020 | 1992–2012 / 2012–2032 / 2027–2047 | 2025–2035 / 2040–2048 / 2055–2065 | Escolta de grupo; los sensores de defensa aérea se reemplazan por bloques. |
| Beleg II–IV, escolta especializado antisubmarino | 1985 / 2005 / 2020 | 1992–2012 / 2012–2032 / 2027–2047 | 2025–2035 / 2040–2048 / 2055–2065 | Variante ASW con sonar, helicóptero y procesamiento acústico, sobre casco dedicado. |
| Ossë I–II, destructor de propósito general | 1970 / 1995 | 1977–1997 / 2002–2022 | 2005–2015 / 2035–2045 | Sustitución por escoltas multipropósito; la clase submarina especial se denomina Aeglos para evitar duplicación. |

#### Anfibios, patrulla, minas y oceanografía

| Familia y generación | Inicio de construcción | Servicio previsto | Retiro previsto | Nota de reemplazo |
|---|---:|---:|---:|---|
| Aranath I–IV, buque de asalto anfibio | 1970 / 1995 / 2010 / 2020 | 1975–1995 / 2002–2022 / 2017–2037 / 2027–2047 | 2005–2015 / 2035–2045 / 2048–2058 / 2058–2068 | Capacidad de mando, aviación, transporte y ayuda humanitaria por generación. |
| Pelargir I–III, LPD/LPH | 1960 / 1990 / 2015 | 1965–1985 / 1997–2017 / 2022–2042 | 1995–2005 / 2030–2040 / 2052–2062 | Transporte anfibio y logístico; no se suma como una clase perpetua. |
| Forlond II–IV, buque de desembarco | 1980 / 2005 / 2020 | 1986–2006 / 2012–2032 / 2027–2047 | 2018–2028 / 2040–2048 / 2055–2065 | Reemplazo seriado de cascos de menor complejidad. |
| Andúnië II, transporte y apoyo logístico anfibio | 2018 | 2025–2045 | 2055–2065 | Complementa los buques de asalto; no reemplaza toda la capacidad LPD/LSD. |
| Sírënandë I–III, OPV oceánico | 1980 / 2000 / 2018 | 1985–2005 / 2006–2026 / 2023–2043 | 2010–2020 / 2035–2045 / 2048–2058 | Patrulla, rescate y presencia; la sustitución no se contabiliza como fragata. |
| Amon Sûl I–III, cazaminas | 1960 / 1990 / 2015 | 1965–1985 / 1996–2016 / 2022–2042 | 1995–2005 / 2025–2035 / 2050–2060 | Vehículos y sensores se renuevan por bloques durante la vida del buque. |
| Menel II, buque de apoyo a contramedidas de minas | 1995 | 2002–2022 | 2035–2045 | Nodo de mando y apoyo para sistemas tripulados y no tripulados. |
| Palantír H-II–H-III, hidrografía | 1990 / 2015 | 1996–2016 / 2022–2042 | 2025–2035 / 2050–2060 | Los instrumentos científicos se actualizan sin fingir extensión ilimitada del casco. |
| Menel O-II–O-III, oceanografía | 1990 / 2018 | 1997–2017 / 2025–2045 | 2030–2040 / 2055–2065 | Sufijo O identifica oceanografía y evita confusión con Menel de contramedidas de minas. |
| Esgaroth I, vehículo de superficie no tripulado | 2015 | 2018–2028 | 2025–2030 | Ciclo de vehículo; su estación o buque nodriza sigue un ciclo distinto. |
| Nénar I, vehículo submarino no tripulado | 2015 | 2019–2029 | 2025–2030 | Renovación rápida de vehículo, batería y sensores; no se cuenta como submarino tripulado. |

#### Auxiliares y servicios especializados

| Tipo y generación | Nombre de clase | Inicio de construcción | Servicio previsto | Retiro previsto |
|---|---|---:|---:|---:|
| Petrolero de flota II–IV | Aulë | 1980 / 2005 / 2020 | 1986–2006 / 2012–2032 / 2027–2047 | 2018–2028 / 2040–2048 / 2055–2065 |
| Reabastecedor multiproducto II–IV | Ecthelion | 1985 / 2005 / 2020 | 1992–2012 / 2012–2032 / 2027–2047 | 2025–2035 / 2040–2050 / 2055–2065 |
| Transporte estratégico II–IV | Harlond | 1985 / 2005 / 2020 | 1992–2012 / 2012–2032 / 2027–2047 | 2025–2035 / 2040–2050 / 2055–2065 |
| Buque hospital II–III | Estel | 1990 / 2018 | 1997–2017 / 2025–2045 | 2030–2040 / 2055–2065 |
| Reparación y taller naval II–IV | Númenor | 1985 / 2005 / 2020 | 1992–2012 / 2012–2032 / 2027–2047 | 2025–2035 / 2040–2050 / 2055–2065 |
| Salvamento oceánico II–III | Galdor | 1990 / 2018 | 1997–2017 / 2025–2045 | 2030–2040 / 2055–2065 |
| Mando y comunicaciones I–II | Alcarondas | 1980 / 2018 | 1986–2006 / 2025–2045 | 2018–2028 / 2055–2065 |
| Rescate polar I–II | Forochel | 1995 / 2020 | 2002–2022 / 2027–2047 | 2035–2045 / 2055–2065 |
| Mantenimiento avanzado I–II | Telchar | 2000 / 2020 | 2007–2027 / 2027–2047 | 2040–2048 / 2055–2065 |

Los nombres **Alcarondas**, **Forochel**, **Telchar** y **Galdor** se asignan aquí a tipos auxiliares para completar los rótulos que estaban genéricos. El antiguo rótulo «Voronwë comunicaciones» de la tabla de 1980 se normaliza como **Alcarondas I**: Voronwë queda reservado a la fragata. **Galdor** identifica salvamento oceánico, distinto de los submarinos Eärendil. En los ocho submarinos especiales/rescate de 2026, la distribución propuesta es cuatro Aeglos de misión especial y cuatro Falathar de rescate; debe tratarse como reparto de planificación hasta que se detalle casco por casco. Los números de generación son identificadores de diseño; no implican que todas las generaciones hayan tenido idénticas cantidades.

#### Lectura de inventarios y renovaciones

El inventario de 2026 expresa plataformas de varias generaciones, no una flota compuesta enteramente por los diseños más nuevos. La sustitución se planifica por lotes y por capacidad industrial: una generación puede entrar en servicio mientras otra se retira. La cifra de cada clase debe vincularse a un desglose por casco y lote antes de presentarla como inventario anual auditado. La familia Voronwë, por tanto, no significa que las 64 fragatas de la tabla 2026 sean Voronwë; el total incluye Círdan IV en retirada y Voronwë I en incorporación, hasta que una tabla de cascos indique cantidades exactas.

La vida de servicio de una familia que atraviesa varias generaciones puede superar 80 años. Eso describe la continuidad del **programa y del nombre**, no buques individuales ni un diseño congelado durante 85 años. Cada generación reemplaza a la anterior con tecnología, casco y calendario propios.



