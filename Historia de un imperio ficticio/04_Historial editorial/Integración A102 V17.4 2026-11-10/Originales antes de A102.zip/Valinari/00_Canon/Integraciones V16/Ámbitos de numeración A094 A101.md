---
tipo: "control editorial"
canon: "V17.3 A101"
actualizado: "2026-11-10"
estado: "ámbitos distinguidos sin sobreescritura"
---
# Ámbitos de numeración A094 a A101

La numeración A094 y A095 se reutilizó en dos líneas de trabajo. Para conservar los documentos se identifica cada ámbito por título completo y procedencia, sin sobrescribir sus notas.

| Identificador | Línea anterior de este chat | Línea del Maestro V17.2 A100 |
| --- | --- | --- |
| A094 | Industria automotriz | Industria de defensa y evolución AAW |
| A095 | Historia de la Fuerza Aérea | Guerra antibuque y rangos de fabricación |

Las referencias a rangos productivos A095 en A099 A100 y A101 remiten exclusivamente al capítulo antibuque del Maestro suministrado. Los contratos se identifican por EXP y los hitos por A101 más contrato. La renumeración de las líneas antiguas no se realiza sin una resolución específica; sus títulos y originales se conservan.

- [[00_Canon/Integraciones V16/Acumulativa A094 Industria automotriz]]
- [[00_Canon/Integraciones V16/Acumulativa A095 Fuerza Aérea]]
- [[00_Canon/Integraciones V16/Acumulativa A094 Industria de defensa AAW]]
- [[00_Canon/Integraciones V16/Acumulativa A095 Guerra antibuque]]
- [[00_Canon/Integraciones V16/Acumulativa A101 Reconstrucción exportadora]]
