---
tipo: ficha temática
canon: V17.7 A105
estado: vigente
periodo: "500 a. C.–500 d. C."
actualizado: 2026-11-11
---

## Resolución vigente A105 para el corte de 1891

Se ratifican dieciocho acorazados incorporados, seis posiciones de primera línea y doce de segunda, con tres capitales en construcción aparte. La reconstrucción de 239 identidades del ámbito catalogado comprende veinte presencias definidas y 219 candidaturas provisionales; no es inventario nacional ni disponibilidad simultánea. A104 mantiene sus cuatro Tarannon y los diseños ampliados. [[00_Canon/Integraciones V16/Acumulativa A105 Armada de Valinor en 1891|Resolución A105 Armada de 1891]] · [[12_Militar/03_Armada/Armada#Armada de Valinor en 1891|Desarrollo de la Armada en 1891]]

Esta resolución contextualiza 1891 y conserva las configuraciones y cantidades de otros periodos de esta ficha.

# Armada antigua, 500 a. C.–500 d. C.

## Poder militar valinari, 500 a. C.–500 d. C.

### Modelo estratégico

El poder militar valinari se basa en una talasocracia defensiva. La armada es el instrumento principal de proyección y defensa exterior, pero opera junto con fortalezas portuarias, milicias de Casas, convoyes logísticos, guarniciones y fuerzas terrestres.

La doctrina central es impedir que una potencia continental alcance los puertos, las islas o los graneros costeros. El enemigo debe ser detectado, desgastado y, cuando sea posible, destruido en el mar antes de consolidar un desembarco.

### Evolución entre 500 a. C. y 500 d. C.

Entre 500 y 300 a. C., cada Casa aporta barcos, marineros, remeros, pilotos, astilleros y tropas. La Corona y el Consejo de las Casas coordinan las campañas mayores, pero todavía no existe una armada completamente centralizada.

Entre 300 y 50 a. C. aparecen arsenales permanentes, registros de tripulaciones, depósitos de madera y brea, torres de observación, señales de fuego, patrullas estacionales y escuadras regionales.

Entre 50 a. C. y 200 d. C. la armada oceánica se profesionaliza. Se organizan escuadras atlánticas, mediterráneas e insulares, además de flotillas de convoy, unidades de desembarco y buques de exploración.

Entre 200 y 500 d. C. la prioridad pasa a ser la defensa de rutas, el control de estrechos, la protección de grano y la guerra contra piratas y expediciones de desembarco.

### Tipos de buque

La armada combina buques oceánicos de vela, galeras rápidas, patrulleros, cargueros protegidos, transportes de tropas y barcos auxiliares. Los buques oceánicos tienen mayor autonomía, estabilidad, capacidad de agua y resistencia al oleaje que los trirremes mediterráneos, pero son menos ágiles en espacios estrechos.

Los trirremes y galeras romanas conservan ventajas en aceleración, maniobra, embestida y combate costero. Por eso la doctrina valinari no reemplaza las galeras: utiliza buques oceánicos para resistencia, transporte y combate prolongado, y galeras para exploración, persecución y abordaje.

### Defensa contra invasiones

La defensa se organiza en cuatro fases: detección mediante torres, vigías y barcos exploradores; aislamiento de la flota enemiga mediante ataques a transportes y suministros; destrucción de escoltas y buques de desembarco; y negación del desembarco mediante guarniciones, obstáculos, fuego costero y contraataques.

Una escuadra atlántica puede incluir, según la campaña, buques oceánicos pesados y medianos, galeras rápidas, patrulleros, transportes protegidos y unidades de apoyo. La ventaja valinari procede de la integración entre navegación, meteorología, bases, inteligencia y logística, no solamente del tamaño de los cascos.

### Comparación con Roma

Roma mantiene ventaja en el Mediterráneo, las galeras de combate, el transporte de legiones y las grandes operaciones anfibias. Valinor mantiene ventaja en navegación oceánica, mar abierto septentrional, guerra de convoyes, defensa de islas atlánticas e inteligencia marítima.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/02_Ejército/Ejército antiguo 500 aC-500 dC]]
- [[12_Militar/02_Ejército/Defensa territorial antigua]]
