# Estado de Auditoría ANP02 tras A106

Integración cerrada el 12 de noviembre de 2026 mediante V17.8 A106, catálogo CMN 6. ANP01 ya estaba integrada por A104; ANP02 y auditoría se integran mediante A106. Los bloques 50–54 se adoptan por la orden posterior de integración. Los rótulos de pendiente en originales describen su estado histórico. Los originales y paquetes se conservan; no deben reintegrarse ni sumarse. Los datos materiales desconocidos permanecen pendientes.
