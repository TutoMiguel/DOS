---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "Revisión editorial 2026-11-07"
actualizado: 2026-11-07
---
# Registro de integración acumulativa V16

## Cobertura del acumulativo

Se revisaron 87 bloques del documento acumulativo. Cada fila identifica su destino o su sustitución por una decisión posterior. «Sustituida» significa que conserva valor de antecedente, no vigencia alternativa. El contenido de ampliaciones queda en fichas temáticas enlazadas y en el capítulo correspondiente del maestro.

| Identificador | Fuente | Tratamiento | Destino o motivo |
|---|---|---|---|
| A000 | Actualizaciones acumulativas del canon valinoriano | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Criterios editoriales y naturaleza del escenario|Criterios editoriales y naturaleza del escenario]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A001 | 1. Estructura política | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A002 | 2. Territorios directos | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A003 | 3. Arnor | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A004 | 4. Calenardhon Austral | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A005 | 5. Sírënandë | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A006 | 6. Nosselië Toliva | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A007 | 7. Enclaves y protectorados | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A008 | 8. Cronología atlántica principal | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A009 | 9. Cronología oriental resumida | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A010 | 10. Acumulación cultural y conocimiento | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A011 | 11. Población y economía federal | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A012 | 12. Regla de nomenclatura | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A013 | 13. Estado cartográfico | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A014 | 16. Ficha geográfica canónica — Valinor a Tyl | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A015 | 17. Retcon canónico — escala territorial, demográfica y cultural consolidada | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A016 | 18. Retcon administrativo — Eryndor y Harnen como estados federados | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A017 | 19. Ampliación demográfica y económica de Eryndor y Harnen | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A018 | 20. Corrección de la ampliación federal — valores proporcionales | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A019 | 21. Auditoría de coherencia y decisiones resueltas | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A020 | 22. Complejo Industrial Estratégico — motores, turbinas y microelectrónica | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A021 | 23. Actualización económica por industria militar y exportaciones estratégicas | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A022 | 25. Canon naval — equivalencia tecnológica de la Círdan IV | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A023 | 26. Clases principales de la Armada Valinoreana | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A024 | 27. Sistemas de radar naval — Palantír-4D y Palantír Aeglos | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A025 | 24. Integración total de actualizaciones acumulativas | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A026 | 28. Magallanes y Andúnië Austral | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A027 | 29. Retcon histórico — Gran Guerra del Pacífico, 1879–1886 | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A028 | 30. Consolidación canónica — Guerra del Pacífico ampliada | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Se conserva la formulación compatible del Canon activo; las propuestas históricas no reactivan valores sustituidos. |
| A029 | Actualización acumulativa — demografía fundadora, asentamiento y distribución territorial | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — La secuencia territorial y las tasas migratorias quedaron sustituidas por la secuencia atlántica vigente y el recálculo centenario del Canon. |
| A030 | 9. Relación diplomática entre Valinor y Roma hacia 50 d. C. | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Orígenes, expansión y relaciones exteriores|Orígenes, expansión y relaciones exteriores]] — Orígenes, expansión y relaciones exteriores |
| A031 | 10. Corrección sobre las relaciones con sociedades locales | Consolidada con corrección posterior | [[00_Canon/Canon V16 Maestro#Orígenes, expansión y relaciones exteriores|Orígenes, expansión y relaciones exteriores]] — Valinor y Roma, 500 a. C.–500 d. C. |
| A032 | 11. Conquista y esclavitud en África, América, el Caribe e islas atlánticas | Integrada | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Conquista y esclavitud en África, América, el Caribe e islas atlánticas |
| A033 | 12. Causas históricas de la conquista y la esclavitud valinari | Integrada | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Causas históricas de la conquista y la esclavitud valinari |
| A034 | 13. Sometimiento productivo, esclavitud y población local | Integrada | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Sometimiento productivo, esclavitud y población local |
| A035 | 14. Crisis religiosa de la Custodia y reforma doctrinal | Integrada | [[00_Canon/Canon V16 Maestro#Religión y memoria|Religión y memoria]] — Crisis religiosa de la Custodia y reforma doctrinal |
| A036 | 15. Endogamia valinari, migración nórdica y población mestiza | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — El régimen matrimonial se consolida en hogar, parentesco y matrimonio, aprobado posteriormente. |
| A037 | 16. Evolución demográfica de los territorios incorporados | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Las proporciones por etapas son antecedentes del recálculo centenario; no se mantienen como una segunda tabla vigente. |
| A038 | 18. Segunda corriente migratoria germánica y de Europa oriental | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — El 30 % no nórdico fue reemplazado por el 60 %, con 777.000 llegadas acumuladas. |
| A039 | 19. Recalculo demográfico centenario y desaparición de la categoría local | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — La matriz centenaria del Canon incluye las migraciones y sustituye esta tabla inicial incompleta. |
| A040 | 17. Modelo demográfico valinari, 1000 a. C.–800 d. C. — versión histórica previa | Sustituida | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Versión expresamente marcada como histórica y sustituida en el acumulativo. |
| A041 | 20. Relación entre Valinor y Roma, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Orígenes, expansión y relaciones exteriores|Orígenes, expansión y relaciones exteriores]] — Valinor y Roma, 500 a. C.–500 d. C. |
| A042 | 21. Poder militar valinari, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Armada antigua, 500 a. C.–500 d. C. |
| A043 | 22. Ejército valinari, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Ejército antiguo, 500 a. C.–500 d. C. |
| A044 | 23. Bases militares y distribución territorial, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Red histórica de bases antiguas |
| A045 | 24. Capital y centros defensivos, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Red histórica de bases antiguas |
| A046 | 25. Economía valinari, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Economía antigua, 500 a. C.–500 d. C. |
| A047 | 26. Profundización de la producción agrícola, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Economía antigua, 500 a. C.–500 d. C. |
| A048 | 27. Política valinari, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A049 | 28. Secuencia política valinari, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A050 | 29. Ascenso de la Casa Telcontar, siglo VI a. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A051 | 30. Constitución monárquica pactista, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A052 | 31. Administración territorial en profundidad, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A053 | 32. Administración política en profundidad, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A054 | 33. Organización territorial valinari en 5 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Administración política y territorial antigua |
| A055 | 34. Factorías valinari bajo autoridad romana, siglo I d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Orígenes, expansión y relaciones exteriores|Orígenes, expansión y relaciones exteriores]] — Valinor y Roma, 500 a. C.–500 d. C. |
| A056 | 35. Canal de Panamá y conexión interoceánica, 1845–1872 | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Economía, agricultura y cuentas territoriales |
| A057 | 36. Ley de Custodia Compartida y acumulación del conocimiento, 700 a. C.–700 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Educación y custodia del conocimiento|Educación y custodia del conocimiento]] — Ley de Custodia Compartida y acumulación del conocimiento, 700 a. C.–700 d. C. |
| A058 | 37. Evolución de las capitales valinari, 1000 a. C.–1200 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Evolución de las capitales hasta 1200 |
| A059 | 38. Capital de Nosselië Toliva, 900 a. C.–1200 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Organización territorial y capitales|Organización territorial y capitales]] — Evolución de las capitales hasta 1200 |
| A060 | 39. Defensa territorial en profundidad, 500 a. C.–500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Defensa territorial antigua |
| A061 | 40. Instituciones económicas y relaciones exteriores: integración por etapas | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Corona, gobierno y administración|Corona, gobierno y administración]] — Corona, gobierno y administración |
| A062 | 41. Integración selectiva del manuscrito previo | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Moneda, banca y fomento |
| A063 | Integración acumulativa del sistema educativo como base de la primacía valinari — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Educación y custodia del conocimiento|Educación y custodia del conocimiento]] — Educación y primacía sistémica |
| A064 | Integración acumulativa de logística, educación material, ganadería y recursos — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Economía, agricultura y cuentas territoriales|Economía, agricultura y cuentas territoriales]] — Logística, ganadería y recursos |
| A065 | Integración acumulativa de hogar, parentesco y matrimonio — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Población, hogares y trabajo|Población, hogares y trabajo]] — Hogar, parentesco y matrimonio |
| A066 | Integración acumulativa de cultura naval y continuidad de rutas — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Cultura naval y continuidad de rutas |
| A067 | Evolución financiera comparada y anticipación institucional — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Evolución financiera comparada |
| A068 | Adelanto de la serie Círdan y transición a Voronwë — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Serie Círdan y transición a Voronwë |
| A069 | Desarrollo de la propulsión naval valinari | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Motores y Propulsión |
| A070 | Producción energética valinari, 1600–2026 — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Energía |
| A071 | Industrialización valinari anticipada y transformación integral — 6 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Industrialización valinari |
| A072 | Desarrollo ampliado de la industrialización valinari — 7 de noviembre de 2026 | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Industrialización valinari |
| A073 | Actualización acumulativa: Armada Real de 1875 | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Defensa y fuerzas armadas |
| A074 | Actualización acumulativa: cañoneras valinari de 1875 | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Cañoneras valinari de 1875 |
| A075 | Actualización acumulativa: distribución de la Armada Real en 1875 | Integrada con conciliación | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Distribución territorial de la Armada en 1875 |
| A076 | Actualización acumulativa: comparación clase por clase con la Royal Navy, 1875 | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Comparación naval de 1875 |
| A077 | Actualización acumulativa: profundización de la metalurgia valinari | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Metalurgia y siderurgia |
| A078 | Actualización acumulativa: metalurgia y siderurgia valinari en el siglo VIII d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Energía, industria y tecnología|Energía, industria y tecnología]] — Metalurgia y siderurgia del siglo VIII |
| A079 | Actualización acumulativa: moneda y sistema monetario valinari, 1000 a. C.–1500 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Evolución monetaria, 1000 a. C.–1500 d. C. |
| A080 | Actualización acumulativa: nombre y valor de la moneda valinari | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Rín valinari |
| A081 | Actualización acumulativa: sistema valinari de fomento y desarrollo integral | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Sistema Valinari de Fomento y Desarrollo |
| A082 | Profundización acumulativa: funcionamiento del Sistema Valinari de Fomento y Desarrollo | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Sistema Valinari de Fomento y Desarrollo |
| A083 | Cronología acumulativa del fomento valinari, 1200–1875 d. C. | Integrada | [[00_Canon/Canon V16 Maestro#Moneda, banca y fomento|Moneda, banca y fomento]] — Sistema Valinari de Fomento y Desarrollo |
| A084 | Actualización acumulativa: las Casas como entidades económicas, financieras, militares y productivas desde el siglo XV | Integrada | [[00_Canon/Canon V16 Maestro#Casas e instituciones patrimoniales|Casas e instituciones patrimoniales]] — Evolución económica e institucional de las Casas |
| A085 | Profundización acumulativa: funcionamiento de las Casas como instituciones desde el siglo XV | Integrada | [[00_Canon/Canon V16 Maestro#Casas e instituciones patrimoniales|Casas e instituciones patrimoniales]] — Evolución económica e institucional de las Casas |
| A086 | Sincronización acumulativa: especificaciones de las clases principales de 1875 | Consolidada en contenido vigente | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]] — Defensa y fuerzas armadas |

## Criterios de precedencia aplicados

- Harnen es protectorado de Beleg Valinor; Rhunost es interno de Harnen.
- La corriente no nórdica vigente es el 60 % de la nórdica: 777.000 llegadas acumuladas hasta 800.
- Los cuadros finales ECON-03 sustituyen las rondas iniciales y se conservan sus cifras.
- El acorazado Círdan I de 1875 y las fragatas Círdan desde 1955 son programas diferentes.
- La disponibilidad 105/35/38 particiona 178 buques, no el total de 332.
- OceanNet funciona desde 1959; 1969 corresponde a consolidación institucional.
- Los siete depósitos documentales no implican siete reservas monetarias iguales.
- Los institutos modernos no se proyectan sobre la Antigüedad.

## Datos abiertos que no son integraciones pendientes

La ley metálica y subdivisión exacta del rín, la fecha general de abolición y la conciliación de estimaciones de población de diferente alcance en 50 d. C. requieren decisiones específicas. Las afirmaciones históricas comparativas sobre marinas extranjeras conservan carácter cualitativo; no se adoptan inventarios no homologados.

## Desarrollo específico de la ficha

**Estatus:** ficha de gestión canónica.

El Canon V16 incorpora las actualizaciones acumulativas sobre educación y primacía sistémica, logística naval, ganadería y abastecimiento, recursos naturales y metales, hogar y parentesco, cultura naval y evolución financiera comparada.

## Principio de coherencia

Educación, producción, crédito, navegación, recursos, familias, ciudadanía, instituciones y defensa se condicionan mutuamente. Ningún recurso, cifra naval, población o institución se considera automáticamente posible sin comprobar capacidad material, administrativa y cronológica.

## Correcciones territoriales vigentes

- Númenor corresponde a Terranova.
- Tol Eressëa es una entidad diferenciada.
- Barad Nimras/Gibraltar es una base arrendada desde 1815.
- Ceuta y Melilla no son distritos federales automáticos.

| 111v | Radar y sensores: doctrina, nomenclatura, integración y límites | Integrada | [[00_Canon/Canon V16 Maestro#Defensa y fuerzas armadas|Defensa y fuerzas armadas]]; [[11_Ciencia y Tecnologia/Radar y Sensores|ficha técnica]]; [[01_Cronologia/Cronología Territorial V16|cronología]] — Se separan radar, sonar, sensores auxiliares y OceanNet; se resuelven las denominaciones Palantír y se fijan límites, validación humana, cronología y decisiones de plataforma aún no cuantificadas. |

## Referencias relacionadas


- [[00_Canon/Integraciones V16/Revisión editorial V16.1]]
- [[00_Canon/Integraciones V16/Propuestas pendientes tras revisión V16.1]]

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
