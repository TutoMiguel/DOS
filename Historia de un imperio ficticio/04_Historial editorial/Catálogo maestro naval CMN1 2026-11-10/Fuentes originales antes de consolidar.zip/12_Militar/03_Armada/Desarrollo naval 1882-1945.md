---
tipo: catálogo militar
canon: V16
estado: vigente
periodo: 1882–1945
actualizado: 2026-11-07
---
# Desarrollo naval 1882–1945

## Alcance

Este catálogo reúne perfiles técnicos adoptados en la integración 111v. Las bandas describen clases o grupos de referencia; no fijan número de cascos, órdenes de batalla ni disponibilidad. El nombre de clase y las cantidades permanecen abiertos cuando el Canon V16 no los determina.

### Norma de adelanto de doce años

La triple expansión no es una caldera. Es una máquina alternativa que aprovecha el vapor sucesivamente en cilindros de alta, media y baja presión. La caldera produce el vapor y puede alimentar tanto esta máquina como una turbina. La turbina de vapor convierte el flujo en rotación continua y constituye una tecnología distinta. La turbina de gas de los Círdan modernos pertenece a otra época y otro ciclo termodinámico.

- **Triple expansión:** primer uso naval operativo valinari adoptado para **1873**, doce años antes de la adopción amplia en nuevos buques de la Royal Navy, situada hacia 1885. No se afirma que Valinor invente el principio ni que no existieran ensayos marítimos extranjeros anteriores; la ventaja consiste en investigación propia, adopción en unidades seleccionadas, producción y sostenimiento.
- **Turbina de vapor:** banco de pruebas y nave experimental valinari en **1882**, doce años antes de la *Turbinia* británica de 1894; primer torpedero o aviso operativo valinari en **1887**, antes de los ensayos británicos de destructores con turbina de 1899; primer buque capital valinari de turbina en **1894**, doce años antes del *HMS Dreadnought* de 1906. Esta secuencia constituye una divergencia tecnológica fuerte y requiere un programa naval y metalúrgico sostenido.
- **Límite:** el adelanto no convierte todos los cascos de 1875 a turbina. La transición se hace por nuevas construcciones y lotes; los barcos antiguos conservan máquinas *compound* o de triple expansión hasta el retiro.

### Catálogo canónico de clases y grupos navales, 1882–1945

Las fichas de este catálogo son **parámetros de diseño adoptados**, no datos ya adoptados por el canon ni un inventario. Las cifras se expresan como rangos porque representan varias unidades y lotes. El desplazamiento es métrico; el armamento, en milímetros; la potencia de máquinas de vapor, en caballos al eje (shp). La velocidad es máxima de prueba. La autonomía indica millas náuticas (mn) a la velocidad económica especificada; no equivale al radio de combate. En submarinos se diferencia superficie y navegación sumergida. Los espesores de blindaje se especifican por zona, no como protección uniforme.

Los barcos canónicos de 1875 quedan en la sección precedente y conservan sus características vigentes. Las sucesiones 1882–1945 reutilizan líneas funcionales Calenhad/Forlond, Rómenna, Pelargir/Alqualondë y Harlond cuando corresponde. Los nombres de las nuevas clases aún no están fijados.

#### 1. Nave experimental de turbina de vapor (1882)

- **Función:** banco de pruebas marítimo para turbina, condensador, ejes y hélices; no es unidad de combate.
- **Desplazamiento:** 150–350 t. **Dimensiones:** eslora 35–55 m; manga 5–8 m. **Calado:** 1,5–2,5 m.
- **Propulsión:** turbina de vapor de carbón con condensador; transmisión experimental de alta velocidad. **Potencia:** 1.500–3.500 shp. **Ejes:** 2–3, con hélices múltiples si todavía no hay una reductora fiable.
- **Velocidad:** 24–30 nudos en pruebas cortas. **Alcance:** 300–800 mn a 10 nudos.
- **Blindaje:** ninguno; compartimentación de seguridad y protección ligera de maquinaria.
- **Armamento:** ninguno o 1–2 piezas de 37–47 mm para ensayos de estabilidad.
- **Dotación:** 20–45, incluidos ingenieros de pruebas.
- **Criterio:** no se cuenta como clase naval ni como prueba de que una turbina de 1882 sea ya fiable para flota oceánica.

#### 2. Torpedero de turbina, evolución Calenhad/Forlond (1887–1895)

- **Función:** ataque rápido desde puertos y estaciones protegidas; nueva construcción, sin reconvertir los torpederos de 1875.
- **Desplazamiento:** 250–600 t. **Dimensiones:** 45–65 m de eslora; manga 5–8 m. **Calado:** 1,8–3,0 m.
- **Propulsión:** turbina de vapor y calderas ligeras de carbón; primeras unidades con varias hélices/ejes y posteriores con reducción más compacta. **Potencia:** 4.000–8.000 shp. **Ejes:** 2–3 según lote.
- **Velocidad:** 25–30 nudos en prueba; velocidad sostenida menor para no agotar carbón ni maquinaria. **Alcance:** 700–1.500 mn a 10 nudos.
- **Blindaje:** sin cinturón; escudos locales y subdivisión estanca.
- **Armamento:** 2–4 tubos lanzatorpedos de 356–450 mm; 2–4 piezas de 47–76 mm.
- **Dotación:** 40–90.
- **Límite:** turbinas de alta potencia son apropiadas para una salida rápida, pero el alcance y la disponibilidad mecánica las hacen dependientes de una base cercana.

#### 3. Buque capital de turbina, primera generación (1894–1905)

- **Función:** combate de línea y demostración de que la turbina puede impulsar un buque capital. **El nombre definitivo de clase y el número de unidades quedan sin asignar; este perfil fija el intervalo técnico de referencia, no el inventario.**
- **Desplazamiento:** 14.000–18.000 t. **Dimensiones:** eslora 125–150 m; manga 22–26 m. **Calado:** 8–9,5 m.
- **Propulsión:** turbinas de vapor, calderas de carbón, condensadores y auxiliares; transmisión ajustada a cuatro hélices. **Potencia:** 22.000–35.000 shp. **Ejes:** 4.
- **Velocidad:** 20–23 nudos en prueba; 17–20 nudos sostenidos según estado de mar y calderas. **Alcance:** 4.000–6.000 mn a 10 nudos.
- **Blindaje adoptado:** cinturón 250–320 mm; torres/barbetas 250–305 mm; cubierta 50–90 mm; protección antitorpedo interna limitada.
- **Armamento:** 4 × 305–343 mm; 10–14 × 120–152 mm; 12–20 piezas de 47–76 mm; 2–4 tubos lanzatorpedos, si se conserva la doctrina de la época.
- **Dotación:** 750–1.050.
- **Aplicación de los doce años:** 1894 se compara con la entrada en servicio del *Dreadnought* en 1906 para la adopción de turbina en un gran acorazado. No significa que todas las armadas del mundo esperaran hasta 1906 para probar turbinas.

#### 4. Crucero de estación y exploración, nueva generación Rómenna (1895–1905)

- **Función:** reconocimiento oceánico, protección de comercio y mando de flotillas.
- **Desplazamiento:** 5.000–8.000 t. **Dimensiones:** eslora 115–140 m; manga 15–19 m. **Calado:** 5,5–7 m.
- **Propulsión:** turbinas de vapor en los lotes nuevos; carbón y calderas acuotubulares cuando el diseño y la experiencia del astillero lo permitan. Unidades anteriores mantienen máquinas alternativas. **Potencia:** 15.000–28.000 shp. **Ejes:** 2–4.
- **Velocidad:** 22–27 nudos de prueba; 18–22 sostenidos. **Alcance:** 4.000–6.000 mn a 10 nudos.
- **Blindaje:** cubierta 40–80 mm y/o cinturón localizado 50–120 mm, según variante.
- **Armamento:** 6–10 × 120–203 mm; 8–16 piezas ligeras de 37–76 mm; 2–4 tubos de torpedo; telémetros ópticos y radiotelegrafía.
- **Dotación:** 400–700.

#### 5. Acorazado de escuadra (1905–1918)

- **Función:** línea de batalla oceánica; sustituye gradualmente a los acorazados de transición, no de inmediato.
- **Desplazamiento:** 18.000–30.000 t. **Dimensiones:** eslora 160–195 m; manga 25–30 m. **Calado:** 8,5–10,5 m.
- **Propulsión:** turbinas de vapor; calderas de carbón en los primeros lotes y carbón/petróleo o petróleo en los posteriores. Reductoras si están maduras. **Potencia:** 30.000–70.000 shp. **Ejes:** 4.
- **Velocidad:** 20–25 nudos de prueba; 17–21 sostenidos. **Alcance:** 5.000–8.000 mn a 10 nudos.
- **Blindaje:** cinturón principal 250–350 mm; torres 250–330 mm; cubierta 50–100 mm; mamparos y protección submarina limitados según generación.
- **Armamento:** batería principal de 8–12 × 305–381 mm; batería secundaria de 10–20 × 100–152 mm; piezas antitorpederas de 37–76 mm; torpedos solo en algunos lotes.
- **Sensores:** telémetros, dirección óptica de tiro, reflectores y radiotelegrafía. No se instala radar antes de la época en que aparece en la cronología canónica.
- **Dotación:** 950–1.500.

#### 6. Crucero blindado y crucero ligero (1900–1918)

**Crucero blindado de escuadra**

- **Desplazamiento:** 8.000–15.000 t. **Dimensiones:** 140–180 m de eslora; 18–23 m de manga. **Calado:** 6,5–8,5 m.
- **Propulsión:** turbinas de vapor y calderas de carbón/petróleo por lote. **Potencia:** 25.000–55.000 shp. **Ejes:** 4.
- **Velocidad:** 22–28 nudos. **Alcance:** 5.000–8.000 mn a 12 nudos.
- **Blindaje:** cinturón 100–200 mm; cubierta 40–80 mm; torres 100–200 mm.
- **Armamento:** 4–8 × 203–254 mm; 8–14 × 120–152 mm; piezas ligeras; torpedos en algunos lotes.
- **Dotación:** 600–1.000.

**Crucero ligero de exploración**

- **Desplazamiento:** 4.000–8.000 t. **Dimensiones:** 120–155 m; manga 14–18 m. **Calado:** 5–7 m.
- **Propulsión:** turbinas de vapor; **potencia** 15.000–35.000 shp; **ejes** 2–4.
- **Velocidad:** 23–29 nudos. **Alcance:** 4.000–7.000 mn a 10–12 nudos.
- **Blindaje:** cubierta 25–60 mm; escudos y protección local 25–75 mm.
- **Armamento:** 8–12 × 102–152 mm; 4–8 tubos de torpedo; armas ligeras contra torpederos.
- **Dotación:** 350–650.

#### 7. Destructor de flota y torpedero oceánico (1900–1918)

- **Función:** escolta de escuadra, exploración cercana, torpedo y defensa contra torpederos enemigos.
- **Desplazamiento:** 700–1.800 t. **Dimensiones:** eslora 65–105 m; manga 6–10 m. **Calado:** 2,5–4 m.
- **Propulsión:** turbinas de vapor en destructores de alta velocidad; máquinas alternativas o diésel en unidades económicas y de patrulla. **Potencia:** 20.000–45.000 shp en unidades de turbina. **Ejes:** normalmente 2.
- **Velocidad:** 27–36 nudos en prueba; 20–28 sostenidos. **Alcance:** 1.500–3.500 mn a 12 nudos.
- **Blindaje:** ninguno como cinturón; protección contra fragmentos en puestos y pañoles seleccionados.
- **Armamento:** 2–5 × 76–102 mm; 2–6 tubos de torpedo de 450–533 mm; ametralladoras y, según fecha, cargas de profundidad.
- **Dotación:** 80–170.

#### 8. Submarino oceánico convencional (1900–1918)

- **Desplazamiento:** 500–1.500 t en superficie. **Dimensiones:** eslora 50–85 m; manga 5–8 m. **Calado:** 3,5–5,5 m.
- **Propulsión:** diésel en superficie y motor eléctrico/baterías sumergido. **Potencia:** diésel 1.500–5.000 shp; eléctrica 500–1.500 shp. **Ejes:** 2.
- **Velocidad:** 14–20 nudos en superficie; 7–10 sumergido. **Alcance:** 4.000–8.000 mn a 10 nudos en superficie; autonomía sumergida de horas a pocos días según velocidad y batería.
- **Blindaje:** casco resistente, no blindaje contra artillería; subdivisión y control de inundación.
- **Armamento:** 4–8 tubos de torpedo de 450–533 mm; cañón de cubierta de 76–102 mm en unidades tardías.
- **Dotación:** 35–70.

#### 9. Nodriza de hidroaviones y primer portaaviones (1912–1918)

- **Función:** observación naval, exploración y prueba de aviación embarcada; puede ser conversión de transporte o buque nuevo.
- **Desplazamiento:** 6.000–15.000 t. **Dimensiones:** 130–190 m; manga 18–25 m. **Calado:** 5,5–8 m.
- **Propulsión:** máquinas alternativas o turbinas de vapor según casco; carbón o petróleo por lote. **Potencia:** 15.000–40.000 shp. **Ejes:** 2–4.
- **Velocidad:** 18–25 nudos. **Alcance:** 4.000–7.000 mn a 10 nudos.
- **Blindaje:** 25–75 mm local; protección de pañoles y máquinas antes que cubierta de vuelo pesada.
- **Armamento:** 4–8 × 100–152 mm y piezas antiaéreas iniciales de 37–76 mm.
- **Aeronaves:** 6–24 hidroaviones o aviones ligeros; grúas, hangares, talleres y combustible limitados.
- **Dotación:** 400–850 más personal aéreo.

#### 10. Acorazado rápido entre guerras (1919–1938)

- **Desplazamiento:** 25.000–40.000 t. **Dimensiones:** eslora 210–245 m; manga 28–34 m. **Calado:** 9–11 m.
- **Propulsión:** turbinas de vapor con calderas de petróleo; transmisión a cuatro ejes. **Potencia:** 70.000–130.000 shp. **Ejes:** 4.
- **Velocidad:** 25–30 nudos de prueba. **Alcance:** 7.000–11.000 mn a 15 nudos.
- **Blindaje:** cinturón 280–380 mm; torres 300–400 mm; cubierta 100–160 mm; protección antitorpedo mejorada.
- **Armamento:** 8–12 × 356–406 mm; 8–16 × 127–152 mm; batería antiaérea de 20–102 mm por lote; dirección óptica y radio, radar solo en modernizaciones tardías conforme a la cronología.
- **Dotación:** 1.300–2.000.

#### 11. Portaaviones de flota entre guerras (1919–1938)

- **Desplazamiento:** 15.000–30.000 t. **Dimensiones:** eslora 190–240 m; manga 25–33 m. **Calado:** 7–9 m.
- **Propulsión:** turbinas de vapor y calderas de petróleo; **potencia** 45.000–100.000 shp; **ejes** 4.
- **Velocidad:** 25–32 nudos. **Alcance:** 7.000–11.000 mn a 15 nudos.
- **Blindaje:** cinturón 25–100 mm; cubierta de vuelo 25–75 mm o sin blindaje integral en diseños que priorizan aeronaves y autonomía.
- **Armamento:** 8–12 × 100–127 mm y piezas antiaéreas de 20–40 mm conforme a la fecha.
- **Ala aérea:** 35–75 aeronaves entre cazas, exploradores, bombarderos y torpederos; configuración dependiente de hangares y ascensores.
- **Dotación:** 900–1.600 navales, más 400–900 de aviación y servicios embarcados.

#### 12. Cruceros de los años veinte y treinta

- **Desplazamiento:** crucero ligero 6.000–10.000 t; pesado 9.000–15.000 t. **Dimensiones:** eslora 150–200 m; manga 17–23 m. **Calado:** 6–8,5 m.
- **Propulsión:** turbinas de vapor, calderas de petróleo, cuatro ejes. **Potencia:** 50.000–110.000 shp.
- **Velocidad:** 30–35 nudos. **Alcance:** 6.000–10.000 mn a 15 nudos.
- **Blindaje:** ligero 50–120 mm de cinturón; pesado 100–200 mm; cubiertas 40–100 mm.
- **Armamento:** ligero 8–12 × 152 mm; pesado 6–9 × 203 mm; secundario/antiaéreo de 76–127 mm; torpedos y 1–3 hidroaviones de exploración en unidades aptas.
- **Dotación:** 600–1.100.

#### 13. Destructor de escuadra entre guerras (1919–1938)

- **Desplazamiento:** 1.500–3.000 t. **Dimensiones:** eslora 100–125 m; manga 10–13 m. **Calado:** 3,5–5 m.
- **Propulsión:** turbinas de vapor y calderas de petróleo; **potencia** 35.000–70.000 shp; **ejes** 2.
- **Velocidad:** 32–38 nudos. **Alcance:** 3.000–6.000 mn a 15 nudos.
- **Blindaje:** sin cinturón; placas locales de 10–25 mm en puestos de mando o pañoles tardíos.
- **Armamento:** 4–8 × 100–127 mm; 4–10 tubos de torpedo de 533 mm; armas antiaéreas ligeras; sonar, hidrofonos y cargas de profundidad en unidades antisubmarinas.
- **Dotación:** 130–250.

#### 14. Submarino oceánico diésel-eléctrico entre guerras (1919–1938)

- **Desplazamiento:** 800–2.500 t en superficie. **Dimensiones:** 65–100 m; manga 6–9 m. **Calado:** 4–6 m.
- **Propulsión:** dos diésel y motores eléctricos/baterías; **potencia** diésel 3.000–8.000 shp y eléctrica 1.000–2.500 shp; **ejes** 2.
- **Velocidad:** 16–22 nudos en superficie; 8–10 sumergido. **Alcance:** 8.000–14.000 mn a 10 nudos en superficie; en inmersión, alcance mucho menor y dependiente del régimen eléctrico.
- **Blindaje:** casco resistente, sin blindaje naval convencional.
- **Armamento:** 6–10 tubos de 533 mm; 1 cañón de cubierta en algunas unidades; minas en variantes especializadas.
- **Dotación:** 45–80.

#### 15. Acorazado rápido de guerra (1939–1945)

- **Desplazamiento:** 35.000–55.000 t a plena carga. **Dimensiones:** eslora 230–270 m; manga 32–38 m. **Calado:** 9,5–11,5 m.
- **Propulsión:** turbinas de vapor con calderas de petróleo; **potencia** 120.000–180.000 shp; **ejes** 4.
- **Velocidad:** 27–32 nudos de prueba. **Alcance:** 10.000–15.000 mn a 15 nudos.
- **Blindaje:** cinturón 300–410 mm; torres 330–450 mm; cubierta 120–200 mm; protección antitorpedo en capas.
- **Armamento:** 8–12 × 356–406 mm; 8–20 × 127–152 mm de doble propósito; baterías antiaéreas de 20–40 mm; radar de búsqueda y dirección de tiro en unidades y lotes tardíos.
- **Dotación:** 1.800–2.700.

#### 16. Portaaviones de flota de guerra (1939–1945)

- **Desplazamiento:** 25.000–45.000 t a plena carga. **Dimensiones:** eslora 240–280 m; manga 32–40 m. **Calado:** 8–10 m.
- **Propulsión:** turbinas de vapor y calderas de petróleo; **potencia** 120.000–200.000 shp; **ejes** 4.
- **Velocidad:** 30–34 nudos de prueba. **Alcance:** 10.000–15.000 mn a 15 nudos.
- **Blindaje:** cinturón 100–200 mm; cubierta de vuelo 30–100 mm según diseño; protección adicional de hangares, pañoles y combustible aeronáutico.
- **Armamento:** 8–16 × 100–127 mm; baterías de 40 mm y 20 mm, con dirección de tiro; radar de alerta, control de caza y enlaces navales por lote.
- **Ala aérea:** 60–100 aeronaves en configuración teórica; normalmente menos disponibles simultáneamente durante operaciones prolongadas. Cazas, exploración, bombardeo y ataque torpedero.
- **Dotación:** 1.800–2.800 navales y 700–1.300 de aviación/servicios; total aproximado 2.500–4.100.

#### 17. Portaaviones de escolta (1941–1945)

- **Función:** convoyes, cobertura antisubmarina, transporte de aeronaves y apoyo de desembarcos; conversión de mercante o casco simplificado.
- **Desplazamiento:** 8.000–20.000 t. **Dimensiones:** eslora 130–190 m; manga 20–28 m. **Calado:** 6–8 m.
- **Propulsión:** máquina alternativa, turbina de vapor sencilla o diésel según casco; **potencia** 8.000–30.000 shp; **ejes** 1–2.
- **Velocidad:** 16–25 nudos. **Alcance:** 6.000–12.000 mn a 12 nudos.
- **Blindaje:** ninguno o protección local ligera de 10–50 mm.
- **Armamento:** 2–8 × 76–127 mm; 20–40 mm antiaéreos; armas antisubmarinas ligeras cuando opera como escolta.
- **Ala aérea:** 20–40 aeronaves, principalmente caza, patrulla y antisubmarina.
- **Dotación:** 500–1.200 navales y personal aéreo.

#### 18. Crucero de guerra (1939–1945)

- **Desplazamiento:** ligero 8.000–13.000 t; pesado 10.000–18.000 t. **Dimensiones:** eslora 170–220 m; manga 19–26 m. **Calado:** 6,5–9 m.
- **Propulsión:** turbinas de vapor con petróleo; **potencia** 70.000–130.000 shp; **ejes** 4.
- **Velocidad:** 30–35 nudos. **Alcance:** 6.000–10.000 mn a 15 nudos.
- **Blindaje:** cinturón 80–200 mm, cubiertas 40–120 mm y protección local de torres.
- **Armamento:** crucero ligero 8–12 × 152 mm; pesado 6–10 × 203 mm; ambos con 100–127 mm de doble propósito, armas antiaéreas ligeras, radares por lote y sonar en unidades de escolta.
- **Dotación:** 700–1.300.

#### 19. Destructor y escolta antisubmarina (1939–1945)

**Destructor de flota**

- **Desplazamiento:** 1.800–3.500 t. **Dimensiones:** 110–135 m de eslora; manga 11–14 m. **Calado:** 3,5–5 m.
- **Propulsión:** turbinas de vapor y petróleo; **potencia** 45.000–80.000 shp; **ejes** 2.
- **Velocidad:** 30–38 nudos. **Alcance:** 3.500–6.000 mn a 15 nudos.
- **Blindaje:** no significativo; protección local de pañoles y puestos.
- **Armamento:** 4–8 × 100–127 mm; 6–10 tubos de 533 mm; 20–40 mm antiaéreos; sonar, cargas de profundidad y morteros antisubmarinos según lote.
- **Dotación:** 180–330.

**Escolta oceánica antisubmarina**

- **Desplazamiento:** 800–2.000 t. **Dimensiones:** 85–120 m; manga 10–15 m. **Calado:** 3–5 m.
- **Propulsión:** diésel, turbina de vapor económica o combinación; **potencia** 8.000–25.000 shp; **ejes** 1–2.
- **Velocidad:** 18–27 nudos. **Alcance:** 4.000–8.000 mn a 12 nudos.
- **Blindaje:** ninguno o protección local ligera.
- **Armamento:** 2–4 × 76–127 mm; 20–40 mm antiaéreos; sonar; morteros antisubmarinos y cargas de profundidad; normalmente sin batería de torpedos pesada.
- **Dotación:** 90–200.

#### 20. Submarino oceánico de guerra (1939–1945)

- **Desplazamiento:** 1.200–2.500 t en superficie; sumergido, aproximadamente 1.700–3.200 t según casco. **Dimensiones:** eslora 75–100 m; manga 7–9 m. **Calado:** 4,5–6 m.
- **Propulsión:** dos diésel en superficie, motores eléctricos y baterías sumergido; **potencia** diésel 4.000–9.000 shp; eléctrica 1.500–3.000 shp; **ejes** 2.
- **Velocidad:** 17–22 nudos en superficie; 7–10 sumergido. **Alcance:** 8.000–14.000 mn a 10 nudos en superficie; patrulla sumergida limitada por baterías y velocidad.
- **Blindaje:** casco resistente, no blindaje contra proyectiles; compartimentación y control de inundación.
- **Armamento:** 6–10 tubos de 533 mm; 12–24 torpedos entre tubos y reserva según diseño; cañón de cubierta de 76–127 mm en ciertos lotes; minas en variantes.
- **Dotación:** 50–85.

#### 21. Auxiliares, petroleros, talleres y transportes de desembarco (1939–1945)

- **Desplazamiento:** 2.000–20.000 t por misión. **Dimensiones:** eslora 90–190 m; manga 14–28 m. **Calado:** 4–9 m cargados.
- **Propulsión:** diésel o vapor; turbinas solo en transportes rápidos. **Potencia:** 5.000–30.000 shp. **Ejes:** 1–2.
- **Velocidad:** 12–22 nudos. **Alcance:** 5.000–12.000 mn a 12 nudos.
- **Blindaje:** ninguno; compartimentación, protección contra incendios y daños por torpedo en buques de mayor valor.
- **Armamento:** 2–8 × 76–127 mm y armas antiaéreas ligeras; el armamento no convierte al transporte en buque de línea.
- **Dotación:** 100–400 navales, más personal técnico, sanitario, de carga o tropas transportadas.
- **Papel en combate:** sostener combustible, munición, víveres, reparación, evacuación médica, desembarco y recuperación de buques.

## Reglas de interpretación

- Potencia, dimensiones, calado, blindaje, armamento, dotación, velocidad y alcance son bandas de diseño, no máximos simultáneos garantizados.
- La velocidad suele representar pruebas; la autonomía depende del combustible, carga, casco, estado de mar y velocidad mantenida.
- La turbina no se instala por modernización automática en los cascos de 1875. Su adopción exige nuevos diseños o reconstrucciones específicamente aprobadas.
- Radar, sonar, aviación, radio y armas se introducen según su propia cronología y por clase/lote.
- No se deducen inventarios a partir de perfiles técnicos.

## Referencias

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/03_Armada/Armada|Armada]]
- [[12_Militar/03_Armada/Armada 1875/Índice de la Armada de 1875|Armada 1875]]
- [[12_Militar/Índice Militar|Índice Militar]]
- [[11_Ciencia y Tecnologia/Turbinas de vapor y máquinas navales|Turbinas de vapor y máquinas navales]]
- [[11_Ciencia y Tecnologia/Radar y Sensores|Radar y Sensores]]
- [[00_Canon/Integraciones V16/Actualización acumulativa 111v — Radar y sensores|Actualización acumulativa 111v]]
