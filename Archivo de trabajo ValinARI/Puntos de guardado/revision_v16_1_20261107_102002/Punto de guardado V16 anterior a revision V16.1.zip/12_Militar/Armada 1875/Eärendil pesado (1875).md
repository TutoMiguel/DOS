---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Eärendil pesado (1875)

- Tipo: acorazado de escuadra.
- Unidades: 4.
- Desplazamiento: 6.500–7.500 t.
- Eslora: 100–112 m.
- Manga: 16–18 m.
- Velocidad máxima: 13–15 nudos.
- Dotación: 420–550 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 4 × 229–254 mm; 6–8 × 120–140 mm; piezas de 37–76 mm.
- Protección: cinturón 220–300 mm; torres 180–250 mm; cubierta 45–70 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
