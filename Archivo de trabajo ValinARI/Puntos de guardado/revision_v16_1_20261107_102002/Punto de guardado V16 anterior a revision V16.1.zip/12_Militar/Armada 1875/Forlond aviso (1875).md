---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Forlond aviso (1875)

- Tipo: aviso costero.
- Unidades: 12.
- Desplazamiento: 400–800 t.
- Eslora: 35–50 m.
- Manga: 6–8 m.
- Velocidad máxima: 15–19 nudos.
- Dotación: 40–80 personas.
- Propulsión: vapor de carbón; máquinas alternativas.
- Armamento: 2–4 × 57–100 mm.
- Protección: protección ligera localizada.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
