---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Alqualondë (1875)

- Tipo: corbeta de enlace.
- Unidades: 8.
- Desplazamiento: 1.200–1.800 t.
- Eslora: 60–75 m.
- Manga: 9–11 m.
- Velocidad máxima: 13–16 nudos.
- Dotación: 120–190 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 6–10 × 100–127 mm.
- Protección: escudos 20–35 mm; protección localizada de máquinas.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
