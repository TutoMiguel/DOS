---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Rómenna aviso (1875)

- Tipo: aviso oceánico.
- Unidades: 12.
- Desplazamiento: 700–1.200 t.
- Eslora: 45–60 m.
- Manga: 7–9 m.
- Velocidad máxima: 16–20 nudos.
- Dotación: 60–110 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 2–6 × 76–120 mm.
- Protección: escudos 10–20 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
