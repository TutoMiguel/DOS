---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Transportes armados (1875)

- Tipo: transporte y desembarco.
- Unidades: 14.
- Desplazamiento: 1.000–3.500 t.
- Eslora: 55–100 m.
- Manga: 9–14 m.
- Velocidad máxima: 10–14 nudos.
- Dotación: 70–180 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 2–8 × 76–120 mm.
- Protección: protección estructural.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
