---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Pelargir (1875)

- Tipo: corbeta oceánica.
- Unidades: 12.
- Desplazamiento: 1.800–2.500 t.
- Eslora: 70–85 m.
- Manga: 10–12 m.
- Velocidad máxima: 13–16 nudos.
- Dotación: 160–240 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 8–12 × 100–152 mm.
- Protección: cubierta reforzada; escudos 20–40 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
