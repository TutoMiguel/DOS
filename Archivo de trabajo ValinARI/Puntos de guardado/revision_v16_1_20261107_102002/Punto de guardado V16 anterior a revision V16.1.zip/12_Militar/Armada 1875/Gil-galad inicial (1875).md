---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Gil-galad inicial (1875)

- Tipo: acorazado de defensa oceánica.
- Unidades: 6.
- Desplazamiento: 5.500–6.800 t.
- Eslora: 92–105 m.
- Manga: 15–17 m.
- Velocidad máxima: 12–15 nudos.
- Dotación: 360–480 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 2–4 × 203–254 mm; 6 × 100–127 mm; piezas de 37–57 mm.
- Protección: cinturón 180–250 mm; torres 160–220 mm; cubierta 40–60 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
