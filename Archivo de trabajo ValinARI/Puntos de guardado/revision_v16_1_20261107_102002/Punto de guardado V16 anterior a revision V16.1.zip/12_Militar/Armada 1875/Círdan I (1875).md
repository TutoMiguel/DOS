---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Círdan I (1875)

- Tipo: acorazado oceánico.
- Unidades: 6.
- Desplazamiento: 7.000–8.500 t.
- Eslora: 105–120 m.
- Manga: 17–19 m.
- Velocidad máxima: 14–16 nudos.
- Dotación: 480–620 personas.
- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.
- Armamento: 4 × 254–305 mm; 6–10 × 120–152 mm; piezas de 37–76 mm.
- Protección: cinturón 250–350 mm; torres/barbetas 200–300 mm; cubierta 50–75 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
