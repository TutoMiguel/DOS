---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Systreyjar (1875)

- Tipo: corbeta ligera.
- Unidades: 8.
- Desplazamiento: 900–1.400 t.
- Eslora: 50–65 m.
- Manga: 8–10 m.
- Velocidad máxima: 14–17 nudos.
- Dotación: 90–150 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 4–8 × 76–120 mm.
- Protección: escudos 15–30 mm; cubierta reforzada.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
