---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Calasir (1875)

- Tipo: cañonera litoral.
- Unidades: 12.
- Desplazamiento: 250–450 t.
- Eslora: 28–40 m.
- Manga: 5–7 m.
- Velocidad máxima: 14–18 nudos.
- Dotación: 30–65 personas.
- Propulsión: vapor de carbón; máquinas alternativas.
- Armamento: 2–4 × 57–100 mm; piezas ligeras de 37–47 mm.
- Protección: cubierta 15–25 mm; escudos ligeros.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
