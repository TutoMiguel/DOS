---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Harlond fluvial (1875)

- Tipo: cañonera fluvial.
- Unidades: 16.
- Desplazamiento: 300–600 t.
- Eslora: 30–45 m.
- Manga: 6–8 m.
- Velocidad máxima: 9–13 nudos.
- Dotación: 40–80 personas.
- Propulsión: vapor de carbón; máquinas alternativas; hélices protegidas o rueda según variante.
- Armamento: 1–2 × 76–120 mm; secundarias de 37–57 mm.
- Protección: escudos 20–40 mm; protección localizada de calderas.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
