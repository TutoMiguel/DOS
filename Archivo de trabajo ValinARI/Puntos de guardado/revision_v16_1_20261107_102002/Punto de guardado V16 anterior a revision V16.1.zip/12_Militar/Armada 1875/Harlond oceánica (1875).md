---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Harlond oceánica (1875)

- Tipo: cañonera oceánica.
- Unidades: 14.
- Desplazamiento: 700–1.000 t.
- Eslora: 45–60 m.
- Manga: 8–10 m.
- Velocidad máxima: 13–16 nudos.
- Dotación: 70–120 personas.
- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.
- Armamento: 2–4 × 120–152 mm; secundarias de 37–57 mm.
- Protección: cubierta 25–40 mm; escudos 40–60 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
