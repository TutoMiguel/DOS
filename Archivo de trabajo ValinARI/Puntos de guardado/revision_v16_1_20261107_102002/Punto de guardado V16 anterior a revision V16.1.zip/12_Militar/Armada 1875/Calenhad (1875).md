---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Calenhad (1875)

- Tipo: torpedero ligero.
- Unidades: 12.
- Desplazamiento: 80–150 t.
- Eslora: 24–32 m.
- Manga: 3–5 m.
- Velocidad máxima: 18–22 nudos.
- Dotación: 15–30 personas.
- Propulsión: vapor de carbón; máquinas alternativas de alta presión; prioridad de potencia y bajo peso.
- Armamento: 1–2 tubos de 356 mm; 1 × 37–47 mm.
- Protección: sin blindaje significativo.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
