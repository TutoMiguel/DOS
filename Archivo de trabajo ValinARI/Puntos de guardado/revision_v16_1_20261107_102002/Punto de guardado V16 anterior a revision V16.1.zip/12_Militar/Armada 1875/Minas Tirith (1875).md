---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Minas Tirith (1875)

- Tipo: monitor litoral.
- Unidades: 4.
- Desplazamiento: 2.500–3.500 t.
- Eslora: 65–80 m.
- Manga: 13–15 m.
- Velocidad máxima: 9–11 nudos.
- Dotación: 150–220 personas.
- Propulsión: vapor de carbón; máquinas alternativas.
- Armamento: 2 × 203–254 mm; 4–6 × 76–100 mm.
- Protección: torres 160–250 mm; cubierta 35–50 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
