---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Eärendil (1875)

- Tipo: crucero protegido.
- Unidades: 8.
- Desplazamiento: 4.500–6.000 t.
- Eslora: 95–115 m.
- Manga: 13–16 m.
- Velocidad máxima: 17–19 nudos.
- Dotación: 300–420 personas.
- Propulsión: vapor de carbón; máquinas alternativas compound; dos ejes y vela auxiliar.
- Armamento: 8–12 × 120–152 mm; piezas de 37–76 mm; 2–4 tubos de 356–381 mm.
- Protección: cubierta y escudos 40–60 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
