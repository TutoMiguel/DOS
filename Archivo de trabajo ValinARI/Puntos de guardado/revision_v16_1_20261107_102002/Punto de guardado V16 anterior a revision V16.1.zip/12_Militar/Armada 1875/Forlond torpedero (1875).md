---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Forlond torpedero (1875)

- Tipo: torpedero rápido.
- Unidades: 12.
- Desplazamiento: 120–250 t.
- Eslora: 30–40 m.
- Manga: 4–6 m.
- Velocidad máxima: 20–24 nudos.
- Dotación: 25–45 personas.
- Propulsión: vapor de carbón; máquinas alternativas de alta presión; prioridad de potencia y bajo peso.
- Armamento: 2 tubos de 356–381 mm; 1–2 × 37–57 mm.
- Protección: sin blindaje significativo.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
