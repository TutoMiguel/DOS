---
tipo: ficha temática
canon: V16
estado: vigente
periodo: "1875"
actualizado: 2026-11-07
---
# Rómenna crucero (1875)

- Tipo: crucero de estación.
- Unidades: 10.
- Desplazamiento: 2.500–4.000 t.
- Eslora: 80–100 m.
- Manga: 11–14 m.
- Velocidad máxima: 15–18 nudos.
- Dotación: 180–300 personas.
- Propulsión: vapor de carbón; máquinas alternativas; vela auxiliar en las variantes oceánicas.
- Armamento: 6–10 × 120–140 mm; piezas de 37–57 mm.
- Protección: cubierta 25–45 mm; escudos 30–50 mm.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología maestra]]
- [[12_Militar/Armada 1875/Índice de la Armada de 1875]]
