---
tipo: ficha militar
canon: V16
periodo_principal: 1000–500 a. C.
periodo_de_desarrollo: 1000–500 a. C.
estado_canon: V16 vigente
---
## Periodización

- **1000–990 a. C.:** defensas de clan, milicias y guerras privadas.
- **990–550 a. C.:** defensa pactista y coordinación entre Casas.
- **550–500 a. C.:** consolidación militar de la Corona Telcontar.
- **500 a. C.–1000 d. C.:** expansión de puertos, convoyes y fortalezas.
- **1000–1800:** profesionalización progresiva.
- **1800–1956:** modernización industrial, naval y logística.
- **1956–2026:** fuerzas armadas modernas, aviación, armada oceánica y OceanNet.

## Casas participantes en las campañas militares, 1000–500 a. C.

La participación de las Casas se define por función y territorio. Las Casas Mayores proporcionan mando, recursos y contingentes; las Casas Menores actúan como capitanías, exploradoras, comerciantes, cartógrafas y protectoras de convoyes. Las Casas Vasallas participan bajo la autoridad de su Casa tutelar y no reciben mando independiente salvo delegación expresa.

### Guerra de los Graneros del Este, 1000–994 a. C.

**Casas Mayores:** Esgal, Calenor, Calenhad, Annúminas y Minas Anor.  
**Casas Menores:** Tumladen, Lindor, Maethor y Nimrodel.  
**Funciones:** defensa de graneros, transporte fluvial, registro de reservas y movilización agrícola.

### Conflicto del Øresund, 997–990 a. C.

**Casas Mayores:** Círdan, Pelargir, Harlond, Teleri y Alqualondë.  
**Casas Menores:** Falastur, Eärond, Aerandir y Círdanir.  
**Funciones:** patrulla del estrecho, escolta mercante, control de atraques y negociación con Dinamarca.

### Campaña de Forostar, 990–985 a. C.

**Casas Mayores:** Annúminas, Fornost, Noldor, Minas Anor y Vanyar.  
**Casas Menores:** Erestor, Meneldir, Gwindor y Aglaran.  
**Funciones:** imposición de arbitrajes, custodia de archivos, protección de santuarios y coordinación de contingentes.

### Guerra de las Rutas Noruegas, 965–950 a. C.

**Casas Mayores:** Mithlond, Harlond, Alqualondë, Eressëa Menel y Teleri.  
**Casas Menores:** Aerandir, Falathar, Voronwë y Thoron.  
**Funciones:** navegación de fiordos, intercambio de madera y hierro, reconocimiento costero y pactos con comunidades noruegas.

### Campaña de Åhus y las Marismas, 930–920 a. C.

**Casas Mayores:** Esgal, Calenhad, Eldalondë y Calenor.  
**Casas Menores:** Tumladen, Nimrodel, Duilin y Belegor.  
**Funciones:** diques, canales, salinas, agricultura, defensa fluvial y protección de obras hidráulicas.

### Guerra de las Tres Costas, 900–885 a. C.

**Casas Mayores:** Pelargir, Mithlond, Teleri, Alqualondë y Taur-en-Mor.  
**Casas Menores:** Ostor, Círdanir, Falastur, Eärond y Baranor.  
**Funciones:** convoyes, bloqueo, diplomacia portuaria y protección del comercio entre Báltico, Kattegat y mar del Norte.

### Campaña de las Islas del Ámbar, 860–845 a. C.

**Casas Mayores:** Eressëa Menel, Alqualondë, Eryn Lasgalen, Taur-en-Mor y Vanyar.  
**Casas Menores:** Aerandir, Falathar, Voronwë, Elentir y Celepharn.  
**Funciones:** cartografía, exploración insular, traducción, factorías temporales y protección de convoyes.

### Guerra de los Puertos Neutrales, 780–765 a. C.

**Casas Mayores:** Harnost, Harlond, Mithlond, Vanyar y Pelargir.  
**Casas Menores:** Baranor, Celepharn, Hallas, Aglaran y Lindor.  
**Funciones:** defensa de mercados, neutralidad portuaria, crédito comercial, mediación y sanciones económicas.

### Campaña de las Rutas Atlánticas, 720–700 a. C.

**Casas Mayores:** Eressëa Menel, Alqualondë, Teleri, Eldalondë y Círdan.  
**Casas Menores:** Aerandir, Falathar, Voronwë, Thoron y Elentir.  
**Funciones:** exploración, astronomía, señales costeras, depósitos de agua, rescate y retorno seguro.

### Crisis de las Minas y los Arsenales, 690–675 a. C.

**Casas Mayores:** Noldor, Barad Calen, Calenor, Minas Anor y Esgal.  
**Casas Menores:** Angren, Gwindor, Erestor, Maethor y Ostor.  
**Funciones:** hierro, carbón, talleres, armas, herrajes navales, protección de artesanos y arbitraje de reservas.

### Guerra de los Graneros del Norte, 640–625 a. C.

**Casas Mayores:** Annúminas, Calenhad, Rhunost, Esgal y Eldalondë.  
**Casas Menores:** Tumladen, Nimrodel, Lindor, Meneldir y Belegor.  
**Funciones:** transporte de cereal, pesca seca, protección de graneros, convoyes y rutas entre Escania y Noruega.

### Guerra de la Sucesión Occidental, 590–560 a. C.

**Casa Real en formación:** Telcontar.  
**Casas Mayores:** Annúminas, Fornost, Círdan, Harlond, Harnost, Pelargir y Eressëa Menel.  
**Casas Menores:** Falastur, Círdanir, Elentir, Ostor, Meneldir y Aerandir.  
**Funciones:** control de Helsingborg, archivos genealógicos, arsenales, graneros, rutas del Øresund, mediación y apoyo a la sucesión.

Las Casas Vasallas participan como contingentes dependientes de estas Casas Mayores. Su aportación se concentra en guardias de puerto, infantería local, escolta de convoyes, administración de graneros, talleres y defensa de santuarios. Ninguna Casa Vasalla altera por sí sola el equilibrio constitucional de las 24 Casas Mayores.

## Contexto institucional y sostenimiento

El contenido corresponde a 1000–500 a. C. Las contribuciones de Casas, milicias, graneros y puertos se interpretan con los medios de esa etapa. COFOVAL, banca industrial, acero naval y fuerzas aéreas pertenecen a siglos posteriores y no financian estas campañas antiguas.

## Referencias relacionadas

- [[00_Canon/Canon V16 Maestro|Canon V16 Maestro]]
- [[01_Cronologia/Cronología Territorial V16|Cronología Territorial V16]]
- [[12_Militar/Organización militar 1000-500 aC|Organización militar valinari]]
- [[09_Politica/Índice de Casas Nobles|Índice de Casas Nobles]]
- [[12_Militar/Índice Militar]]
- [[08_Economia/Sistema Valinari de Fomento y Desarrollo]]
- [[09_Politica/Evolución económica e institucional de las Casas]]
